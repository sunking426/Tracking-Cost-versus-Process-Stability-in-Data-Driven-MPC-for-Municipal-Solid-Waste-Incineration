"""Paired reports for a restricted two-input Ridge model-control pilot.

All policy trajectories are simulated. Logged future plant outcomes are not
counterfactual truth for these policies. Cross-model ranges are sensitivity
checks, not independent plant replications.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np

from .control import TRACKING_SCALES
from .numeric_baselines import sha256, write_json
from .visual_diagnostics_statistics import DAY_NS, paired_block_interval


MODELS=('full','early','middle','late','pooled_matched')
POLICIES=('hold','linear_bc','grid_mpc')
METRICS=('return','temperature_tracking_mae','pressure_tracking_mae',
         'steam_tracking_mae','oxygen_band_distance','violation_fraction')


def archive(path):
    with np.load(path,allow_pickle=False) as raw:return {k:raw[k].copy() for k in raw.files}


def episode_metrics(row):
    reward=np.asarray(row['reward'],dtype=np.float64)
    tracking=np.asarray(row['tracking_cost'],dtype=np.float64)
    oxygen=np.asarray(row['oxygen_cost'],dtype=np.float64)
    violation=np.asarray(row['violation'],dtype=np.float64)
    if (reward.ndim!=2 or reward.shape[1]!=10 or tracking.shape!=(*reward.shape,3)
            or oxygen.shape!=reward.shape or violation.shape!=reward.shape
            or not all(np.isfinite(v).all() for v in (reward,tracking,oxygen,violation))
            or np.any(reward>1e-7)):
        raise ValueError('finite negative rewards and aligned ten-step canonical costs required')
    return np.column_stack((reward.sum(1),tracking.mean(1)*np.asarray(TRACKING_SCALES[:3]),
                            oxygen.mean(1)*float(TRACKING_SCALES[3]),violation.mean(1)))


def improvements(reference,candidate):
    if reference.shape!=candidate.shape or reference.ndim!=2 or reference.shape[1]!=6:
        raise ValueError('aligned six-endpoint episode metrics required')
    difference=reference-candidate
    difference[:,0]*=-1
    return difference[None]


def csv_write(path,rows):
    with Path(path).open('w',newline='') as stream:
        w=csv.DictWriter(stream,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def load_study(folder):
    from .ridge_control_probe import verify
    root=Path(folder).resolve()
    cfg=json.loads((root/'config.json').read_text())
    frozen=json.loads((root/'selection_frozen.json').read_text())
    verify(frozen['files'],root);verify(frozen['source_code_hashes'])
    verify(json.loads((root/'input_hashes.json').read_text()))
    manifest=json.loads((root/'run_manifest.json').read_text())
    if (manifest['status']!='complete'
            or manifest['source_selection_sha256']!=sha256(root/'selection.json')
            or manifest['source_selection_frozen_sha256']!=sha256(root/'selection_frozen.json')
            or manifest['planner_model']!='full' or manifest['trajectories_dropped']!=0
            or manifest['predictions_clipped'] or manifest['rl_trained']):
        raise ValueError('completed fixed-planner control pilot required')
    rows={}
    for item in manifest['files']:
        if sha256(root/item['path'])!=item['sha256']:raise ValueError('trajectory hash mismatch')
        key=(item['split'],item['model_id'],item['policy'])
        if key in rows:raise ValueError('duplicate trajectory identity')
        row=archive(root/item['path']);n=len(row['indices'])
        if row['pred_cv'].shape!=(n,10,9) or row['executed_action'].shape!=(n,10,8):
            raise ValueError('trajectory shapes differ from fixed pilot')
        if np.any(np.abs(row['executed_action'][:,:, [1,2,4,5,6,7]])>1e-12):
            raise ValueError('a non-admitted action channel was changed')
        if np.any(np.abs(row['executed_action'])>.1+1e-10):
            raise ValueError('pilot action budget exceeded')
        episode_metrics(row);rows[key]=row
    expected={(s,m,p) for s in ('val','test') for m in MODELS for p in POLICIES}
    if set(rows)!=expected:raise ValueError('all thirty trajectories required')
    for split in ('val','test'):
        base=rows[split,'full','hold']
        for model in MODELS:
            for policy in POLICIES:
                for key in ('indices','time_ns','truth_cv'):
                    if not np.array_equal(rows[split,model,policy][key],base[key]):
                        raise ValueError('initial rows or factual record changed between policies/models')
    return root,cfg,rows


def summarize(folder):
    root,cfg,rows=load_study(folder)
    metrics={k:episode_metrics(v) for k,v in rows.items()}
    table=[];contrasts=[];detail={}
    for (split,model,policy),value in metrics.items():
        row=rows[split,model,policy]
        table.append({'split':split,'model':model,'policy':policy,'episodes':len(value),
            **dict(zip(METRICS,value.mean(0).tolist())),
            'nonzero_action_fraction':float(np.any(np.abs(row['executed_action'])>1e-10,axis=-1).mean()),
            'blocked_proposal_fraction':float(np.mean(row['blocked_nonzero'])),
            'zero_action_unsupported_fraction':float(np.mean(row['zero_action_unsupported'])),
            'mean_movement_cost':float(np.mean(row['movement_cost']))})
    for split in ('val','test'):
        for model in MODELS:
            for reference,candidate in [('hold','grid_mpc'),('hold','linear_bc'),('linear_bc','grid_mpc')]:
                delta=improvements(metrics[split,model,reference],metrics[split,model,candidate])
                days=rows[split,model,reference]['time_ns']//DAY_NS
                result=paired_block_interval(delta,days,draws=10000,seed=20261106,confidence_level=.95)
                key='/'.join((split,model,candidate+'_vs_'+reference));detail[key]=result
                for j,name in enumerate(METRICS):
                    contrasts.append({'split':split,'model':model,'candidate':candidate,'reference':reference,
                        'endpoint':name,'difference':float(result['difference'][j]),
                        'ci_lower':float(result['ci_lower'][j]),'ci_upper':float(result['ci_upper'][j])})
    cross=[detail['test/'+model+'/grid_mpc_vs_hold'] for model in MODELS[1:]]
    result={'status':'complete','metrics':table,'contrasts':detail,
        'primary':'Grid MPC versus hold: report each of four non-planner evaluation models separately.',
        'cross_model_mpc_minus_hold_mean_returns':{model:detail['test/'+model+'/grid_mpc_vs_hold']['difference'][0] for model in MODELS[1:]},
        'worst_cross_model_mean_return_gain':min(r['difference'][0] for r in cross),
        'all_cross_model_mean_gains_positive':all(r['difference'][0]>0 for r in cross),
        'all_cross_model_return_interval_lowers_positive':all(r['ci_lower'][0]>0 for r in cross),
        'source_run_manifest_sha256':sha256(root/'run_manifest.json'),
        'limits':['All returns and physical trajectories are outputs of learned Ridge models, not observed intervention outcomes.',
                  'Only primary-air and induced-draft fan frequency can change; other six MV levels remain at their initial values.',
                  'Linear BC is a constrained linear imitation baseline, not a tuned neural BC or the old GRU actor.',
                  'MPC tests nine one-step displacement-and-hold plans and replans each minute. It is not an unrestricted optimal-control solver.',
                  'The full model is always the planner. Its own evaluation is not an independent check; the other models share original training data.',
                  'Whole-day intervals are exploratory and conditional on fixed models; no multiplicity correction and no new blind test period.',
                  'Unsupported nonzero proposals are rejected. Zero remains available as a numerical fallback, not a certified safe action.',
                  'Initial joint support at each decision does not certify the full proposed horizon, physical actuator resolution, causality or deployment safety.',
                  'Reward gains can trade temperature/pressure/steam/oxygen tracking, movement and empirical-envelope violations. All components are retained.']}
    folder=root/'statistics';folder.mkdir(exist_ok=True)
    csv_write(folder/'policy_metrics.csv',table);csv_write(folder/'comparisons.csv',contrasts)
    write_json(folder/'summary.json',result)
    return result


def render(root,result):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,ax=plt.subplots(figsize=(10,5))
    for offset,candidate,color in [(-.12,'linear_bc','#ff7f0e'),(.12,'grid_mpc','#1f77b4')]:
        vals=[result['contrasts']['test/'+m+'/'+candidate+'_vs_hold'] for m in MODELS]
        center=np.asarray([v['difference'][0] for v in vals])
        low=np.asarray([v['ci_lower'][0] for v in vals]);high=np.asarray([v['ci_upper'][0] for v in vals])
        for i in range(5):
            ax.plot([i+offset,i+offset],[low[i],high[i]],color=color,lw=2)
        ax.scatter(np.arange(5)+offset,center,color=color,label=candidate,zorder=3)
    ax.axhline(0,color='black',lw=1,ls='--');ax.grid(alpha=.2)
    ax.set_xticks(np.arange(5),['Full (planner)','Early','Middle','Late','Pooled matched'])
    ax.set_ylabel('Ten-step return difference versus hold')
    ax.set_title('Restricted two-input control: model-specific exploratory 95% intervals',pad=15)
    ax.legend(loc='best');fig.tight_layout()
    folder=root/'figures';folder.mkdir(exist_ok=True)
    for ext in ('png','svg'):fig.savefig(folder/('return_comparisons.'+ext),dpi=160)
    plt.close(fig)


def build_report(folder):
    root=Path(folder).resolve();result=summarize(root);render(root,result)
    lines=['Restricted Ridge control pilot','',result['primary'],
        'Model | policy | mean ten-step return | empirical violation fraction']
    for row in result['metrics']:
        if row['split']=='test':lines.append(f"{row['model']} | {row['policy']} | {row['return']:.9f} | {row['violation_fraction']:.9f}")
    lines+=['','Grid MPC minus hold on cross-model evaluation:']
    for m in MODELS[1:]:
        v=result['contrasts']['test/'+m+'/grid_mpc_vs_hold']
        lines.append(f"{m}: {v['difference'][0]:.9f} [{v['ci_lower'][0]:.9f}, {v['ci_upper'][0]:.9f}]")
    lines+=['',*result['limits']];(root/'RESULTS.txt').write_text('\n'.join(lines)+'\n')
    files=[*sorted((root/'statistics').glob('*')),*sorted((root/'figures').glob('*')),root/'RESULTS.txt']
    write_json(root/'report_manifest.json',{'status':'complete','files':{str(p.relative_to(root)):sha256(p) for p in files if p.is_file()}})
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('study_dir')
    args=parser.parse_args();result=build_report(args.study_dir)
    print(json.dumps({'status':'complete','worst_cross_model_mean_return_gain':result['worst_cross_model_mean_return_gain']}))


if __name__=='__main__':main()
