"""Aggregate saved diagnostics and render source-bound scientific figures.

No fitting, model selection, or narrative interpretation occurs here. Every
reported effect uses saved paired predictions, and figure inputs are hashed.
"""
from __future__ import annotations

import csv
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

import numpy as np

from .data import control_values
from .visual_diagnostics_statistics import CONTROL_NAMES, CONTROL_UNITS, DAY_NS, paired_block_interval


CORRECTORS = ("numeric", "timing", "original52", "static40", "fixed10", "fixed60", "null_fixed10")
CONTENT_METHODS = ("original52", "static40", "fixed10", "fixed60", "null_fixed10")
LABELS = {"original52": "原52维描述符", "static40": "静态40维描述符",
          "fixed10": "10分钟描述符", "fixed60": "60分钟描述符",
          "timing4": "仅采集时序", "null_fixed10": "打乱内容对照",
          "sensor": "纯传感器", "numeric": "数值残差校正", "timing": "数值＋时序校正"}
COLORS = {"original52": "#1f77b4", "static40": "#666666", "fixed10": "#ff7f0e",
          "fixed60": "#2ca02c", "timing4": "#888888", "null_fixed10": "#555555"}
QUANTITY_LABELS = ("炉膛温度", "负压", "蒸汽流量", "氧浓度")
UNIT_LABELS = ("°C", "Pa", "t/h", "vol%")


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _json(path: Path, content) -> None:
    path.write_text(json.dumps(content, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
                    encoding="utf-8")


def _csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        raise ValueError("empty diagnostic result table")
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def _metric(errors: np.ndarray) -> dict:
    return {"mae": np.abs(errors).mean(axis=(0, 1)).tolist(),
            "rmse": np.sqrt(np.square(errors).mean(axis=(0, 1))).tolist()}


def _record_source(path: Path, root: Path, sources: dict) -> None:
    try:
        name = path.relative_to(root).as_posix()
    except ValueError:
        name = str(path.resolve())
    sources[name] = _sha(path)


def _residual_arrays(root: Path, seeds: list[int], sources: dict) -> tuple[dict, np.ndarray, np.ndarray]:
    """Load actual outer-test four-quantity forecasts, never sensor_model files."""
    reference_path = root / "models/sensor" / f"seed_{seeds[0]}" / "test_predictions.npz"
    with np.load(reference_path, allow_pickle=False) as reference:
        expected_indices = reference["indices"].copy()
        expected_times = reference["time_ns"].copy()
        expected_truth = control_values(reference["y"])
    _record_source(reference_path, root, sources)
    errors = {}
    for method in ("sensor", *CORRECTORS):
        runs = []
        for seed in seeds:
            path = root / "residual" / f"seed_{seed}" / method / "test_predictions.npz"
            with np.load(path, allow_pickle=False) as archive:
                indices, times, truth, prediction = (archive[key] for key in
                    ("indices", "time_ns", "truth", "prediction"))
                if truth.shape != prediction.shape or truth.ndim != 2 or truth.shape[1] != 4:
                    raise ValueError(f"invalid residual prediction shape: {path}")
                if not np.isfinite(prediction).all() or not np.isfinite(truth).all():
                    raise ValueError(f"nonfinite residual prediction: {path}")
                if not np.array_equal(archive["error"], prediction - truth):
                    raise ValueError(f"residual saved error mismatch: {path}")
                if not (np.array_equal(indices, expected_indices) and np.array_equal(times, expected_times)
                          and np.array_equal(truth, expected_truth)):
                    raise ValueError(f"residual predictions are not paired: {path}")
                runs.append(prediction.astype(np.float64) - truth.astype(np.float64))
            _record_source(path, root, sources)
        errors[method] = np.stack(runs)
    return errors, expected_indices, expected_times


def _aggregate_residual(root: Path, config: dict, sources: dict) -> dict:
    path = root / "residual/residual_results.json"
    record = json.loads(path.read_text())
    _record_source(path, root, sources)
    seeds = [int(seed) for seed in config["diagnostics"]["seeds"]]
    if record["protocol"]["seeds"] != seeds or set(record["seeds"]) != {str(seed) for seed in seeds}:
        raise ValueError("residual fits are incomplete or use different seeds")
    errors, indices, times = _residual_arrays(root, seeds, sources)
    day_ids = times // DAY_NS
    for method, runs in errors.items():
        for position, seed in enumerate(seeds):
            expected = (record["seeds"][str(seed)]["sensor"]["test"] if method == "sensor"
                        else record["seeds"][str(seed)]["correctors"][method]["metrics"]["test"])
            actual = _metric(runs[position:position + 1])
            for metric in ("mae", "rmse"):
                if not np.allclose(actual[metric], expected[metric], rtol=1e-10, atol=1e-10):
                    raise ValueError(f"residual metrics disagree with saved predictions: {method}, {seed}")
    result = {"status": "completed", "seeds": seeds, "samples": len(indices),
        "calendar_days": len(np.unique(day_ids)), "control_names": list(CONTROL_NAMES),
        "units": list(CONTROL_UNITS), "overall": {name: _metric(value) for name, value in errors.items()},
        "comparison_scope": "exploratory source-disjoint residual calibration, not causal identification",
        "difference_direction": "reference MAE minus candidate MAE; positive favors candidate",
        "comparisons": {}}
    pairs = [(candidate, reference) for reference in ("numeric", "timing") for candidate in CORRECTORS]
    pairs.append(("fixed10", "null_fixed10"))
    rows = []
    for candidate, reference in pairs:
        difference = np.abs(errors[reference]) - np.abs(errors[candidate])
        interval = paired_block_interval(difference, day_ids,
            draws=int(config["diagnostics"].get("bootstrap_draws", 10000)),
            seed=int(config["diagnostics"].get("bootstrap_seed", 20261104)),
            confidence_level=float(config["diagnostics"].get("confidence_level", .95)))
        kind = ("self_reference" if candidate == reference else
                "exploratory_negative_control" if reference == "null_fixed10" else "exploratory_residual_diagnostic")
        result["comparisons"][f"{candidate}_vs_{reference}"] = {
            "candidate": candidate, "reference": reference, "priority": kind,
            "intervals": {"calendar_day": interval}}
        for channel, (quantity, unit) in enumerate(zip(CONTROL_NAMES, CONTROL_UNITS)):
            rows.append({"candidate": candidate, "reference": reference, "priority": kind,
                "quantity": quantity, "unit": unit, "mae_reduction": interval["difference"][channel],
                "ci_lower": interval["ci_lower"][channel], "ci_upper": interval["ci_upper"][channel],
                "samples": len(indices), "training_seeds": len(seeds),
                "calendar_days": interval["time_blocks"], "exploratory": True,
                "multiplicity_adjustment": "none"})
    out = root / "statistics"
    _json(out / "residual_statistics.json", result)
    _csv(out / "residual_statistics.csv", rows)
    np.savez_compressed(out / "residual_paired_error_arrays.npz", indices=indices, time_ns=times,
        seed=np.asarray(seeds), **{f"error_{method}": value for method, value in errors.items()})
    return result


def _aggregate_sensitivity(root: Path, config: dict, sources: dict) -> dict:
    seeds = [int(seed) for seed in config["diagnostics"]["seeds"]]
    expected_indices = expected_times = None
    aligned_errors, altered_errors, prediction_changes = [], {}, {}
    conditions = ("mean_content", "misaligned_content")
    for name in conditions:
        altered_errors[name], prediction_changes[name] = [], []
    for seed in seeds:
        folder = root / "models/fixed10" / f"seed_{seed}"
        path = folder / "test_predictions.npz"
        with np.load(path, allow_pickle=False) as archive:
            indices, times, truth, aligned = (archive[key] for key in ("indices", "time_ns", "y", "pred"))
            if expected_indices is None:
                expected_indices, expected_times = indices.copy(), times.copy()
            elif not (np.array_equal(indices, expected_indices) and np.array_equal(times, expected_times)):
                raise ValueError("sensitivity fitted seeds have different test identities")
            truth_cv, aligned_cv = control_values(truth).astype(np.float64), control_values(aligned).astype(np.float64)
            aligned_errors.append(aligned_cv - truth_cv)
        _record_source(path, root, sources)
        for name in conditions:
            path = folder / f"sensitivity_{name}.npz"
            with np.load(path, allow_pickle=False) as archive:
                if not (np.array_equal(archive["indices"], indices) and np.array_equal(archive["time_ns"], times)
                        and np.array_equal(archive["y"], truth)):
                    raise ValueError(f"unpaired inference sensitivity: {path}")
                prediction_cv = control_values(archive["pred"]).astype(np.float64)
                if prediction_cv.shape != truth_cv.shape or not np.isfinite(prediction_cv).all():
                    raise ValueError(f"invalid inference sensitivity: {path}")
                altered_errors[name].append(prediction_cv - truth_cv)
                prediction_changes[name].append(prediction_cv - aligned_cv)
            _record_source(path, root, sources)
    aligned_errors = np.stack(aligned_errors)
    result = {"status": "completed", "seeds": seeds, "samples": len(expected_indices),
        "scope": "inference-only input perturbation of fitted fixed10 models; possible out-of-distribution inputs",
        "independently_retrained_comparator": False,
        "difference_direction": "aligned MAE minus perturbed MAE; positive means perturbation reduced error",
        "aligned": _metric(aligned_errors), "conditions": {}}
    rows = []
    for name in conditions:
        error, change = np.stack(altered_errors[name]), np.stack(prediction_changes[name])
        interval = paired_block_interval(np.abs(aligned_errors) - np.abs(error), expected_times // DAY_NS,
            draws=int(config["diagnostics"].get("bootstrap_draws", 10000)),
            seed=int(config["diagnostics"].get("bootstrap_seed", 20261104)),
            confidence_level=float(config["diagnostics"].get("confidence_level", .95)))
        item = {"metrics": _metric(error), "interval": interval,
                "mean_absolute_prediction_change": np.abs(change).mean(axis=(0, 1)).tolist(),
                "maximum_absolute_prediction_change": np.abs(change).max(axis=(0, 1)).tolist()}
        result["conditions"][name] = item
        for channel, (quantity, unit) in enumerate(zip(CONTROL_NAMES, CONTROL_UNITS)):
            rows.append({"condition": name, "quantity": quantity, "unit": unit,
                "aligned_mae": result["aligned"]["mae"][channel], "perturbed_mae": item["metrics"]["mae"][channel],
                "mae_reduction_after_perturbation": interval["difference"][channel],
                "ci_lower": interval["ci_lower"][channel], "ci_upper": interval["ci_upper"][channel],
                "mean_absolute_prediction_change": item["mean_absolute_prediction_change"][channel],
                "maximum_absolute_prediction_change": item["maximum_absolute_prediction_change"][channel],
                "inference_only": True, "possible_out_of_distribution_input": True})
    _json(root / "statistics/inference_sensitivity_statistics.json", result)
    _csv(root / "statistics/inference_sensitivity_statistics.csv", rows)
    return result


def _pyplot():
    os.environ.setdefault("MPLCONFIGDIR", str(Path(tempfile.gettempdir()) / "mswi-visual-diagnostics-mpl"))
    import matplotlib
    matplotlib.use("Agg")
    from matplotlib import font_manager, pyplot as plt
    finder = shutil.which("kpsewhich")
    if finder is None and Path("/Library/TeX/texbin/kpsewhich").is_file():
        finder = "/Library/TeX/texbin/kpsewhich"
    if finder is None:
        raise FileNotFoundError("kpsewhich is required to locate the FandolSong Chinese figure font")
    font_path = subprocess.check_output([finder, "FandolSong-Regular.otf"], text=True).strip()
    if not font_path or not Path(font_path).is_file():
        raise FileNotFoundError("FandolSong-Regular.otf was not found")
    font_manager.fontManager.addfont(font_path)
    family = font_manager.FontProperties(fname=font_path).get_name()
    plt.rcParams.update({"font.family": [family, "DejaVu Sans"], "font.size": 12,
        "axes.titlesize": 14, "axes.labelsize": 12, "axes.unicode_minus": False,
        "axes.facecolor": "white", "figure.facecolor": "white", "axes.edgecolor": "black",
        "axes.linewidth": .8, "svg.fonttype": "path", "savefig.facecolor": "white"})
    return plt, font_path


def _style_axis(axis, grid_axis="x"):
    axis.grid(axis=grid_axis, color="#777777", linestyle="--", linewidth=.55, alpha=.45)
    axis.set_axisbelow(True)
    for spine in axis.spines.values():
        spine.set_visible(True)
        spine.set_color("black")


def _forest(axis, rows, channel: int):
    bounds = [0.]
    for position, (method, interval) in enumerate(rows):
        point, low, high = (interval[key][channel] for key in ("difference", "ci_lower", "ci_upper"))
        color = COLORS[method]
        axis.hlines(position, low, high, color=color, linewidth=1.5)
        axis.vlines([low, high], position - .07, position + .07, color=color, linewidth=1.)
        axis.plot(point, position, marker="s" if method == "null_fixed10" else "o", markersize=6,
                  color=color, markerfacecolor="white" if method == "null_fixed10" else color)
        bounds.extend([point, low, high])
    minimum, maximum = min(bounds), max(bounds)
    padding = max((maximum - minimum) * .1, 1e-5)
    axis.set_xlim(minimum - padding, maximum + padding)
    axis.axvline(0, color="black", linewidth=.9, linestyle="--")
    axis.set_yticks(np.arange(len(rows)), [LABELS[method] for method, _ in rows])
    axis.set_ylim(len(rows) - .5, -.5)
    _style_axis(axis)


def _save_figure(figure, folder: Path, name: str) -> list[Path]:
    paths = []
    for extension in ("png", "svg"):
        path = folder / f"{name}.{extension}"
        figure.savefig(path, dpi=220, bbox_inches="tight")
        paths.append(path)
    return paths


def _load_horizon_figure_data(root: Path, sources: dict) -> dict:
    """Validate saved direct Ridge effects without refitting or resampling."""
    folder = root / "horizon_probe"
    paths = {name: folder / name for name in ("results.json", "protocol.json", "completed.json")}
    results, protocol, completed = (json.loads(paths[name].read_text()) for name in paths)
    if (results["status"] != "completed" or completed["status"] != "completed"
            or completed["results_sha256"] != _sha(paths["results.json"])
            or completed["protocol_sha256"] != _sha(paths["protocol.json"])
            or results["protocol"] != protocol):
        raise ValueError("horizon results are incomplete or differ from their completed record")
    if (protocol["horizons_minutes"] != [1, 5, 10]
            or protocol["targets"] != list(CONTROL_NAMES)
            or set(results["horizons"]) != {"1", "5", "10"}
            or not protocol["intervals"]["no_neural_training_seed_axis"]):
        raise ValueError("unexpected direct-horizon figure protocol")
    for path in paths.values():
        _record_source(path, root, sources)
    for horizon in (1, 5, 10):
        cell = results["horizons"][str(horizon)]
        errors, reference = {}, None
        for method in ("sensor", "original52", "fixed10"):
            path = folder / f"horizon_{horizon:02d}" / method / "test_predictions.npz"
            if _sha(path) != cell["methods"][method]["test_predictions_sha256"]:
                raise ValueError(f"horizon source hash mismatch: {path}")
            with np.load(path, allow_pickle=False) as archive:
                identity = {key: archive[key].copy() for key in (
                    "indices", "destination_indices", "time_ns", "destination_time_ns", "truth")}
                truth, prediction = identity["truth"], archive["pred"]
                if (truth.ndim != 2 or truth.shape[1] != 4 or prediction.shape != truth.shape
                        or not np.isfinite(truth).all() or not np.isfinite(prediction).all()
                        or len(truth) != cell["eligible_counts"]["test"]):
                    raise ValueError(f"invalid horizon predictions: {path}")
                if reference is None:
                    reference = identity
                elif any(not np.array_equal(identity[key], reference[key]) for key in reference):
                    raise ValueError(f"unpaired horizon predictions: {path}")
                errors[method] = prediction - truth
                if not np.array_equal(errors[method], archive["error"]):
                    raise ValueError(f"horizon saved error mismatch: {path}")
                if not np.allclose(np.abs(errors[method]).mean(axis=0),
                        cell["methods"][method]["mae"], rtol=1e-10, atol=1e-10):
                    raise ValueError(f"horizon MAE disagrees with predictions: {path}")
            _record_source(path, root, sources)
        days, counts = np.unique(reference["time_ns"] // DAY_NS, return_counts=True)
        for method in ("original52", "fixed10"):
            interval = cell["comparisons"][f"{method}_vs_sensor"]
            bounds = np.asarray([interval[key] for key in ("difference", "ci_lower", "ci_upper")])
            if (bounds.shape != (3, 4) or not np.isfinite(bounds).all()
                    or np.any(bounds[1] > bounds[2])
                    or not np.isclose(interval["confidence_level"], .95)
                    or interval["deterministic_fits"] != 1 or "training_seeds" in interval
                    or not interval["exploratory"] or interval["multiple_comparison_adjustment"] != "none"
                    or interval["samples"] != len(reference["time_ns"])
                    or interval["time_blocks"] != len(days)
                    or interval["block_sample_counts"] != counts.tolist()):
                raise ValueError(f"invalid saved horizon interval: {horizon}, {method}")
            expected = (np.abs(errors["sensor"]) - np.abs(errors[method])).mean(axis=0)
            if not np.allclose(bounds[0], expected, rtol=1e-10, atol=1e-10):
                raise ValueError(f"horizon plotted effect disagrees with predictions: {horizon}, {method}")
    return results


def _horizon_figure(plt, results: dict):
    """Plot each saved endpoint and day interval directly, with no pooling."""
    horizons, methods = (1, 5, 10), ("original52", "fixed10")
    figure, axes = plt.subplots(2, 2, figsize=(13.4, 9.2))
    for channel, axis in enumerate(axes.flat):
        for position, method in enumerate(methods):
            intervals = [results["horizons"][str(h)]["comparisons"][f"{method}_vs_sensor"]
                         for h in horizons]
            x = np.arange(3) + (position - .5) * .12
            point, lower, upper = (np.asarray([item[key][channel] for item in intervals])
                                   for key in ("difference", "ci_lower", "ci_upper"))
            axis.plot(x, point, color=COLORS[method], marker="o", markersize=6,
                      linewidth=1.4, label=LABELS[method])
            axis.vlines(x, lower, upper, color=COLORS[method], linewidth=1.4)
            axis.hlines(lower, x - .035, x + .035, color=COLORS[method], linewidth=1.1)
            axis.hlines(upper, x - .035, x + .035, color=COLORS[method], linewidth=1.1)
        axis.axhline(0, color="black", linestyle="--", linewidth=.9)
        axis.set_xticks(np.arange(3), [str(h) for h in horizons])
        axis.set_xlim(-.35, 2.35)
        axis.set_title(QUANTITY_LABELS[channel])
        axis.set_xlabel("预测时域（分钟）")
        axis.set_ylabel(f"相对纯传感器的MAE减小量（{UNIT_LABELS[channel]}）")
        _style_axis(axis, "y")
    handles, labels = axes.flat[0].get_legend_handles_labels()
    figure.legend(handles, labels, loc="upper center", bbox_to_anchor=(.5, .93),
                  ncol=2, frameon=False)
    figure.suptitle("独立 Ridge 探针：不同预测时域的描述符增益", fontsize=17, y=.985)
    day_counts = [results["horizons"][str(h)]["comparisons"]["fixed10_vs_sensor"]["time_blocks"]
                  for h in horizons]
    day_text = str(day_counts[0]) if len(set(day_counts)) == 1 else "/".join(map(str, day_counts))
    counts = "/".join(f"{results['horizons'][str(h)]['eligible_counts']['test']:,}" for h in horizons)
    figure.text(.5, .025,
        "正值表示误差减小；各时域独立拟合 Ridge，竖线为按起点日历日配对重采样的探索性95%区间。\n"
        f"未做多重比较校正；仅描述时间块变化，无神经网络训练种子轴；{day_text} 个日历日。\n"
        f"1/5/10分钟测试窗口分别为 {counts}；不同物理量的纵轴单位及尺度不同。",
        ha="center", va="bottom", fontsize=10.5)
    figure.subplots_adjust(left=.10, right=.98, top=.84, bottom=.20, wspace=.28, hspace=.45)
    return figure


def render_horizon_effects(study_dir) -> dict:
    """Add the saved Ridge horizon figure; preserve all other result files.

    This incremental entry point does not call the main/residual aggregators.
    Existing figure provenance is retained per file when the renderer changes.
    """
    root = Path(study_dir).resolve()
    out = root / "figures"
    manifest_path = out / "figure_manifest.json"
    manifest = json.loads(manifest_path.read_text())
    for name, digest in manifest["figure_sha256"].items():
        if _sha(root / name) != digest:
            raise ValueError(f"previous figure changed since manifest was written: {name}")
    results = _load_horizon_figure_data(root, manifest["sources_sha256"])
    plt, font_path = _pyplot()
    figure = _horizon_figure(plt, results)
    generated = _save_figure(figure, out, "horizon_effects")
    plt.close(figure)
    renderer = _sha(Path(__file__))
    renderers = manifest.setdefault("figure_renderer_sha256", {
        name: manifest["renderer_sha256"] for name in manifest["figure_sha256"]})
    for path in generated:
        name = path.relative_to(root).as_posix()
        manifest["figure_sha256"][name] = _sha(path)
        renderers[name] = renderer
    manifest["status"] = "rendered_pending_visual_review"
    manifest["renderer_sha256"] = renderer
    manifest["renderer_scope"] = "latest renderer; figure_renderer_sha256 binds each figure to its rendering version"
    manifest["chinese_font"] = font_path
    manifest["figures"]["horizon_effects"] = (
        "original52 and fixed10 versus sensor at 1/5/10 minutes, four quantities; "
        "independent direct Ridge probes with unadjusted exploratory origin-day intervals, no neural seed axis")
    manifest["horizon_results"] = "horizon_probe/results.json"
    _json(manifest_path, manifest)
    return manifest


def render_diagnostic_report(study_dir, config_file) -> dict:
    """Aggregate complete saved runs and render three static scientific figures."""
    root = Path(study_dir).resolve()
    config_path = Path(config_file).resolve()
    config = json.loads(config_path.read_text())
    source_path = root / "statistics/summary.json"
    main = json.loads(source_path.read_text())
    if main["seeds"] != config["diagnostics"]["seeds"]:
        raise ValueError("main statistics and requested training seeds disagree")
    sources = {}
    _record_source(config_path, root, sources)
    _record_source(source_path, root, sources)
    for name, digest in main["source_prediction_sha256"].items():
        path = root / name
        if _sha(path) != digest:
            raise ValueError(f"prediction has changed since main statistics were computed: {path}")
        sources[name] = digest
    residual = _aggregate_residual(root, config, sources)
    sensitivity = _aggregate_sensitivity(root, config, sources)
    for name in ("residual_statistics.json", "inference_sensitivity_statistics.json"):
        _record_source(root / "statistics" / name, root, sources)
    out = root / "figures"
    out.mkdir(parents=True, exist_ok=True)
    plt, font_path = _pyplot()
    generated = []
    figure, axes = plt.subplots(2, 2, figsize=(13.4, 8.5))
    main_methods = ("original52", "static40", "fixed10", "fixed60", "timing4", "null_fixed10")
    rows = [(method, main["comparisons"][f"{method}_vs_sensor"]["intervals"]["calendar_day"])
            for method in main_methods]
    for channel, axis in enumerate(axes.flat):
        _forest(axis, rows, channel)
        axis.set_title(QUANTITY_LABELS[channel])
        axis.set_xlabel(f"MAE减小量（{UNIT_LABELS[channel]}）")
    figure.suptitle("描述符增量信息：相对纯传感器模型", fontsize=17, y=.98)
    figure.text(.5, .035, "正值表示误差减小；横线为按日与训练种子配对重采样的探索性95%区间，未做多重比较校正。\n"
        f"共同测试窗口 {main['test_samples']:,} 个，{len(main['seeds'])} 次完整训练，{main['calendar_days']} 个日历日；各面板单位与横轴尺度不同。",
        ha="center", va="bottom", fontsize=10.5)
    figure.subplots_adjust(left=.14, right=.98, top=.90, bottom=.16, wspace=.51, hspace=.44)
    generated += _save_figure(figure, out, "main_effects")
    plt.close(figure)

    figure, axes = plt.subplots(1, 2, figsize=(13.4, 5.8))
    for axis, reference, title in zip(axes, ("numeric", "timing"), ("相对数值残差校正", "相对数值＋采集时序校正")):
        rows = [(method, residual["comparisons"][f"{method}_vs_{reference}"]["intervals"]["calendar_day"])
                for method in CONTENT_METHODS]
        _forest(axis, rows, 0)
        axis.set_title(title)
        axis.set_xlabel("温度MAE减小量（°C）")
    figure.suptitle("残差诊断：描述符能否进一步改善温度预测", fontsize=17, y=.98)
    figure.text(.5, .035, "正值表示误差减小；传感器拟合与残差校准使用来源不重叠的训练时段。\n"
        f"横线为 {len(residual['seeds'])} 次训练与 {residual['calendar_days']} 个日历日的探索性95%配对区间，未做多重比较校正；其余物理量见结果表。",
        ha="center", va="bottom", fontsize=10.5)
    figure.subplots_adjust(left=.14, right=.98, top=.84, bottom=.25, wspace=.48)
    generated += _save_figure(figure, out, "residual_effects")
    plt.close(figure)

    figure, axes = plt.subplots(2, 2, figsize=(13.4, 9.1))
    strata = ("freshness_0_2_minutes", "freshness_2_5_minutes", "freshness_5_10_minutes")
    groups = ("≤2分钟", "2–5分钟", "5–10分钟")
    methods = ("original52", "fixed10", "fixed60")
    tick_labels = [f"{label}\n窗口 {main['strata'][key]['samples']:,}；图像 {main['strata'][key]['unique_captures']:,}"
                   for label, key in zip(groups, strata)]
    for channel, axis in enumerate(axes.flat):
        for position, method in enumerate(methods):
            values = []
            for key in strata:
                cell = main["strata"][key]
                values.append(np.nan if not cell["samples"] else
                    cell["methods"]["sensor"]["mae"][channel] - cell["methods"][method]["mae"][channel])
            axis.bar(np.arange(3) + (position - 1) * .24, values, width=.22,
                     color=COLORS[method], edgecolor="black", linewidth=.6, label=LABELS[method])
        axis.axhline(0, color="black", linewidth=.8)
        axis.set_xticks(np.arange(3), tick_labels, fontsize=10.5)
        axis.set_title(QUANTITY_LABELS[channel])
        axis.set_ylabel(f"MAE减小量（{UNIT_LABELS[channel]}）")
        _style_axis(axis, "y")
    handles, labels = axes.flat[0].get_legend_handles_labels()
    figure.legend(handles, labels, loc="upper center", bbox_to_anchor=(.5, .93), ncol=3, frameon=False)
    figure.suptitle("图像新鲜度分层：相对纯传感器模型", fontsize=17, y=.985)
    figure.text(.5, .03, "新鲜度＝预测前一分钟减去已选图像的捕获时间；正值表示误差减小。\n"
        f"显示 {len(main['seeds'])} 次完整训练的分层平均值，无置信区间；三个预设层均完整报告，同一图像可出现在不同新鲜度层。",
        ha="center", va="bottom", fontsize=10.5)
    figure.subplots_adjust(left=.075, right=.98, top=.84, bottom=.16, wspace=.26, hspace=.49)
    generated += _save_figure(figure, out, "freshness_strata")
    plt.close(figure)
    manifest = {"status": "rendered_pending_visual_review", "sources_sha256": sources,
        "figure_sha256": {path.relative_to(root).as_posix(): _sha(path) for path in generated},
        "renderer_sha256": _sha(Path(__file__)), "chinese_font": font_path,
        "palette": COLORS, "figures": {
            "main_effects": "paired daily confidence intervals for all six main variants versus sensor",
            "residual_effects": "temperature residual contrasts versus numeric and timing corrections; other quantities retained in CSV",
            "freshness_strata": "descriptive subgroup means only, no confidence intervals"},
        "main_primary_endpoint": "temperature MAE, fixed10 versus sensor and timing4",
        "negative_control_pair": "fixed10 versus null_fixed10 is directly paired in main and residual statistics",
        "inference_sensitivity_scope": sensitivity["scope"],
        "residual_statistics": "statistics/residual_statistics.json",
        "inference_sensitivity_statistics": "statistics/inference_sensitivity_statistics.json"}
    _json(out / "figure_manifest.json", manifest)
    return manifest
