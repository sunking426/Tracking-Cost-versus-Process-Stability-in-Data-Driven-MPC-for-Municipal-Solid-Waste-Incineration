"""Paired endpoint tables, zero-degradation decisions and inspectable figures."""
from __future__ import annotations
import csv
import json
from pathlib import Path
import numpy as np
from .control import reward_and_violation, TRACKING_SCALES
from .control_acceptance import assess_contrasts
from .visual_diagnostics_statistics import paired_block_interval, DAY_NS
from .ridge_control_probe_report import METRICS
from .ridge_policy_study import OUT, ROOT, REF, MODELS, GROUPS, SEEDS, read_npz, write_json, sha, shared
from .ridge_policy_evaluation import BASELINES

def csv_write(path,rows):
    with Path(path).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def endpoints(row,horizon):
    r=row['reward'][:,:horizon].astype(float)
    return np.column_stack((r.sum(1),row['tracking_cost'][:,:horizon].astype(float).mean(1)*TRACKING_SCALES[:3],
        row['oxygen_cost'][:,:horizon].astype(float).mean(1)*float(TRACKING_SCALES[3]),row['violation'][:,:horizon].mean(1)))

def difference(reference,candidate):
    delta=reference-candidate;delta[...,0]*=-1;return delta

def summarize():
    stats,execution,_,_=shared();metrics={};table=[];byseed=[];action_table=[];manifest=[]
    for split in ('val','test'):
        inputs=read_npz(REF/f'inputs/{split}.npz')
        for mid in MODELS:
            for group in BASELINES+GROUPS:
                accum={10:[],50:[]};actionrows=[]
                for seed in SEEDS if group in GROUPS else (0,):
                    path=OUT/f'trajectories/{split}/{mid}/{group}/seed{seed}.npz';row=read_npz(path)
                    saved=json.loads(path.with_suffix('.json').read_text())
                    if sha(path)!=saved['sha256']:raise AssertionError('trajectory hash')
                    if row['pred_cv'].shape!=(256,50,9):raise AssertionError('trajectory dimensions')
                    for key in ('indices','time_ns'):
                        if not np.array_equal(row[key],inputs[key]):raise AssertionError('changed frozen starts')
                    reward,violation,cost=reward_and_violation(row['pred_cv'],row['executed_action'],stats)
                    for key,expected in {'reward':reward,'violation':violation,**cost}.items():
                        if not np.array_equal(row[key],expected):raise AssertionError('canonical reward/component mismatch '+key)
                    delta=row['physical_executed_action'];actions=row['executed_action'];upath=row['u_path']
                    if np.any(delta[:,:,[1,2,4,5,6,7]]!=0):raise AssertionError('inactive action changed')
                    if np.any(np.abs(delta)>.1*execution.bound+1e-10):raise AssertionError('budget exceeded')
                    if np.any(upath<np.asarray(stats['u_low'])) or np.any(upath>np.asarray(stats['u_high'])):raise AssertionError('absolute MV bounds')
                    if np.any(np.any(actions!=0,axis=-1)&~row['action_supported']):raise AssertionError('unsupported nonzero execution')
                    for horizon in (10,50):
                        value=endpoints(row,horizon);accum[horizon].append(value)
                        byseed.append({'split':split,'model':mid,'method':group,'seed':seed,'horizon':horizon,**dict(zip(METRICS,value.mean(0).tolist()))})
                        d=delta[:,:horizon];a=actions[:,:horizon]
                        action_table.append({'split':split,'model':mid,'method':group,'seed':seed,'horizon':horizon,
                            'nonzero_fraction':float(np.any(a!=0,axis=-1).mean()),'blocked_fraction':float(row['blocked_nonzero'][:,:horizon].mean()),
                            'unsupported_hold_fraction':float(row['zero_action_unsupported'][:,:horizon].mean()),
                            'mean_movement_cost':float(row['movement_cost'][:,:horizon].mean()),
                            'cumulative_movement_cost':float(row['movement_cost'][:,:horizon].astype(float).sum(1).mean()),
                            **{f'mean_abs_delta_{j}':float(np.abs(d[:,:,j]).mean()) for j in (0,3)},
                            **{f'max_abs_delta_{j}':float(np.abs(d[:,:,j]).max()) for j in (0,3)},
                            **{f'mean_episode_total_abs_delta_{j}':float(np.abs(d[:,:,j]).sum(1).mean()) for j in (0,3)},
                            **{f'mean_abs_normalized_action_{j}':float(np.abs(a[:,:,j]).mean()) for j in (0,3)},
                            **{f'max_abs_normalized_action_{j}':float(np.abs(a[:,:,j]).max()) for j in (0,3)}})
                    manifest.append({'path':str(path.relative_to(OUT)),'sha256':sha(path),'episodes':256,'steps_per_episode':50})
                for h,values in accum.items():
                    value=np.stack(values);metrics[split,mid,group,h]=value
                    table.append({'split':split,'model':mid,'method':group,'horizon':h,'seeds':len(values),'starts_per_seed':256,
                        **dict(zip(METRICS,value.mean((0,1)).tolist())),
                        'return_sd_across_seed_means':float(value[:,:,0].mean(1).std(ddof=1)) if len(values)>1 else 0.0})
    contrasts={};contrast_table=[];paired={}
    pairs=[('hold',g) for g in BASELINES[1:]+GROUPS]+[(g,'ridge_td3bc') for g in ('bc','offline_td3bc','twin_td3','sensor_td3bc','no_policy_retrieval','grid_mpc','cem_mpc')]
    for split in ('val','test'):
        times=read_npz(REF/f'inputs/{split}.npz')['time_ns'];days=times//DAY_NS
        for mid in MODELS:
            for h in (10,50):
                for reference,candidate in pairs:
                    delta=difference(metrics[split,mid,reference,h],metrics[split,mid,candidate,h])
                    key=f'{split}/{mid}/{h}/{candidate}_vs_{reference}'
                    result=paired_block_interval(delta,days,draws=10000,seed=20261106,confidence_level=.95)
                    result['estimand']='paired episode endpoint improvement, equal weight over registered trained seeds; positive means better'
                    result['worse_episode_fraction_by_endpoint']=(delta<0).mean((0,1)).tolist()
                    contrasts[key]=result;paired[key.replace('/','__')]=delta
                    for j,name in enumerate(METRICS):
                        contrast_table.append({'split':split,'model':mid,'horizon':h,'candidate':candidate,'reference':reference,'metric':name,
                            'difference':result['difference'][j],'ci_lower':result['ci_lower'][j],'ci_upper':result['ci_upper'][j],
                            'worse_episode_fraction':result['worse_episode_fraction_by_endpoint'][j],'time_blocks':result['time_blocks'],'seeds':result['training_seeds']})
    protocol=json.loads((ROOT/'experiment_protocols/control_acceptance_20261106/protocol.json').read_text())
    acceptance={}
    for split in ('val','test'):
        for group in BASELINES[1:]+GROUPS:
            acceptance[f'{split}/{group}']=assess_contrasts({mid:contrasts[f'{split}/{mid}/10/{group}_vs_hold'] for mid in MODELS[1:]},protocol)
    report=OUT/'report';report.mkdir(exist_ok=True)
    csv_write(report/'endpoint_means.csv',table);csv_write(report/'endpoint_by_seed.csv',byseed)
    csv_write(report/'contrasts.csv',contrast_table);csv_write(report/'action_and_support.csv',action_table)
    write_json(report/'contrasts.json',contrasts);write_json(report/'acceptance.json',acceptance)
    np.savez_compressed(report/'paired_episode_improvements.npz',**paired)
    np.savez_compressed(report/'episode_endpoints.npz',**{'__'.join(map(str,k)):v for k,v in metrics.items()})
    write_json(OUT/'trajectory_manifest.json',{'files':manifest,'files_count':len(manifest),'episodes':len(manifest)*256,'modeled_control_steps':len(manifest)*256*50,
        'trajectories_dropped':0,'predictions_clipped':False,'canonical_rewards_recomputed':True,'new_plant_interventions':0})
    render(report,metrics,contrasts)
    return table,contrasts,acceptance

def render(report,metrics,contrasts):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':180})
    colors=['#1f77b4','#ff7f0e','#2ca02c','#d62728','#9467bd','#8c564b']
    show=('hold','bc','offline_td3bc','ridge_td3bc','grid_mpc','cem_mpc')
    labels=('Hold','BC','Offline TD3+BC','Ridge TD3+BC','Grid MPC','CEM-128')
    fig,axes=plt.subplots(2,2,figsize=(12,7.5))
    for ax,mid in zip(axes.ravel(),MODELS[1:]):
        arrays=[metrics['test',mid,g,10].mean(0)[:,0] for g in show]
        box=ax.boxplot(arrays,tick_labels=labels,patch_artist=True,showfliers=False)
        for patch in box['boxes']:patch.set_facecolor('white');patch.set_edgecolor('black')
        for median in box['medians']:median.set_color('#1f77b4')
        ax.set_title(mid);ax.set_ylabel('10-step return');ax.tick_params(axis='x',rotation=18)
    fig.tight_layout();fig.savefig(report/'control_returns.png');plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(11,4.2))
    for j,g in enumerate(show):
        for ax,h in zip(axes,(10,50)):
            y=[metrics['test',mid,g,h].mean((0,1))[0] for mid in MODELS[1:]]
            ax.plot(MODELS[1:],y,marker='o',color=colors[j],label=labels[j]);ax.set_title(f'{h}-step horizon');ax.set_ylabel('Mean return')
    axes[1].legend(fontsize=8);fig.tight_layout();fig.savefig(report/'horizon_comparison.png');plt.close(fig)
    fig,ax=plt.subplots(figsize=(7,4.7))
    for j,g in enumerate(show[1:]):
        points=np.array([contrasts[f'test/{mid}/10/{g}_vs_hold']['difference'] for mid in MODELS[1:]])
        ax.scatter(-points[:,1],points[:,0],label=labels[j+1],color=colors[j+1],s=40)
        for mid,p in zip(MODELS[1:],points):ax.annotate(mid,(-p[1],p[0]),fontsize=7,xytext=(3,3),textcoords='offset points')
    ax.axvline(0,color='gray',lw=.8);ax.axhline(0,color='gray',lw=.8)
    ax.set_xlabel('Temperature MAE increase versus hold (deg C)');ax.set_ylabel('10-step return gain versus hold');ax.legend(fontsize=8)
    fig.tight_layout();fig.savefig(report/'temperature_return_tradeoff.png');plt.close(fig)

if __name__=='__main__':summarize()
