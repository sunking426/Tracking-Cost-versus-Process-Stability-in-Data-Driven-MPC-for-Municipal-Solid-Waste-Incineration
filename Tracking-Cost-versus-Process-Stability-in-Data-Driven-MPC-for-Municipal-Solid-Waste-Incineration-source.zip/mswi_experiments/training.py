"""Reproducible supervised twin and behavior-cloning training."""
from __future__ import annotations

import csv
import json
from pathlib import Path
import random
import time

import numpy as np
import torch
from torch import Tensor
import torch.nn.functional as F

from .models import Actor, Twin, actor_config, make_state, twin_config
from .data import control_values


def seed_everything(seed: int, threads: int = 4) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.set_num_threads(int(threads))


def _write_json(path: Path, value) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def _inputs(data: dict) -> dict[str, Tensor]:
    names = ("u_hist", "z_hist", "visual", "z_prev", "z_target", "u_current", "z_current", "action")
    arrays = {name: torch.as_tensor(np.asarray(data[name]), dtype=torch.float32) for name in names}
    n = len(arrays["u_hist"])
    if any(len(v) != n for v in arrays.values()):
        raise ValueError("prepared dataset arrays do not share the sample dimension")
    for name, value in arrays.items():
        if not torch.isfinite(value).all():
            raise ValueError(f"nonfinite training input: {name}")
    for split in ("train_idx", "val_idx", "test_idx"):
        idx = np.asarray(data[split])
        if idx.ndim != 1 or len(idx) == 0 or idx.min() < 0 or idx.max() >= n:
            raise ValueError(f"invalid or empty {split}")
    return arrays


def _batches(indices, batch_size: int, rng: np.random.Generator | None = None):
    idx = np.asarray(indices, dtype=np.int64)
    if rng is not None:
        idx = rng.permutation(idx)
    for start in range(0, len(idx), batch_size):
        yield torch.from_numpy(idx[start:start + batch_size].copy())


def _metrics(y: np.ndarray, pred: np.ndarray) -> dict:
    error = np.asarray(pred, dtype=np.float64) - np.asarray(y, dtype=np.float64)
    return {"n": len(y), "mae_per_channel": np.abs(error).mean(axis=0).tolist(),
            "rmse_per_channel": np.sqrt(np.square(error).mean(axis=0)).tolist()}


@torch.no_grad()
def predict_twin(twin: Twin, data: dict, indices, batch_size: int = 512) -> np.ndarray:
    """Return absolute CV predictions, preserving the requested index order."""
    twin.eval()
    arrays = _inputs(data)
    result = []
    for idx in _batches(indices, batch_size):
        delta = twin(arrays["u_hist"][idx], arrays["z_hist"][idx], arrays["visual"][idx])
        result.append((arrays["z_prev"][idx] + delta).cpu().numpy())
    return np.concatenate(result, axis=0)


@torch.no_grad()
def encode_states(twin: Twin, data: dict, batch_size: int = 512) -> Tensor:
    """Freeze the trained twin representation and cache explicit policy states."""
    twin.eval()
    arrays = _inputs(data)
    states = []
    for idx in _batches(np.arange(len(arrays["u_hist"])), batch_size):
        states.append(make_state(twin, arrays["u_hist"][idx], arrays["z_hist"][idx],
                                 arrays["visual"][idx], arrays["u_current"][idx],
                                 arrays["z_current"][idx]).detach().cpu())
    return torch.cat(states, dim=0)


def load_twin(path, device: str = "cpu") -> Twin:
    checkpoint = torch.load(Path(path), map_location=device, weights_only=True)
    if checkpoint.get("kind") != "twin":
        raise ValueError("checkpoint is not a canonical twin")
    model = Twin(**checkpoint["model_config"])
    model.load_state_dict(checkpoint["state_dict"], strict=True)
    return model.to(device).eval()


def load_actor(path, device: str = "cpu") -> Actor:
    checkpoint = torch.load(Path(path), map_location=device, weights_only=True)
    if checkpoint.get("kind") != "actor":
        raise ValueError("checkpoint is not a canonical actor")
    model = Actor(**checkpoint["model_config"])
    model.load_state_dict(checkpoint["state_dict"], strict=True)
    return model.to(device).eval()


def fit_twin(data: dict, stats: dict, mode: str, seed: int, config: dict, outdir, *,
             evaluate_test: bool = True) -> tuple[Twin, dict]:
    """Fit using train/validation, optionally deferring all test prediction.

    Experiments comparing multiple candidates can set ``evaluate_test=False``
    and evaluate saved checkpoints only after every selection has been frozen.
    """
    cfg = config["training"]
    seed_everything(seed, cfg.get("threads", 4))
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    twin = Twin(stats, mode=mode, hidden=int(cfg.get("hidden", 128)))
    arrays = _inputs(data)
    target_delta = arrays["z_target"] - arrays["z_prev"]
    optimizer = torch.optim.AdamW(twin.parameters(), lr=float(cfg.get("lr", 1e-3)),
                                 weight_decay=float(cfg.get("weight_decay", 1e-4)))
    batch = int(cfg.get("batch_size", 256))
    epochs = int(cfg.get("twin_epochs", cfg.get("epochs", 20)))
    patience = int(cfg.get("patience", 4))
    if min(batch, epochs, patience) <= 0:
        raise ValueError("batch_size, epochs and patience must be positive")
    rng = np.random.default_rng(seed)
    best = float("inf")
    stale = 0
    history = []
    start = time.monotonic()
    for epoch in range(1, epochs + 1):
        twin.train()
        train_sum = 0.0
        for idx in _batches(data["train_idx"], batch, rng):
            pred = twin(arrays["u_hist"][idx], arrays["z_hist"][idx], arrays["visual"][idx])
            loss = (((pred - target_delta[idx]) / twin.delta_scale) ** 2).mean()
            if not torch.isfinite(loss):
                raise FloatingPointError("nonfinite twin training loss")
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(twin.parameters(), float(cfg.get("grad_clip", 1.0)))
            optimizer.step()
            train_sum += float(loss.detach()) * len(idx)
        twin.eval()
        val_sum = 0.0
        with torch.no_grad():
            for idx in _batches(data["val_idx"], batch):
                pred = twin(arrays["u_hist"][idx], arrays["z_hist"][idx], arrays["visual"][idx])
                loss = (((pred - target_delta[idx]) / twin.delta_scale) ** 2).mean()
                val_sum += float(loss) * len(idx)
        val_loss = val_sum / len(data["val_idx"])
        row = {"epoch": epoch, "train_normalized_mse": train_sum / len(data["train_idx"]),
               "val_normalized_mse": val_loss, "elapsed_s": time.monotonic() - start}
        history.append(row)
        _write_json(out / "history.json", history)
        print(f"twin[{mode}] seed={seed} epoch={epoch}/{epochs} "
              f"train={row['train_normalized_mse']:.6f} val={val_loss:.6f}", flush=True)
        if val_loss < best - float(cfg.get("min_delta", 1e-5)):
            best = val_loss
            stale = 0
            torch.save({"kind": "twin", "model_config": twin_config(twin),
                        "state_dict": twin.state_dict(), "seed": int(seed), "epoch": epoch,
                        "best_val_loss": best, "training_config": cfg}, out / "twin.pt")
        else:
            stale += 1
        if stale >= patience:
            break
    twin = load_twin(out / "twin.pt")
    metrics = {"mode": mode, "seed": int(seed), "epochs_completed": len(history),
               "best_val_normalized_mse": best,
               "elapsed_s": time.monotonic() - start}
    if not evaluate_test:
        metrics["test_evaluated"] = False
        _write_json(out / "metrics.json", metrics)
        return twin, metrics
    test_idx = np.asarray(data["test_idx"], dtype=np.int64)
    y = np.asarray(data["z_target"])[test_idx]
    pred = predict_twin(twin, data, test_idx, batch_size=batch)
    metrics = {"mode": mode, "seed": int(seed), "epochs_completed": len(history),
               "best_val_normalized_mse": best, "test": _metrics(y, pred),
               "test_control": _metrics(control_values(y), control_values(pred)),
               "elapsed_s": time.monotonic() - start}
    np.savez_compressed(out / "test_predictions.npz", indices=test_idx,
                        time_ns=np.asarray(data["time_ns"])[test_idx], y=y, pred=pred, error=pred - y)
    with (out / "test_predictions.csv").open("w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["sample_index", "time_ns"] + [f"y_{i}" for i in range(twin.z_dim)] +
                        [f"pred_{i}" for i in range(twin.z_dim)])
        writer.writerows([[int(ix), int(ts), *yi.tolist(), *pi.tolist()]
                          for ix, ts, yi, pi in zip(test_idx, np.asarray(data["time_ns"])[test_idx], y, pred)])
    _write_json(out / "metrics.json", metrics)
    return twin, metrics


def hurdle_loss(prediction: Tensor, gate_logits: Tensor, target: Tensor,
                raw_action: Tensor, *, zero_threshold: float = 1e-6,
                w_bce: float = 1.0, w_reg: float = 1.0, w_sparse: float = 0.1,
                huber_delta: float = 1.0) -> Tensor:
    """Gate labels use physical actions, retaining the meaning of exact no-change."""
    nonzero = (raw_action.abs() > zero_threshold).to(prediction.dtype)
    bce = F.binary_cross_entropy_with_logits(gate_logits, nonzero)
    regression = F.huber_loss(prediction, target, delta=huber_delta, reduction="none")
    regression = (regression * nonzero).sum() / nonzero.sum().clamp_min(1.0)
    sparse = (prediction.abs() * (1.0 - nonzero)).mean()
    return w_bce * bce + w_reg * regression + w_sparse * sparse


def fit_bc(data: dict, stats: dict, twin: Twin, seed: int, config: dict, outdir) -> tuple[Actor, dict]:
    cfg = config["training"]
    seed_everything(seed, cfg.get("threads", 4))
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    twin.eval()
    for parameter in twin.parameters():
        parameter.requires_grad_(False)
    arrays = _inputs(data)
    batch = int(cfg.get("batch_size", 256))
    states = encode_states(twin, data, batch_size=batch)
    actor = Actor(twin.state_dim, twin.u_dim, hidden=int(cfg.get("hidden", 128)))
    scale = torch.as_tensor(stats["action_scale"], dtype=torch.float32)
    if scale.shape != (twin.u_dim,) or not (scale > 0).all():
        raise ValueError("action_scale must contain a positive scale per MV")
    targets = torch.clamp(arrays["action"] / scale, -1.0, 1.0)
    optimizer = torch.optim.AdamW(actor.parameters(), lr=float(cfg.get("bc_lr", cfg.get("lr", 1e-3))),
                                 weight_decay=float(cfg.get("weight_decay", 1e-4)))
    epochs = int(cfg.get("bc_epochs", cfg.get("epochs", 20)))
    patience = int(cfg.get("patience", 4))
    if min(batch, epochs, patience) <= 0:
        raise ValueError("batch_size, epochs and patience must be positive")
    loss_kwargs = {"zero_threshold": float(cfg.get("action_zero_threshold", 1e-6)),
                   "w_bce": float(cfg.get("bc_gate_weight", 1.0)),
                   "w_reg": float(cfg.get("bc_regression_weight", 1.0)),
                   "w_sparse": float(cfg.get("bc_sparse_weight", 0.1)),
                   "huber_delta": float(cfg.get("bc_huber_delta", 1.0))}
    rng = np.random.default_rng(seed)
    best = float("inf")
    stale = 0
    history = []
    start = time.monotonic()
    for epoch in range(1, epochs + 1):
        actor.train()
        train_sum = 0.0
        for idx in _batches(data["train_idx"], batch, rng):
            prediction, logits, _ = actor.forward_details(states[idx])
            loss = hurdle_loss(prediction, logits, targets[idx], arrays["action"][idx], **loss_kwargs)
            if not torch.isfinite(loss):
                raise FloatingPointError("nonfinite BC training loss")
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(actor.parameters(), float(cfg.get("grad_clip", 1.0)))
            optimizer.step()
            train_sum += float(loss.detach()) * len(idx)
        actor.eval()
        val_sum = 0.0
        with torch.no_grad():
            for idx in _batches(data["val_idx"], batch):
                prediction, logits, _ = actor.forward_details(states[idx])
                loss = hurdle_loss(prediction, logits, targets[idx], arrays["action"][idx], **loss_kwargs)
                val_sum += float(loss) * len(idx)
        val_loss = val_sum / len(data["val_idx"])
        row = {"epoch": epoch, "train_hurdle_loss": train_sum / len(data["train_idx"]),
               "val_hurdle_loss": val_loss, "elapsed_s": time.monotonic() - start}
        history.append(row)
        _write_json(out / "history.json", history)
        print(f"bc[{twin.mode}] seed={seed} epoch={epoch}/{epochs} "
              f"train={row['train_hurdle_loss']:.6f} val={val_loss:.6f}", flush=True)
        if val_loss < best - float(cfg.get("min_delta", 1e-5)):
            best = val_loss
            stale = 0
            torch.save({"kind": "actor", "model_config": actor_config(actor),
                        "state_dict": actor.state_dict(), "seed": int(seed), "epoch": epoch,
                        "best_val_loss": best, "training_config": cfg,
                        "twin_mode": twin.mode, "action_scale": list(stats["action_scale"]),
                        "action_bound": list(stats["action_bound"]), "loss_config": loss_kwargs}, out / "actor.pt")
        else:
            stale += 1
        if stale >= patience:
            break
    actor = load_actor(out / "actor.pt")
    test_idx = np.asarray(data["test_idx"], dtype=np.int64)
    with torch.no_grad():
        normalized_prediction = torch.cat([actor(states[idx]) for idx in _batches(test_idx, batch)]).numpy()
    y = arrays["action"][test_idx].numpy()
    pred = normalized_prediction * np.asarray(stats["action_scale"], dtype=np.float32)
    metrics = {"seed": int(seed), "twin_mode": twin.mode, "epochs_completed": len(history),
               "best_val_hurdle_loss": best, "test_action": _metrics(y, pred),
               "test_normalized_action": _metrics(y / scale.numpy(), normalized_prediction),
               "target_clip_fraction_train": float((arrays["action"][data["train_idx"]].abs() > scale).float().mean()),
               "elapsed_s": time.monotonic() - start}
    np.savez_compressed(out / "test_actions.npz", indices=test_idx,
                        time_ns=np.asarray(data["time_ns"])[test_idx], y=y, pred=pred, normalized_pred=normalized_prediction)
    with (out / "test_actions.csv").open("w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["sample_index", "time_ns"] + [f"y_action_{i}" for i in range(twin.u_dim)] +
                        [f"pred_action_{i}" for i in range(twin.u_dim)])
        writer.writerows([[int(ix), int(ts), *yi.tolist(), *pi.tolist()]
                          for ix, ts, yi, pi in zip(test_idx, np.asarray(data["time_ns"])[test_idx], y, pred)])
    _write_json(out / "metrics.json", metrics)
    return actor, metrics
