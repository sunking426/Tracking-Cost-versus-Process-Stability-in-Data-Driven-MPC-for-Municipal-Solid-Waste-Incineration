"""Preparation and compatibility gates for the frozen Ridge policy study."""
from __future__ import annotations
import argparse
import hashlib
import json
import shutil
from pathlib import Path
import numpy as np
import torch
from threadpoolctl import threadpool_limits
from .data import load_data, MINUTE_NS
from .control import project_normalized_actions, reward_and_violation
from .ridge_dynamics import RidgeDynamics
from .ridge_policy import ACTIVE, INACTIVE, PolicyContext, Execution, RidgePolicyEnv, policy_numeric
from .ridge_control_probe import fixed_candidates, bc_request, grid_plan, FIXED
from .ridge_response import analytic_responses

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'experiment_runs/ridge_policy_pipeline_20261107'
REF=ROOT/'experiment_runs/ridge_control_probe_20261106'
DESIGN=ROOT/'experiment_protocols/ridge_policy_pipeline_20261107_v2'
SEEDS=(11,23,37,53,71)
MODELS=('full','early','middle','late','pooled_matched')
GROUPS=('bc','ridge_td3bc','offline_td3bc','twin_td3','sensor_td3bc','no_policy_retrieval')

def read_npz(path):
    with np.load(path,allow_pickle=False) as f:return {k:f[k] for k in f.files}

def write_json(path,obj):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    Path(path).write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def shared():
    stats=json.loads((REF/'stats.json').read_text())
    execution=Execution(stats,read_npz(REF/'support.npz'))
    context=PolicyContext(read_npz(OUT/'policy_context.npz'),stats) if (OUT/'policy_context.npz').exists() else None
    model=RidgeDynamics.load(REF/'evaluation_models/full.npz')
    return stats,execution,context,model

def input_rows(data,ids):
    return {**{k:np.asarray(data[k][ids]) for k in ('u_hist','z_hist','z_current','time_ns')},'indices':np.asarray(ids)}

def episode_exclusion(data,ids):
    return (np.minimum(data['source_start_ns'][ids],data['time_ns'][ids]-10*MINUTE_NS),
            np.maximum(data['source_end_ns'][ids],data['time_ns'][ids]+10*MINUTE_NS),data['visual_time_ns'][ids])

def eligible(data,stats,split):
    ids=np.asarray(data[split+'_idx']); child=data['next_idx'][ids];safe=np.maximum(child,0)
    keep=(child>=0)&np.isin(safe,ids)&(data['time_ns'][safe]-data['time_ns'][ids]==MINUTE_NS)
    all_ids=ids[keep];nxt=data['next_idx'][all_ids]
    u=np.asarray(data['u_current'],dtype=np.float64);raw=np.asarray(data['action'][all_ids],dtype=np.float64)
    if not np.allclose(raw,u[nxt]-u[all_ids],atol=2e-4,rtol=1e-5):raise AssertionError('logged delta provenance mismatch')
    low,high,bound,scale=[np.asarray(stats[k]) for k in ('u_low','u_high','action_bound','action_scale')]
    bounded=((u[all_ids]>=low)&(u[all_ids]<=high)&(u[nxt]>=low)&(u[nxt]<=high)).all(1)
    action_ok=(np.abs(raw)<=bound+1e-5).all(1)
    ids=all_ids[bounded&action_ok];raw=np.asarray(data['action'][ids],dtype=np.float64)
    _,executed,_=project_normalized_actions(torch.from_numpy(raw/scale),torch.from_numpy(u[ids]),stats)
    if not np.allclose(executed.numpy(),raw,atol=2e-4,rtol=1e-5):raise AssertionError('logged delta changed under projection')
    return all_ids,ids,{'continuous':len(all_ids),'retained':len(ids),'excluded':int(len(all_ids)-len(ids)),
        'source_delta_max_difference':float(np.max(np.abs(np.asarray(data['action'][ids],float)-(u[data['next_idx'][ids]]-u[ids])))),
        'projection_max_difference':float(np.max(np.abs(executed.numpy()-raw))),
        'action_storage':'original physical recorded delta / action_scale; no restricted-action relabelling',
        'source_rounding_atol':2e-4,'source_rounding_rtol':1e-5,'absolute_bounds_tolerance':0.0}

def block_states(data,ids,context):
    """Contiguous nonoverlapping <=10-transition blocks; no fabricated terminal."""
    nxt=data['next_idx'][ids];blocks=[];start=0
    for i in range(1,len(ids)+1):
        if i==len(ids) or i-start==10 or ids[i]!=nxt[i-1]:
            blocks.append((start,i));start=i
    lo=np.empty(len(ids),dtype=np.int64);hi=lo.copy();caps=np.full((len(ids),11),-1,dtype=np.int64);roots=lo.copy()
    for a,b in blocks:
        source=np.r_[ids[a:b],nxt[b-1]];root=ids[a]
        lo[a:b]=min(int(data['source_start_ns'][source].min()),int(data['time_ns'][root]-10*MINUTE_NS))
        hi[a:b]=max(int(data['source_end_ns'][source].max()),int(data['time_ns'][root]+10*MINUTE_NS))
        caps[a:b,:len(source)]=data['visual_time_ns'][source];roots[a:b]=root
    exclusion=(lo,hi,caps)
    x=policy_numeric(data['u_hist'][ids],data['z_hist'][ids],data['z_current'][ids])
    xn=policy_numeric(data['u_hist'][nxt],data['z_hist'][nxt],data['z_current'][nxt])
    visual,donor=context.query(x,exclusion);visual_next,donor_next=context.query(xn,exclusion)
    rootx=policy_numeric(data['u_hist'][roots],data['z_hist'][roots],data['z_current'][roots])
    frozen,frozen_donor=context.query(rootx,exclusion)
    return {'state':context.features(x,visual),'next_state':context.features(xn,visual_next),
        'hold_state':context.features(x,frozen),'hold_next_state':context.features(xn,frozen),
        'donor':donor,'next_donor':donor_next,'hold_donor':frozen_donor,'block_root':roots,
        'exclusion_low':lo,'exclusion_high':hi,'excluded_captures':caps}

def support_counts(data,ids,execution):
    raw=np.asarray(data['action'][ids],float);times=data['time_ns'][ids]
    exact=(raw[:,INACTIVE]==0).all(1);near=(np.abs(raw[:,INACTIVE])<=1e-6).all(1)
    days=times//(1440*MINUTE_NS)
    return {'rows':len(ids),'days':len(np.unique(days)),
        'exact_six_zero':{'count':int(exact.sum()),'fraction':float(exact.mean()),'days':len(np.unique(days[exact]))},
        'near_six_zero_1e_minus6':{'count':int(near.sum()),'fraction':float(near.mean()),'days':len(np.unique(days[near]))},
        'active_nonzero_counts':(np.abs(raw[:,ACTIVE])>1e-6).sum(0).tolist(),
        'active_within_small_budget_fraction':(np.abs(raw[:,ACTIVE])<=.1*execution.bound[ACTIVE]).mean(0).tolist()}

def prepare():
    if OUT.exists() and any(OUT.iterdir()):raise FileExistsError('new study folder required')
    OUT.mkdir(parents=True)
    data,stats,_=load_data(ROOT/'experiment_runs/corrected_vision/data')
    if stats!=json.loads((REF/'stats.json').read_text()):raise AssertionError('statistics differ')
    frozen=json.loads((DESIGN/'design_frozen.json').read_text())
    write_json(OUT/'design_at_start.json',frozen)
    shutil.copy2(DESIGN/'protocol.json',OUT/'protocol.json')
    execution=Execution(stats,read_npz(REF/'support.npz'));context=PolicyContext.fit(data,stats)
    np.savez_compressed(OUT/'policy_context.npz',**context.v)
    all_train,train_ids,elig=eligible(data,stats,'train')
    audit={'all_continuous_training':support_counts(data,all_train,execution),'critic_training_pool':support_counts(data,train_ids,execution),'eligibility':elig}
    u=np.asarray(data['u_current'][train_ids],float);z=data['z_current'][train_ids];t=data['time_ns'][train_ids]
    raw=np.asarray(data['action'][train_ids],float)
    distance,supported,_=execution.support.query(u,z,raw,t)
    audit['raw_eight_action_support_fraction']=float(supported.mean())
    audit['support_backend_audit']=execution.support.audit(u[:1024],z[:1024],raw[:1024],t[:1024])
    audit['nine_candidate_support']=[]
    for candidate in fixed_candidates(stats,FIXED):
        query=np.broadcast_to(candidate,u.shape).copy();scr=execution.screen(query,u,z,t)
        audit['nine_candidate_support'].append({'request':candidate.tolist(),'supported_fraction':float(scr['supported'].mean()),'admitted_fraction':float(scr['admitted'].mean()),'full_execution_fraction':float(scr['complete'].mean())})
    for split in ('train','val'):
        _,ids,eligibility=eligible(data,stats,split);nxt=data['next_idx'][ids]
        # Validation queries are disjoint from the train memory; the same block
        # exclusion code also makes this invariant explicit.
        states=block_states(data,ids,context)
        b=np.clip(np.asarray(data['action'][ids],float)[:,ACTIVE]/(.1*execution.bound[ACTIVE]),-1,1)
        actual,proposal,blocked=execution.apply(execution.request(b),data['u_current'][ids],data['z_current'][ids],data['time_ns'][ids])
        action=np.asarray(data['action'][ids],float)/execution.scale
        reward,_,_=reward_and_violation(data['z_current'][nxt],action,stats)
        values={**states,'indices':ids,'next_indices':nxt,'action':action.astype(np.float32),'reward':reward[:,None],
            'u':data['u_current'][ids].astype(float),'z':data['z_current'][ids].astype(float),'times':data['time_ns'][ids],
            'next_u':data['u_current'][nxt].astype(float),'next_z':data['z_current'][nxt].astype(float),'next_times':data['time_ns'][nxt],
            'b_ref':(actual['executed'][:,ACTIVE]/execution.m).astype(np.float32),
            'physical_ref':actual['physical'][:,ACTIVE].astype(np.float32)}
        np.savez_compressed(OUT/f'logged_{split}.npz',**values)
        summary={'eligibility':eligibility,'reference_rejected_fraction':float(blocked.mean()),'reference_supported_fraction':float(proposal['supported'].mean()),
            'raw_active_exceeds_small_budget_fraction':float((np.abs(data['action'][ids][:,ACTIVE])>.1*execution.bound[ACTIVE]).any(1).mean()),
            'reference_nonzero_counts':(np.abs(values['physical_ref'])>1e-6).sum(0).tolist(),
            'block_count':len(np.unique(states['block_root']))}
        audit[split+'_reference']=summary
        if len(ids)<256 or np.any((np.abs(values['physical_ref'])>1e-6).sum(0)==0):raise AssertionError('reference sample availability gate failed')
    # Model rollouts only require bounded initial MV, independent of factual next MV.
    train=data['train_idx'];current=data['u_current'][train]
    resets=train[((current>=np.asarray(stats['u_low']))&(current<=np.asarray(stats['u_high']))).all(1)]
    np.save(OUT/'training_reset_indices.npy',resets)
    audit['training_reset_count']=len(resets);audit['status']='passed_availability_only_not_causal_validation'
    audit['interpretation']='Synthetic target-action coverage is supplied by a fitted model, not by new plant interventions.'
    write_json(OUT/'support_audit.json',audit)
    source=[REF/'support.npz',REF/'stats.json',ROOT/'experiment_runs/corrected_vision/data/dataset.npz',DESIGN/'protocol.json']
    source += list((REF/'evaluation_models').glob('*.npz'))+list((REF/'inputs').glob('*.npz'))
    write_json(OUT/'input_hashes.json',{str(p):sha(p) for p in source})
    print(json.dumps(audit,ensure_ascii=False),flush=True)

def calibrate():
    stats,execution,context,planner=shared();bc=read_npz(REF/'models/linear_bc.npz')
    kernel=analytic_responses(planner,10)['step'];results=[]
    for split in ('val','test'):
        row=read_npz(REF/f'inputs/{split}.npz')
        for mid in MODELS:
            model=RidgeDynamics.load(REF/f'evaluation_models/{mid}.npz')
            for policy in ('hold','linear_bc','grid_mpc'):
                env=RidgePolicyEnv(model,execution,horizon=10);env.reset(options={'inputs':row});buffers={}
                for step in range(10):
                    if policy=='hold':a=np.zeros((len(env.u),8))
                    elif policy=='linear_bc':a=bc_request(bc,env.u,env.z,env.current,stats,FIXED)
                    else:a,_=grid_plan(planner,kernel,env.u,env.z,env.current,env.times,execution.support.values,stats,FIXED)
                    _,_,terminated,truncated,info=env.step_request(a)
                    if terminated.any() or truncated.any()!=(step==9):raise AssertionError('termination contract')
                    for k,v in info.items():buffers.setdefault(k,[]).append(v)
                old=read_npz(REF/f'trajectories/{split}/{mid}/{policy}.npz')
                new={k:np.stack(v,axis=1) for k,v in buffers.items()};errors={}
                for k,v in new.items():
                    if v.dtype==bool:
                        if not np.array_equal(v,old[k]):raise AssertionError(f'{split}/{mid}/{policy}/{k}')
                    else:
                        atol=1e-6 if k in ('reward','tracking','oxygen','movement','violation_cost') else 1e-8
                        if k in ('executed_action','physical_executed_action','requested_action'):atol=1e-10
                        if not np.allclose(v,old[k],atol=atol,rtol=1e-10):raise AssertionError(f'{split}/{mid}/{policy}/{k}: {np.max(np.abs(v-old[k]))}')
                        errors[k]=float(np.max(np.abs(v-old[k])))
                mean=float(new['reward'].astype(float).sum(1).mean());oldmean=float(old['reward'].astype(float).sum(1).mean())
                if abs(mean-oldmean)>1e-5:raise AssertionError('return compatibility')
                results.append({'split':split,'model':mid,'policy':policy,'mean_return':mean,'mean_return_difference':mean-oldmean,'errors':errors})
                print('compatible',split,mid,policy,mean,flush=True)
    write_json(OUT/'environment_compatibility.json',{'status':'passed','cases':results,'trajectories':30*256,'steps':30*256*10})

def main():
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['prepare','calibrate']);args=parser.parse_args()
    torch.set_num_threads(4)
    with threadpool_limits(4):globals()[args.stage]()

if __name__=='__main__':main()
