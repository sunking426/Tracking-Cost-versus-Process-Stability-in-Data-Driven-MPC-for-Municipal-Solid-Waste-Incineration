"""Source-checked tables and figures for frozen RGB utilization probes.

This renderer reads completed model records only. It fits no models, does not
select test winners, and preserves all candidates and their validation scores.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from .visual_diagnostics_report import _pyplot, _save_figure, _style_axis
from .visual_diagnostics_statistics import CONTROL_NAMES, DAY_NS
from .visual_representation_report import _csv, _json, _sha
from .visual_utilization_probe import DIMENSIONS, HORIZONS, RHOS, RHO_TIE_ORDER, candidate_name


QUANTITIES_ZH = ("炉膛温度", "负压", "蒸汽流量", "氧浓度")
UNITS = ("°C", "Pa", "t/h", "vol%")
CANDIDATES = tuple(candidate_name(d, r) for d in DIMENSIONS for r in RHOS)
METHODS = ("quality", *CANDIDATES, "matched_null", "adaptive_rgb", "old52_reference")
RHO_COLORS = {.1: "#ff7f0e", 1.: "#1f77b4", 10.: "#2ca02c"}
REFERENCE_ROWS = (
    ("quality", "数值＋时序＋质量基线", "#1f77b4", "o"),
    ("rgb32_rho1", "固定32维、ρ=1", "#ff7f0e", "s"),
    ("matched_null", "同容量错配编码", "#2ca02c", "D"),
    ("old52_reference", "原52维描述符", "#777777", "^"),
)


def _add_source(path, root, sources):
    path = Path(path).resolve()
    try:
        name = path.relative_to(root).as_posix()
    except ValueError:
        name = str(path)
    sources[name] = _sha(path)


def _check_selection(cell):
    methods = cell["methods"]
    selected = min(CANDIDATES, key=lambda name: (
        methods[name]["selected_val_score"], methods[name]["visual_dimension"],
        RHO_TIE_ORDER[float(methods[name]["rho"])], methods[name]["alpha"]))
    alias = methods["adaptive_rgb"]
    if cell["adaptive_selected"] != selected or alias["selected_candidate"] != selected:
        raise ValueError("Adaptive record disagrees with validation selection")
    for name in ("quality", *CANDIDATES, "matched_null", "adaptive_rgb"):
        row = methods[name]
        alphas, scores = np.asarray(row["alphas"]), np.asarray(row["val_normalized_mse"])
        if alphas.ndim != 1 or scores.shape != alphas.shape or not len(scores) or not np.isfinite(scores).all():
            raise ValueError("Invalid validation candidate scores")
        best = min(range(len(scores)), key=lambda i: (scores[i], alphas[i]))
        if row["alpha"] != alphas[best] or row["selected_val_score"] != scores[best]:
            raise ValueError("Saved alpha disagrees with validation scores")
    for key in ("visual_dimension", "rho", "alpha", "selected_val_score"):
        if alias[key] != methods[selected][key]:
            raise ValueError("Adaptive alias differs from its selected fit")
    null = methods["matched_null"]
    if (null["visual_dimension"] != alias["visual_dimension"] or null["rho"] != alias["rho"]
            or not null["null"] or alias["null"]):
        raise ValueError("Null comparator does not match selected visual capacity")


def load_completed_utilization(study_dir):
    """Verify 39 test records, including aliases and external references."""
    root = Path(study_dir).resolve(); probe = root/"probe"
    files = {name: probe/name for name in ("results.json", "protocol.json", "completed.json", "artifact_hashes.json")}
    result, protocol, complete, hashes = [json.loads(path.read_text()) for path in files.values()]
    if (result["status"] != "completed" or complete["status"] != "completed"
            or complete["selected_fits"] != 33 or complete["adaptive_aliases"] != 3
            or complete["external_old52_references"] != 3
            or complete["results_sha256"] != _sha(files["results.json"])
            or complete["protocol_sha256"] != _sha(files["protocol.json"])
            or complete["artifact_hashes_sha256"] != _sha(files["artifact_hashes.json"])
            or result["protocol"] != protocol):
        raise ValueError("Utilization probe is incomplete or inconsistent with completion hashes")
    if (protocol["horizons_minutes"] != list(HORIZONS) or protocol["visual_dimensions"] != list(DIMENSIONS)
            or protocol["rhos"] != list(RHOS) or protocol["targets"] != list(CONTROL_NAMES)
            or set(result["horizons"]) != {str(h) for h in HORIZONS}
            or protocol["intervals"]["multiple_comparison_adjustment"] != "none"):
        raise ValueError("Unexpected utilization protocol")
    sources = {}; arrays = {}; checks = []
    for path in files.values(): _add_source(path, root, sources)
    for horizon in HORIZONS:
        cell = result["horizons"][str(horizon)]
        if set(cell["methods"]) != set(METHODS):
            raise ValueError("Missing candidate, alias or reference in result")
        _check_selection(cell)
        n = cell["eligible_counts"]["test"]; shared = None; arrays[horizon] = {}
        for method in METHODS:
            metric = cell["methods"][method]
            if method == "old52_reference":
                path = Path(metric["split_metrics"]["test"]["predictions_file"])
            else:
                path = probe/f"horizon_{horizon:02d}"/method/"test_predictions.npz"
                if _sha(path) != hashes[str(path.relative_to(probe))]:
                    raise ValueError("Current prediction artifact hash mismatch")
            if _sha(path) != metric["predictions_sha256"]:
                raise ValueError("Prediction differs from saved metric hash")
            with np.load(path, allow_pickle=False) as saved:
                row = {k: saved[k].copy() for k in ("indices", "destination_indices", "time_ns",
                        "destination_time_ns", "truth", "pred", "error")}
            if (row["truth"].shape != (n, 4) or row["pred"].shape != (n, 4) or row["error"].shape != (n, 4)
                    or not all(np.isfinite(row[k]).all() for k in ("truth", "pred", "error"))
                    or not np.array_equal(row["error"], row["pred"]-row["truth"])):
                raise ValueError("Invalid saved prediction array")
            identities = ("indices", "destination_indices", "time_ns", "destination_time_ns", "truth")
            if any(row[k].shape != (n,) for k in identities[:-1]):
                raise ValueError("Invalid paired identity vector")
            if shared is None: shared = row
            elif any(not np.array_equal(shared[k], row[k]) for k in identities):
                raise ValueError("Methods do not share identical samples, times and truth")
            if not np.all(row["destination_time_ns"]-row["time_ns"] == (horizon-1)*60_000_000_000):
                raise ValueError("Incorrect forecast time span")
            mae = np.abs(row["error"]).mean(axis=0); rmse = np.sqrt(np.square(row["error"]).mean(axis=0))
            if not (np.allclose(mae, metric["mae"], rtol=0, atol=1e-10)
                    and np.allclose(rmse, metric["rmse"], rtol=0, atol=1e-10)):
                raise ValueError("Saved MAE/RMSE disagree with predictions")
            arrays[horizon][method] = row; _add_source(path, root, sources)
            checks.append({"horizon": horizon, "method": method, "samples": n,
                           "role": metric["role"], "hash_metrics_pairing_verified": True})
        chosen = cell["adaptive_selected"]
        if not np.array_equal(arrays[horizon]["adaptive_rgb"]["pred"], arrays[horizon][chosen]["pred"]):
            raise ValueError("Adaptive predictions do not equal selected candidate predictions")
        days = shared["time_ns"]//DAY_NS
        for key, contrast in cell["comparisons"].items():
            a, b = contrast["candidate"], contrast["reference"]
            expected = (np.abs(arrays[horizon][b]["error"])-np.abs(arrays[horizon][a]["error"])).mean(axis=0)
            lo, hi = np.asarray(contrast["ci_lower"]), np.asarray(contrast["ci_upper"])
            if (key != a+"_vs_"+b or not np.allclose(expected, contrast["difference"], rtol=0, atol=1e-10)
                    or lo.shape != (4,) or hi.shape != (4,) or not np.isfinite(np.r_[lo,hi]).all()
                    or np.any(lo > hi) or contrast["samples"] != n or contrast["time_blocks"] != len(np.unique(days))
                    or contrast["multiple_comparison_adjustment"] != "none" or not contrast["exploratory"]
                    or contrast["deterministic_fits"] != 1):
                raise ValueError("Invalid paired contrast or interval metadata")
        required = {name+"_vs_quality" for name in CANDIDATES}
        required |= {"adaptive_rgb_vs_"+ref for ref, *_ in REFERENCE_ROWS}
        if not required.issubset(cell["comparisons"]):
            raise ValueError("Required complete contrasts are missing")
    return result, arrays, sources, checks


def export_utilization_tables(root, result, arrays):
    """Keep all candidates, all quantities and every saved validation score."""
    root = Path(root); out = root/"statistics"; out.mkdir(exist_ok=True)
    overall=[]; daily=[]; comparisons=[]; selections=[]; choices=[]; contributions=[]
    for h in HORIZONS:
        cell = result["horizons"][str(h)]
        chosen = cell["methods"]["adaptive_rgb"]
        choices.append({"horizon_minutes": h, "selected_candidate": cell["adaptive_selected"],
                        "visual_dimension": chosen["visual_dimension"], "rho": chosen["rho"],
                        "alpha": chosen["alpha"], "validation_mse": chosen["selected_val_score"],
                        "selection_data": "validation only; alias, not an extra fit"})
        for method in METHODS:
            row = cell["methods"][method]
            for q,name in enumerate(CONTROL_NAMES):
                overall.append({"horizon_minutes": h,"method": method,"role": row["role"],"quantity": name,"unit": UNITS[q],
                    "samples": row["samples"],"visual_dimension": row.get("visual_dimension", ""),"rho": row.get("rho", ""),
                    "alpha": row.get("alpha", ""),"validation_mse": row.get("selected_val_score", ""),
                    "mae": row["mae"][q],"rmse": row["rmse"][q],"selected_candidate": row.get("selected_candidate", "")})
            saved = arrays[h][method]; days = saved["time_ns"]//DAY_NS
            for day in np.unique(days):
                error = saved["error"][days==day]
                for q,name in enumerate(CONTROL_NAMES):
                    daily.append({"horizon_minutes": h,"method": method,"quantity": name,"unit": UNITS[q],
                                  "origin_calendar_date": str(np.datetime64(int(day), "D")),"samples": len(error),
                                  "mae": float(np.abs(error[:,q]).mean()),"rmse": float(np.sqrt(np.square(error[:,q]).mean()))})
            if row["role"] == "selected fit":
                for alpha,score in zip(row["alphas"], row["val_normalized_mse"]):
                    selections.append({"horizon_minutes": h,"method": method,"visual_dimension": row["visual_dimension"],
                                       "rho": row["rho"],"alpha_candidate": alpha,"validation_mse": score,
                                       "selected_alpha": alpha == row["alpha"],"adaptive_selected": method == cell["adaptive_selected"]})
            for split, metrics in row["split_metrics"].items():
                if "visual_contribution" not in metrics: continue
                c = metrics["visual_contribution"]
                for q,name in enumerate(CONTROL_NAMES):
                    contributions.append({"horizon_minutes":h,"method":method,"role":row["role"],"split":split,
                                          "quantity":name,"unit":UNITS[q],"visual_linear_term_rms":c["rms"][q],
                                          "visual_linear_term_sd":c["sd"][q],"visual_linear_term_mean":c["mean"][q],
                                          "scope":c["scope"]})
        for key,row in cell["comparisons"].items():
            for q,name in enumerate(CONTROL_NAMES):
                comparisons.append({"horizon_minutes":h,"comparison":key,"candidate":row["candidate"],"reference":row["reference"],
                    "quantity":name,"unit":UNITS[q],"endpoint_priority":row["endpoint_priorities"][name],
                    "mae_reduction":row["difference"][q],"ci_lower":row["ci_lower"][q],"ci_upper":row["ci_upper"][q],
                    "samples":row["samples"],"calendar_days":row["time_blocks"],"confidence_level":row["confidence_level"],
                    "draws":row["draws"],"multiple_comparison_adjustment":"none","exploratory":True,
                    "includes_validation_selection_uncertainty":False})
    paths=[]
    for name,rows in [("overall.csv",overall),("comparisons.csv",comparisons),("per_day.csv",daily),
                      ("validation_candidates.csv",selections),("adaptive_choices.csv",choices),("visual_contribution.csv",contributions)]:
        path=out/name;_csv(path,rows);paths.append(path)
    return paths


def dimension_figure(plt, result):
    figure,axes=plt.subplots(2,2,figsize=(14,10)); cell=result["horizons"]["5"]
    x=np.arange(3,dtype=float)
    for q,ax in enumerate(axes.flat):
        for rho,offset,marker in ((.1,-.07,'s'),(1.,0.,'o'),(10.,.07,'^')):
            rows=[cell['comparisons'][candidate_name(d,rho)+'_vs_quality'] for d in DIMENSIONS]
            mean=np.asarray([r['difference'][q] for r in rows]);lo=np.asarray([r['ci_lower'][q] for r in rows]);hi=np.asarray([r['ci_upper'][q] for r in rows])
            color=RHO_COLORS[rho]
            ax.plot(x+offset,mean,marker=marker,color=color,lw=1.4,label=f'ρ={rho:g}')
            ax.vlines(x+offset,lo,hi,color=color,lw=1.2)
            ax.hlines(lo,x+offset-.035,x+offset+.035,color=color,lw=1)
            ax.hlines(hi,x+offset-.035,x+offset+.035,color=color,lw=1)
        ax.axhline(0,color='black',ls='--',lw=.9)
        ax.set_xticks(x,['32维 PCA','128维 PCA','512维原始编码']);ax.set_xlim(-.25,2.25)
        ax.set_title(QUANTITIES_ZH[q]);ax.set_ylabel(f'相对质量基线的MAE减小量（{UNITS[q]}）');_style_axis(ax,grid_axis='y')
    handles,labels=axes[0,0].get_legend_handles_labels()
    figure.legend(handles,labels,loc='upper center',bbox_to_anchor=(.5,.925),ncol=3,frameon=False)
    figure.suptitle('5分钟预测：保留更多RGB维度与调整视觉约束',fontsize=17,y=.98)
    n=cell['eligible_counts']['test'];days=cell['comparisons'][CANDIDATES[0]+'_vs_quality']['time_blocks']
    caption=(f'正值表示误差减小；对照含数值历史、采集时序与质量/颜色统计。{n:,} 个共同测试窗口，{days} 个日历日。\n'
             'ρ是标准化后的视觉/基础系数惩罚比：ρ<1视觉约束较弱，ρ>1较强；每组α只由验证集选择。\n'
             '512维原始编码同时改变维数和坐标基底。横轴为配置类别；日块95%探索性区间未校正多重比较，也未覆盖验证选型不确定性。')
    figure.text(.5,.025,caption,ha='center',va='bottom',fontsize=10)
    figure.subplots_adjust(left=.10,right=.98,top=.82,bottom=.17,wspace=.34,hspace=.43)
    return figure


def adaptive_figure(plt,result):
    figure,axes=plt.subplots(2,2,figsize=(14,10));x=np.asarray(HORIZONS,dtype=float)
    offsets=(-.24,-.08,.08,.24)
    for q,ax in enumerate(axes.flat):
        for (reference,label,color,marker),offset in zip(REFERENCE_ROWS,offsets):
            rows=[result['horizons'][str(h)]['comparisons']['adaptive_rgb_vs_'+reference] for h in HORIZONS]
            mean=np.asarray([r['difference'][q] for r in rows]);lo=np.asarray([r['ci_lower'][q] for r in rows]);hi=np.asarray([r['ci_upper'][q] for r in rows])
            ax.plot(x+offset,mean,marker=marker,color=color,lw=1.3,label=label)
            ax.vlines(x+offset,lo,hi,color=color,lw=1.1)
            ax.hlines(lo,x+offset-.10,x+offset+.10,color=color,lw=.9)
            ax.hlines(hi,x+offset-.10,x+offset+.10,color=color,lw=.9)
        ax.axhline(0,color='black',ls='--',lw=.9);ax.set_xticks(x,[str(h) for h in HORIZONS]);ax.set_xlim(.3,10.7)
        ax.set_xlabel('预测时域（分钟）');ax.set_ylabel(f'对照MAE－选定RGB方案MAE（{UNITS[q]}）')
        ax.set_title(QUANTITIES_ZH[q]);_style_axis(ax,grid_axis='y')
    handles,labels=axes[0,0].get_legend_handles_labels()
    figure.legend(handles,labels,loc='upper center',bbox_to_anchor=(.5,.93),ncol=2,frameon=False,fontsize=11)
    figure.suptitle('验证集选定的RGB方案：相对各对照的预测差异',fontsize=17,y=.99)
    selected='；'.join(f"{h}分钟：{result['horizons'][str(h)]['methods']['adaptive_rgb']['visual_dimension']}维/ρ={result['horizons'][str(h)]['methods']['adaptive_rgb']['rho']:g}" for h in HORIZONS)
    counts='/'.join(f"{result['horizons'][str(h)]['eligible_counts']['test']:,}" for h in HORIZONS)
    caption=(f'正值表示选定RGB方案更好。每个时域仅按验证集选维度、ρ、α；{selected}。\n'
             f'1/5/10分钟测试窗口为 {counts}，仍为既往已查看的8个日历日。日块95%探索性区间，未校正多重比较。\n'
             '区间条件于已选模型，未涵盖验证选型不确定性；错配仅为同容量负对照，不是完整选择流程的置换检验。')
    figure.text(.5,.025,caption,ha='center',va='bottom',fontsize=10)
    figure.subplots_adjust(left=.10,right=.98,top=.79,bottom=.18,wspace=.34,hspace=.43)
    return figure


def verify_figure_values(figure, result, kind):
    """Compare actual plotted line/interval coordinates to saved result rows."""
    checks=[]
    for q, ax in enumerate(figure.axes):
        if kind == 'rgb_dimension_penalty_effects':
            series=[(rho, [result['horizons']['5']['comparisons'][candidate_name(d,rho)+'_vs_quality'] for d in DIMENSIONS])
                    for rho in RHOS]
        elif kind == 'adaptive_rgb_effects':
            series=[(reference, [result['horizons'][str(h)]['comparisons']['adaptive_rgb_vs_'+reference] for h in HORIZONS])
                    for reference,*_ in REFERENCE_ROWS]
        else:
            raise ValueError('Unknown utilization figure kind')
        for i,(label,rows) in enumerate(series):
            means=np.asarray([r['difference'][q] for r in rows])
            bounds=np.asarray([[r['ci_lower'][q],r['ci_upper'][q]] for r in rows])
            plotted=np.asarray(ax.lines[i].get_ydata())
            intervals=np.asarray(ax.collections[i*3].get_segments())[:,:,1]
            if not np.array_equal(plotted,means) or not np.array_equal(intervals,bounds):
                raise ValueError('Rendered points or interval bounds differ from saved results')
            for j,row in enumerate(rows):
                checks.append({'figure':kind,'quantity':CONTROL_NAMES[q],'series':str(label),'position':j,
                               'point':float(means[j]),'ci_lower':float(bounds[j,0]),'ci_upper':float(bounds[j,1]),
                               'actual_plot_coordinates_match':True})
    return checks


def render_utilization_report(study_dir):
    root=Path(study_dir).resolve()
    result,arrays,sources,checks=load_completed_utilization(root)
    tables=export_utilization_tables(root,result,arrays)
    out=root/'figures';out.mkdir(exist_ok=True)
    plt,font=_pyplot();images=[];plot_checks=[]
    for name,builder in [('rgb_dimension_penalty_effects',dimension_figure),('adaptive_rgb_effects',adaptive_figure)]:
        figure=builder(plt,result);plot_checks.extend(verify_figure_values(figure,result,name))
        images.extend(_save_figure(figure,out,name));plt.close(figure)
    verification=out/'plot_value_verification.json'
    _json(verification,{'status':'passed','point_estimates_verified':len(plot_checks),
                        'intervals_verified':len(plot_checks),'checks':plot_checks})
    manifest={'status':'rendered_pending_visual_review','source_sha256':sources,'renderer_sha256':_sha(Path(__file__)),
              'style_helper_sha256':_sha(Path(__file__).with_name('visual_diagnostics_report.py')),
              'figure_sha256':{str(p.relative_to(root)):_sha(p) for p in images},
              'plot_value_verification_sha256':_sha(verification),
              'table_sha256':{str(p.relative_to(root)):_sha(p) for p in tables},'validated_test_records':checks,
              'fits':33,'adaptive_aliases':3,'external_old52_references':3,'chinese_font':font,
              'rho_colors':{str(k):v for k,v in RHO_COLORS.items()},
              'direction':'reference MAE minus candidate MAE; positive favors candidate',
              'contribution_scope':'linear visual output RMS/SD describes numerical use; not information gain or causal importance',
              'selection_scope':'validation-only dimension/rho/alpha choice; reported CIs condition on selected models',
              'interval_scope':result['protocol']['intervals'],'test_scope':result['protocol']['test_scope'],
              'csv_scope':'all candidate/alias/reference metrics, contrasts, day metrics, all165 alpha validation scores and all visual contribution records',
              'figure_scope':{'rgb_dimension_penalty_effects':'all9 visual configurations versus quality at5 minutes, all4 quantities',
                              'adaptive_rgb_effects':'selected RGB versus4 references at1/5/10 minutes, all4 quantities'}}
    _json(out/'utilization_figure_manifest.json',manifest)
    return manifest


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--study',required=True)
    args=parser.parse_args();print(json.dumps(render_utilization_report(args.study),ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
