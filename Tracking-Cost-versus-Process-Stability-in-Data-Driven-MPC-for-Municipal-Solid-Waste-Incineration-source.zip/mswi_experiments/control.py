"""Learned process dynamics and explicitly defined non-RL control baselines."""
from __future__ import annotations

from typing import Any, Mapping

import numpy as np
import torch
from .data import control_values as control_variables


CONTROL_NAMES = ("temperature", "pressure", "steam_flow", "oxygen")
TARGETS = np.asarray([1000.0, -50.0, 32.0, 3.8], dtype=np.float32)
TRACKING_SCALES = np.asarray([50.0, 20.0, 5.0, 0.5], dtype=np.float32)


def project_normalized_actions(
    requested: torch.Tensor, current_u: torch.Tensor, stats: Mapping[str, Any]
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Project a requested increment to the action and absolute MV envelopes.

    Return (normalized executed increment, physical executed increment, next MV).
    This is the common differentiable execution map for environment steps and
    actor/critic queries. In particular, an outward action at an MV bound
    executes zero and has zero actor gradient through that saturated component.
    """
    if requested.ndim != 2 or requested.shape != current_u.shape:
        raise ValueError("Requested actions and current MV must have matching (batch, channels) shapes")
    if not requested.is_floating_point() or not current_u.is_floating_point():
        raise ValueError("Action projection requires floating-point tensors")
    if not torch.isfinite(requested).all() or not torch.isfinite(current_u).all():
        raise FloatingPointError("Nonfinite requested action or current MV")
    current_u = current_u.to(device=requested.device, dtype=requested.dtype)
    scale, bound, low, high = (
        torch.as_tensor(stats[name], dtype=requested.dtype, device=requested.device)
        for name in ("action_scale", "action_bound", "u_low", "u_high")
    )
    if any(value.shape != (requested.shape[1],) or not torch.isfinite(value).all()
           for value in (scale, bound, low, high)):
        raise ValueError("Action statistics must be finite channel vectors")
    if torch.any(scale <= 0) or torch.any(bound < 0) or torch.any(low > high):
        raise ValueError("Invalid action scales or bounds")
    physical = requested.clamp(-1.0, 1.0) * scale
    physical = torch.maximum(torch.minimum(physical, bound), -bound)
    next_u = torch.maximum(torch.minimum(current_u + physical, high), low)
    executed = next_u - current_u
    return executed / scale, executed, next_u


def project_state_actions(
    requested: torch.Tensor, state: torch.Tensor, stats: Mapping[str, Any]
) -> torch.Tensor:
    """Return executed normalized actions for states laid out [h,u_norm,z_norm]."""
    u_dim, z_dim = len(stats["u_mean"]), len(stats["z_mean"])
    if requested.ndim != 2 or requested.shape[1] != u_dim:
        raise ValueError("Requested action dimension differs from state MV dimension")
    if state.ndim != 2 or state.shape[0] != requested.shape[0] or state.shape[1] <= u_dim + z_dim:
        raise ValueError("Expected state layout [h,u_norm,z_norm] with matching action batch")
    u_mean = state.new_tensor(stats["u_mean"])
    u_scale = state.new_tensor(stats["u_scale"])
    if u_scale.shape != (u_dim,) or not torch.isfinite(u_mean).all() or not torch.isfinite(u_scale).all() or torch.any(u_scale <= 0):
        raise ValueError("Invalid MV normalization statistics")
    current_u = state[:, -(u_dim + z_dim):-z_dim] * u_scale + u_mean
    executed, _, _ = project_normalized_actions(requested, current_u, stats)
    return executed


def reward_and_violation(
    z_next: np.ndarray, normalized_executed_action: np.ndarray, stats: Mapping[str, Any]
) -> tuple[np.ndarray, np.ndarray, dict[str, np.ndarray]]:
    """Negative next-state costs; the envelope is empirical, not certified safety."""
    cv = control_variables(z_next).astype(np.float32)
    a = np.asarray(normalized_executed_action, dtype=np.float32)
    if a.shape[:-1] != cv.shape[:-1] or a.shape[-1] != 8:
        raise ValueError("Action and CV batch shapes differ")
    if not np.isfinite(cv).all() or not np.isfinite(a).all():
        raise FloatingPointError("Nonfinite state or action in reward computation")
    low = np.asarray(stats["control_low"], dtype=np.float32)
    high = np.asarray(stats["control_high"], dtype=np.float32)
    if low.shape != (4,) or high.shape != (4,) or np.any(low > high):
        raise ValueError("Invalid four-variable empirical operating envelope")
    violation = ((cv < low) | (cv > high)).any(axis=-1)
    tracking = np.abs(cv[..., :3] - TARGETS[:3]) / TRACKING_SCALES[:3]
    oxygen_distance = np.maximum(np.maximum(3.5 - cv[..., 3], 0.0), cv[..., 3] - 4.0)
    oxygen_cost = oxygen_distance / TRACKING_SCALES[3]
    movement_cost = 0.05 * np.square(a).mean(axis=-1)
    violation_cost = 0.5 * violation.astype(np.float32)
    reward = -(tracking.sum(axis=-1) + oxygen_cost + movement_cost + violation_cost)
    if np.any(reward > 1e-7):
        raise AssertionError("Negative-cost reward must not be positive")
    return reward.astype(np.float32), violation, {
        "tracking_cost": tracking,
        "oxygen_cost": oxygen_cost,
        "movement_cost": movement_cost,
        "violation_cost": violation_cost,
    }


def observations_from_data(data: Mapping[str, np.ndarray], indices: np.ndarray) -> dict[str, torch.Tensor]:
    indices = np.asarray(indices, dtype=np.int64)
    if indices.ndim != 1 or len(indices) == 0:
        raise ValueError("Observation indices must be a nonempty vector")
    names = ("u_hist", "z_hist", "visual", "u_current", "z_current")
    return {name: torch.as_tensor(np.asarray(data[name][indices]).copy(), dtype=torch.float32)
            for name in names}


def clone_observation(observation: Mapping[str, torch.Tensor]) -> dict[str, torch.Tensor]:
    return {key: value.detach().clone() for key, value in observation.items()}


class TwinEnv:
    """Vectorized numerical surrogate; no connection to plant actuators.

    Each step first updates the MV history and retrieves an available historical
    visual proxy, then predicts the next CV increment. All evaluated policies
    use this same dynamics implementation, including policy-visual ablations.
    """

    def __init__(self, twin, memory, stats, data, config):
        self.twin = twin.eval()
        self.memory = memory
        self.stats = stats
        self.data = data
        self.config = config
        self.action_scale = np.asarray(stats["action_scale"], dtype=np.float32)
        self.action_bound = np.asarray(stats["action_bound"], dtype=np.float32)
        self.u_low = np.asarray(stats["u_low"], dtype=np.float32)
        self.u_high = np.asarray(stats["u_high"], dtype=np.float32)
        for value in (self.action_scale, self.action_bound, self.u_low, self.u_high):
            if value.shape != (8,) or not np.isfinite(value).all():
                raise ValueError("Invalid eight-channel action statistics")
        if np.any(self.action_scale <= 0) or np.any(self.action_bound < 0) or np.any(self.u_low > self.u_high):
            raise ValueError("Invalid action scales or bounds")
        self.observation: dict[str, torch.Tensor] | None = None
        self.steps = 0

    def reset(self, indices: np.ndarray) -> dict[str, torch.Tensor]:
        self.observation = observations_from_data(self.data, np.asarray(indices, dtype=np.int64))
        u = self.observation["u_current"].numpy()
        if ((u < self.u_low - 1e-5) | (u > self.u_high + 1e-5)).any():
            raise ValueError("Surrogate start MV is outside the declared training operating envelope")
        self.steps = 0
        return clone_observation(self.observation)

    @torch.no_grad()
    def step(self, normalized_actions: np.ndarray | torch.Tensor):
        if self.observation is None:
            raise RuntimeError("reset must be called before step")
        action = np.asarray(torch.as_tensor(normalized_actions).detach().cpu(), dtype=np.float32)
        batch = len(self.observation["u_current"])
        if action.shape != (batch, 8) or not np.isfinite(action).all():
            raise ValueError(f"Expected finite actions of shape {(batch, 8)}, got {action.shape}")
        executed_normalized_tensor, executed_tensor, next_u_tensor = project_normalized_actions(
            torch.as_tensor(action), self.observation["u_current"], self.stats
        )
        next_u = next_u_tensor.numpy()
        executed = executed_tensor.numpy()
        executed_normalized = executed_normalized_tensor.numpy()
        next_u_hist = torch.cat((self.observation["u_hist"][:, 1:], next_u_tensor[:, None]), dim=1)
        next_z_hist = torch.cat(
            (self.observation["z_hist"][:, 1:], self.observation["z_current"][:, None]), dim=1
        )
        visual, selected = self.memory.query(next_u_hist, next_z_hist)
        visual = torch.as_tensor(visual, dtype=torch.float32).detach()
        increment = self.twin(next_u_hist, next_z_hist, visual)
        next_z = self.observation["z_current"] + increment
        if not torch.isfinite(next_z).all():
            raise FloatingPointError("Twin produced a nonfinite recursive state")
        reward, violation, costs = reward_and_violation(next_z.numpy(), executed_normalized, self.stats)
        self.observation = {
            "u_hist": next_u_hist,
            "z_hist": next_z_hist,
            "visual": visual,
            "u_current": next_u_tensor,
            "z_current": next_z,
        }
        self.steps += 1
        info = {
            "control": control_variables(next_z.numpy()),
            "z": next_z.numpy().copy(),
            "u": next_u.copy(),
            "violation": violation.copy(),
            "executed_action": executed.copy(),
            "normalized_executed_action": executed_normalized.copy(),
            "visual_sample_indices": np.asarray(selected, dtype=np.int64),
            **costs,
        }
        return clone_observation(self.observation), reward, info


class ActorPolicy:
    """Frozen observation encoder and a deterministic learned actor head."""

    def __init__(self, actor, twin, policy_visual="retrieval"):
        if policy_visual not in {"retrieval", "hold"}:
            raise ValueError("Unknown policy visual mode")
        self.actor = actor.eval()
        self.twin = twin.eval()
        self.policy_visual = policy_visual
        self.initial_visual = None

    def reset(self, observation):
        self.initial_visual = observation["visual"].detach().clone()

    @torch.no_grad()
    def __call__(self, observation):
        from .models import make_state
        if self.initial_visual is None:
            raise RuntimeError("Policy reset is required")
        visual = self.initial_visual if self.policy_visual == "hold" else observation["visual"]
        state = make_state(
            self.twin, observation["u_hist"], observation["z_hist"], visual,
            observation["u_current"], observation["z_current"],
        )
        return self.actor(state).cpu().numpy()


class LinearFeedbackPolicy:
    """Ridge-identified static action response followed by proportional feedback.

    This is a reproducible data-derived baseline, not a plant-tuned PID or a
    human expert. Its response matrix is estimated only from training pairs.
    """

    def __init__(self, data, stats, gain=0.1, ridge=1.0):
        self.stats = stats
        self.gain = float(gain)
        idx = np.asarray(data["train_idx"], dtype=np.int64)
        idx = idx[np.asarray(data["next_idx"])[idx] >= 0]
        nxt = np.asarray(data["next_idx"])[idx]
        if len(idx) < 16:
            raise ValueError("Too few logged transitions for linear feedback")
        scale = np.asarray(stats["action_scale"], dtype=np.float64)
        bound = np.asarray(stats["action_bound"], dtype=np.float64)
        x = np.asarray(data["action"][idx], dtype=np.float64) / scale
        active = bound > 1e-8
        x[:, ~active] = 0.0
        y = (control_variables(data["z_current"][nxt]) - control_variables(data["z_current"][idx]))
        y = y / TRACKING_SCALES
        x = x - x.mean(axis=0)
        y = y - y.mean(axis=0)
        response = np.linalg.solve(x.T @ x + float(ridge) * np.eye(8), x.T @ y)
        self.inverse_response = np.linalg.pinv(response.T, rcond=1e-3).astype(np.float32)
        self.active = active

    def reset(self, observation):
        pass

    def __call__(self, observation):
        cv = control_variables(observation["z_current"].numpy())
        error = (cv - TARGETS) / TRACKING_SCALES
        action = -self.gain * error @ self.inverse_response.T
        action[:, ~self.active] = 0.0
        return np.clip(action, -1.0, 1.0).astype(np.float32)


class NearestLoggedActionPolicy:
    """Nearest training observation's recorded action; not a human Expert."""

    def __init__(self, data, stats, max_items=2048):
        idx = np.asarray(data["train_idx"], dtype=np.int64)
        idx = idx[np.asarray(data["next_idx"])[idx] >= 0]
        if not len(idx):
            raise ValueError("No training transitions for nearest logged actions")
        pos = np.linspace(0, len(idx) - 1, min(int(max_items), len(idx)), dtype=np.int64)
        self.indices = idx[pos]
        self.u_mean = np.asarray(stats["u_mean"], dtype=np.float32)
        self.u_scale = np.asarray(stats["u_scale"], dtype=np.float32)
        self.z_mean = np.asarray(stats["z_mean"], dtype=np.float32)
        self.z_scale = np.asarray(stats["z_scale"], dtype=np.float32)
        self.keys = self._keys(data["u_current"][self.indices], data["z_current"][self.indices])
        self.actions = np.clip(
            data["action"][self.indices] / np.asarray(stats["action_scale"], dtype=np.float32), -1.0, 1.0
        )
        self.actions[:, np.asarray(stats["action_bound"]) == 0] = 0

    def _keys(self, u, z):
        key = np.concatenate(((u - self.u_mean) / self.u_scale, (z - self.z_mean) / self.z_scale), axis=-1)
        return key / np.maximum(np.linalg.norm(key, axis=-1, keepdims=True), 1e-8)

    def reset(self, observation):
        pass

    def __call__(self, observation):
        key = self._keys(observation["u_current"].numpy(), observation["z_current"].numpy())
        nearest = np.argmax(key @ self.keys.T, axis=1)
        return self.actions[nearest].astype(np.float32)
