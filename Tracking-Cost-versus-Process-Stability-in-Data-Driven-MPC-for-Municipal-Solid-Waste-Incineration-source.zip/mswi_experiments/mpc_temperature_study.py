"""Frozen validation-only A-E temperature protection experiment orchestration."""
from __future__ import annotations
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import time
import numpy as np
import torch
from threadpoolctl import threadpool_limits
from .ridge_policy_study import read_npz,write_json,sha
from .ridge_dynamics import RidgeDynamics
from .ridge_policy import Execution,RidgePolicyEnv
from .ridge_policy_planning import CEMPlanner
from .mpc_temperature import TemperatureCEM

ROOT=Path(__file__).resolve().parents[1]
REF=ROOT/'experiment_runs/ridge_control_probe_20261106'
PRIOR=ROOT/'experiment_runs/ridge_policy_pipeline_20261107'
DESIGN=ROOT/'experiment_protocols/mpc_temperature_20261107'
OUT=ROOT/'experiment_runs/mpc_temperature_20261107'
MODELS=('full','early','middle','late','pooled_matched')
VARIANTS=('A','B','C','D','E')
SAMPLE_KEYS=('u_hist','z_hist','z_current','time_ns','indices')

def protocol():return json.loads((DESIGN/'protocol.json').read_text())

def shared():
    stats=json.loads((REF/'stats.json').read_text())
    execution=Execution(stats,read_npz(REF/'support.npz'))
    model=RidgeDynamics.load(REF/'evaluation_models/full.npz')
    return stats,execution,model

def verify_sources():
    for path,expected in json.loads((DESIGN/'source_bindings.json').read_text()).items():
        if sha(path)!=expected:raise AssertionError('registered source changed: '+path)

def prepare():
    verify_sources()
    if OUT.exists() and any(OUT.iterdir()):raise FileExistsError('new empty study folder required')
    OUT.mkdir(parents=True)
    for name in ('protocol.json','PRESET_zh.txt','source_bindings.json'):shutil.copy2(DESIGN/name,OUT/name)
    row=read_npz(REF/'inputs/val.npz')
    if len(row['indices'])!=256:raise AssertionError('fixed256 validation starts')
    stats,execution,model=shared();variant=TemperatureCEM(model,execution,1,False);old=CEMPlanner(model,execution)
    env=RidgePolicyEnv(model,execution,horizon=50);env.reset(options={'inputs':row});checks=[]
    # Full original batch. No new-method result is used to adjust the settings.
    for step in range(3):
        original,od=old.plan(env.u,env.z,env.current,env.times,env.indices,step)
        actual,ad=variant.plan(env.u,env.z,env.current,env.times,env.indices,step)
        np.testing.assert_array_equal(actual,original)
        np.testing.assert_array_equal(ad['best_requested_plan_b'],od['best_requested_plan_b'])
        np.testing.assert_array_equal(ad['selected_original_return'],od['planner_score'])
        checks.append({'step':step,'action_and_selected_plan_bitwise_equal':True})
        env.step_request(actual)
    write_json(OUT/'compatibility_before_run.json',{'status':'passed','checks':checks,'batch':256})
    print('A compatibility passed',flush=True)

def freeze_implementation():
    verify_sources()
    if json.loads((OUT/'compatibility_before_run.json').read_text())['status']!='passed':raise AssertionError('readiness')
    files=[ROOT/'mswi_experiments'/n for n in ('mpc_temperature.py','mpc_temperature_study.py','mpc_temperature_report.py')]
    files += [ROOT/'tests/test_mpc_temperature.py']
    hashes={str(p):sha(p) for p in files}
    path=OUT/'implementation_frozen.json'
    if path.exists():
        if json.loads(path.read_text())['hashes']!=hashes:raise AssertionError('implementation changed after outcome execution began')
    else:
        write_json(path,{'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'hashes':hashes})
        snap=OUT/'code_snapshot'
        for p in files+list((ROOT/'mswi_experiments').glob('ridge_*.py'))+[ROOT/'mswi_experiments/control.py',ROOT/'mswi_experiments/data.py',ROOT/'mswi_experiments/visual_diagnostics_statistics.py']:
            dest=snap/p.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)

def run_case(variant_id,mid):
    path=OUT/f'trajectories/{variant_id}/{mid}.npz'
    if path.exists() and path.with_suffix('.json').exists():
        if sha(path)!=json.loads(path.with_suffix('.json').read_text())['sha256']:raise AssertionError('existing trajectory modified')
        return
    stats,execution,full=shared();cfg=next(v for v in protocol()['variants'] if v['id']==variant_id)
    planner=TemperatureCEM(full,execution,cfg['temperature_weight'],cfg['temperature_constraint'])
    evaluator=RidgeDynamics.load(REF/f'evaluation_models/{mid}.npz')
    inputs=read_npz(REF/'inputs/val.npz');env=RidgePolicyEnv(evaluator,execution,horizon=50)
    env.reset(options={'inputs':inputs});buffers={};start=time.perf_counter()
    for step in range(50):
        request,diagnostics=planner.plan(env.u,env.z,env.current,env.times,env.indices,step)
        _,_,done,cut,info=env.step_request(request)
        if done.any() or cut.all()!=(step==49):raise AssertionError('sample truncation semantics')
        info.update(diagnostics)
        for k,v in info.items():buffers.setdefault(k,[]).append(v)
        if (step+1)%10==0:print(variant_id,mid,'steps',step+1,'seconds',round(time.perf_counter()-start,1),flush=True)
    arrays={k:np.stack(v,axis=1) for k,v in buffers.items()}
    arrays.update(indices=inputs['indices'],time_ns=inputs['time_ns'],initial_u=inputs['u_hist'][:,-1],initial_z_current=inputs['z_current'])
    for k,v in arrays.items():
        if np.issubdtype(v.dtype,np.number) and not np.isfinite(v).all():raise FloatingPointError(k)
    compatibility=None
    if variant_id=='A':
        old=read_npz(PRIOR/f'trajectories/val/{mid}/cem_mpc/seed0.npz')
        compatibility={}
        for k in ('pred_cv','u_path','requested_action','executed_action','reward','best_requested_plan_b'):
            np.testing.assert_array_equal(arrays[k],old[k]);compatibility[k]=0.
    path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix('.partial.npz')
    np.savez_compressed(tmp,**arrays);tmp.replace(path)
    write_json(path.with_suffix('.json'),{'variant':variant_id,'model':mid,'split':'val','episodes':256,'horizon':50,
        'elapsed_seconds':time.perf_counter()-start,'sha256':sha(path),'A_prior_max_differences':compatibility,
        'original_return10':float(arrays['reward'][:,:10].astype(float).sum(1).mean()),
        'original_return50':float(arrays['reward'].astype(float).sum(1).mean()),'support_certificate_counts':planner.support.counts})
    print('complete',variant_id,mid,flush=True)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=('prepare','freeze','run'));parser.add_argument('--shard',type=int,default=0);parser.add_argument('--shards',type=int,default=1)
    args=parser.parse_args();torch.set_num_threads(4)
    with threadpool_limits(4):
        if args.stage=='prepare':prepare()
        elif args.stage=='freeze':freeze_implementation()
        else:
            if not 0<=args.shard<args.shards:raise ValueError('invalid static shard')
            freeze_implementation()
            cases=[(v,m) for v in VARIANTS for m in MODELS]
            for v,m in cases[args.shard::args.shards]:run_case(v,m)

if __name__=='__main__':main()
