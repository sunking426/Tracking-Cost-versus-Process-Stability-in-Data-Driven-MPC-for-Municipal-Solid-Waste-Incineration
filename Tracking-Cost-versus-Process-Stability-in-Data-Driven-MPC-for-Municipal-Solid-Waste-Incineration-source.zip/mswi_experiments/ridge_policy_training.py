"""Fixed-budget BC and TD3 variants on explicit Ridge policy interfaces."""
from __future__ import annotations
import argparse
import copy
import json
import time
from pathlib import Path
import numpy as np
import torch
from torch.nn import functional as F
from threadpoolctl import threadpool_limits
from .data import load_data
from .models import Actor
from .rl import TwinCritic
from .training import hurdle_loss
from .ridge_policy import RidgePolicyEnv, ACTIVE
from .ridge_policy_study import ROOT, OUT, SEEDS, GROUPS, read_npz, write_json, sha, shared, input_rows, episode_exclusion

FIELDS=('state','action','reward','next_state','u','z','times','next_u','next_z','next_times')

def seed_all(seed):
    torch.manual_seed(seed);np.random.seed(seed);torch.use_deterministic_algorithms(True)
    return np.random.default_rng(seed)

def mode_for(group):return 'sensor' if group=='sensor_td3bc' else 'hold' if group=='no_policy_retrieval' else 'full'

def state_variant(logged,mode):
    result={k:logged[k] for k in FIELDS if k not in ('state','next_state')}
    for key in ('state','next_state'):
        x=logged[('hold_'+key) if mode=='hold' else key]
        if mode=='sensor':x=x.copy();x[:,178:]=0
        result[key]=x
    return result

def load_actor(path):
    checkpoint=torch.load(path,map_location='cpu',weights_only=False)
    actor=Actor(230,2,128);actor.load_state_dict(checkpoint['actor']);actor.eval()
    return actor

def bc_fit(seed,mode,train,val):
    folder=OUT/f'models/bc_{mode}/seed{seed}';folder.mkdir(parents=True,exist_ok=True)
    if (folder/'complete.json').exists():return
    started=time.perf_counter();rng=seed_all(seed);actor=Actor(230,2,128)
    optimizer=torch.optim.AdamW(actor.parameters(),lr=.001,weight_decay=.0001,betas=(.9,.999),eps=1e-8,amsgrad=False)
    arrays=[]
    for source in (train,val):
        s=source['state'].copy()
        if mode=='sensor':s[:,178:]=0
        arrays.append(tuple(torch.from_numpy(np.ascontiguousarray(x)).float() for x in (s,source['b_ref'],source['physical_ref'])))
    x,y,raw=arrays[0];vx,vy,vr=arrays[1];best=float('inf');patience=0;history=[]
    for epoch in range(1,21):
        actor.train();losses=[]
        for batch in np.array_split(rng.permutation(len(x)),np.arange(256,len(x),256)):
            pred,gates,_=actor.forward_details(x[batch]);loss=hurdle_loss(pred,gates,y[batch],raw[batch])
            optimizer.zero_grad(set_to_none=True);loss.backward();torch.nn.utils.clip_grad_norm_(actor.parameters(),1.);optimizer.step()
            losses.append(float(loss.detach()))
        actor.eval()
        with torch.no_grad():
            pred,gates,_=actor.forward_details(vx);vl=float(hurdle_loss(pred,gates,vy,vr))
        if not np.isfinite(vl):raise FloatingPointError('BC loss')
        history.append({'epoch':epoch,'train_loss_batch_mean':float(np.mean(losses)),'validation_loss':vl})
        if vl<best-1e-5:
            best=vl;patience=0
            torch.save({'actor':actor.state_dict(),'optimizer':optimizer.state_dict(),'seed':seed,'epoch':epoch,'mode':mode,
                'torch_rng':torch.get_rng_state(),'numpy_rng':rng.bit_generator.state,'state_dim':230,'action_dim':2},folder/'actor.pt')
        else:patience+=1
        print('BC',mode,seed,epoch,vl,flush=True)
        if patience>=4:break
    write_json(folder/'history.json',history)
    write_json(folder/'complete.json',{'seed':seed,'mode':mode,'epochs_run':len(history),'best_validation_loss':best,'elapsed_seconds':time.perf_counter()-started,'checkpoint_sha256':sha(folder/'actor.pt')})

def sample(pool,n,rng):
    ids=rng.integers(0,len(pool['state']),n)
    return {k:pool[k][ids] for k in FIELDS}

def generate(actor,env,data,resets,rng):
    ids=rng.choice(resets,32,replace=True);state,_=env.reset(options={'inputs':input_rows(data,ids),'exclusion':episode_exclusion(data,ids)})
    rows={k:[] for k in FIELDS};roots=[];steps=[];donors=[];nextdonors=[]
    for step in range(10):
        u=env.u[:,-1].copy();z=env.current.copy();times=env.times.copy();donor=env.last_donors.copy()
        with torch.no_grad():b=actor(torch.from_numpy(state)).numpy()
        b=np.clip(b+rng.normal(0,.1,b.shape),-1,1)
        following,reward,terminated,truncated,info=env.step(b)
        if terminated.any():raise AssertionError('sample cutoff must not terminate Bellman bootstrap')
        values={'state':state,'action':info['executed_action'].astype(np.float32),'reward':reward[:,None],
            'next_state':following,'u':u,'z':z,'times':times,'next_u':env.u[:,-1].copy(),'next_z':env.current.copy(),'next_times':env.times.copy()}
        for k,v in values.items():rows[k].append(v)
        roots.append(ids);steps.append(np.full(len(ids),step));donors.append(donor);nextdonors.append(env.last_donors.copy());state=following
    out={k:np.concatenate(v) for k,v in rows.items()}
    out.update(root_indices=np.concatenate(roots),step=np.concatenate(steps),donor=np.concatenate(donors),next_donor=np.concatenate(nextdonors))
    return out

def train_one(group,seed,logged,data,resets):
    folder=OUT/f'models/{group}/seed{seed}';folder.mkdir(parents=True,exist_ok=True)
    if (folder/'complete.json').exists():return
    started=time.perf_counter();rng=seed_all(seed);mode=mode_for(group)
    stats,execution,context,model=shared();pool=state_variant(logged,mode)
    actor=Actor(230,2,128)
    if group!='twin_td3':
        init='sensor' if mode=='sensor' else 'full'
        actor.load_state_dict(load_actor(OUT/f'models/bc_{init}/seed{seed}/actor.pt').state_dict())
    critic=TwinCritic(230,8,128);target_actor=copy.deepcopy(actor);target_critic=copy.deepcopy(critic)
    actor_optimizer=torch.optim.Adam(actor.parameters(),lr=.0003,betas=(.9,.999),eps=1e-8,weight_decay=0)
    critic_optimizer=torch.optim.Adam(critic.parameters(),lr=.0003,betas=(.9,.999),eps=1e-8,weight_decay=0)
    env=RidgePolicyEnv(model,execution,context,horizon=10,visual_mode=mode)
    generated=None;generation_events=[];history=[];offline=group=='offline_td3bc'
    for update in range(1,1501):
        if not offline and (update-1)%100==0:
            new=generate(actor,env,data,resets,rng)
            new['generation_update']=np.full(len(new['state']),update)
            generated=new if generated is None else {k:np.concatenate((generated[k],new[k]))[-20000:] for k in new}
            generation_events.append({'update':update,'transitions':len(new['state'])})
        batch=sample(pool,256 if offline else 128,rng)
        if not offline:
            synthetic=sample(generated,128,rng);batch={k:np.concatenate((batch[k],synthetic[k])) for k in FIELDS}
        s,a,r,ns=[torch.from_numpy(np.ascontiguousarray(batch[k])).float() for k in ('state','action','reward','next_state')]
        with torch.no_grad():
            b=(target_actor(ns)+(torch.randn((len(ns),2))*.2).clamp(-.5,.5)).clamp(-1,1)
            na=execution.tensor(b,batch['next_u'],batch['next_z'],batch['next_times'])
            q1,q2=target_critic(ns,na);target=r+.99*torch.minimum(q1,q2)
        q1,q2=critic(s,a);critic_loss=F.mse_loss(q1,target)+F.mse_loss(q2,target)
        critic_optimizer.zero_grad(set_to_none=True);critic_loss.backward();torch.nn.utils.clip_grad_norm_(critic.parameters(),10.);critic_optimizer.step()
        actor_loss=None;bc_loss=None
        if update%2==0:
            for p in critic.parameters():p.requires_grad_(False)
            executed=execution.tensor(actor(s),batch['u'],batch['z'],batch['times'])
            q=critic(s,executed)[0]
            if group=='twin_td3':loss=-q.mean()
            else:
                iid=rng.integers(0,len(pool['state']),256);bs=torch.from_numpy(pool['state'][iid])
                ba=execution.tensor(actor(bs),pool['u'][iid],pool['z'][iid],pool['times'][iid])
                bref=torch.from_numpy(logged['b_ref'][iid]);be=ba[:,ACTIVE]/torch.as_tensor(execution.m,dtype=torch.float32)
                reg=F.mse_loss(be,bref);loss=-(2.5/(q.abs().mean().detach()+1e-6))*q.mean()+2.5*reg;bc_loss=float(reg.detach())
            actor_optimizer.zero_grad(set_to_none=True);loss.backward();torch.nn.utils.clip_grad_norm_(actor.parameters(),10.);actor_optimizer.step();actor_loss=float(loss.detach())
            for p in critic.parameters():p.requires_grad_(True)
            with torch.no_grad():
                for target_p,p in zip(target_actor.parameters(),actor.parameters()):target_p.mul_(.995).add_(p,alpha=.005)
                for target_p,p in zip(target_critic.parameters(),critic.parameters()):target_p.mul_(.995).add_(p,alpha=.005)
        if not torch.isfinite(critic_loss):raise FloatingPointError('nonfinite TD3 loss')
        if update%100==0:
            history.append({'update':update,'critic_loss':float(critic_loss.detach()),'actor_loss':actor_loss,'bc_mse':bc_loss,
                'mean_q':float(q1.detach().mean()),'mean_target':float(target.mean())})
            print('TD3',group,seed,update,history[-1],flush=True)
    checkpoint={'actor':actor.state_dict(),'critic':critic.state_dict(),'target_actor':target_actor.state_dict(),
        'target_critic':target_critic.state_dict(),'actor_optimizer':actor_optimizer.state_dict(),'critic_optimizer':critic_optimizer.state_dict(),
        'seed':seed,'group':group,'updates':1500,'torch_rng':torch.get_rng_state(),'numpy_rng':rng.bit_generator.state,
        'state_dim':230,'actor_action_dim':2,'critic_action_dim':8}
    torch.save(checkpoint,folder/'actor.pt')
    if generated is not None:np.savez_compressed(folder/'generated_replay.npz',**generated)
    write_json(folder/'history.json',history)
    write_json(folder/'complete.json',{'seed':seed,'group':group,'critic_updates':1500,'actor_updates':750,
        'generated_transitions':0 if offline else len(generated['state']),'generation_events':generation_events,
        'elapsed_seconds':time.perf_counter()-started,'checkpoint_sha256':sha(folder/'actor.pt')})

def train_all():
    gate=json.loads((OUT/'environment_compatibility.json').read_text())
    if gate['status']!='passed':raise RuntimeError('compatibility must pass before training')
    for path,expected in json.loads((OUT/'input_hashes.json').read_text()).items():
        if sha(path)!=expected:raise AssertionError('frozen input changed: '+path)
    codefiles=[Path(__file__),ROOT/'mswi_experiments/ridge_policy.py',ROOT/'mswi_experiments/ridge_policy_study.py']
    codehash={str(p):sha(p) for p in codefiles}
    frozen=OUT/'training_code_hashes.json'
    if frozen.exists() and json.loads(frozen.read_text())!=codehash:raise AssertionError('training code changed after freeze')
    if not frozen.exists():write_json(frozen,codehash)
    train=read_npz(OUT/'logged_train.npz');val=read_npz(OUT/'logged_val.npz')
    for mode in ('full','sensor'):
        for seed in SEEDS:bc_fit(seed,mode,train,val)
    data,_,_=load_data(ROOT/'experiment_runs/corrected_vision/data');resets=np.load(OUT/'training_reset_indices.npy')
    for group in GROUPS[1:]:
        for seed in SEEDS:train_one(group,seed,train,data,resets)

def main():
    torch.set_num_threads(4)
    with threadpool_limits(4):train_all()

if __name__=='__main__':main()
