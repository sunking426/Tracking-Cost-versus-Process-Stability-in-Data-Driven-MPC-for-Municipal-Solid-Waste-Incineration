"""Human-readable final readout, generated from the complete audited tables."""
from __future__ import annotations
import csv,json
from pathlib import Path
import numpy as np
from .s8_cross_evaluation import ROOT,OUT,DESIGN,MODELS,verify
from .ridge_policy_study import write_json
from .frozen_mpc import file_sha256


def main():
    verify();folder=OUT/'report'
    audit=json.loads((OUT/'final_integrity_audit.json').read_text())
    assert audit['status']=='passed' and audit['trajectory_files']==168
    pos=json.loads((folder/'positioning.json').read_text())
    assert pos.get('positioning') in ('controller','framework')
    summary=[];diff=[];ratios=[]
    for layer in ('B','C'):
        for name,target in (('metrics',summary),('paired_differences',diff),('sd_ratios',ratios)):
            target.extend(list(csv.DictReader((folder/f'{layer}_{name}.csv').open())))
    def mean(layer,mid,m,h,k):
        return float(next(x['mean'] for x in summary if (x['layer'],x['model'],x['method'],x['horizon'],x['metric'])==(layer,mid,m,str(h),k)))
    def change(layer,mid,h,k,reference='bc'):
        return next(x for x in diff if (x['layer'],x['model'],x['method'],x['reference'],x['horizon'],x['metric'])==(layer,mid,'S8',reference,str(h),k))
    label={'gru23':'GRU23','early':'早期Ridge','middle':'中期Ridge','late':'晚期Ridge','pooled_matched':'混合Ridge'}
    result='按预设规则可保留短时稳定性控制器定位，继续验证；不代表工厂验收通过。' if pos['positioning']=='controller' else '按预设规则采用框架定位，λ=8作为稳定性目标的代表配置；不重新选择配置。'
    lines=['λ=8冻结、GRU交叉评价与残差扰动评价：最终结果','',result,'',
        '一、执行与验收',
        'λ=8以“代表配置，未通过全部既往研究筛查”身份封存；未改动作、温度权重、支持过滤、CEM预算或随机数规则。',
        '配置SHA256：'+file_sha256(DESIGN/'config.json'),
        '早期Ridge上256起点×50步的λ=8与旧轨迹34个共同字段逐值一致；零扰动下C0、保持操作及五个BC种子也逐值复现。',
        'GRU按验证损失选择种子23；9228条单步验证预测逐值一致，NMSE=1.2642167784606368。',
        'B/C共168个轨迹文件，含43008条50步模拟轨迹、2150400个转移步。BC先逐种子计算指标，再平均五个种子；C在每个起点内先平均五条扰动序列。',
        '四个模型均完成C层。仅pooled按用户批准使用原始训练分区全部43406条有效建模样本计算残差，含28948条未参与该模型拟合的训练行；另外三个模型限于各自14458条拟合行。',
        '所有残差来自原始训练分区，不居中、不缩放、不截断；同日起连续10分钟块，五块组成50步，九通道一起抽取。',
        '残差36项标准差检查均在预设Monte Carlo范围内；实际相对可抽块总体的最大偏差约20%（晚期T3），已保留并披露。',
        '独立审计重算所有轨迹的奖励及成本，并重建第1、10、50步反馈；扰动序列与来源块逐值核对，动作边界和六个非控制通道均通过。','',
        '二、定位规则逐项核对',
        f"C层：{pos['C']['passing_cells']}/12项λ=8去趋势标准差均值不高于BC；各量退化模型数={pos['C']['worse_models_per_variable']}；判定{'通过' if pos['C']['passed'] else '未通过'}。",
        f"B层：{sum(x['noninferior_mean'] for x in pos['B']['details'])}/3项均值不高于BC；判定{'通过' if pos['B']['passed'] else '未通过'}。",
        f"稳定性项作用：四个C层模型等权平均后，{'三个量均' if pos['design_effect']['passed'] else '并非三个量均'}低于C0；判定{'通过' if pos['design_effect']['passed'] else '未通过'}。",'',
        '三、10步主要稳定性结果：λ=8 / BC 的去趋势标准差均值比',
        '环境               炉温         蒸汽         含氧量']
    for layer,mids in (('B',('gru23',)),('C',MODELS)):
        for mid in mids:
            vals=[mean(layer,mid,'S8',10,'detrended_sd_'+v)/mean(layer,mid,'bc',10,'detrended_sd_'+v) for v in ('temperature','steam','oxygen')]
            lines.append(f"{label[mid]:14s}"+' '.join(f'{v:12.6f}' for v in vals))
    c_significant=sum(x['ci_high']<0 for x in pos['C']['details'])
    lines+=['比值小于1表示该指标均值较小。逐模型区间见C_sd_ratios.csv与配对差值表。',
        f'C层{c_significant}/12项配对差值的探索性95%区间低于零；GRU三项差值区间均包含零，不能把B层均值通过写成已证明优于BC。',
        'B层λ=8三项比BC低约2.58%、2.15%、3.39%；C层的幅度应按上表描述，不使用“大幅提高稳定性”的表述。',
        '稳定性项相对C0的C层等权平均效果：']
    for v in ('temperature','steam','oxygen'):
        a=np.mean([mean('C',mid,'S8',10,'detrended_sd_'+v) for mid in MODELS]);b=np.mean([mean('C',mid,'C0',10,'detrended_sd_'+v) for mid in MODELS])
        row=next(x for x in pos['design_effect']['details'] if x['variable']==v)
        lines.append(f"  {v}: S8={a:.6f}, C0={b:.6f}, 变化={(a/b-1)*100:.3f}%，差值区间[{row['ci_low']:.6f},{row['ci_high']:.6f}]。")
    lines+=['','四、收益与仍存在的取舍（λ=8减BC）',
        '环境               10步回报差    高温比例差/百分点    50步低氧比例差/百分点']
    safety=[]
    for layer,mids in (('B',('gru23',)),('C',MODELS)):
        for mid in mids:
            r=float(change(layer,mid,10,'original_return')['difference']);ht=float(change(layer,mid,10,'any_high1050_fraction')['difference'])*100;ox=float(change(layer,mid,50,'oxygen_low3p5_fraction')['difference'])*100
            lines.append(f'{label[mid]:14s}{r:12.6f}{ht:18.6f}{ox:23.6f}')
            safety.append(dict(layer=layer,model=mid,return_difference=r,high1050_difference_pp=ht,low_oxygen_difference_pp=ox))
    lines+=['回报差正值为综合成本降低；后两列正值为相应事件比例上升。高温指任一个测点>1050℃，不能替换成六路均温超过1050℃。',
        'C层绝对温度代理检查：10步全体轨迹最低890.81℃；50步全体最低857.03℃（BC），λ=8最低880.28℃，均未低于850℃。单测点事件仍存在。',
        'C层50步单测点低于850℃事件数（每模型1280条轨迹合计，BC对五种子平均）：早期S8/BC=68/68；中期76/76；晚期416/426.8；混合240/240。这些是测点×时间计数，不是报警次数。',
        '成本六项分解、炉压偏差、原始标准差、50步标准差、累计风机变化及全部区间均在按模型分列的CSV中。',
        'GRU层回报改善仍主要来自炉压：相对BC炉压项改善1.211147，温度项退化0.238613，含氧量项退化0.090653，净回报改善约0.989436。',
        'GRU的50步低氧比例为S8 74.60%、BC 64.82%。最差50步六路均温滚动代理降到775.07℃，相同低温事件也出现在保持操作和BC；最差起点S8未执行非零动作，与保持操作轨迹一致。',
        '50步是压力测试，不能将模型长递归漂移当作真实工厂预测；短期稳定性结果不能替代高温和低氧评价。','',
        '去趋势标准差降低与低氧时间上升并不矛盾：前者剔除了线性趋势，衡量围绕局部趋势的波动；后者衡量运行水平是否落在区间外。降低前者不等于消除了后者。','',
        '原始标准差也不能省略：C层10步早期模型含氧量原始标准差比BC高约0.19%；50步蒸汽原始标准差在四个模型分别高7.47%、0.92%、2.06%、3.22%。50步含氧量原始标准差在中、晚、混合模型分别高0.82%、1.27%、1.65%。因此不能把去趋势结果写成长期原始波动全面降低。',
        '五、解释边界与停止',
        '这是模型闭环评价，残差混合了模型误差、未建模输入和测量变化；不是实炉扰动试验。四个Ridge共享或重叠历史数据，GRU也来自同一数据集，不能据此宣布排除了模型偏差。',
        'BC是历史操作的学习代理，不是真实操作员面对同一扰动时的反事实响应。',
        '10步去趋势标准差不是工厂长期运行标准差的等价物；六路均温滚动值是研究代理，不用于认证法规合规。',
        '定位规则按均值作研究筛查；区间为按起点配对的探索性95%，未做多重比较校正，也不是未接触过数据的确认性检验。早期开发已查看过测试集，本轮未用于选择或评价。',
        '可选的额外GRU种子和TD3+BC未运行，已在执行前记录。',
        '本次到此停止：未做D消融、未做E测试集评价、未修改论文。','',
        '文件：positioning.json（逐条判定）；B/C_metrics_by_model.csv（模型分列完整指标）；B/C_paired_differences_by_model.csv（配对区间）；B/C_sd_ratio_h10/h50.png/pdf（去趋势比值图）；B/C_raw_sd_ratio_h10/h50.png/pdf（原始标准差比值图）；both_trajectory_audit.csv与absolute_temperature_checks.csv（逐轨迹及汇总极值和事件数）；residual_SD_fidelity.csv（残差抽样检查）。']
    (folder/'RESULTS_zh.txt').write_text('\n'.join(lines)+'\n')
    one=['λ=8两层评价：一页结论','',result,'',
        '验收：冻结依赖哈希一致；λ=8完整256×50步重现旧轨迹；零扰动重现C0、保持操作和五种子BC；GRU单步预测逐值重现。',
        'B/C已完成168个轨迹文件。仅用验证起点；pooled残差范围按用户批准扩大到全部原始训练行，控制器未调整。','',
        f"规则1（扰动层）：{pos['C']['passing_cells']}/12项去趋势标准差均值不高于BC，判定{'通过' if pos['C']['passed'] else '未通过'}。",
        f"规则2（GRU层）：{sum(x['noninferior_mean'] for x in pos['B']['details'])}/3项均值不高于BC，判定{'通过' if pos['B']['passed'] else '未通过'}；三个差值区间均含零。",
        f"规则3（设计作用）：四个Ridge等权平均后，S8相对C0的三项判定{'全部通过' if pos['design_effect']['passed'] else '未全部通过'}。",'',
        '10步去趋势标准差相对BC的变化（负值为降低）',
        '环境           炉温       蒸汽       含氧量']
    for layer,mids in (('B',('gru23',)),('C',MODELS)):
        for mid in mids:
            vals=[100*(mean(layer,mid,'S8',10,'detrended_sd_'+v)/mean(layer,mid,'bc',10,'detrended_sd_'+v)-1) for v in ('temperature','steam','oxygen')]
            one.append(f"{label[mid]:12s}"+' '.join(f'{v:+8.2f}%' for v in vals))
    cs=[r for r in safety if r['layer']=='C']
    one+=['',f'C层{c_significant}/12项配对差值区间低于零。区间为探索性95%，不做多重比较校正；B层通过均值规则不等于显著优于BC。',
        '原始波动仍有取舍：50步蒸汽原始标准差在四个模型上比BC高0.92%～7.47%，不能宣称长期稳定性全面改善。',
        f"C层相对BC：高温时间比例差范围{min(r['high1050_difference_pp'] for r in cs):+.2f}～{max(r['high1050_difference_pp'] for r in cs):+.2f}个百分点；50步低氧比例差{min(r['low_oxygen_difference_pp'] for r in cs):+.2f}～{max(r['low_oxygen_difference_pp'] for r in cs):+.2f}个百分点。",
        '收益不能替代风险：GRU中S8相对BC回报+0.989，但高温比例+1.73个百分点、50步低氧比例+9.78个百分点。GRU的50步最低滚动均温代理775.07℃，保持和BC也有相同低温事件；说明长递归不能作为可靠实炉预测。C层风险差值详见完整报告。',
        '解释：支持度来自学习模型中的短时反馈及残差压力评价。改善量级有限，未证明实炉效果或安全；BC只是历史操作的学习代理。',
        '停止：未做消融、未评价测试集、未改论文。全部指标、配对区间、残差源行和哈希已保存。']
    (folder/'CONCLUSION_1PAGE_zh.txt').write_text('\n'.join(one)+'\n')
    write_json(folder/'readout_numbers.json',{'positioning':pos['positioning'],'safety_and_return_differences':safety})
    print(result)


if __name__=='__main__':main()
