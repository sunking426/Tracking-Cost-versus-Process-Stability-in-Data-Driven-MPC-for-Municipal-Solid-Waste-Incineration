"""Causal visual-feature contrasts on an unchanged prepared sample population.

This diagnostic layer reads the canonical per-capture measurements. It does not
rebuild samples, select checkpoints, inspect targets, or modify prepared arrays.
Fixed-duration windows end at each sample's already-selected capture, rather
than at its later prediction time. Partition provenance clips older captures.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np

from .data import FEATURE_COLUMNS, MINUTE_NS, read_visual_features


STATIC_COLUMNS = tuple(
    name for name in FEATURE_COLUMNS
    if not any(name == f"ft_{slot}_area{area}" for area in range(1, 5) for slot in (7, 8, 12))
)
PARTITIONS = ("train", "val", "test")


def _timestamp(value, name: str) -> int:
    parsed = np.datetime64(value, "ns")
    if np.isnat(parsed):
        raise ValueError(f"{name} must be a finite timestamp")
    return int(parsed.astype(np.int64))


def _range_summary(begin: np.ndarray, end: np.ndarray, rows: np.ndarray) -> dict:
    if not len(rows):
        return {"samples": 0, "source_begin_ns_min": None, "source_begin_ns_max": None,
                "source_end_ns_min": None, "source_end_ns_max": None}
    return {"samples": int(len(rows)),
            "source_begin_ns_min": int(begin[rows].min()),
            "source_begin_ns_max": int(begin[rows].max()),
            "source_end_ns_min": int(end[rows].min()),
            "source_end_ns_max": int(end[rows].max())}


def _unique_source_captures(capture_time, begin, end, rows) -> int:
    """Count distinct canonical captures in a union of inclusive source spans."""
    if not len(rows):
        return 0
    left = np.searchsorted(capture_time, begin[rows], side="left")
    right = np.searchsorted(capture_time, end[rows], side="right")
    delta = np.zeros(len(capture_time) + 1, dtype=np.int64)
    np.add.at(delta, left, 1)
    np.add.at(delta, right, -1)
    return int((np.cumsum(delta[:-1]) > 0).sum())


def build_visual_variants(data: dict, feature_file: Path, source_manifest: dict
                          ) -> tuple[dict[str, np.ndarray], dict[str, np.ndarray], dict]:
    """Return original52, static40, fixed10, fixed60 and timing4 feature arrays.

    All variants have exactly the prepared sample order and row count. The
    fixed variants contain 40 static values, eight population SDs of per-region
    ft_1/ft_2, and four quality values: age at the one-minute-lagged observation
    cutoff, log1p(capture count), actual capture span, and a >=2-captures flag.
    The latter four values from fixed10 form timing4. Unassigned purge rows get
    finite causal features, but never enter any partition's statistics.

    source_manifest is the manifest returned by data.load_data; each partition
    must provide earliest_source and latest_source. Its earliest_source is an
    inclusive lower bound for new window captures. This function never admits
    earlier sources merely to fill a duration or a capture count.
    """
    time = np.asarray(data["time_ns"])
    chosen_time = np.asarray(data["visual_time_ns"])
    original = np.asarray(data["visual"])
    if time.ndim != 1 or len(time) == 0 or not np.issubdtype(time.dtype, np.integer):
        raise ValueError("time_ns must be a nonempty integer vector")
    n = len(time)
    if chosen_time.shape != (n,) or not np.issubdtype(chosen_time.dtype, np.integer):
        raise ValueError("visual_time_ns must match time_ns")
    if original.shape != (n, len(FEATURE_COLUMNS)) or not np.isfinite(original).all():
        raise ValueError("visual must contain finite canonical 52-dimensional rows")
    if (np.diff(time) <= 0).any():
        raise ValueError("prepared sample times must be strictly increasing")
    age = (time - MINUTE_NS - chosen_time).astype(np.float64) / MINUTE_NS
    if (age < 0).any():
        raise ValueError("selected capture is in the future of the observation cutoff")

    capture_time, values, capture_origins, feature_meta = read_visual_features(Path(feature_file))
    expected_hash = source_manifest.get("visual", {}).get("sha256")
    if expected_hash is not None and expected_hash != feature_meta["sha256"]:
        raise ValueError("feature CSV hash differs from the prepared source manifest")
    chosen_index = np.searchsorted(capture_time, chosen_time)
    if (chosen_index >= len(capture_time)).any() or not np.array_equal(capture_time[chosen_index], chosen_time):
        raise ValueError("selected capture timestamp is absent from the canonical feature CSV")
    if not np.array_equal(values[chosen_index], original):
        raise ValueError("prepared visual values differ from their canonical selected captures")
    if "visual_source_start_ns" in data and not np.array_equal(
            capture_origins[chosen_index], np.asarray(data["visual_source_start_ns"])):
        raise ValueError("prepared visual source times differ from canonical capture provenance")

    partition_id = np.full(n, -1, dtype=np.int8)
    bounds = {}
    indices = {}
    for label, name in enumerate(PARTITIONS):
        rows = np.asarray(data[name + "_idx"])
        if rows.ndim != 1 or not np.issubdtype(rows.dtype, np.integer):
            raise ValueError(f"{name}_idx must be an integer vector")
        if len(rows) and (rows.min() < 0 or rows.max() >= n or len(np.unique(rows)) != len(rows)):
            raise ValueError(f"invalid or duplicate {name} indices")
        if (partition_id[rows] != -1).any():
            raise ValueError("prepared partition indices overlap")
        partition = source_manifest["split"]["partitions"][name]
        lower = _timestamp(partition["earliest_source"], name + " earliest_source")
        upper = _timestamp(partition["latest_source"], name + " latest_source")
        if lower > upper:
            raise ValueError(f"{name} source interval is reversed")
        if len(rows) and ((capture_origins[chosen_index[rows]] < lower).any()
                          or (chosen_time[rows] > upper).any()):
            raise ValueError(f"original visual source crosses the {name} partition")
        partition_id[rows] = label
        bounds[label] = (lower, upper)
        indices[name] = rows

    static_positions = [FEATURE_COLUMNS.index(name) for name in STATIC_COLUMNS]
    static = original[:, static_positions].copy()
    variants = {"original52": original.copy(), "static40": static}
    origins = capture_origins[chosen_index]
    original_source_begin = np.asarray(data["source_start_ns"])
    original_source_end = np.asarray(data["source_end_ns"])
    for name, source in (("source_start_ns", original_source_begin), ("source_end_ns", original_source_end)):
        if source.shape != (n,) or not np.issubdtype(source.dtype, np.integer):
            raise ValueError(f"{name} must be an integer vector matching time_ns")
    if (original_source_begin > original_source_end).any():
        raise ValueError("prepared source interval is reversed")
    metadata = {"age_minutes": age.astype(np.float32),
                "original_history_minutes": ((chosen_time - origins) / MINUTE_NS).astype(np.float32),
                "partition_id": partition_id, "chosen_capture_index": chosen_index.astype(np.int64)}
    source_ranges = {"original52": (origins, chosen_time), "static40": (chosen_time, chosen_time)}
    column_names = {"original52": list(FEATURE_COLUMNS), "static40": list(STATIC_COLUMNS)}
    clipping = {}
    temporal_positions = [FEATURE_COLUMNS.index(f"ft_{slot}_area{area}")
                          for area in range(1, 5) for slot in (1, 2)]

    for duration in (10, 60):
        spread = np.empty((n, 8), dtype=np.float32)
        counts = np.empty(n, dtype=np.int64)
        spans = np.empty(n, dtype=np.float32)
        source_begin = np.empty(n, dtype=np.int64)
        removed = np.empty(n, dtype=np.int64)
        clipped_capture_indices = set()
        cache = {}
        for i, (label, selected) in enumerate(zip(partition_id, chosen_index)):
            key = (int(label), int(selected))
            if key not in cache:
                end = int(selected) + 1
                raw_begin = int(np.searchsorted(capture_time, int(capture_time[selected]) - duration * MINUTE_NS,
                                               side="left"))
                begin = raw_begin
                if label >= 0:
                    begin = max(begin, int(np.searchsorted(capture_time, bounds[int(label)][0], side="left")))
                if not begin < end:
                    raise ValueError("partition clipping removed the selected current capture")
                if begin > raw_begin:
                    clipped_capture_indices.update(range(raw_begin, begin))
                measured = values[begin:end, temporal_positions].astype(np.float64)
                cache[key] = (measured.std(axis=0, ddof=0).astype(np.float32), end - begin,
                              (int(capture_time[selected]) - int(capture_time[begin])) / MINUTE_NS,
                              int(capture_time[begin]), begin - raw_begin)
            sd, count, span, first, removed_count = cache[key]
            spread[i], counts[i], spans[i], source_begin[i], removed[i] = sd, count, span, first, removed_count
        quality = np.column_stack((age, np.log1p(counts), spans, counts >= 2)).astype(np.float32)
        variant = f"fixed{duration}"
        variants[variant] = np.concatenate((static, spread, quality), axis=1)
        quality_names = ["capture_age_minutes", f"log1p_capture_count{duration}m",
                         f"capture_span{duration}m_minutes", f"has_two_captures{duration}m"]
        column_names[variant] = [*STATIC_COLUMNS,
            *(f"ft_{slot}_std{duration}m_area{area}" for area in range(1, 5) for slot in (1, 2)),
            *quality_names]
        metadata[f"capture_count{duration}"] = counts
        metadata[f"span{duration}"] = spans
        metadata[f"source_begin{duration}_ns"] = source_begin
        metadata[f"source_end{duration}_ns"] = chosen_time.copy()
        metadata[f"boundary_removed_count{duration}"] = removed
        source_ranges[variant] = (source_begin, chosen_time)
        clipping[variant] = {"samples_with_older_captures_excluded": int((removed > 0).sum()),
                             "capture_occurrences_excluded": int(removed.sum()),
                             "unique_captures_excluded": len(clipped_capture_indices)}
        if duration == 10:
            variants["timing4"] = quality.copy()
            column_names["timing4"] = quality_names
            source_ranges["timing4"] = (source_begin, chosen_time)

    variant_manifest = {}
    all_rows = np.arange(n)
    for name, matrix in variants.items():
        if matrix.shape != (n, len(column_names[name])) or not np.isfinite(matrix).all():
            raise FloatingPointError(f"invalid diagnostic feature variant {name}")
        begin, end = source_ranges[name]
        partition_summaries = {}
        cross_count = 0
        for label, partition_name in enumerate(PARTITIONS):
            rows = indices[partition_name]
            lower, upper = bounds[label]
            crosses = (begin[rows] < lower) | (end[rows] > upper) | (end[rows] > chosen_time[rows])
            count = int(crosses.sum())
            cross_count += count
            summary = _range_summary(begin, end, rows)
            summary.update({"cross_boundary_samples_after_clipping": count,
                            "unique_selected_captures": int(len(np.unique(chosen_index[rows]))),
                            "unique_source_captures": _unique_source_captures(capture_time, begin, end, rows)})
            if name.startswith("fixed") or name == "timing4":
                duration = 10 if name == "timing4" else int(name[5:])
                removed = metadata[f"boundary_removed_count{duration}"][rows]
                summary["samples_with_older_captures_excluded"] = int((removed > 0).sum())
                summary["capture_occurrences_excluded"] = int(removed.sum())
            partition_summaries[partition_name] = summary
        if cross_count:
            raise ValueError(f"{name} contains a cross-partition visual source")
        variant_manifest[name] = {"columns": column_names[name], "shape": list(matrix.shape),
            "source_range": _range_summary(begin, end, all_rows),
            "cross_boundary_samples_after_clipping": cross_count,
            "unique_selected_captures": int(len(np.unique(chosen_index))),
            "unique_source_captures": _unique_source_captures(capture_time, begin, end, all_rows),
            "partitions": partition_summaries}
        if name in clipping:
            variant_manifest[name]["boundary_clipping"] = clipping[name]
        elif name == "timing4":
            variant_manifest[name]["boundary_clipping"] = clipping["fixed10"]

    # Purging a later residual-model split must account for every upstream
    # source actually consumed by a positive visual variant, including duration
    # windows that can extend beyond the baseline six-capture source history.
    for name, (begin, end) in source_ranges.items():
        metadata[f"variant_source_start_ns_{name}"] = begin.copy()
        metadata[f"variant_source_end_ns_{name}"] = end.copy()
    metadata["source_start_ns"] = np.minimum.reduce((original_source_begin,
        metadata["source_begin10_ns"], metadata["source_begin60_ns"]))
    metadata["source_end_ns"] = np.maximum.reduce((original_source_end, chosen_time))

    manifest = {"schema": 1, "protocol": "fixed prepared rows; current/past capture features only",
        "feature_source": feature_meta, "samples": n,
        "unassigned_purge_samples": int((partition_id < 0).sum()),
        "partition_labels": {name: label for label, name in enumerate(PARTITIONS)},
        "window_definition": "inclusive [selected_capture - duration, selected_capture], clipped at partition earliest_source",
        "quality_definition": ["minutes from selected capture to prediction time minus one minute",
                               "log1p(number of distinct captures in the clipped duration)",
                               "minutes between earliest and selected capture", "one if at least two captures else zero"],
        "temporal_definition": "population SD (ddof=0) of raw per-capture ft_1 and ft_2; singleton SD is zero",
        "future_captures_used": False, "prepared_samples_or_indices_changed": False,
        "residual_purge_source_union": _range_summary(metadata["source_start_ns"], metadata["source_end_ns"], all_rows),
        "variants": variant_manifest}
    return variants, metadata, manifest
