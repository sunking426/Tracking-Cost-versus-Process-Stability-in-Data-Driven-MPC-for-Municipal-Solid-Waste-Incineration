"""Paired surrogate control comparisons and explicitly offline advisory replay."""
from __future__ import annotations

import csv
import copy
import hashlib
import json
import shutil
from pathlib import Path

import numpy as np
import torch

from .control import (
    ActorPolicy, LinearFeedbackPolicy, NearestLoggedActionPolicy, TARGETS,
    TwinEnv, observations_from_data,
)
from .models import make_state
from .baselines import CEMMPCPolicy
from .rl import build_logged_transitions, eligible_start_indices, train_td3


LABELS = {
    "linear_feedback": "Linear feedback",
    "nearest_logged": "Nearest logged action",
    "bc": "Behavior cloning",
    "twin_td3": "Twin-TD3",
    "sensor_td3bc": "Sensor-only TD3+BC",
    "full_td3bc": "Full TD3+BC",
    "no_bc_init": "Without BC initialization",
    "no_bc_reg": "Without BC regularization",
    "no_policy_retrieval": "Without policy visual retrieval",
    "offline_td3bc": "Logged-only TD3+BC",
    "cem_mpc": "CEM-MPC",
}
MAIN_METHODS = ("linear_feedback", "nearest_logged", "bc", "twin_td3", "sensor_td3bc", "full_td3bc")
ABLATIONS = {
    "Full": "full_td3bc", "Without BC initialization": "no_bc_init",
    "Without BC regularization": "no_bc_reg", "Without image": "sensor_td3bc",
    "Without policy visual retrieval": "no_policy_retrieval",
}


def select_evaluation_starts(data, stats, episodes=50, horizon=50):
    eligible = eligible_start_indices(data, stats, "test_idx")
    times = np.asarray(data["time_ns"], dtype=np.int64)
    last_test = times[np.asarray(data["test_idx"], dtype=np.int64)].max()
    eligible = eligible[times[eligible] + (horizon - 1) * 60_000_000_000 <= last_test]
    eligible = eligible[np.argsort(times[eligible], kind="stable")]
    separated = []
    last = None
    for idx in eligible:
        if last is None or times[idx] - times[last] >= horizon * 60_000_000_000:
            separated.append(int(idx))
            last = int(idx)
    if len(separated) < episodes:
        raise ValueError(
            f"Only {len(separated)} non-overlapping feasible test starts; {episodes} requested"
        )
    take = np.linspace(0, len(separated) - 1, int(episodes), dtype=np.int64)
    starts = np.asarray(separated, dtype=np.int64)[take]
    if len(np.unique(starts)) != episodes:
        raise AssertionError("Evaluation reset states must not be duplicated")
    return starts, {
        "eligible_test_starts": len(eligible),
        "nonoverlapping_candidates": len(separated),
        "selected_starts": len(starts),
        "minimum_start_separation_minutes": int(horizon),
        "qualification": "Initial MV within training empirical bounds; same held-out starts for all methods",
    }


def trajectory_metrics(rewards, control, violation):
    rewards = np.asarray(rewards, dtype=np.float64)
    control = np.asarray(control, dtype=np.float64)
    violation = np.asarray(violation, dtype=bool)
    if rewards.ndim != 2 or control.shape != (*rewards.shape, 4) or violation.shape != rewards.shape:
        raise ValueError("Trajectory arrays have incompatible shapes")
    if not np.isfinite(rewards).all() or not np.isfinite(control).all():
        raise FloatingPointError("Evaluation contains nonfinite outputs")
    if (rewards > 1e-7).any():
        raise ValueError("Negative-cost evaluation contains positive rewards")
    episode_returns = rewards.sum(axis=1)
    stable = ~violation.any(axis=1)
    return {
        "mean_return": float(episode_returns.mean()),
        "return_std_episode": float(episode_returns.std(ddof=1)) if len(rewards) > 1 else 0.0,
        "tracking_mae": np.abs(control - TARGETS).mean(axis=(0, 1)).tolist(),
        "stability_rate": float(stable.mean()),
        "violation_rate": float(violation.mean()),
        "stable_episodes": int(stable.sum()), "episodes": len(rewards),
        "violation_steps": int(violation.sum()), "steps": int(violation.size),
        "recovery_steps": None,
        "recovery_qualification": "No externally identified disturbance events; recovery time is not estimated",
    }


def evaluate_policy(env, policy, start_indices, horizon, method, seed, data, outdir):
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    observation = env.reset(start_indices)
    policy.reset(observation)
    reward_rows, controls, violations, states, mvs, actions, normalized_actions = [], [], [], [], [], [], []
    for _ in range(int(horizon)):
        chosen = policy(observation)
        observation, reward, info = env.step(chosen)
        reward_rows.append(reward)
        controls.append(info["control"])
        violations.append(info["violation"])
        states.append(info["z"])
        mvs.append(info["u"])
        actions.append(info["executed_action"])
        normalized_actions.append(info["normalized_executed_action"])
    arrays = {
        "rewards": np.stack(reward_rows, axis=1),
        "control": np.stack(controls, axis=1),
        "violation": np.stack(violations, axis=1),
        "z": np.stack(states, axis=1), "u": np.stack(mvs, axis=1),
        "actions": np.stack(actions, axis=1),
        "normalized_actions": np.stack(normalized_actions, axis=1),
        "start_indices": np.asarray(start_indices, dtype=np.int64),
        "start_time_ns": np.asarray(data["time_ns"])[start_indices],
    }
    metrics = trajectory_metrics(arrays["rewards"], arrays["control"], arrays["violation"])
    metrics.update({"method": method, "seed": int(seed), "label": LABELS[method]})
    if isinstance(policy, CEMMPCPolicy):
        metrics["planning"] = policy.metrics()
        (outdir / "planning.json").write_text(json.dumps(metrics["planning"], indent=2) + "\n")
    np.savez_compressed(outdir / "evaluation.npz", **arrays)
    (outdir / "evaluation_metrics.json").write_text(json.dumps(metrics, indent=2) + "\n")
    return arrays, metrics


def _write_trajectory_rows(writer, arrays, method, seed):
    episodes, horizon = arrays["rewards"].shape
    for episode in range(episodes):
        for step in range(horizon):
            row = {
                "method": method, "seed": int(seed), "episode": episode,
                "start_index": int(arrays["start_indices"][episode]),
                "start_time_ns": int(arrays["start_time_ns"][episode]),
                "sim_time_ns": int(arrays["start_time_ns"][episode] + (step + 1) * 60_000_000_000),
                "step": step + 1, "reward": float(arrays["rewards"][episode, step]),
                "temperature": float(arrays["control"][episode, step, 0]),
                "pressure": float(arrays["control"][episode, step, 1]),
                "steam_flow": float(arrays["control"][episode, step, 2]),
                "oxygen": float(arrays["control"][episode, step, 3]),
                "violation": int(arrays["violation"][episode, step]),
            }
            for prefix, key, dim in (("u", "u", 8), ("action", "actions", 8),
                                      ("normalized_action", "normalized_actions", 8), ("z", "z", 9)):
                row.update({f"{prefix}_{i}": float(arrays[key][episode, step, i]) for i in range(dim)})
            writer.writerow(row)


def aggregate_runs(run_arrays, by_seed):
    rewards = np.concatenate([x["rewards"] for x in run_arrays], axis=0)
    controls = np.concatenate([x["control"] for x in run_arrays], axis=0)
    violations = np.concatenate([x["violation"] for x in run_arrays], axis=0)
    summary = trajectory_metrics(rewards, controls, violations)
    seed_returns = [x["mean_return"] for x in by_seed]
    summary["policy_seed_count"] = len(by_seed)
    summary["seed_mean_return_std"] = float(np.std(seed_returns, ddof=1)) if len(seed_returns) > 1 else 0.0
    summary["tracking_mae_std_between_seeds"] = (
        np.std([x["tracking_mae"] for x in by_seed], axis=0, ddof=1).tolist()
        if len(by_seed) > 1 else [0.0] * 4
    )
    return summary


@torch.no_grad()
def recommend_actions(actor, twin, observation, stats):
    state = make_state(twin, **observation)
    normalized = actor(state).numpy()
    scale = np.asarray(stats["action_scale"], dtype=np.float32)
    bound = np.asarray(stats["action_bound"], dtype=np.float32)
    requested = np.clip(normalized, -1, 1) * scale
    requested[:, bound == 0] = 0
    current = observation["u_current"].numpy()
    next_requested = current + requested
    low = np.asarray(stats["u_low"], dtype=np.float32)
    high = np.asarray(stats["u_high"], dtype=np.float32)
    supported = (
        (np.abs(requested) <= bound + 1e-5).all(axis=1)
        & (next_requested >= low - 1e-5).all(axis=1)
        & (next_requested <= high + 1e-5).all(axis=1)
    )
    return {"normalized_action": normalized, "requested_action": requested,
            "requested_next_u": next_requested, "within_empirical_action_envelope": supported}


def _consecutive_advisory_indices(data, requested):
    idx = np.asarray(data["test_idx"], dtype=np.int64)
    idx = idx[np.asarray(data["next_idx"])[idx] >= 0]
    if not len(idx):
        raise ValueError("No held-out logged action pairs for advisory replay")
    times = np.asarray(data["time_ns"], dtype=np.int64)[idx]
    breaks = np.flatnonzero(np.diff(times) != 60_000_000_000) + 1
    segments = np.split(idx, breaks)
    long_enough = [s for s in segments if len(s) >= requested]
    segment = long_enough[0] if long_enough else max(segments, key=len)
    return segment[:int(requested)]


@torch.no_grad()
def offline_advisory_replay(actor, twin, data, stats, config, outdir, seed):
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    requested = int(config.get("evaluation", {}).get("advisory_steps", 360))
    idx = _consecutive_advisory_indices(data, requested)
    observation = observations_from_data(data, idx)
    recommendations = recommend_actions(actor.eval(), twin.eval(), observation, stats)
    executed = np.asarray(data["action"][idx], dtype=np.float32)
    scale = np.asarray(stats["action_scale"], dtype=np.float32)
    actual_normalized = executed / scale
    chosen = recommendations["requested_action"] / scale
    tolerance = float(config.get("evaluation", {}).get("direction_zero_tolerance", 0.01))
    sign_chosen = np.where(np.abs(chosen) <= tolerance, 0, np.sign(chosen))
    sign_actual = np.where(np.abs(actual_normalized) <= tolerance, 0, np.sign(actual_normalized))
    active = sign_actual != 0
    agreed = sign_chosen == sign_actual
    deviation = np.linalg.norm(chosen - actual_normalized, axis=1)
    supported = recommendations["within_empirical_action_envelope"]
    metrics = {
        "setting": "offline replay of held-out observations; recommendations were not issued to operators or executed",
        "policy_seed": int(seed), "requested_steps": requested, "observed_steps": len(idx),
        "start_time_ns": int(data["time_ns"][idx[0]]), "end_time_ns": int(data["time_ns"][idx[-1]]),
        "historical_time_span_minutes": float((data["time_ns"][idx[-1]] - data["time_ns"][idx[0]]) / 60e9),
        "action_support_ratio": float(supported.mean()),
        "outside_empirical_action_envelope_ratio": float((~supported).mean()),
        "direction_agreement_all_channels": float(agreed.mean()),
        "direction_agreement_active_logged_channels": float(agreed[active].mean()) if active.any() else None,
        "direction_denominator_all": int(agreed.size), "direction_denominator_active": int(active.sum()),
        "direction_zero_tolerance_normalized": tolerance,
        "mean_normalized_action_deviation": float(deviation.mean()),
        "operator_adoption_rate": None, "alarm_rate": None,
        "qualification": "Historical envelope and action agreement do not establish plant safety or causal control improvement",
    }
    fields = ["sample_index", "time_ns", "supported", "normalized_action_deviation"]
    fields += [f"recommended_action_{i}" for i in range(8)] + [f"logged_action_{i}" for i in range(8)]
    with (outdir / "advisory_replay.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for j, sample in enumerate(idx):
            row = {"sample_index": int(sample), "time_ns": int(data["time_ns"][sample]),
                   "supported": int(supported[j]), "normalized_action_deviation": float(deviation[j])}
            row.update({f"recommended_action_{i}": float(recommendations["requested_action"][j, i]) for i in range(8)})
            row.update({f"logged_action_{i}": float(executed[j, i]) for i in range(8)})
            writer.writerow(row)
    (outdir / "metrics.json").write_text(json.dumps(metrics, indent=2) + "\n")
    return metrics


def _trajectory_fieldnames():
    names = ["method", "seed", "episode", "start_index", "start_time_ns", "sim_time_ns",
             "step", "reward", "temperature", "pressure", "steam_flow", "oxygen", "violation"]
    names += [f"{prefix}_{i}" for prefix, dim in
              (("u", 8), ("action", 8), ("normalized_action", 8), ("z", 9)) for i in range(dim)]
    return names


def _static_policies(data, stats, full_twin, eval_twin, bc_full, training_memory, config):
    cfg = config.get("evaluation", {})
    policies = {
        "linear_feedback": LinearFeedbackPolicy(data, stats, gain=float(cfg.get("feedback_gain", 0.1))),
        "nearest_logged": NearestLoggedActionPolicy(data, stats),
        "bc": ActorPolicy(bc_full, full_twin),
    }
    if "cem_mpc" in cfg.get("additional_baselines", []):
        if full_twin is eval_twin:
            raise ValueError("CEM-MPC planning and evaluation must use distinct fitted twins")
        policies["cem_mpc"] = CEMMPCPolicy(full_twin, training_memory, stats, bc_full,
                                         **dict(config.get("mpc", {})))
    return policies


def run_control_suite(data, stats, full_twin, sensor_twin, eval_twin, bc_full, bc_sensor, config, outdir):
    """Train named policy variants and evaluate all on paired surrogate starts."""
    from .retrieval import VisualMemory
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    cfg = config.get("evaluation", {})
    episodes, horizon = int(cfg.get("episodes", 50)), int(cfg.get("horizon", 50))
    starts, eligibility = select_evaluation_starts(data, stats, episodes, horizon)
    seeds = [int(x) for x in config.get("rl", {}).get("seeds", [11, 23, 37])]
    if not seeds or len(set(seeds)) != len(seeds):
        raise ValueError("RL seeds must be nonempty and unique")
    additional = list(cfg.get("additional_baselines", []))
    if len(additional) != len(set(additional)) or not set(additional) <= {"offline_td3bc", "cem_mpc"}:
        raise ValueError("Additional baselines must uniquely name offline_td3bc and/or cem_mpc")
    memory_cfg = config.get("retrieval", {})
    memory_args = {"max_items": int(memory_cfg.get("max_items", 512)), "k": int(memory_cfg.get("k", 3))}
    training_memory = VisualMemory(full_twin, data, data["train_idx"], **memory_args)
    evaluation_memory = VisualMemory(eval_twin, data, data["train_idx"], **memory_args)
    for name, memory in (("training_memory", training_memory), ("evaluation_memory", evaluation_memory)):
        memory.save(outdir / name)
    train_env = TwinEnv(full_twin, training_memory, stats, data, config)
    eval_env = TwinEnv(eval_twin, evaluation_memory, stats, data, config)
    logged_full = build_logged_transitions(data, stats, full_twin)
    logged_sensor = build_logged_transitions(data, stats, sensor_twin)
    logged_hold = build_logged_transitions(data, stats, full_twin, policy_visual="hold")
    results = {
        "setting": "paired closed-loop learned-surrogate evaluation; not physical plant control",
        "evaluation_start_indices": starts.tolist(), "start_eligibility": eligibility,
        "episodes_per_policy_seed": episodes, "steps_per_episode": horizon,
        "rl_seeds": seeds, "main_methods": list(MAIN_METHODS) + additional, "ablation_methods": ABLATIONS,
        "tracking_targets": TARGETS.tolist(), "oxygen_reward_interval": [3.5, 4.0],
        "envelope_definition": "training 1st/99th percentiles of four controlled quantities",
        "results": {}, "advisory": None,
        "additional_baselines": additional,
    }
    fieldnames = _trajectory_fieldnames()
    selected_full_actor = None
    with (outdir / "trajectories.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        static = _static_policies(data, stats, full_twin, eval_twin, bc_full, training_memory, config)
        for method, policy in static.items():
            arrays, metrics = evaluate_policy(
                eval_env, policy, starts, horizon, method, 0, data, outdir / method / "evaluation"
            )
            _write_trajectory_rows(writer, arrays, method, 0)
            results["results"][method] = {"label": LABELS[method], "summary": aggregate_runs([arrays], [metrics]),
                                           "by_seed": [metrics], "evaluation_files": [str(Path(method) / "evaluation" / "evaluation.npz")]}
            (outdir / "results.json").write_text(json.dumps(results, indent=2) + "\n")
        bc_weight = float(config.get("rl", {}).get("bc_weight", 1.0))
        variants = {
            "twin_td3": (full_twin, bc_full, False, 0.0, "retrieval", logged_full),
            "sensor_td3bc": (sensor_twin, bc_sensor, True, bc_weight, "retrieval", logged_sensor),
            "full_td3bc": (full_twin, bc_full, True, bc_weight, "retrieval", logged_full),
            "no_bc_init": (full_twin, bc_full, False, bc_weight, "retrieval", logged_full),
            "no_bc_reg": (full_twin, bc_full, True, 0.0, "retrieval", logged_full),
            "no_policy_retrieval": (full_twin, bc_full, True, bc_weight, "hold", logged_hold),
        }
        if "offline_td3bc" in additional:
            variants["offline_td3bc"] = (full_twin, bc_full, True, bc_weight, "retrieval", logged_full)
        for method, (policy_twin, initialization, use_bc_init, weight, visual, logs) in variants.items():
            runs, seed_metrics, files = [], [], []
            method_config = config
            training_env = train_env
            if method == "offline_td3bc":
                method_config = copy.deepcopy(config)
                method_config["rl"]["synthetic_fraction"] = 0.0
                training_env = None
            for seed in seeds:
                destination = outdir / method / f"seed_{seed}"
                learned, training_metrics = train_td3(
                    initialization, policy_twin, training_env, data, stats, seed, method_config, destination,
                    bc_weight=weight, bc_init=use_bc_init, policy_visual=visual, logged=logs,
                )
                arrays, metrics = evaluate_policy(
                    eval_env, ActorPolicy(learned, policy_twin, visual), starts, horizon, method, seed,
                    data, destination,
                )
                metrics["training"] = training_metrics
                _write_trajectory_rows(writer, arrays, method, seed)
                stream.flush()
                runs.append(arrays)
                seed_metrics.append(metrics)
                files.append(str(Path(method) / f"seed_{seed}" / "evaluation.npz"))
                if method == "full_td3bc" and seed == seeds[0]:
                    selected_full_actor = learned
            results["results"][method] = {
                "label": LABELS[method], "summary": aggregate_runs(runs, seed_metrics),
                "by_seed": seed_metrics, "evaluation_files": files,
            }
            (outdir / "results.json").write_text(json.dumps(results, indent=2) + "\n")
    if selected_full_actor is None:
        raise AssertionError("Predetermined first-seed full actor was not trained")
    results["advisory"] = offline_advisory_replay(
        selected_full_actor, full_twin, data, stats, config, outdir / "advisory", seeds[0]
    )
    (outdir / "results.json").write_text(json.dumps(results, indent=2) + "\n")
    return results


def replay_control_suite(data, stats, full_twin, sensor_twin, eval_twin, bc_full, bc_sensor,
                         config, source_control, outdir):
    """Re-evaluate recorded policy checkpoints without any optimizer updates.

    Baselines, action execution, dynamics, trajectory recording and aggregation
    use exactly the same owners as ``run_control_suite``. Historical training
    metadata remains explicitly labelled as source metadata. ``outdir`` must be
    independent of ``source_control`` so frozen reference trajectories survive.
    """
    from .retrieval import VisualMemory
    from .training import load_actor

    source_control, outdir = Path(source_control).resolve(), Path(outdir).resolve()
    if (source_control == outdir or source_control in outdir.parents
            or outdir in source_control.parents):
        raise ValueError("Replay output must be independent of the reference control directory")
    source_path = source_control / "results.json"
    source = json.loads(source_path.read_text())
    cfg = config.get("evaluation", {})
    seeds = [int(x) for x in config["rl"]["seeds"]]
    additional = list(cfg.get("additional_baselines", []))
    expected = set(MAIN_METHODS) | {"no_bc_init", "no_bc_reg", "no_policy_retrieval"} | set(additional)
    if not seeds or len(seeds) != len(set(seeds)) or source["rl_seeds"] != seeds:
        raise ValueError("Replay optimization seeds differ from the recorded policy set")
    if set(source["results"]) != expected or source["main_methods"] != list(MAIN_METHODS) + additional:
        raise ValueError("Replay methods differ from the recorded policy set")
    episodes, horizon = int(cfg["episodes"]), int(cfg["horizon"])
    if source["episodes_per_policy_seed"] != episodes or source["steps_per_episode"] != horizon:
        raise ValueError("Replay horizon or reset count differs from the recorded evaluation")
    starts, _ = select_evaluation_starts(data, stats, episodes, horizon)
    if not np.array_equal(starts, np.asarray(source["evaluation_start_indices"])):
        raise ValueError("Prepared data no longer produces the recorded evaluation resets")
    static_names = {"linear_feedback", "nearest_logged", "bc", "cem_mpc"}
    actors = {}
    for method, entry in source["results"].items():
        expected_seeds = [0] if method in static_names else seeds
        if [row["seed"] for row in entry["by_seed"]] != expected_seeds:
            raise ValueError(f"Recorded seed metadata is incomplete for {method}")
        if method not in static_names:
            for seed in seeds:
                path = source_control / method / f"seed_{seed}" / "actor.pt"
                if not path.is_file():
                    raise FileNotFoundError(f"Missing replay policy checkpoint: {path}")
                actors[method, seed] = path

    outdir.mkdir(parents=True, exist_ok=True)
    memory_cfg = config.get("retrieval", {})
    memory_args = {"max_items": int(memory_cfg.get("max_items", 512)), "k": int(memory_cfg.get("k", 3))}
    training_memory = VisualMemory(full_twin, data, data["train_idx"], **memory_args)
    evaluation_memory = VisualMemory(eval_twin, data, data["train_idx"], **memory_args)
    training_memory.save(outdir / "training_memory")
    evaluation_memory.save(outdir / "evaluation_memory")
    env = TwinEnv(eval_twin, evaluation_memory, stats, data, config)
    static = _static_policies(data, stats, full_twin, eval_twin, bc_full, training_memory, config)
    result = {key: copy.deepcopy(value) for key, value in source.items() if key not in {"results", "advisory"}}
    result.update({"results": {}, "advisory": None,
                   "operation": "checkpoint inference and surrogate rollout replay; no policy training",
                   "training_updates_performed": 0,
                   "source_results_sha256": hashlib.sha256(source_path.read_bytes()).hexdigest()})
    selected_full_actor = None
    with (outdir / "trajectories.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=_trajectory_fieldnames())
        writer.writeheader()
        for method, entry in source["results"].items():
            runs, by_seed, files = [], [], []
            for previous in entry["by_seed"]:
                seed = int(previous["seed"])
                if method in static:
                    destination = outdir / method / "evaluation"
                    policy = static[method]
                else:
                    destination = outdir / method / f"seed_{seed}"
                    actor = load_actor(actors[method, seed])
                    policy_twin = sensor_twin if method == "sensor_td3bc" else full_twin
                    visual = "hold" if method == "no_policy_retrieval" else "retrieval"
                    policy = ActorPolicy(actor, policy_twin, visual)
                    if method == "full_td3bc" and seed == seeds[0]:
                        selected_full_actor = actor
                arrays, metrics = evaluate_policy(env, policy, starts, horizon, method, seed, data, destination)
                if method not in static:
                    shutil.copy2(actors[method, seed], destination / "actor.pt")
                    metrics["source_actor_sha256"] = hashlib.sha256(actors[method, seed].read_bytes()).hexdigest()
                if "training" in previous:
                    metrics["training"] = copy.deepcopy(previous["training"])
                    metrics["training_provenance"] = "Recorded source optimization metadata; no updates performed in replay"
                metrics["replay_training_updates"] = 0
                (destination / "evaluation_metrics.json").write_text(json.dumps(metrics, indent=2) + "\n")
                _write_trajectory_rows(writer, arrays, method, seed)
                stream.flush()
                runs.append(arrays)
                by_seed.append(metrics)
                files.append(str((destination / "evaluation.npz").relative_to(outdir)))
            result["results"][method] = {"label": entry["label"], "summary": aggregate_runs(runs, by_seed),
                                          "by_seed": by_seed, "evaluation_files": files}
            (outdir / "results.json").write_text(json.dumps(result, indent=2) + "\n")
    if selected_full_actor is None:
        raise AssertionError("Predetermined full actor is absent from replay")
    result["advisory"] = offline_advisory_replay(
        selected_full_actor, full_twin, data, stats, config, outdir / "advisory", seeds[0])
    (outdir / "results.json").write_text(json.dumps(result, indent=2) + "\n")
    return result
