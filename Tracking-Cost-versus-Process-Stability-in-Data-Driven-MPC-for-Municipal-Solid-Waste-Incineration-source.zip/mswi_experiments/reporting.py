"""Report fixed-protocol experimental strengthening without editing the paper."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import torch

from .data import control_values, load_data
from .training import load_twin, predict_twin




def _json(path):return json.loads(Path(path).read_text())
def _sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def compare_prediction_pipelines(previous, output, destination):
    """Compare fixed fits at the same dates, using each fit's own descriptor units.

    This is a descriptive whole-pipeline contrast, not an isolated ROI effect or
    a claim that different learned evaluation dynamics give comparable returns.
    """
    old,_,_=load_data(previous/'data');new,_,_=load_data(output/'data')
    new_indices=np.asarray(new['test_idx'])
    mapping={int(t):i for i,t in enumerate(old['time_ns'])}
    old_indices=np.asarray([mapping[int(t)] for t in new['time_ns'][new_indices]],dtype=np.int64)
    if not np.isin(old_indices,old['test_idx']).all():raise AssertionError('New test dates leave the original test partition')
    truth=control_values(new['z_target'][new_indices]);np.testing.assert_array_equal(truth,control_values(old['z_target'][old_indices]))
    raw={'time_ns':new['time_ns'][new_indices],'truth':truth};summary={'n':len(truth),'models':{}}
    torch.set_num_threads(4)
    for mode in ['multi','sensor']:
        old_model=load_twin(previous/'models'/f'twin_{mode}'/'twin.pt')
        old_prediction=control_values(predict_twin(old_model,old,old_indices))
        with np.load(output/'validation'/f'{mode}_onestep.npz',allow_pickle=False) as record:
            np.testing.assert_array_equal(record['indices'],new_indices)
            new_prediction=record['prediction'].copy()
        raw['old_'+mode]=old_prediction;raw['corrected_'+mode]=new_prediction
        summary['models'][mode]={'old_mae':abs(old_prediction.astype(float)-truth).mean(axis=0).tolist(),
            'corrected_mae':abs(new_prediction.astype(float)-truth).mean(axis=0).tolist(),
            'old_model_sha256':_sha(previous/'models'/f'twin_{mode}'/'twin.pt'),
            'corrected_model_sha256':_sha(output/'models'/f'twin_{mode}'/'twin.pt')}
    summary['qualification']='Same test timestamps and targets; descriptor definitions and source-aware partitioning changed together. Descriptive pipeline contrast, not isolated ROI causality.'
    np.savez_compressed(destination/'same_timestamp_prediction_comparison.npz',**raw)
    (destination/'same_timestamp_prediction_comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
    return summary


def write_report(output: Path, previous: Path):
    output,previous=output.resolve(),previous.resolve()
    report=output/'report';report.mkdir(exist_ok=True)
    protocol=_json(output/'protocol.json');validation=_json(output/'validation/validation_results.json')
    statistics=_json(output/'statistics/paired_statistics.json');controls=_json(output/'control/results.json')
    analysis=_json(output/'analysis/analysis_results.json');data_manifest=_json(output/'data/manifest.json')
    verification=_json(output/'control/verification_report.json')
    comparison=compare_prediction_pipelines(previous,output,report)
    paper=Path(__file__).resolve().parents[2]/'sci/applied_intelligence_revision_20261102'
    changed=[name for name,digest in protocol['protected_manuscript_files'].items() if _sha(paper/name)!=digest]
    if changed:raise AssertionError(f'Protected manuscript files changed: {changed}')

    lines=['固定方案补强实验结果（先汇报，不更新论文）\n',
        '本轮改变：按真实图像宽高归一化ROI；提取前不画线；面积用比例；修正明确的均值/水平重心错误；恢复最近六张捕获的因果时间标准差。保留8,070原图、52维；完整来源记录用于时间划分。\n',
        '模型架构、监督训练上限20/早停4、奖励与动作边界规则保持预定设置。RL五个优化种子11/23/37/53/71；每种子1,500 critic、750 actor更新。新增严格logged-only TD3+BC与固定预算CEM-MPC。编码器和BC只训练种子11，五种子的区间条件于这些固定模型，不代表全训练流水线不确定性。\n']
    counts={name:record['samples'] for name,record in data_manifest['split']['partitions'].items()}
    lines.append(f"训练/验证/测试窗口：{counts['train']}/{counts['val']}/{counts['test']}。按所有六张实际图像源排除边界样本，不能把样本变化误当视觉收益。\n")
    lines+=['预测：修正后多模态、传感器、评估twin及保持上次值(persistence)单步MAE。顺序均为温度°C/负压Pa/蒸汽t/h/氧vol%。\n']
    for name,record in validation['models'].items():
        lines.append(f"{name}: "+', '.join(f'{v:.6f}' for v in record['onestep']['mae'])+'\n')
    lines+=['\n旧/新特征流水线在完全相同测试时间点的单步MAE对比（不是单独ROI因果效应）：\n']
    for name,record in comparison['models'].items():
        lines.append(f"{name} old: "+', '.join(f'{v:.6f}' for v in record['old_mae'])+'\n')
        lines.append(f"{name} corrected: "+', '.join(f'{v:.6f}' for v in record['corrected_mae'])+'\n')
    lines+=['\n递归预测：共同50条轨迹、未来MV固定日志、CV只回填模型预测。各时域端点MAE：\n']
    for name,record in validation['models'].items():
        for h,values in zip(validation['horizons'],record['rollout']['mae']):
            lines.append(f"{name} h={h}: "+', '.join(f'{v:.6f}' for v in values)+'\n')
    lines+=['\n控制：同一批50个起点，先预定前10步为主结果，50步为压力测试；共用同一新评估twin。旧/新控制回报不能当作相同环境上的直接提升幅度，因为动力学也重训。\n']
    for h,section in statistics['horizons'].items():
        lines += [f'\n{h}步：方法 | 平均return | seed均值SD | T MAE | P MAE | F MAE | O MAE | 越界步% | 零越界回合%\n']
        for method in controls['main_methods']:
            record=section['methods'][method];m=record['mean'];sd=record['seed_mean_sd'][0]
            lines.append(f"{method} | {m[0]:.4f} | {sd:.4f} | "+' | '.join(f'{v:.4f}' for v in m[1:5])+f' | {100*m[5]:.3f} | {100*m[6]:.2f}\n')
        lines.append('完整方法减对照的return配对差（正值利于完整方法）；95%交叉seed/reset bootstrap区间为探索性、未多重校正：\n')
        for effect in section['comparisons']:
            ci=effect['seed_reset_crossed_ci95'][0]
            lines.append(f"full minus {effect['comparator']}: {effect['mean_difference'][0]:.4f}, CI [{ci[0]:.4f}, {ci[1]:.4f}]\n")
            for block in effect['blocks']:
                if effect['comparator'] in ['sensor_td3bc','offline_td3bc','cem_mpc']:
                    lines.append(f"  chronological block{block['block']}: {block['mean_difference'][0]:.4f}\n")
    ad=controls['advisory'];lines.append(f"\n离线建议回放：{ad['observed_steps']}观测；原始请求满足经验动作边界{100*ad['action_support_ratio']:.2f}%，日志活动通道方向一致{100*ad['direction_agreement_active_logged_channels']:.2f}%。没有现场执行、采纳或报警数据。\n")
    primary=statistics['horizons']['10'];effects={e['comparator']:e for e in primary['comparisons']}
    full=primary['methods']['full_td3bc']['mean'];bc=primary['methods']['bc']['mean']
    lines+=['\n结果判断（区别于实验是否真实完成）：\n',
        '图像来源/ROI/历史来源问题已修复，强基线、长时域验证和配对统计已补齐；但可靠视觉增益仍未建立。\n',
        f"10步Full−Sensor回报差{effects['sensor_td3bc']['mean_difference'][0]:.4f}，探索性交叉95%区间{effects['sensor_td3bc']['seed_reset_crossed_ci95'][0]}含0。\n",
        f"10步Full−MPC回报差{effects['cem_mpc']['mean_difference'][0]:.4f}，区间{effects['cem_mpc']['seed_reset_crossed_ci95'][0]}；短时域MPC更好，不能写完整方法全面胜出。\n",
        f"Full对BC的综合回报提高，但10步温度跟踪MAE为{full[1]:.3f}°C，BC为{bc[1]:.3f}°C；是固定奖励权重下的取舍，不是所有控制量均改善。\n",
        f"10步多模态递归温度MAE为{validation['models']['multi']['rollout']['mae'][2][0]:.3f}°C，persistence为{validation['models']['persistence']['rollout']['mae'][2][0]:.3f}°C；50步评估twin温度MAE为{validation['models']['eval']['rollout']['mae'][-1][0]:.3f}°C，故模型可信度仍有限。\n",
        '这些结果支持可核查的离线研究和部分模型内策略改进，但不能据此称已经证明多模态核心贡献或满足某分区期刊的录用水平。\n']
    lines+=['\n解释边界：旧test期间之前已经看过，本轮是开发后固定重评，不是新的盲测。三段时间分组用于检验效应方向，不等于moving-block bootstrap；reset CI仍有交换性假设，不能声称已消除时间自相关。CEM为有限预算、分块增量搜索，并非全局最优。\n',
        f"控制独立复算{verification['checks']}项通过，{verification['control_trajectory_rows']}条CSV记录与NPZ对应；所有reward非正。所有32个论文目录文件哈希保持不变。\n"]
    for title,file in [('预测独立复核','validation/verification_report.json'),
                       ('统计独立复核','statistics/verification_report.json'),
                       ('控制优化器及强基线独立审计','control/independent_audit.json')]:
        record=_json(output/file);lines.append(f"{title}：{record['checks']}项，状态{record['status']}。\n")
    (report/'实验结果汇报.txt').write_text('\n'.join(lines))

    from .figures import make_summary_figures
    make_summary_figures(output, report)
    manifest={'status':'complete','manuscript_files_unchanged':True,'protected_file_count':len(protocol['protected_manuscript_files']),
        'control_results_sha256':_sha(output/'control/results.json'),'validation_results_sha256':_sha(output/'validation/validation_results.json'),
        'statistics_sha256':_sha(output/'statistics/paired_statistics.json'),'report_code_sha256':_sha(__file__),
        'figures':[p.name for p in sorted(report.glob('*.png'))]}
    (report/'report_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'report_complete':True,'manuscript_files_unchanged':True,'report':str(report/'实验结果汇报.txt')},ensure_ascii=False))
    return manifest


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);p.add_argument('--previous',type=Path,required=True)
    args=p.parse_args();write_report(args.output,args.previous)
