"""Frozen Ridge operation-response diagnostics across equal-size training periods.

The inputs describe observed state at t and hypothetical MV levels at t+1..t+H.
No response is treated as an identified plant intervention; joint support is
an initial-state proximity screen, not a safety or executability certificate.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil
import time

import numpy as np
from scipy.spatial.distance import cdist
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

from .control import reward_and_violation
from .data import MINUTE_NS, control_values, load_data
from .numeric_baselines import fit_linear_candidates, numeric_features, sha256, write_json
from .ridge_dynamics import RidgeDynamics, continuous_chains
from .ridge_response import (analytic_responses, autoregressive_stability,
                             decision_rollout, physical_coefficients, project_trial_paths)
from .ridge_validation import resolve_predictor

MODEL_IDS = ('full','early','middle','late','pooled_matched')
SPLITS = ('val','test')
SNAPSHOT_NAMES = ('ridge_response_study.py','ridge_response.py','ridge_response_report.py',
                  'ridge_dynamics.py','ridge_validation.py','numeric_baselines.py',
                  'control.py','data.py','numeric_baselines_report.py','ridge_validation_report.py')
FIXED = {'horizon':10,'endpoints':[1,5,10],'alpha':100.,'fraction':.1,
         'training_blocks':3,'anchor_separation_minutes':11,'maximum_anchors':256,
         'support_bank_size':2048,'support_calibration_size':1024,
         'support_exclusion_minutes':11,'support_quantile':.95,
         'response_deadband_sigma':.05,'max_response_amplitude_ratio':3.,
         'minimum_supported_executable_fraction':.8,'gate_endpoints':[1,5,10]}


def archive(path):
    with np.load(path,allow_pickle=False) as source:
        return {k:source[k] for k in source.files}


def verify(hashes,root=None):
    for name,digest in hashes.items():
        path=Path(name) if root is None else Path(root)/name
        if sha256(path)!=digest: raise ValueError('frozen input changed: '+str(path))


def paths(config_file):
    path=Path(config_file).resolve(); cfg=json.loads(path.read_text())
    if any(cfg.get(k)!=v for k,v in FIXED.items()):
        raise ValueError('configuration differs from the fixed response protocol')
    if not isinstance(cfg.get('threads'),int) or cfg['threads']<1:
        raise ValueError('positive integer thread count required')
    return cfg,path.parent,path.parent/cfg['output_dir']


def evenly_spaced(indices,count):
    indices=np.asarray(indices,dtype=np.int64)
    if indices.ndim!=1 or not len(indices) or count<1 or np.any(np.diff(indices)<=0):
        raise ValueError('nonempty ordered unique indices and positive count required')
    return indices[np.linspace(0,len(indices)-1,min(count,len(indices)),dtype=np.int64)]


def training_blocks(data):
    """Equal row counts; trim numeric-source overlap before symmetric trimming."""
    train=np.asarray(data['train_idx'],dtype=np.int64)
    times=np.asarray(data['time_ns'],dtype=np.int64)
    if len(train)<6 or np.any(np.diff(train)<=0) or np.any(np.diff(times[train])<=0):
        raise ValueError('ordered training rows required')
    chunks=np.array_split(train,3); purged=[]; details=[]
    previous_end=None
    for name,chunk in zip(('early','middle','late'),chunks):
        keep=np.ones(len(chunk),dtype=bool)
        if previous_end is not None: keep=times[chunk]-10*MINUTE_NS>previous_end
        remaining=chunk[keep]
        if not len(remaining): raise ValueError('empty temporal training block after source purge')
        previous_end=int(times[chunk[-1]])
        purged.append(remaining)
        details.append({'model_id':name,'chunk_count':len(chunk),'purged_rows':chunk[~keep].tolist(),
                        'after_purge_count':len(remaining)})
    common=min(map(len,purged)); result={}
    for name,idx,detail in zip(('early','middle','late'),purged,details):
        excess=len(idx)-common; left=excess//2
        chosen=idx[left:left+common]
        result[name]=chosen
        detail.update(training_samples=common,trimmed_left=left,trimmed_right=excess-left,
                      first_time_ns=int(times[chosen[0]]),last_time_ns=int(times[chosen[-1]]),
                      source_start_ns=int(times[chosen[0]]-10*MINUTE_NS),source_end_ns=int(times[chosen[-1]]))
    result['pooled_matched']=evenly_spaced(train,common)
    result['full']=train.copy()
    return result,{'equal_block_samples':common,'blocks':details,
        'numeric_source_interval':'[t-10min,t] for predictor input and target; visual sources not used',
        'pooled_matched':'Same number of rows spaced uniformly over all original training rows; deliberately overlaps temporal blocks, not an independent replicate.',
        'regularization':'All four equal-size fits use alpha100. The full model has more rows and is a reference, not a matched regularization comparison.'}


def select_anchors(data,stats,split,horizon=10,minimum_separation=11,maximum=256):
    chains=continuous_chains(data,split,horizon+1)
    if not len(chains): raise ValueError('no complete decision-plus-future chains')
    starts=chains[:,0]; u=np.asarray(data['u_current'],dtype=np.float64)[starts]
    low,high=(np.asarray(stats[k],dtype=np.float64) for k in ('u_low','u_high'))
    allowed=((u>=low)&(u<=high)).all(axis=1)
    times=np.asarray(data['time_ns'],dtype=np.int64)
    candidates=np.flatnonzero(allowed); selected=[]; last=None
    for position in candidates:
        stamp=int(times[starts[position]])
        if last is None or stamp-last>=minimum_separation*MINUTE_NS:
            selected.append(int(position));last=stamp
    selected=np.asarray(selected,dtype=np.int64)
    if not len(selected): raise ValueError('no anchors inside the initial MV envelope')
    chosen=evenly_spaced(selected,maximum)
    return chains[chosen],{'complete_chains':len(chains),'outside_initial_mv_envelope':int((~allowed).sum()),
        'inside_initial_mv_envelope':int(allowed.sum()),'after_time_separation':len(selected),
        'selected':len(chosen),'maximum':maximum,'minimum_separation_minutes':minimum_separation,
        'selection':'Chronological greedy separation then evenly spaced positions; no CV/outcome/model-error criterion',
        'selected_chain_positions':chosen.tolist()}


def joint_features(u,z,delta):
    u,z,delta=[np.asarray(v,dtype=np.float64) for v in (u,z,delta)]
    if u.ndim!=2 or u.shape[1]!=8 or z.shape!=(len(u),9) or delta.shape!=u.shape:
        raise ValueError('joint features require aligned (N,8)/(N,9)/(N,8) arrays')
    x=np.concatenate((u,z,delta),axis=1)
    if not len(x) or not np.isfinite(x).all(): raise ValueError('nonempty finite joint features required')
    return x


def nearest_distance(x,bank,*,query_time=None,bank_time=None,exclusion_minutes=11,chunk_size=128):
    x,bank=[np.asarray(v,dtype=np.float64) for v in (x,bank)]
    if x.ndim!=2 or bank.ndim!=2 or x.shape[1]!=bank.shape[1] or not len(bank):
        raise ValueError('compatible nonempty distance feature arrays required')
    if not np.isfinite(x).all() or not np.isfinite(bank).all(): raise ValueError('nonfinite proximity features')
    if (query_time is None)!=(bank_time is None): raise ValueError('both query and bank times required for exclusion')
    if query_time is not None:
        query_time,bank_time=[np.asarray(v,dtype=np.int64) for v in (query_time,bank_time)]
        if query_time.shape!=(len(x),) or bank_time.shape!=(len(bank),): raise ValueError('distance time identities mismatch')
    result=np.empty(len(x));nearest=np.empty(len(x),dtype=np.int64)
    for start in range(0,len(x),chunk_size):
        stop=min(start+chunk_size,len(x)); distances=cdist(x[start:stop],bank,metric='euclidean')
        if query_time is not None:
            overlap=np.abs(query_time[start:stop,None]-bank_time[None,:])<=exclusion_minutes*MINUTE_NS
            distances[overlap]=np.inf
        closest=np.argmin(distances,axis=1); values=distances[np.arange(stop-start),closest]
        if not np.isfinite(values).all(): raise ValueError('no time-disjoint support donor')
        result[start:stop]=values; nearest[start:stop]=closest
    return result,nearest


def fit_support(data,*,bank_size=2048,calibration_size=1024,quantile=.95,exclusion_minutes=11):
    train=np.asarray(data['train_idx'],dtype=np.int64); next_idx=np.asarray(data['next_idx'],dtype=np.int64)
    times=np.asarray(data['time_ns'],dtype=np.int64)
    valid=np.zeros(len(times),dtype=bool);valid[train]=True
    child=next_idx[train];safe=np.maximum(child,0)
    keep=(child>=0)&valid[safe]&(times[safe]-times[train]==MINUTE_NS)
    rows=train[keep]
    if not len(rows): raise ValueError('no consecutive training state/action pairs')
    u=np.asarray(data['u_current'],dtype=np.float64);z=np.asarray(data['z_current'],dtype=np.float64)
    delta=np.asarray(data['action'],dtype=np.float64)[rows]
    recomputed=u[next_idx[rows]]-u[rows]
    tolerance=np.finfo(np.float32).eps*(np.abs(u[next_idx[rows]])+np.abs(u[rows])+1)
    if np.any(np.abs(delta-recomputed)>tolerance): raise ValueError('recorded action is not the next physical MV increment')
    x=joint_features(u[rows],z[rows],delta);scaler=StandardScaler().fit(x);xs=scaler.transform(x)
    bank_pos=evenly_spaced(np.arange(len(rows)),bank_size)
    calibration_pos=evenly_spaced(np.arange(len(rows)),calibration_size)
    bank=xs[bank_pos]
    distances,nearest=nearest_distance(xs[calibration_pos],bank,query_time=times[rows[calibration_pos]],
        bank_time=times[rows[bank_pos]],exclusion_minutes=exclusion_minutes)
    return {'training_indices':rows,'x_mean':scaler.mean_,'x_scale':scaler.scale_,
        'bank_indices':rows[bank_pos],'bank_time_ns':times[rows[bank_pos]],'bank_standardized':bank,
        'calibration_indices':rows[calibration_pos],'calibration_time_ns':times[rows[calibration_pos]],
        'calibration_distance':distances,'calibration_nearest_bank_position':nearest,
        'threshold':np.asarray(np.quantile(distances,quantile)),
        'quantile':np.asarray(quantile),'exclusion_minutes':np.asarray(exclusion_minutes)}


def support_query(support,u,z,delta,time_ns):
    x=joint_features(u,z,delta);xs=(x-support['x_mean'])/support['x_scale']
    distances,nearest=nearest_distance(xs,support['bank_standardized'],query_time=time_ns,
        bank_time=support['bank_time_ns'],exclusion_minutes=int(support['exclusion_minutes']))
    return distances,distances<=float(support['threshold']),nearest


def prepare(config_file):
    cfg,project,out=paths(config_file)
    if out.exists() and any(out.iterdir()): raise FileExistsError('study preparation requires a new empty directory')
    out.mkdir(parents=True,exist_ok=True)
    source=project/cfg['source_run']/'data';data,stats,_=load_data(source)
    selected,checkpoint,prior,full=resolve_predictor(project,cfg['current_predictor'])
    verify(json.loads((prior/'input_hashes.json').read_text()))
    if json.loads((prior/'stats.json').read_text())!=stats:
        raise ValueError('source model and current data statistics differ')
    if json.loads((prior/'input_hashes.json').read_text()).get(str((source/'dataset.npz').resolve()))!=sha256(source/'dataset.npz'):
        raise ValueError('full model was not trained from this exact dataset')
    if float(full.weights['alpha'])!=100. or not np.array_equal(full.weights['delta_scale'],np.asarray(stats['delta_scale'])):
        raise ValueError('full numerical model is not canonical Ridge100')
    if not np.array_equal(data['z_current'],data['z_target']) or not np.array_equal(data['u_current'],data['u_hist'][:,-1]):
        raise ValueError('initial observed states differ from canonical data')
    numeric_features(data)
    blocks,block_metadata=training_blocks(data)
    rows={k+'_indices':v for k,v in blocks.items()}
    delta=control_values(np.asarray(data['z_target'],dtype=np.float64)-np.asarray(data['z_prev'],dtype=np.float64))
    rows['phys_scale']=np.maximum(np.std(delta[data['train_idx']],axis=0,ddof=0),1e-8)
    metadata={}
    for split in SPLITS:
        rows[split+'_chains'],metadata[split]=select_anchors(data,stats,split,cfg['horizon'],cfg['anchor_separation_minutes'],cfg['maximum_anchors'])
    support=fit_support(data,bank_size=cfg['support_bank_size'],calibration_size=cfg['support_calibration_size'],
        quantile=cfg['support_quantile'],exclusion_minutes=cfg['support_exclusion_minutes'])
    np.savez_compressed(out/'rows.npz',**rows);np.savez_compressed(out/'support.npz',**support)
    (out/'inputs').mkdir()
    for split in SPLITS:
        chain=rows[split+'_chains'];idx=chain[:,0];n=len(idx)
        u,z,current=[np.asarray(data[k],dtype=np.float64)[idx] for k in ('u_hist','z_hist','z_current')]
        trial=project_trial_paths(u[:,-1],stats,cfg['fraction'],cfg['horizon'])
        stamp=np.asarray(data['time_ns'])[idx]
        repeated_u=np.repeat(u[:,-1,None],16,axis=1).reshape(-1,8)
        repeated_z=np.repeat(current[:,None],16,axis=1).reshape(-1,9)
        requested=np.broadcast_to(trial['requested_delta'],(n,16,8)).reshape(-1,8)
        distance,supported,nearest=support_query(support,repeated_u,repeated_z,requested,np.repeat(stamp,16))
        executed_distance,executed_supported,_=support_query(support,repeated_u,repeated_z,trial['executed_delta'].reshape(-1,8),np.repeat(stamp,16))
        base_distance,base_supported,_=support_query(support,u[:,-1],current,np.zeros((n,8)),stamp)
        logged_delta=np.asarray(data['action'],dtype=np.float64)[idx]
        logged_distance,logged_supported,_=support_query(support,u[:,-1],current,logged_delta,stamp)
        np.savez_compressed(out/'inputs'/f'{split}.npz',indices=idx,chains=chain,time_ns=stamp,
            future_time_ns=np.asarray(data['time_ns'])[chain[:,1:]],u_hist=u,z_hist=z,z_current=current,
            truth_cv=np.asarray(data['z_target'],dtype=np.float64)[chain[:,1:]],
            logged_mv=np.asarray(data['u_current'],dtype=np.float64)[chain[:,1:]],
            **trial,support_distance=distance.reshape(n,16),supported=supported.reshape(n,16),
            support_nearest_bank_position=nearest.reshape(n,16),
            executed_support_distance=executed_distance.reshape(n,16),executed_supported=executed_supported.reshape(n,16),
            baseline_support_distance=base_distance,baseline_supported=base_supported,
            logged_delta=logged_delta,logged_support_distance=logged_distance,logged_supported=logged_supported)
    shutil.copyfile(source/'stats.json',out/'stats.json');write_json(out/'config.json',cfg)
    protocol={'scope':'Operation response and cross-training-period consistency; no causal effects, plant intervention, MPC or RL training.',
        'decision_time':'Observe MV t-10..t, CV t-10..t-1 and actual CV_t. First action changes u_(t+1); response h forecasts CV_(t+h). Subsequent CV feedback is predicted only.',
        'patterns':'Pulse: next-minute MV level displacement then return to initial level. Step: displacement retained. Signs and all eight MVs retained; first displacement10% of training action_bound.',
        'projection':'Canonical project_normalized_actions(float64), including pulse reversal. No predicted-CV clipping; in-envelope numerical actions do not certify actuator resolution or plant safety.',
        'training_blocks':block_metadata,'anchors':metadata,
        'support':'25D current MV8/current CV9/physical next delta8, train-only StandardScaler;2048uniform training donors;1024uniform training calibration rows; exclude donor times within11min;95th calibration distance threshold. Initial joint proximity only, not a density certificate or entire-trajectory support.',
        'gate':'Heuristic only, evaluated on training-fit responses and validation-anchor support. At h10 a physical pair is stable when all3 temporal blocks plus pooled_matched exceed the same ±0.05 physical innovation sigma and maxabs/minabs<=3; full reference must not show a material opposite sign. Any material sign conflict among the four matched models at h1/5/10 disqualifies that MV. Each sign must achieve >=0.8 validation fraction of complete requested action AND requested joint support. At least one stable pair is required. Same-model inverse response over time is permitted. No causal or safety claim.',
        'physical_scale':'std(control_values(z_target-z_prev) on all original training rows,ddof0), floor1e-8.',
        'fixed_alpha':'100 for every equal-sized new fit. No validation hyperparameter search or test selection. All models retained.',
        'limits':['Previously inspected validation/test periods: exploratory only.','Full model versus small block models also differs in sample size and effective penalty.','Temporal changes and correlated logged inputs confound causal interpretation.','Initial support can be poor even within marginal MV envelopes.','Model-derived response/reward is not an observed plant outcome.']}
    write_json(out/'protocol.json',protocol)
    write_json(out/'preparation.json',{'status':'complete','blocks':block_metadata,'anchors':metadata,
        'full_model':selected,'support_training_rows':len(support['training_indices']),
        'support_bank_rows':len(support['bank_indices']),'support_calibration_rows':len(support['calibration_indices']),
        'support_threshold':float(support['threshold']),'phys_scale':rows['phys_scale'].tolist()})
    input_files=[source/n for n in ('dataset.npz','stats.json','manifest.json')]
    input_files += [project/cfg['current_predictor'],checkpoint,prior/'selection.json',prior/'selection_frozen.json',prior/'input_hashes.json',prior/'stats.json']
    hashes={str(q.resolve()):sha256(q) for q in input_files};write_json(out/'input_hashes.json',hashes)
    files=['rows.npz','support.npz','stats.json','config.json','protocol.json','preparation.json','input_hashes.json',*[f'inputs/{s}.npz' for s in SPLITS]]
    verify(hashes)
    write_json(out/'prepare_frozen.json',{'status':'complete','files':{n:sha256(out/n) for n in files}})
    print('Prepared equal-size blocks, initial support, and outcome-independent anchors.',flush=True)
    return out


def load_prepared(config_file):
    cfg,project,out=paths(config_file)
    if cfg!=json.loads((out/'config.json').read_text()): raise ValueError('configuration changed after prepare')
    frozen=json.loads((out/'prepare_frozen.json').read_text())
    if frozen.get('status')!='complete': raise ValueError('preparation incomplete')
    verify(frozen['files'],out);verify(json.loads((out/'input_hashes.json').read_text()))
    data,stats,_=load_data(project/cfg['source_run']/'data')
    return cfg,project,out,data,stats,archive(out/'rows.npz'),archive(out/'support.npz')


def fit(config_file):
    cfg,project,out,data,stats,rows,_=load_prepared(config_file)
    if (out/'models').exists() or (out/'selection.json').exists(): raise FileExistsError('models already started; preserve frozen run')
    (out/'models').mkdir();x=numeric_features(data)
    y=np.asarray(data['z_target'],dtype=np.float64);prev=np.asarray(data['z_prev'],dtype=np.float64)
    _,checkpoint,_,full=resolve_predictor(project,cfg['current_predictor']);records=[]
    for model_id in MODEL_IDS:
        path=out/'models'/f'{model_id}.npz';idx=rows[model_id+'_indices']
        if model_id=='full':
            shutil.copyfile(checkpoint,path)
            pred=full.predict_next(data['u_hist'][data['val_idx']],data['z_hist'][data['val_idx']])
            loss=float(np.mean(((pred-y[data['val_idx']])/np.asarray(stats['delta_scale']))**2))
        else:
            weights,candidates,chosen=fit_linear_candidates(x,y-prev,prev,y,idx,data['val_idx'],stats['delta_scale'],[cfg['alpha']])
            if len(candidates)!=1: raise AssertionError('fixed-alpha fitting produced model selection')
            np.savez_compressed(path,**weights);loss=float(chosen['val_normalized_mse'])
        records.append({'model_id':model_id,'model_path':str(path.relative_to(out)),
            'reused':model_id=='full','training_rows_key':model_id+'_indices','training_samples':len(idx),
            'alpha':cfg['alpha'],'validation_nmse':loss,'source_model':str(checkpoint) if model_id=='full' else None})
        print(model_id,'training rows',len(idx),'validation NMSE',loss,flush=True)
    write_json(out/'selection.json',{'status':'complete','models':records,'model_selection':'none; alpha100 fixed, all retained',
        'prepare_frozen_sha256':sha256(out/'prepare_frozen.json')})
    frozen=dict(json.loads((out/'prepare_frozen.json').read_text())['files'])
    for name in ['prepare_frozen.json','selection.json',*[r['model_path'] for r in records]]:frozen[name]=sha256(out/name)
    (out/'code_snapshot').mkdir();source_hashes={}
    for name in SNAPSHOT_NAMES:
        source=project/'mswi_experiments'/name;shutil.copyfile(source,out/'code_snapshot'/name)
        frozen['code_snapshot/'+name]=sha256(out/'code_snapshot'/name);source_hashes[str(source)]=sha256(source)
    verify(json.loads((out/'input_hashes.json').read_text()))
    write_json(out/'selection_frozen.json',{'status':'complete','files':frozen,'source_code_hashes':source_hashes})
    print('All models and reporting code frozen before evaluation.',flush=True)
    return out


def _cost_arrays(pred,actions,stats,prefix):
    reward,violation,costs=reward_and_violation(pred,actions,stats)
    result={prefix+'_reward':reward,prefix+'_return':reward.sum(axis=-1),prefix+'_violation':violation}
    result.update({prefix+'_'+name:value for name,value in costs.items()})
    return result


def run(config_file):
    cfg,project,out,_,stats,rows,_=load_prepared(config_file)
    frozen=json.loads((out/'selection_frozen.json').read_text());verify(frozen['files'],out);verify(frozen['source_code_hashes'])
    if (out/'run_manifest.json').exists() or (out/'rollouts').exists(): raise FileExistsError('response evaluation already started')
    selection=json.loads((out/'selection.json').read_text());models=[RidgeDynamics.load(out/r['model_path']) for r in selection['models']]
    if tuple(r['model_id'] for r in selection['models'])!=MODEL_IDS:raise ValueError('model order changed')
    (out/'rollouts').mkdir();started=time.monotonic();files=[];checks=[]
    responses={'model_ids':np.asarray(MODEL_IDS),'amp':cfg['fraction']*np.asarray(stats['action_bound']),
               'phys_scale':rows['phys_scale'],'endpoints':np.asarray(cfg['endpoints'],dtype=np.int64)}
    analytic=[analytic_responses(m,cfg['horizon']) for m in models]
    for pattern in ('pulse','step'): responses[pattern]=np.stack([a[pattern] for a in analytic])
    coefficients=[physical_coefficients(m) for m in models]
    responses['U']=np.stack([v[0] for v in coefficients]);responses['Z']=np.stack([v[1] for v in coefficients])
    stability=[autoregressive_stability(m) for m in models]
    for name in ('companion','eigenvalues','spectral_radius'):responses[name]=np.asarray([s[name] for s in stability])
    np.savez_compressed(out/'responses.npz',**responses)
    files.append({'kind':'responses','path':'responses.npz','sha256':sha256(out/'responses.npz')})
    for split in SPLITS:
        inputs=archive(out/'inputs'/f'{split}.npz');n=len(inputs['indices']);h=cfg['horizon']
        folder=out/'rollouts'/split;folder.mkdir()
        u,z,current=[inputs[k] for k in ('u_hist','z_hist','z_current')]
        expanded_u=np.repeat(u[:,None,None],2,axis=1);expanded_u=np.repeat(expanded_u,16,axis=2).reshape(n*32,11,8)
        expanded_z=np.repeat(z[:,None,None],2,axis=1);expanded_z=np.repeat(expanded_z,16,axis=2).reshape(n*32,10,9)
        expanded_current=np.repeat(current[:,None,None],2,axis=1);expanded_current=np.repeat(expanded_current,16,axis=2).reshape(n*32,9)
        future=inputs['trialfuture_mv'].reshape(n*32,h,8)
        for model_idx,(model,model_id) in enumerate(zip(models,MODEL_IDS)):
            baseline=decision_rollout(model,u,z,current,inputs['baselinefuture_mv'])
            trial=decision_rollout(model,expanded_u,expanded_z,expanded_current,future).reshape(n,2,16,h,9)
            logged=decision_rollout(model,u,z,current,inputs['logged_mv'])
            if not all(np.isfinite(v).all() for v in (baseline,trial,logged)): raise FloatingPointError('nonfinite response path')
            # With initial states in the envelope, projected pulse returns exactly;
            # the ARX difference is the unit response times the actual displacement.
            for pattern_idx,pattern in enumerate(('pulse','step')):
                expected=np.einsum('hzm,ncm->nchz',analytic[model_idx][pattern],inputs['executed_delta'])
                observed=trial[:,pattern_idx]-baseline[:,None]
                error=float(np.max(np.abs(expected-observed)))
                if error>1e-8: raise AssertionError('analytic and canonical response mismatch')
                checks.append({'split':split,'model_id':model_id,'pattern':pattern,
                               'max_abs_error':error,'compared_coordinates':int(expected.size)})
            values={'indices':inputs['indices'],'time_ns':inputs['time_ns'],'future_time_ns':inputs['future_time_ns'],
                    'truth_cv':inputs['truth_cv'],'baseline_pred':baseline,'trial_pred':trial,'logged_pred':logged}
            values.update(_cost_arrays(baseline,np.zeros((n,h,8)),stats,'baseline'))
            values.update(_cost_arrays(trial,inputs['normalized_actions'],stats,'trial'))
            dest=folder/f'{model_id}.npz';np.savez_compressed(dest,**values)
            files.append({'kind':'rollout','split':split,'model_id':model_id,'path':str(dest.relative_to(out)),
                          'sha256':sha256(dest),'anchors':n,'trial_shape':list(trial.shape)})
            print(split,model_id,'saved',n,'anchors x32trialpaths',flush=True)
    write_json(out/'response_checks.json',{'status':'passed','checks':checks,'tolerance':1e-8,
        'note':'Every projected trial minus its held baseline agrees with the same state-independent analytic response times actual executed displacement. This is implementation verification, not plant validation.'})
    verify(frozen['files'],out);verify(frozen['source_code_hashes'])
    write_json(out/'run_manifest.json',{'status':'complete','files':files,
        'source_selection_sha256':sha256(out/'selection.json'),'source_selection_frozen_sha256':sha256(out/'selection_frozen.json'),
        'response_checks_sha256':sha256(out/'response_checks.json'),'elapsed_seconds':time.monotonic()-started,
        'trajectories_dropped':0,'predictions_clipped':False,'policy_optimized':False})
    return out


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('stage',choices=('prepare','fit','run','all'))
    parser.add_argument('--config',default='ridge_response_20261106.json');args=parser.parse_args()
    cfg,_,_=paths(args.config)
    with threadpool_limits(limits=cfg['threads']):
        for stage in ('prepare','fit','run') if args.stage=='all' else (args.stage,): globals()[stage](args.config)


if __name__=='__main__':main()
