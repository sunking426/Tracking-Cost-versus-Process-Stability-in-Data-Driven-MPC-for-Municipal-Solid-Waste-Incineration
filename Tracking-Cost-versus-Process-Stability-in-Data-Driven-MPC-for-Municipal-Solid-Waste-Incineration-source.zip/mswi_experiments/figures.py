"""Publication figures bound directly to saved numerical experiment outputs."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path

import numpy as np


SHORT = {'linear_feedback': 'Linear', 'nearest_logged': 'Logged-NN',
         'bc': 'BC', 'twin_td3': 'TD3', 'sensor_td3bc': 'Sensor+BC',
         'full_td3bc': 'Multi+BC', 'offline_td3bc':'Offline+BC', 'cem_mpc':'CEM-MPC'}
COLORS = ['#4878a8', '#ba6b40', '#5a986c', '#a65b9b', '#b39931', '#4c6f72', '#bc5870', '#686bb0']
VARIABLES = [('Temperature', '°C'), ('Negative pressure', 'Pa'),
             ('Steam flow', 't/h'), ('Oxygen concentration', 'vol%')]


SUMMARY_LABELS={'linear_feedback':'Linear','nearest_logged':'Neighbor','bc':'BC','twin_td3':'TD3',
        'sensor_td3bc':'Sensor','full_td3bc':'Full','offline_td3bc':'Offline TD3+BC','cem_mpc':'CEM-MPC',
        'no_bc_init':'No BC init','no_bc_reg':'No BC reg','no_policy_retrieval':'Hold visual'}
SUMMARY_VARIABLES=[('Temperature','°C'),('Pressure','Pa'),('Steam','t/h'),('Oxygen','vol%')]


def make_figures(output):
    output = Path(output)
    os.environ.setdefault('MPLCONFIGDIR', str(output / 'matplotlib_cache'))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10,
                         'axes.spines.top': False, 'axes.spines.right': False,
                         'savefig.facecolor': 'white'})
    analysis_file = output / 'analysis/analysis_results.json'
    control_file = output / 'control/results.json'
    analysis = json.loads(analysis_file.read_text())
    control = json.loads(control_file.read_text())
    directory = output / 'figures'
    directory.mkdir(exist_ok=True)

    def save(fig, name):
        fig.savefig(directory / name, dpi=300, bbox_inches='tight')
        plt.close(fig)

    # Architecture of the actual implementation, replacing the schematic of an
    # unexecuted RGB/field experiment.
    fig, ax = plt.subplots(figsize=(8, 7))
    ax.set(xlim=(0, 10), ylim=(0, 10))
    ax.axis('off')
    boxes = [(0.3, 8.6, 4.1, .9, 'Logged process: 8 MVs, 9 CVs'),
             (5.5, 8.6, 4.1, .9, 'Recorded flame: 52 numeric features'),
             (2.1, 7.0, 5.8, .9, 'Causal windows and chronological partitions'),
             (1.0, 5.3, 4.1, 1.0, 'GRU process encoders + visual MLP\nOne-step CV-increment twin'),
             (5.7, 5.3, 3.7, 1.0, 'Training-only visual memory\nCosine retrieval'),
             (1.0, 3.4, 4.1, 1.0, 'Frozen latent + current MVs/CVs\nGated behavior-cloning actor'),
             (5.7, 3.4, 3.7, 1.0, 'Short surrogate rollouts\nLogged + generated replay'),
             (2.1, 1.8, 5.8, .9, 'TD3 actor/dual critics with behavior regularization'),
             (1.0, .2, 4.1, .9, 'Paired policy evaluation\nSeparately fitted twin'),
             (5.7, .2, 3.7, .9, 'Offline advisory replay\nNo plant actuation')]
    for x, y, w, h, text in boxes:
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=.08',
                                   facecolor='#edf3f7', edgecolor='#506675'))
        ax.text(x + w/2, y + h/2, text, ha='center', va='center', fontsize=9)
    for start, end in [((2.3,8.5),(4.2,8.0)),((7.6,8.5),(5.8,8.0)),
                       ((4.3,6.9),(3.1,6.4)),((6.5,6.9),(7.5,6.4)),
                       ((3.0,5.2),(3.0,4.5)),((7.5,5.2),(7.5,4.5)),
                       ((5.2,5.8),(5.6,5.8)),((3.1,3.3),(4.3,2.8)),
                       ((7.4,3.3),(5.8,2.8)),((4.2,1.7),(3.2,1.2)),
                       ((5.8,1.7),(7.5,1.2))]:
        ax.add_patch(FancyArrowPatch(start, end, arrowstyle='->', mutation_scale=12,
                                     color='#506675', linewidth=1.1))
    save(fig, 'Fig1.png')

    tsne = np.load(output / 'analysis/tsne.npz', allow_pickle=False)
    steam = tsne['steam']
    fig, axes = plt.subplots(1, 2, figsize=(9, 3.6), layout='constrained')
    for ax, key, label in zip(axes, ['sensor', 'multi'], ['Sensor-only latent', 'Multimodal latent']):
        points = tsne[key]
        scatter = ax.scatter(points[:,0], points[:,1], c=steam, cmap='viridis',
                             vmin=steam.min(), vmax=steam.max(), s=7, alpha=.75)
        ax.set(title=label, xlabel='t-SNE dimension 1', ylabel='t-SNE dimension 2')
    fig.colorbar(scatter, ax=axes, label='Observed steam flow (t/h)', shrink=.85)
    save(fig, 'Fig2.png')

    rollout = analysis['rollout']
    horizons = np.asarray(rollout['horizons'])
    errors = np.asarray(rollout['rmse'])
    fig, axes = plt.subplots(2, 2, figsize=(8.2, 5.4), layout='constrained')
    for j, (ax, (label, unit)) in enumerate(zip(axes.flat, VARIABLES)):
        ax.plot(horizons, errors[:,j], marker='o', color=COLORS[j])
        ax.axvline(10, linestyle='--', color='#666666', linewidth=1)
        ax.set(title=label, xlabel='Prediction horizon (steps)', ylabel=f'RMSE ({unit})',
               xticks=horizons)
        ax.grid(alpha=.2)
    save(fig, 'Fig3.png')

    example = rollout['example']
    fig, ax = plt.subplots(figsize=(7, 3.8), layout='constrained')
    ax.plot(example['steps'], np.asarray(example['truth'])[:,0], label='Logged temperature', marker='o', markersize=3)
    ax.plot(example['steps'], np.asarray(example['prediction'])[:,0], label='Recursive prediction', linestyle='--', marker='s', markersize=3)
    ax.axvline(10, linestyle=':', color='#666666')
    ax.set(xlabel='Rollout step', ylabel='Mean furnace temperature (°C)')
    ax.legend()
    ax.grid(alpha=.2)
    save(fig, 'Fig4.png')

    methods = control['main_methods']
    arrays = {}
    first = {}
    for method in methods:
        items = [np.load(output / 'control' / p, allow_pickle=False)
                 for p in control['results'][method]['evaluation_files']]
        arrays[method] = {name: np.concatenate([item[name] for item in items], axis=0)
                          for name in ('rewards','control')}
        first[method] = items[0]
    labels = [SHORT[m] for m in methods]
    for j in range(5):
        values = [(arrays[m]['rewards'].sum(axis=1) if j==0 else arrays[m]['control'][...,j-1].reshape(-1))
                  for m in methods]
        fig, ax = plt.subplots(figsize=(4.4, 3.2), layout='constrained')
        box = ax.boxplot(values, tick_labels=labels, patch_artist=True, showmeans=True,
                         flierprops={'markersize': 2, 'alpha': .3})
        for patch, color in zip(box['boxes'], COLORS):
            patch.set_facecolor(color)
            patch.set_alpha(.45)
        ax.tick_params(axis='both', labelsize=11)
        ax.tick_params(axis='x', labelrotation=35)
        if j==0:
            ax.set(ylabel='Cumulative episode reward', title='Closed-loop surrogate return')
        else:
            name, unit = VARIABLES[j-1]
            ax.set(ylabel=f'{name} ({unit})', title=f'{name} distribution')
            if j==4:
                ax.axhspan(3.5,4.0,color='#cccccc',alpha=.25)
            else:
                ax.axhline([1000,-50,32][j-1],color='#777777',linestyle=':',linewidth=1)
        ax.grid(axis='y', alpha=.2)
        ax.yaxis.label.set_size(12)
        ax.title.set_size(12)
        save(fig, f'Fig5{"abcde"[j]}.png')

    full = first['full_td3bc']
    episode_returns = full['rewards'].sum(axis=1)
    representative = int(np.argsort(episode_returns)[len(episode_returns)//2])
    start = int(full['start_indices'][representative])
    from .data import load_data, control_values
    data, _, _ = load_data(output / 'data')
    initial = control_values(data['z_current'][start])
    for j in range(5):
        fig, ax = plt.subplots(figsize=(4.4, 3.7), layout='constrained')
        for method, color in zip(methods, COLORS):
            run = first[method]
            if int(run['start_indices'][representative]) != start:
                raise ValueError('Paired plot methods do not share the same initial condition')
            y = run['rewards'][representative] if j==0 else np.r_[initial[j-1], run['control'][representative,:,j-1]]
            x = np.arange(1,len(y)+1) if j==0 else np.arange(len(y))
            ax.plot(x,y,label=SHORT[method],color=color,linewidth=1.2)
        if j==0:
            ax.set(ylabel='Per-step reward',title='Paired representative surrogate episode')
        else:
            name,unit=VARIABLES[j-1]
            ax.set(ylabel=f'{name} ({unit})',title=name)
            if j==4:ax.axhspan(3.5,4.0,color='#cccccc',alpha=.25)
            else:ax.axhline([1000,-50,32][j-1],color='#777777',linestyle=':',linewidth=1)
        ax.set_xlabel('Control step')
        fig.legend(*ax.get_legend_handles_labels(), loc='outside upper center',
                   fontsize=8, ncol=4, frameon=False)
        ax.tick_params(axis='both', labelsize=11)
        ax.xaxis.label.set_size(12)
        ax.yaxis.label.set_size(12)
        ax.title.set_size(12)
        ax.grid(alpha=.2)
        save(fig,f'Fig6{"abcde"[j]}.png')

    ablation_ids = list(control['ablation_methods'].values())
    ablation_labels = ['Full','No BC init','No BC reg','No image','Hold visual']
    fig, axes=plt.subplots(1,3,figsize=(10,3.7),layout='constrained')
    for ax,key,title,scale in zip(axes,['mean_return','stability_rate','violation_rate'],
                                ['Episode reward','Zero-violation episodes (%)','Violating steps (%)'],[1,100,100]):
        values=[control['results'][m]['summary'][key]*scale for m in ablation_ids]
        ax.bar(np.arange(len(values)),values,color='#4878a8',alpha=.8)
        ax.set(xticks=np.arange(len(values)),xticklabels=ablation_labels,title=title)
        ax.tick_params(axis='x',labelrotation=35,labelsize=8)
        ax.grid(axis='y',alpha=.2)
    save(fig,'Fig7.png')
    record={'analysis_sha256':hashlib.sha256(analysis_file.read_bytes()).hexdigest(),
            'control_sha256':hashlib.sha256(control_file.read_bytes()).hexdigest(),
            'representative_episode':representative,'representative_start_index':start,
            'representative_rule':'median full-method first-predetermined-seed episode return; same start for all curves',
            'figures':sorted(p.name for p in directory.glob('Fig*.png'))}
    (directory/'figure_sources.json').write_text(json.dumps(record,indent=2)+'\n')


def make_summary_figures(output, destination=None):
    """Render saved prediction/control summaries without manuscript dependencies.

    The source JSON files are read-only. A caller can route all generated plots,
    the machine-readable summary, and its source hashes into a separate folder.
    No model is loaded, fitted, or evaluated by this function.
    """
    output = Path(output).resolve()
    report = Path(destination).resolve() if destination is not None else output / 'summary'
    paths = {name: output / relative for name, relative in {
        'validation': 'validation/validation_results.json',
        'statistics': 'statistics/paired_statistics.json',
        'control': 'control/results.json',
    }.items()}
    records = {name: json.loads(path.read_text()) for name, path in paths.items()}
    validation, statistics, controls = (records[name] for name in ('validation', 'statistics', 'control'))
    report.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault('MPLCONFIGDIR',str(report/'matplotlib_cache'))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    colors={'multi':'#3978a5','sensor':'#b47b43','eval':'#648b6b','persistence':'#999999'}
    fig,axes=plt.subplots(2,2,figsize=(9,6),layout='constrained')
    names=list(validation['models'])
    for j,ax in enumerate(axes.flat):
        ax.bar(np.arange(len(names)),[validation['models'][n]['onestep']['mae'][j] for n in names],color=[colors[n] for n in names])
        ax.set(xticks=np.arange(len(names)),xticklabels=names,ylabel=f'MAE ({SUMMARY_VARIABLES[j][1]})',title=SUMMARY_VARIABLES[j][0]);ax.grid(axis='y',alpha=.2)
    fig.savefig(report/'one_step_comparison.png',dpi=200);plt.close(fig)
    fig,axes=plt.subplots(2,2,figsize=(9,6),layout='constrained')
    for j,ax in enumerate(axes.flat):
        for name,record in validation['models'].items():
            ax.plot(validation['horizons'],np.asarray(record['rollout']['rmse'])[:,j],marker='o',label=name,color=colors[name])
        ax.axvline(10,color='#777',linestyle=':',linewidth=1);ax.set(xlabel='Recursive horizon (steps)',ylabel=f'RMSE ({SUMMARY_VARIABLES[j][1]})',title=SUMMARY_VARIABLES[j][0]);ax.grid(alpha=.2)
    axes[0,0].legend(fontsize=8);fig.savefig(report/'recursive_horizons.png',dpi=200);plt.close(fig)
    methods=controls['main_methods'];labels=[SUMMARY_LABELS[n] for n in methods]
    fig,axes=plt.subplots(2,3,figsize=(13,8),layout='constrained')
    for row,h in enumerate([10,50]):
        section=statistics['horizons'][str(h)]
        for col,(metric,title,factor) in enumerate([(0,'Episode return',1),(5,'Violating steps (%)',100),(6,'Zero-violation episodes (%)',100)]):
            values=[section['methods'][n]['mean'][metric]*factor for n in methods]
            error=[section['methods'][n]['seed_mean_sd'][metric]*factor for n in methods]
            ax=axes[row,col];ax.bar(np.arange(len(methods)),values,yerr=error,capsize=2,color='#487da2',alpha=.85)
            ax.set(xticks=np.arange(len(methods)),xticklabels=labels,title=f'{h}-step {title}');ax.tick_params(axis='x',labelrotation=35,labelsize=8);ax.grid(axis='y',alpha=.2)
    fig.suptitle('Means and optimization-seed SD; static policies have one fixed run',fontsize=11)
    fig.savefig(report/'control_comparison.png',dpi=200);plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(11,5),layout='constrained')
    wanted=['sensor_td3bc','bc','offline_td3bc','cem_mpc','no_bc_init','no_bc_reg','no_policy_retrieval']
    for ax,h in zip(axes,[10,50]):
        lookup={e['comparator']:e for e in statistics['horizons'][str(h)]['comparisons']}
        x=np.asarray([lookup[k]['mean_difference'][0] for k in wanted]);ci=np.asarray([lookup[k]['seed_reset_crossed_ci95'][0] for k in wanted])
        y=np.arange(len(wanted));ax.hlines(y,ci[:,0],ci[:,1],color='#3978a5',linewidth=2);ax.scatter(x,y,color='#3978a5',s=25)
        ax.axvline(0,color='#777',linestyle=':');ax.set(yticks=y,yticklabels=[SUMMARY_LABELS[k] for k in wanted],xlabel='Full minus comparator episode return',title=f'{h}-step paired effect and exploratory 95% CI');ax.grid(axis='x',alpha=.2)
    fig.savefig(report/'paired_return_intervals.png',dpi=200);plt.close(fig)
    summary = {
        'schema_version': 1,
        'primary_horizon': statistics['primary_horizon'],
        'prediction': validation,
        'control': statistics,
        'advisory': controls['advisory'],
        'source_sha256': {str(path.relative_to(output)): hashlib.sha256(path.read_bytes()).hexdigest()
                          for path in paths.values()},
        'plotting_code_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'figures': ['one_step_comparison.png', 'recursive_horizons.png',
                    'control_comparison.png', 'paired_return_intervals.png'],
        'paper_figure_sources': {'Fig3.png': 'recursive_horizons.png',
                                'Fig10.png': 'paired_return_intervals.png'},
        'interpretation': 'Saved learned-surrogate results; exploratory unadjusted intervals; '
                          'fixed supervised models and previously inspected test period.',
    }
    (report / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    return summary


def main(argv=None):
    import argparse
    parser = argparse.ArgumentParser(description='Render portable summary figures from saved results.')
    parser.add_argument('output', type=Path, help='Run directory containing validation, statistics and control JSON files')
    parser.add_argument('--summary-directory', type=Path, help='Destination directory (default: RUN/summary)')
    args = parser.parse_args(argv)
    summary = make_summary_figures(args.output, args.summary_directory)
    print(json.dumps({'summary_complete': True, 'figures': summary['figures']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
