"""Fixed CEM budget; exact support certificates and affine rollout acceleration.

Support decisions are exact: one known eligible donor certifies membership;
the triangle inequality can certify non-membership. Ambiguous cases use the
canonical exact nearest-distance search. No approximate NN or relaxed gate.
"""
from __future__ import annotations
import itertools
import numpy as np
import torch
from .control import project_normalized_actions, reward_and_violation
from .data import MINUTE_NS
from .ridge_response import analytic_responses, decision_rollout
from .ridge_response_study import joint_features
from .ridge_policy import ACTIVE

class PlanningSupport:
    def __init__(self,execution):
        self.execution=execution;self.counts={'rows':0,'member_certificate':0,'outside_certificate':0,'exact_fallback':0}

    def supported(self,u,z,delta,times,n,c):
        e=self.execution;v=e.support.values
        x=(joint_features(u,z,delta)-v['x_mean'])/v['x_scale'];xx=x.reshape(n,c,25)
        center=xx.mean(1);physical=center*v['x_scale']+v['x_mean']
        stamps=times.reshape(n,c)
        if not np.all(stamps==stamps[:,:1]):raise AssertionError('certificate group has unequal exclusion time')
        d,_,idx=e.support.query(physical[:,:8],physical[:,8:17],physical[:,17:],stamps[:,0])
        radius=float(v['threshold']);donor=e.support.bank[idx]
        upper=np.linalg.norm(xx-donor[:,None],axis=2)
        lower=d[:,None]-np.linalg.norm(xx-center[:,None],axis=2)
        good=upper<radius-1e-10;bad=lower>radius+1e-10
        unknown=~(good|bad);flat=unknown.ravel();result=good.ravel()
        if flat.any():result[flat]=e.support.query(u[flat],z[flat],delta[flat],times[flat])[1]
        self.counts['rows']+=len(x);self.counts['member_certificate']+=int(good.sum())
        self.counts['outside_certificate']+=int(bad.sum());self.counts['exact_fallback']+=int(flat.sum())
        return result

class CEMPlanner:
    def __init__(self,model,execution):
        self.model=model;self.execution=execution;self.support=PlanningSupport(execution)
        self.kernel=analytic_responses(model,10)['step'][:,:,ACTIVE]
        levels=[(0,0)]+[x for x in itertools.product((-1,0,1),repeat=2) if x!=(0,0)]
        self.fixed=np.zeros((9,10,2));self.fixed[:,0]=levels;self.warm=None

    def reset(self):self.warm=None

    def score(self,plans,u_hist,z_hist,current,times,*,return_trace=False):
        n,c,h,adim=plans.shape
        if (h,adim)!=(10,2):raise ValueError('CEM plans require10x2')
        e=self.execution;u=np.repeat(u_hist[:,-1,None],c,axis=1).astype(float)
        baseline=decision_rollout(self.model,u_hist,z_hist,current,np.repeat(u_hist[:,-1,None],10,axis=1))
        effects=np.zeros((n,c,10,9));z=np.repeat(current[:,None],c,axis=1).astype(float)
        score=np.zeros((n,c));trace={'prediction':[],'executed':[],'reward':[]}
        for step in range(10):
            request=e.request(plans[:,:,step].reshape(-1,2));flat_u=u.reshape(-1,8)
            a,delta,nu=project_normalized_actions(torch.from_numpy(request),torch.from_numpy(flat_u),e.stats)
            a,delta,nu=[v.numpy() for v in (a,delta,nu)]
            complete=np.all(np.abs(delta-request*e.scale)<=1e-10,axis=1)
            stamp=np.repeat(times+step*MINUTE_NS,c)
            supported=self.support.supported(flat_u,z.reshape(-1,9),delta,stamp,n,c)
            admitted=(complete&supported)|~np.any(request!=0,axis=1)
            # Initial MV is bounded and all subsequent updates use this map.
            # Hence rejected zero fallback executes exactly zero in every MV.
            a[~admitted]=0;delta[~admitted]=0;nu[~admitted]=flat_u[~admitted]
            physical=delta.reshape(n,c,8)
            effects[:,:,step:]+=np.einsum('ncj,hzj->nchz',physical[:,:,ACTIVE],self.kernel[:10-step])
            z=baseline[:,None,step]+effects[:,:,step]
            r,_,_=reward_and_violation(z,a.reshape(n,c,8),e.stats);score+=r.astype(float)
            u=nu.reshape(n,c,8)
            if return_trace:
                trace['prediction'].append(z.copy());trace['executed'].append(a.reshape(n,c,8).copy());trace['reward'].append(r.copy())
        if return_trace:return score,{k:np.stack(v,axis=2) for k,v in trace.items()}
        return score

    def plan(self,u,z,current,times,indices,decision_step):
        n=len(u)
        warm=np.zeros((n,10,2)) if self.warm is None else np.concatenate((self.warm[:,1:],np.zeros((n,1,2))),axis=1)
        mean=warm.copy();std=np.full_like(mean,.35);incumbent=np.zeros_like(mean)
        best_score=np.full(n,-np.inf);best=np.zeros_like(mean);iteration_scores=[]
        rngs=[np.random.default_rng(np.random.SeedSequence([2026,int(i),int(decision_step)])) for i in indices]
        for iteration in range(4):
            noise=np.stack([rng.normal(size=(117,10,2)) for rng in rngs])
            random=np.clip(mean[:,None]+std[:,None]*noise,-1,1)
            plans=np.concatenate((np.broadcast_to(self.fixed,(n,9,10,2)),warm[:,None],incumbent[:,None],random),axis=1)
            score=self.score(plans,u,z,current,times)
            order=np.argsort(-score,axis=1,kind='stable');winner=order[:,0]
            incumbent=plans[np.arange(n),winner].copy();iteration_score=score[np.arange(n),winner]
            better=iteration_score>best_score
            best[better]=incumbent[better];best_score[better]=iteration_score[better]
            # Zero plan explicitly wins a tie even if a prior iteration had a
            # different plan with the same score.
            zero_tie=score[:,0]==best_score;best[zero_tie]=0
            elite=plans[np.arange(n)[:,None],order[:,:16]];mean=elite.mean(1);std=np.maximum(elite.std(1,ddof=0),.05)
            iteration_scores.append(iteration_score)
        self.warm=best.copy()
        return self.execution.request(best[:,0]),{'best_requested_plan_b':best,'planner_score':best_score,
            'iteration_best_score':np.stack(iteration_scores,axis=1)}
