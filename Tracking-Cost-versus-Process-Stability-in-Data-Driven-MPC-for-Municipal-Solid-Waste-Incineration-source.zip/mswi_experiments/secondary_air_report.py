"""Audit the prospective validation-only channel comparison and report it."""
from __future__ import annotations
import json
import numpy as np
import torch
from threadpoolctl import threadpool_limits
from .control import reward_and_violation
from .data import MINUTE_NS
from .ridge_policy import RidgePolicyEnv
from .ridge_dynamics import RidgeDynamics
from .ridge_policy_report import endpoints,csv_write
from .ridge_control_probe_report import METRICS
from .visual_diagnostics_statistics import paired_block_interval,DAY_NS
from .ridge_policy_study import read_npz,write_json,sha
from .mpc_channels import recommend
from .secondary_air_study import OUT,REF,PRIOR,OLD,MODELS,VARIANTS,WEIGHTS,SAMPLE_KEYS,protocol,shared,verify_sources,freeze


def audit_case(row,mid,vid,execution,full,inputs):
    if row['pred_cv'].shape!=(256,10,9):raise AssertionError('dimensions')
    for k in ('indices','time_ns'):np.testing.assert_array_equal(row[k],inputs[k])
    reward,violation,cost=reward_and_violation(row['pred_cv'],row['executed_action'],execution.stats)
    for k,v in dict(reward=reward,violation=violation,**cost).items():np.testing.assert_array_equal(row[k],v)
    physical=row['physical_executed_action'];requested=row['requested_action']
    if np.any(physical[:,:,execution.inactive]!=0) or np.any(physical[:,:,2]<0):raise AssertionError('channel contract')
    if np.any(np.abs(physical)>.1*execution.bound+1e-10):raise AssertionError('physical budgets')
    if np.any(requested[:,:,2]<0) or np.any(row['best_requested_plan_b'][...,2]<0):raise AssertionError('secondary sign')
    if np.any(row['u_path']<np.asarray(execution.stats['u_low'])) or np.any(row['u_path']>np.asarray(execution.stats['u_high'])):raise AssertionError('MV bounds')
    if np.any(np.any(row['executed_action']!=0,axis=-1)&~row['action_supported']):raise AssertionError('unsupported nonzero')
    env=RidgePolicyEnv(RidgeDynamics.load(REF/f'evaluation_models/{mid}.npz'),execution,horizon=10)
    env.reset(options={'inputs':inputs});errors={}
    for step in range(10):
        _,_,_,_,info=env.step_request(row['requested_action'][:,step])
        for k,v in info.items():
            np.testing.assert_array_equal(v,row[k][:,step]);errors[k]=0.
    ids=np.array([0,127,255]);small={k:inputs[k][ids] for k in SAMPLE_KEYS};plan_errors=[]
    for step in (0,4,9):
        if step==0:history=small
        else:
            history=dict(u_hist=np.concatenate((small['u_hist'],row['u_path'][ids,:step]),1)[:,-11:],
                z_hist=np.concatenate((small['z_hist'],small['z_current'][:,None],row['pred_cv'][ids,:step-1]),1)[:,-10:],
                z_current=row['pred_cv'][ids,step-1],time_ns=small['time_ns']+step*MINUTE_NS,indices=small['indices'])
        pe=RidgePolicyEnv(full,execution,horizon=10);he=RidgePolicyEnv(full,execution,horizon=10)
        pe.reset(options={'inputs':history});he.reset(options={'inputs':history})
        original=np.zeros(3);jt=np.zeros(3);hold_jt=np.zeros(3)
        for j in range(10):
            _,r,_,_,info=pe.step(row['best_requested_plan_b'][ids,step,j]);_,_,_,_,hi=he.step(np.zeros((3,3)))
            original+=r.astype(float);jt+=info['tracking_cost'][:,0].astype(float);hold_jt+=hi['tracking_cost'][:,0].astype(float)
        values=dict(selected_original_return=original,selected_temperature_cost=jt,hold_temperature_cost=hold_jt,
                    selected_planning_score=original-(WEIGHTS[vid]-1)*jt)
        err={k:float(np.max(np.abs(v-row[k][ids,step]))) for k,v in values.items()}
        for k,v in values.items():np.testing.assert_allclose(v,row[k][ids,step],atol=1e-5,rtol=0)
        plan_errors.append(dict(decision_step=step,errors=err))
    return dict(variant=vid,model=mid,feedback_max_errors=errors,selected_plan_rescores=plan_errors)


def summarize():
    verify_sources();freeze();stats,execution,full=shared();inputs=read_npz(REF/'inputs/val.npz');days=inputs['time_ns']//DAY_NS
    if len(np.unique(days))!=7:raise AssertionError('seven fixed calendar blocks')
    values={};means=[];actions=[];audits=[];manifest=[];fingerprints=None
    out=OUT/'report';out.mkdir(exist_ok=True)
    for mid in MODELS:
        hold=read_npz(PRIOR/f'trajectories/val/{mid}/hold/seed0.npz')
        for k in ('indices','time_ns'):np.testing.assert_array_equal(hold[k],inputs[k])
        values[mid,'hold']=endpoints(hold,10)
        for vid in VARIANTS:
            old=read_npz(OLD/f'trajectories/{vid}/{mid}.npz');values[mid,'2'+vid]=endpoints(old,10)
            path=OUT/f'trajectories/{vid}/{mid}.npz';row=read_npz(path);meta=json.loads(path.with_suffix('.json').read_text())
            if sha(path)!=meta['sha256']:raise AssertionError('trajectory hash')
            np.testing.assert_array_equal(row['noise_sha256'],old['noise_sha256'][:,:10])
            hashes=(row['noise_sha256'],row['secondary_noise_sha256'])
            if fingerprints is None:fingerprints=tuple(x.copy() for x in hashes)
            for x,y in zip(fingerprints,hashes):np.testing.assert_array_equal(x,y)
            audits.append(audit_case(row,mid,vid,execution,full,inputs))
            manifest.append(dict(path=str(path.relative_to(OUT)),sha256=sha(path),episodes=256,steps=10))
            values[mid,'3'+vid]=endpoints(row,10)
            for channels,r in [(2,old),(3,row)]:
                d=r['physical_executed_action'][:,:10];name=str(channels)+vid
                actions.append(dict(model=mid,variant=name,nonzero_fraction=float(np.any(d!=0,axis=-1).mean()),
                    blocked_nonzero_fraction=float(r['blocked_nonzero'][:,:10].mean()),unsupported_hold_fraction=float(r['zero_action_unsupported'][:,:10].mean()),
                    mean_movement_cost=float(r['movement_cost'][:,:10].mean()),
                    secondary_requested_fraction=float((r['requested_action'][:,:10,2]>0).mean()),
                    secondary_executed_fraction=float((d[:,:,2]>0).mean()),
                    secondary_used_episode_fraction=float(np.any(d[:,:,2]>0,axis=1).mean()),
                    secondary_mean_total_increment=float(d[:,:,2].sum(1).mean()),
                    **{f'mean_abs_increment_mv{j}':float(np.abs(d[:,:,j]).mean()) for j in (0,3,2)}))
            print('audited',vid,mid,flush=True)
        for v in ('hold',)+tuple(str(c)+v for c in (2,3) for v in VARIANTS):
            means.append(dict(model=mid,variant=v,horizon=10,**dict(zip(METRICS,values[mid,v].mean(0).tolist()))))
    baseline=np.stack([values[m,'hold'].mean(0) for m in MODELS[1:]])
    candidates={v:np.stack([values[m,'3'+v].mean(0) for m in MODELS[1:]]) for v in VARIANTS}
    old_c_gain=min(values[m,'2C'][:,0].mean()-values[m,'hold'][:,0].mean() for m in MODELS[1:])
    if abs(old_c_gain-protocol()['old_C_G'])>1e-12:raise AssertionError('old C reference changed')
    recommendation=recommend(baseline,candidates,protocol()['old_C_G'])
    recommendation.update(role='prespecified recommendation only; user decides main configuration',old_C_G=old_c_gain)
    contrasts=[];details={};guards=[]
    for m in MODELS:
        for v in ('3A','3B','3C','3D'):
            for ref in dict.fromkeys(('hold','2'+v[-1],'2C')):
                delta=values[m,ref]-values[m,v];delta[:,0]*=-1
                label=f'{m}/{v}_vs_{ref}'
                interval=paired_block_interval(delta[None],days,draws=10000,seed=20261106)
                interval['estimand']='paired endpoint improvement with one fixed CEM random stream; seven date blocks; exploratory unadjusted interval'
                details[label]=interval
                for j,name in enumerate(METRICS):
                    contrasts.append(dict(model=m,variant=v,reference=ref,metric=name,difference=interval['difference'][j],
                        ci_lower=interval['ci_lower'][j],ci_upper=interval['ci_upper'][j],worse_episode_fraction=float((delta[:,j]<0).mean())))
                if ref=='hold':
                    slack=delta.copy();slack[:,1:]+=.01*values[m,'hold'][:,1:]
                    si=paired_block_interval(slack[None],days,draws=10000,seed=20261106)
                    details[label+'_relative_slack']=si
                    b=values[m,'hold'].mean(0);c=values[m,v].mean(0)
                    for j,name in enumerate(METRICS[1:],1):
                        guards.append(dict(model=m,variant=v,metric=name,hold_mean=float(b[j]),candidate_mean=float(c[j]),
                            increase=float(c[j]-b[j]),relative_allowance=float(.01*b[j]),strict_pass=bool(c[j]<=b[j]),
                            relative_1pct_pass=bool(c[j]<=1.01*b[j]),relative_slack=float(1.01*b[j]-c[j]),
                            relative_slack_ci_lower=si['ci_lower'][j],relative_slack_ci_upper=si['ci_upper'][j]))
    csv_write(out/'endpoint_means.csv',means);csv_write(out/'contrasts.csv',contrasts);csv_write(out/'guardrails.csv',guards)
    csv_write(out/'actions_and_support.csv',actions);write_json(out/'contrasts.json',details);write_json(out/'recommendation.json',recommendation)
    np.savez_compressed(out/'episode_endpoints.npz',**{'__'.join(k):v for k,v in values.items()})
    write_json(OUT/'audit.json',dict(status='passed',cases=audits,shared_noise_bitwise_equal_to_old_two_channel=True,
        all20_secondary_noise_arrays_equal=True,original_rewards_recomputed=51200,feedback_steps_reexecuted=51200,
        selected_plan_rescores=180,test_evaluations=0,trajectories_dropped=0,predictions_clipped=False,new_plant_interventions=0))
    write_json(OUT/'trajectory_manifest.json',dict(files=manifest,case_count=20,episodes=5120,steps=51200,all_validation_only=True))
    render(out,values,actions);write_readout(out,values,recommendation,guards,details,actions)
    verify_sources()


def render(out,values,actions):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':180})
    colors=['#1f77b4','#ff7f0e','#2ca02c','#d62728']
    fig,axs=plt.subplots(2,2,figsize=(11,8))
    for ax,m in zip(axs.ravel(),MODELS[1:]):
        ref=values[m,'hold'].mean(0)
        for i,v in enumerate(VARIANTS):
            pts=[]
            for ch,marker in [(2,'o'),(3,'^')]:
                c=values[m,str(ch)+v].mean(0);p=(c[1]-ref[1],c[0]-ref[0]);pts.append(p)
                ax.scatter(*p,color=colors[i],marker=marker,s=55)
                ax.annotate(str(ch)+v,p,xytext=(4,4),textcoords='offset points',fontsize=8)
            ax.plot(*np.array(pts).T,ls=':',color=colors[i],lw=.8)
        ax.axvline(0,color='black',lw=.7);ax.axvline(.01*ref[1],color='#ff7f0e',ls='--',lw=1)
        ax.axhline(0,color='black',lw=.7);ax.set_title(m)
        ax.set_xlabel('Temperature MAE increase vs hold (deg C)');ax.set_ylabel('Original 10-step return gain')
    fig.suptitle('2 channels (circles) vs 3 channels (triangles); A/B/C/D = weights 1/2/4/8',fontsize=10)
    fig.tight_layout();fig.savefig(out/'cost_temperature_tradeoff.png');plt.close(fig)
    fig,axs=plt.subplots(1,2,figsize=(11,4.3))
    for i,v in enumerate(VARIANTS):
        rows=[next(r for r in actions if r['model']==m and r['variant']=='3'+v) for m in MODELS[1:]]
        axs[0].plot(MODELS[1:],[100*r['secondary_executed_fraction'] for r in rows],'o-',color=colors[i],label='3'+v)
        axs[1].plot(MODELS[1:],[r['secondary_mean_total_increment'] for r in rows],'o-',color=colors[i],label='3'+v)
    axs[0].set_ylabel('Decisions with positive secondary-air action (%)')
    axs[1].set_ylabel('Mean cumulative secondary-air increase (source units)')
    axs[1].legend();fig.tight_layout();fig.savefig(out/'secondary_air_usage.png');plt.close(fig)


def write_readout(out,values,rec,guards,details,actions):
    lines=[]
    def add(s=''):lines.append(s)
    add('二次风三通道验证实验：第2步结果')
    add('范围：四个三通道配置（温度权重1、2、4、8），每配置256个固定验证起点，在5个Ridge评价器各运行10步。full是规划模型，仅作描述；4个非规划评价器参与推荐判定。复用两通道A–D及保持操作的旧轨迹前10步。')
    add('本轮是保存了完整轨迹的模型内闭环实验，不是现场干预；没有新增模型训练、测试集评价、50步实验、GRU评价或论文改写。主配置尚未冻结，按用户要求在第2步后停止。')
    add('一、按事先规则得到的建议')
    add(f"建议代码：{rec['recommended']}；层级：{rec['route']}。2C表示旧两通道权重4；3A–3D表示三通道权重1、2、4、8。")
    add('配置 | 最差模型原始回报改善G | 严格零退化 | 1%相对容差 | 严格路线入围 | 1%路线入围')
    for v,r in rec['configurations'].items():
        add(f"3{v} | {r['strict']['worst_cost_gain']:.8f} | {r['strict']['pass']} | {r['relative']['pass']} | {r['strict_eligible']} | {r['relative_eligible']}")
    add(f"旧2C参照G={rec['old_C_G']:.8f}；严格路线最低G={.9*rec['old_C_G']:.8f}；1%路线最低G={rec['old_C_G']:.8f}。严格路线优先，各路线内最大化G；精确并列按预设处理。")
    add('门槛依据五项护栏均值，并非每个起点都不退化。1%是各模型保持操作对应均值的1%，不是工厂安全/工艺限值，也不是越界率增加1个百分点。')
    add()
    add('二、10步原始累计回报（负成本，越大越好）')
    add('模型 | Hold | 2A | 2B | 2C | 2D | 3A | 3B | 3C | 3D')
    for m in MODELS:add(m+' | '+' | '.join(f'{values[m,v][:,0].mean():.6f}' for v in ('hold','2A','2B','2C','2D','3A','3B','3C','3D')))
    add()
    add('三、三通道相对保持操作的各项变化')
    add('正回报差是改善；其他五项正差是退化。越界率差以百分点报告。')
    add('模型/配置 | 回报改善 | 温度误差增加℃ | 炉压误差增加Pa | 蒸汽误差增加t/h | O2带外误差增加百分点 | 越界率增加百分点')
    for m in MODELS[1:]:
        for v in ('2C','3A','3B','3C','3D'):
            d=values[m,v].mean(0)-values[m,'hold'].mean(0);d[5]*=100
            add(m+'/'+v+' | '+' | '.join(f'{x:+.7f}' for x in d))
    add('未通过1%容差的具体项目：')
    failures=[r for r in guards if r['model']!='full' and not r['relative_1pct_pass']]
    for r in failures:add(f"{r['model']}/{r['variant']}/{r['metric']}: 增加{r['increase']:.8g}，允许{r['relative_allowance']:.8g}")
    if not failures:add('无。')
    add()
    add('四、二次风实际使用')
    add('模型/配置 | 使用二次风的控制步比例 | 至少使用一次的起点比例 | 平均累计增加量（原始频率单位）')
    for r in actions:
        if r['model']!='full' and r['variant'].startswith('3'):
            add(f"{r['model']}/{r['variant']} | {100*r['secondary_executed_fraction']:.3f}% | {100*r['secondary_used_episode_fraction']:.3f}% | {r['secondary_mean_total_increment']:.6f}")
    add('每步二次风增量范围[0,1.5]；一次风和引风机保持原双向0.1B；其余五通道不动。所有非零执行动作通过原25维状态—动作联合支持过滤，零动作仍可无支持放行。动作费用仍在8维原始动作上计算。')
    add()
    add('五、与旧2C的配对回报差及探索性95%区间')
    for m in MODELS[1:]:
        for v in ('3A','3B','3C','3D'):
            r=details[f'{m}/{v}_vs_2C'];add(f"{m}/{v}: {r['difference'][0]:+.6f} [{r['ci_lower'][0]:+.6f}, {r['ci_upper'][0]:+.6f}]")
    add('区间按7个整日期块配对bootstrap10000次、种子20261106，未作多重比较校正；仅一个固定CEM随机流，未估计不同搜索种子间方差。配置选择使用均值门槛，不能改称显著无退化。1%容差余量区间见guardrails.csv。')
    add('历史测试期已被反复检查这一事实不因当前仅用验证集而消失；本轮没有重新打开或评价测试集。后续测试也不能称为从未看过的盲测。')
    add()
    add('六、响应方向与范围')
    add('只读实验10：二次风增加1.5后保持，第10步四个非规划模型的温度响应均为负（约−1.44至−2.24℃），氧含量均为正（约+0.026至+0.058个百分点）；第1步响应小且部分方向不同。因此不支持把增大二次风解释为普遍升温手段。响应是模型内扰动，氧含量上升是否有害取决于起点相对3.5–4.0%区间的位置。')
    add('阶段1的69/256（26.95%）起点受二次风经验下界限制、不能完整减小1.5；不是69个都在设备物理下限，也不足以推断炉子大多数时间处于低位。正方向234/256=91.41%可完整执行且有支持，故只试增加方向。')
    add('三通道共享原两维候选噪声和相同CEM预算，但多一维搜索会改变适应后的候选与搜索难度。结果比较的是固定预算下的配置，不证明三通道控制空间不存在更优解。')
    add()
    add('七、核验与文件')
    add('二次风关闭后，A–D各256起点前3步与旧两通道保存结果逐值相同。20组新轨迹共5120条、51200个控制步，原奖励和全部反馈重新计算一致；180条所选10步计划由标准递归环境独立复核。两个原通道噪声指纹与旧结果逐值一致，新增二次风噪声在全部20组相同。没有删轨迹或裁剪CV预测。')
    add('完整数值：endpoint_means.csv、guardrails.csv、contrasts.csv/json、actions_and_support.csv、recommendation.json、episode_endpoints.npz。图：cost_temperature_tradeoff.png、secondary_air_usage.png。原始轨迹、预设、源文件哈希及审计见上级目录。')
    (out/'REPORT_zh.txt').write_text('\n'.join(lines)+'\n')

if __name__=='__main__':
    torch.set_num_threads(4)
    with threadpool_limits(4):summarize()
