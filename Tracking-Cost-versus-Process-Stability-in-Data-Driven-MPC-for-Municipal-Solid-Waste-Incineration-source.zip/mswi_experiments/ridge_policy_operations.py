"""Prespecified advisory replay and single-decision latency measurements."""
from __future__ import annotations
import argparse
import csv
import os
import platform
import time
import numpy as np
import torch
from threadpoolctl import threadpool_limits, threadpool_info
from .data import load_data
from .ridge_policy import RidgePolicyEnv, policy_numeric
from .ridge_policy_evaluation import DecisionPolicy, BASELINES, actor_path
from .ridge_policy_training import load_actor, mode_for
from .ridge_policy_study import OUT, ROOT, REF, GROUPS, SEEDS, read_npz, write_json, sha, shared
from .ridge_policy_report import csv_write

def advisory():
    source=ROOT/'experiment_runs/corrected_vision/control/advisory/advisory_replay.csv'
    with source.open(newline='') as f:records=list(csv.DictReader(f))
    if len(records)!=360:raise AssertionError('fixed360 advisory rows')
    ids=np.array([int(r['sample_index']) for r in records]);times=np.array([int(r['time_ns']) for r in records])
    data,stats,_=load_data(ROOT/'experiment_runs/corrected_vision/data')
    if not np.array_equal(data['time_ns'][ids],times):raise AssertionError('advisory source row provenance')
    _,execution,context,_=shared();u=data['u_current'][ids].astype(float);z=data['z_current'][ids].astype(float)
    in_scope=((u>=np.asarray(stats['u_low']))&(u<=np.asarray(stats['u_high']))).all(1)
    numeric=policy_numeric(data['u_hist'][ids],data['z_hist'][ids],z);visual,donor=context.query(numeric)
    state=context.features(numeric,visual);folder=OUT/'advisory';folder.mkdir(exist_ok=True);summaries=[];csvrows=[]
    for seed in SEEDS:
        actor=load_actor(actor_path('ridge_td3bc',seed))
        with torch.no_grad():b=actor(torch.from_numpy(state)).numpy()
        request=execution.request(b);raw_delta=request*execution.scale;raw_next=u+raw_delta
        raw_increment_ok=(np.abs(raw_delta)<=.1*execution.bound+1e-10).all(1)
        raw_envelope_ok=((raw_next>=np.asarray(stats['u_low']))&(raw_next<=np.asarray(stats['u_high']))).all(1)
        raw_dist,raw_supported,_=execution.support.query(u,z,raw_delta,times)
        actual,proposal,blocked=execution.apply(request[in_scope],u[in_scope],z[in_scope],times[in_scope])
        post_delta=np.full_like(request,np.nan);post_delta[in_scope]=actual['physical']
        masks={
            'initial_scope_eligible':in_scope,'raw_increment_budget_feasible':raw_increment_ok,'raw_absolute_envelope_feasible':raw_envelope_ok,
            'raw_joint_supported':raw_supported,'post_projection_feasible':np.zeros(360,bool),'post_execution_supported':np.zeros(360,bool),
            'clipped_or_rejected':np.zeros(360,bool),'nonzero_executed':np.zeros(360,bool)}
        nu=proposal['next_u'];masks['post_projection_feasible'][in_scope]=((nu>=np.asarray(stats['u_low']))&(nu<=np.asarray(stats['u_high']))).all(1)
        masks['post_execution_supported'][in_scope]=actual['supported'];masks['clipped_or_rejected'][in_scope]=~proposal['complete']|blocked
        masks['nonzero_executed'][in_scope]=np.any(actual['physical']!=0,axis=1)
        summary={'seed':seed,'rows':360,'in_scope_rows':int(in_scope.sum()),'out_of_scope_rows':int((~in_scope).sum()),
            'rates_all360':{k:{'count':int(v.sum()),'fraction':float(v.mean())} for k,v in masks.items()},
            'rates_given_in_scope':{k:{'count':int(v[in_scope].sum()),'fraction':float(v[in_scope].mean())} for k,v in masks.items()}}
        summaries.append(summary)
        np.savez_compressed(folder/f'seed{seed}.npz',indices=ids,time_ns=times,visual_donor=donor,raw_requested_action=request,
            raw_physical_delta=raw_delta,raw_support_distance=raw_dist,executed_physical_delta=post_delta,**masks)
        for i,idx in enumerate(ids):
            csvrows.append({'seed':seed,'sample_index':int(idx),'time_ns':int(times[i]),'in_scope':bool(in_scope[i]),
                'raw_primary_air_delta':float(raw_delta[i,0]),'raw_induced_draft_delta':float(raw_delta[i,3]),
                'executed_primary_air_delta':float(post_delta[i,0]) if in_scope[i] else '',
                'executed_induced_draft_delta':float(post_delta[i,3]) if in_scope[i] else '',
                'raw_supported':bool(raw_supported[i]),'raw_absolute_envelope_feasible':bool(raw_envelope_ok[i])})
    write_json(folder/'summary.json',{'source_sha256':sha(source),'source':str(source),'seeds':summaries,
        'scope':'offline recommendations only; no plant actuation; out-of-scope rows retained without fabricated projected actions',
        'interpretation':'post-projection feasibility partly follows from the projection rule and is not a learned-policy gain over historical raw feasibility'})
    csv_write(folder/'replay.csv',csvrows)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    row=read_npz(folder/'seed11.npz');fig,axes=plt.subplots(2,1,figsize=(10,5),sharex=True)
    for ax,j,label in zip(axes,(0,3),('Primary-air channel','Induced-draft channel')):
        ax.plot(np.arange(360),row['raw_physical_delta'][:,j],color='#1f77b4',label='Requested')
        ax.plot(np.arange(360),row['executed_physical_delta'][:,j],color='#ff7f0e',label='Executed in model / admissible advice')
        ax.set_ylabel(label+'\n(source units)');ax.legend(fontsize=8);ax.spines[['top','right']].set_visible(False)
    axes[-1].set_xlabel('Replay minute');fig.tight_layout();fig.savefig(folder/'advisory_seed11.png',dpi=180);plt.close(fig)

def latency():
    # Run only after the training/evaluation jobs have completed, not concurrently.
    stats,execution,context,model=shared();inputs=read_npz(REF/'inputs/val.npz')
    positions=np.linspace(0,255,64).round().astype(int)
    entries=[]
    for group in BASELINES+GROUPS:
        for seed in SEEDS if group in GROUPS else (0,):
            entries.append((group,seed,DecisionPolicy(group,seed,model,execution,context),
                RidgePolicyEnv(model,execution,context if group in GROUPS else None,visual_mode=mode_for(group))))
    def measure(entry,position,forward=False):
        group,seed,policy,env=entry;row={k:v[position:position+1] for k,v in inputs.items()}
        if forward:
            state,_=env.reset(options={'inputs':row});tensor=torch.from_numpy(state)
            t=time.perf_counter_ns()
            with torch.no_grad():policy.actor(tensor)
            return (time.perf_counter_ns()-t)/1e6
        t=time.perf_counter_ns();state,_=env.reset(options={'inputs':row})
        if policy.cem is not None:policy.cem.reset()
        request,_=policy.decide(env,state,0)
        execution.apply(request,env.u[:,-1],env.current,env.times)
        return (time.perf_counter_ns()-t)/1e6
    for entry in entries:
        for _ in range(5):measure(entry,int(positions[0]))
    rows=[]
    # Interleave methods within each anchor/repeat to reduce order/thermal drift.
    for position in positions:
        for repeat in range(3):
            for entry in entries:
                ms=measure(entry,int(position));group,seed,policy,_=entry
                rows.append({'method':group,'seed':seed,'validation_position':int(position),'original_index':int(inputs['indices'][position]),
                    'repeat':repeat,'end_to_end_ms':ms,'actor_forward_only_ms':measure(entry,int(position),True) if policy.actor is not None else ''})
        print('latency anchor',position,flush=True)
    folder=OUT/'latency';folder.mkdir(exist_ok=True);csv_write(folder/'decisions.csv',rows)
    summary=[]
    for group in BASELINES+GROUPS:
        subset=[r for r in rows if r['method']==group];values=np.array([r['end_to_end_ms'] for r in subset])
        forward=[r['actor_forward_only_ms'] for r in subset if r['actor_forward_only_ms']!='']
        summary.append({'method':group,'observations':len(values),'mean_ms':float(values.mean()),'median_ms':float(np.median(values)),'p95_ms':float(np.quantile(values,.95)),
            'actor_forward_median_ms':float(np.median(forward)) if forward else None,
            'nominal_planned_model_transitions_per_decision':5120 if group=='cem_mpc' else 90 if group=='grid_mpc' else 0,
            'implementation_note':'Grid/CEM use exact affine response acceleration; nominal candidate transitions are not separate Python model calls.'})
    write_json(folder/'summary.json',{'methods':summary,'positions':positions.tolist(),'cpu_threads':4,'batch_size':1,'warmup_decisions_per_model':5,
        'repeats_per_anchor':3,'platform':platform.platform(),'machine':platform.machine(),'logical_cpu_count':os.cpu_count(),'torch_version':torch.__version__,
        'threadpools':threadpool_info(),'scope':'end-to-end observation assembly, retrieval if implemented, decision, projection and support; excludes plant transition, model loading and I/O',
        'sensor_note':'shared observation implementation retrieves then zeros visual fields; not claimed to be a speed-optimized sensor-only deployment',
        'timer':'time.perf_counter_ns','concurrency':'no other jobs from this study during measurements; uncontrolled external OS activity remains possible'})

def main():
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['advisory','latency']);args=parser.parse_args()
    torch.set_num_threads(4)
    with threadpool_limits(4):globals()[args.stage]()

if __name__=='__main__':main()
