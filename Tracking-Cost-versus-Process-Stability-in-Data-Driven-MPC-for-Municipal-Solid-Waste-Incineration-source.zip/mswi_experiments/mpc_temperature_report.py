"""Validate trajectories and summarize the frozen temperature protection scan."""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import torch
from threadpoolctl import threadpool_limits
from .control import reward_and_violation
from .data import MINUTE_NS
from .ridge_policy import RidgePolicyEnv
from .ridge_dynamics import RidgeDynamics
from .ridge_policy_report import endpoints,csv_write
from .ridge_control_probe_report import METRICS
from .visual_diagnostics_statistics import paired_block_interval,DAY_NS
from .ridge_policy_study import read_npz,write_json,sha
from .mpc_temperature import select_configuration
from .mpc_temperature_study import OUT,REF,PRIOR,MODELS,VARIANTS,SAMPLE_KEYS,protocol,shared,verify_sources

def audit_case(row,mid,vid,execution,full,inputs):
    if row['pred_cv'].shape!=(256,50,9):raise AssertionError('wrong episode count/horizon')
    for k in ('indices','time_ns'):
        np.testing.assert_array_equal(row[k],inputs[k])
    stats=execution.stats
    reward,violation,cost=reward_and_violation(row['pred_cv'],row['executed_action'],stats)
    for k,v in {'reward':reward,'violation':violation,**cost}.items():np.testing.assert_array_equal(row[k],v)
    if np.any(row['physical_executed_action'][:,:,[1,2,4,5,6,7]]!=0):raise AssertionError('inactive MV')
    if np.any(np.abs(row['physical_executed_action'])>.1*execution.bound+1e-10):raise AssertionError('action budget')
    if np.any(np.any(row['executed_action']!=0,axis=-1)&~row['action_supported']):raise AssertionError('unsupported nonzero action')
    if vid=='E' and np.any(row['planned_temperature_margin']<0):raise AssertionError('E predicted plan violates constraint')
    env=RidgePolicyEnv(RidgeDynamics.load(REF/f'evaluation_models/{mid}.npz'),execution,horizon=50)
    env.reset(options={'inputs':inputs});errors={k:0. for k in ('pred_cv','reward','executed_action')}
    for step in range(50):
        _,_,_,_,info=env.step_request(row['requested_action'][:,step])
        for k in errors:
            errors[k]=max(errors[k],float(np.max(np.abs(info[k]-row[k][:,step]))))
            np.testing.assert_array_equal(info[k],row[k][:,step])
    # Standard recursion rescores selected CEM plans independently of the
    # affine candidate accelerator. Three fixed starts and four fixed steps.
    ids=np.array([0,127,255]);small={k:inputs[k][ids] for k in SAMPLE_KEYS};plan_errors=[]
    cfg=next(c for c in protocol()['variants'] if c['id']==vid)
    for step in (0,9,24,49):
        if step==0:history=small
        else:
            history={'u_hist':np.concatenate((small['u_hist'],row['u_path'][ids,:step]),axis=1)[:,-11:],
                'z_hist':np.concatenate((small['z_hist'],small['z_current'][:,None],row['pred_cv'][ids,:step-1]),axis=1)[:,-10:],
                'z_current':row['pred_cv'][ids,step-1],'time_ns':small['time_ns']+step*MINUTE_NS,'indices':small['indices']}
        plan_env=RidgePolicyEnv(full,execution,horizon=10);hold_env=RidgePolicyEnv(full,execution,horizon=10)
        plan_env.reset(options={'inputs':history});hold_env.reset(options={'inputs':history})
        original=np.zeros(3);jt=np.zeros(3);hold_jt=np.zeros(3)
        for j in range(10):
            _,r,_,_,info=plan_env.step(row['best_requested_plan_b'][ids,step,j])
            _,_,_,_,hi=hold_env.step(np.zeros((3,2)))
            original+=r.astype(float);jt+=info['tracking_cost'][:,0].astype(float);hold_jt+=hi['tracking_cost'][:,0].astype(float)
        values={'selected_original_return':original,'selected_temperature_cost':jt,'hold_temperature_cost':hold_jt,
                'selected_planning_score':original-(cfg['temperature_weight']-1)*jt}
        err={k:float(np.max(np.abs(v-row[k][ids,step]))) for k,v in values.items()}
        for k,v in values.items():np.testing.assert_allclose(v,row[k][ids,step],atol=1e-5,rtol=0)
        plan_errors.append({'decision_step':step,'errors':err})
    return {'variant':vid,'model':mid,'full_feedback_errors':errors,'plan_rescore':plan_errors}

def summarize():
    verify_sources();frozen=json.loads((OUT/'implementation_frozen.json').read_text())['hashes']
    for p,h in frozen.items():
        if sha(p)!=h:raise AssertionError('frozen implementation changed')
    stats,execution,full=shared();inputs=read_npz(REF/'inputs/val.npz');days=inputs['time_ns']//DAY_NS
    values={};means=[];actions=[];fingerprint=None;audits=[];manifest=[];out=OUT/'report';out.mkdir(exist_ok=True)
    for mid in MODELS:
        hold=read_npz(PRIOR/f'trajectories/val/{mid}/hold/seed0.npz')
        for h in (10,50):
            values[mid,'hold',h]=endpoints(hold,h)
            means.append({'model':mid,'variant':'hold','horizon':h,**dict(zip(METRICS,values[mid,'hold',h].mean(0).tolist()))})
        for vid in VARIANTS:
            path=OUT/f'trajectories/{vid}/{mid}.npz';row=read_npz(path);meta=json.loads(path.with_suffix('.json').read_text())
            if sha(path)!=meta['sha256']:raise AssertionError('trajectory hash')
            if fingerprint is None:fingerprint=row['noise_sha256'].copy()
            np.testing.assert_array_equal(row['noise_sha256'],fingerprint)
            audits.append(audit_case(row,mid,vid,execution,full,inputs))
            manifest.append({'path':str(path.relative_to(OUT)),'sha256':sha(path),'episodes':256,'steps':50})
            for h in (10,50):
                value=endpoints(row,h);values[mid,vid,h]=value
                means.append({'model':mid,'variant':vid,'horizon':h,**dict(zip(METRICS,value.mean(0).tolist()))})
                d=row['physical_executed_action'][:,:h]
                actions.append({'model':mid,'variant':vid,'horizon':h,'nonzero_fraction':float(np.any(d!=0,axis=-1).mean()),
                    'blocked_nonzero_fraction':float(row['blocked_nonzero'][:,:h].mean()),'unsupported_hold_fraction':float(row['zero_action_unsupported'][:,:h].mean()),
                    'movement_cost':float(row['movement_cost'][:,:h].mean()),
                    'primary_air_mean_abs_increment':float(np.abs(d[:,:,0]).mean()),'induced_draft_mean_abs_increment':float(np.abs(d[:,:,3]).mean()),
                    'primary_air_max_abs_increment':float(np.abs(d[:,:,0]).max()),'induced_draft_max_abs_increment':float(np.abs(d[:,:,3]).max()),
                    'min_planned_temperature_margin':float(row['planned_temperature_margin'][:,:h].min()),
                    'mean_feasible_candidates':float(row['feasible_candidate_counts'][:,:h].mean())})
            print('audited',vid,mid,flush=True)
    details={};contrasts=[];paired={};guard_rows=[];decisions={}
    for h in (10,50):
        baseline=np.stack([values[m,'hold',h].mean(0) for m in MODELS[1:]])
        candidates={v:np.stack([values[m,v,h].mean(0) for m in MODELS[1:]]) for v in VARIANTS}
        decisions[str(h)]=select_configuration(baseline,candidates)
        decisions[str(h)]['role']='primary_selection' if h==10 else 'secondary_descriptive_only_no_reselection'
        for m in MODELS:
            for v in VARIANTS:
                for ref in ('hold','A'):
                    if v==ref:continue
                    delta=values[m,ref,h]-values[m,v,h];delta[:,0]*=-1
                    label=f'{m}/{h}/{v}_vs_{ref}'
                    result=paired_block_interval(delta[None],days,draws=10000,seed=20261106)
                    result['estimand']='paired original return gain and guardrail reduction; one fixed shared CEM random stream, whole-day bootstrap'
                    details[label]=result;paired[label.replace('/','__')]=delta
                    for j,name in enumerate(METRICS):
                        contrasts.append({'model':m,'horizon':h,'variant':v,'reference':ref,'metric':name,'difference':result['difference'][j],
                            'ci_lower':result['ci_lower'][j],'ci_upper':result['ci_upper'][j],'worse_episode_fraction':float((delta[:,j]<0).mean())})
                    if ref=='hold':
                        slack=delta.copy();slack[:,1:]+=.01*values[m,'hold',h][:,1:]
                        si=paired_block_interval(slack[None],days,draws=10000,seed=20261106)
                        details[label+'_relative_1pct_slack']=si
                        base=values[m,'hold',h].mean(0);cand=values[m,v,h].mean(0)
                        for j,name in enumerate(METRICS[1:],1):
                            increase=cand[j]-base[j]
                            guard_rows.append({'model':m,'horizon':h,'variant':v,'metric':name,'hold_mean':float(base[j]),'candidate_mean':float(cand[j]),
                                'increase':float(increase),'strict_margin':0.,'relative_margin':float(.01*base[j]),
                                'increase_percent_of_hold':float(100*increase/base[j]) if base[j]!=0 else None,
                                'strict_pass':bool(cand[j]<=base[j]),'relative_1pct_pass':bool(cand[j]<=1.01*base[j]),
                                'relative_slack_ci_lower':si['ci_lower'][j],'relative_slack_ci_upper':si['ci_upper'][j]})
    csv_write(out/'endpoint_means.csv',means);csv_write(out/'contrasts.csv',contrasts)
    csv_write(out/'guardrails.csv',guard_rows);csv_write(out/'actions_and_support.csv',actions)
    write_json(out/'contrasts.json',details);write_json(out/'selection.json',decisions)
    np.savez_compressed(out/'episode_endpoints.npz',**{'__'.join(map(str,k)):v for k,v in values.items()})
    np.savez_compressed(out/'paired_improvements.npz',**paired)
    write_json(OUT/'audit.json',{'status':'passed','cases':audits,'all25_noise_hash_arrays_equal':True,
        'noise_positions_per_case':int(fingerprint.size),'original_rewards_recomputed':320000,'all_feedback_reexecuted':320000,
        'selected_plan_rescores':25*3*4,'test_evaluations':0,'trajectories_dropped':0,'predictions_clipped':False})
    write_json(OUT/'trajectory_manifest.json',{'files':manifest,'case_count':25,'episodes':6400,'steps':320000,'all_validation_only':True})
    render(out,values,decisions)
    write_readout(out,values,decisions,details,actions)

def render(out,values,decisions):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':180})
    colors=['#1f77b4','#ff7f0e','#2ca02c','#d62728','#9467bd']
    fig,axs=plt.subplots(2,2,figsize=(11,8))
    for ax,m in zip(axs.ravel(),MODELS[1:]):
        ref=values[m,'hold',10].mean(0);points=[]
        for i,v in enumerate(VARIANTS):
            c=values[m,v,10].mean(0);x=c[1]-ref[1];y=c[0]-ref[0];points.append((x,y))
            ax.scatter(x,y,color=colors[i],s=60,label=v);ax.annotate(v,(x,y),xytext=(5,5),textcoords='offset points')
        pts=np.array(points);keep=[]
        for i,(x,y) in enumerate(pts):
            dominated=np.any((pts[:,0]<=x)&(pts[:,1]>=y)&((pts[:,0]<x)|(pts[:,1]>y)))
            if not dominated:keep.append(i)
        order=sorted(keep,key=lambda i:pts[i,0]);ax.plot(pts[order,0],pts[order,1],color='gray',ls=':',lw=1)
        ax.axvline(0,color='black',lw=.8);ax.axvline(.01*ref[1],color='#ff7f0e',ls='--',lw=1)
        ax.axhline(0,color='black',lw=.8);ax.set_title(m)
        ax.set_xlabel('Temperature MAE increase vs hold (deg C)');ax.set_ylabel('Original 10-step return gain')
    axs[0,0].legend(title='Configuration',fontsize=8);fig.tight_layout();fig.savefig(out/'cost_temperature_tradeoff.png');plt.close(fig)
    fig,axs=plt.subplots(1,2,figsize=(11,4.5))
    for ax,h in zip(axs,(10,50)):
        for i,v in enumerate(VARIANTS):
            gains=[values[m,v,h][:,0].mean()-values[m,'hold',h][:,0].mean() for m in MODELS[1:]]
            ax.plot(MODELS[1:],gains,'o-',color=colors[i],label=v)
        ax.axhline(0,color='black',lw=.8);ax.set_title(f'{h}-step original return gain');ax.set_ylabel('Candidate minus hold')
    axs[1].legend();fig.tight_layout();fig.savefig(out/'horizon_gains.png');plt.close(fig)

def write_readout(out,values,decisions,details,actions):
    lines=[]
    def add(x=''):lines.append(x)
    names={'A':'原CEM，温度权重1','B':'温度权重2','C':'温度权重4','D':'温度权重8','E':'原成本＋预测温度约束'}
    primary=decisions['10'];labels={'strict_pass':'严格零退化通过','relative_1pct_pass':'1%研究容差通过（次要）','not_passed':'未通过'}
    add('CEM-MPC温度保护：验证集A–E扫描结果')
    add('本轮仅执行第一步。无新模型训练、无GRU交叉评价、无通道/支持消融、无新测试集评价；论文与原复现包未更新。')
    add('五个配置在256个固定验证起点、五个Ridge评价器上各完成50步，10步是主终点；full仅描述，四个非规划评价器用于配置选择。全部是实际运行并存档的模型实验，不是现场干预。')
    add('公共随机数使用SeedSequence([2026,原起点ID,决策步])。25份档案的每起点/每步噪声指纹完全相同；这不意味着优化后的候选动作或闭环状态相同。')
    add('A与上一轮验证集CEM的五份50步轨迹逐值一致。所有320,000个控制步重算奖励并重做标准环境反馈；另用标准递归复核300条所选计划。')
    add()
    add('一、选择结论')
    if primary['selected'] is None:add('没有配置通过严格零退化或1%研究容差层级。本轮不选最终配置，不按结果扩大扫描或继续GRU/消融。有限搜索未找到配置，不等于证明不存在可行控制。')
    else:add(f"按预设选择{primary['selected']}：{names[primary['selected']]}，层级为{labels[primary['selected_tier']]}。这只是验证集配置选择，不是独立验证通过或现场可用性证明。")
    add('配置 | 层级 | 四评价器最小原始回报改善')
    for v,item in primary['configurations'].items():add(f"{v} | {labels[item['tier']]} | {item['strict']['worst_cost_gain']:+.6f}")
    add('先比较严格层级，再比较1%次要层级；在可选层级内最大化四模型最小原始回报改善。精确并列按A到E。50步不参与重新选择。')
    add()
    for h in (10,50):
        add(f'二、{h}步原始累计回报（负成本，越大越好）')
        add('模型 | Hold | A | B | C | D | E')
        for m in MODELS:add(m+' | '+' | '.join(f'{values[m,v,h][:,0].mean():.5f}' for v in ('hold',)+VARIANTS))
        add(f'{h}步相对保持操作的温度偏差增加（℃；正值表示退化）')
        add('模型 | A | B | C | D | E')
        for m in MODELS[1:]:add(m+' | '+' | '.join(f'{values[m,v,h][:,1].mean()-values[m,"hold",h][:,1].mean():+.6f}' for v in VARIANTS))
        add()
    add('三、10步各项退化与研究容差')
    add('1%作用于每个模型保持操作的对应均值，保持基准0则容差0；不增加绝对下限。越界率的1%是相对变化，不是1个百分点。该层级不是工厂确认的实用或安全标准。')
    for m in MODELS[1:]:
        base=values[m,'hold',10].mean(0)
        add(m+'：允许退化量[T℃, P Pa, 蒸汽t/h, O2百分点, 越界率百分点]='+str([round(x,7) for x in list(.01*base[1:5])+[base[5]]]))
        add('配置 | 回报改善 | T增加 | P增加 | 蒸汽增加 | O2带外距离增加 | 越界率增加百分点')
        for v in VARIANTS:
            c=values[m,v,10].mean(0);d=c-base;d[5]*=100
            add(v+' | '+' | '.join(f'{x:+.6f}' for x in d))
    add('逐指标的均值、退化比例、允许量和通过标志见guardrails.csv。不能仅凭温度改善，就忽略炉压、蒸汽、氧含量或越界率的变化。')
    add()
    add('四、探索性配对区间：10步原始回报改善（候选−保持）')
    for m in MODELS[1:]:
        for v in VARIANTS:
            r=details[f'{m}/10/{v}_vs_hold'];add(f"{m}/{v}: {r['difference'][0]:+.5f} [{r['ci_lower'][0]:+.5f}, {r['ci_upper'][0]:+.5f}]")
    add('整日配对bootstrap10,000次、随机种子20261106、95%区间，未作多重比较校正。只有7个日期块，不能给出要求至少10块的区间充分支持标签。1%层级区间对1.01×保持−候选逐起点重采样，包含保持基准的不确定性。')
    add('这是验证集选择过程，性能估计会受到配置选择影响。旧测试时期已被看过，后续统一评价也不能重新称为全新盲测。')
    add()
    add('五、执行与解释')
    add('E在full规划模型中约束的是每次计划的执行后十步平均温度误差，不是每个预测步的温度上限，也不保证反复重新规划后整个闭环时域相对初始保持轨迹不退化。跨评价模型的实际误差仍按同一标准独立核对。')
    add('动作与支持过滤不变：两通道0.1B；近邻为标准化MV8/CV9/动作8的25维欧氏距离，2048训练支持样本；不支持的非零动作变成保持，零动作仍放行。')
    add('非零动作、拦截、无支持零动作和E的可行候选数见actions_and_support.csv。不能把大量退回保持造成的温度不变称为控制改善，所有通过层级仍要求成本严格下降。')
    add('成本—温度图中的虚线连接五个已试配置里的非支配点，仅是有限候选集的取舍图，不是全局最优帕累托前沿。橙色竖线只显示温度1%容差，不代表其他四项护栏通过。')
    add('代码仅新增温度配置的排序/可行性规则与噪声核验；状态转移、支持执行和原奖励复用旧模块，旧实验源文件保持不变。')
    add('文件：endpoint_means.csv、guardrails.csv、contrasts.csv/json、selection.json、actions_and_support.csv、episode_endpoints.npz；图：cost_temperature_tradeoff.png、horizon_gains.png。')
    (out/'REPORT_zh.txt').write_text('\n'.join(lines)+'\n')

if __name__=='__main__':
    torch.set_num_threads(4)
    with threadpool_limits(4):summarize()
