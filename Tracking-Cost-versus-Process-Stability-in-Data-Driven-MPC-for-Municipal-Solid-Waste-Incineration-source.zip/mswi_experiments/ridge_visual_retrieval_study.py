"""Frozen nearest-history visual retrieval experiments for Ridge dynamics.

Fit selects regularization on validation only. Predict reloads the frozen fit,
then evaluates single steps and predicted-CV-only recursive trajectories.
The established pure numerical predictor and manuscript are not modified.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import platform
import shutil
import sys

import numpy as np
from threadpoolctl import threadpool_limits

from .data import load_data
from .numeric_baselines import (_check_data, fit_linear_candidates, numeric_features,
                                sha256, write_json)
from .ridge_dynamics import RidgeDynamics, continuous_chains, recursive_rollout
from .ridge_validation import resolve_predictor
from .ridge_visual_retrieval import NumericalVisualMemory, RidgeWithVisual, retrieved_rollout


FIT_METHODS = {
    'retrieved52': ('52', 'real', 'retrieved'),
    'retrieved_rgb32': ('rgb32', 'real', 'retrieved'),
    'shuffled52': ('52', 'shuffled', 'retrieved'),
    'shuffled_rgb32': ('rgb32', 'shuffled', 'retrieved'),
    'observed52_retrieved': ('52', 'real', 'observed'),
    'observed_rgb32_retrieved': ('rgb32', 'real', 'observed'),
}


def archive(path):
    with np.load(path, allow_pickle=False) as raw:
        return {name: raw[name] for name in raw.files}


def paths(config_file):
    path = Path(config_file).resolve()
    cfg = json.loads(path.read_text())
    if cfg['horizon'] != 10 or cfg['endpoints'] != [1, 5, 10] or cfg['memory_items'] != 512:
        raise ValueError('this protocol fixes a 512-anchor memory and ten-step trajectories')
    return cfg, path.parent, path.parent / cfg['output_dir']


def verify(hashes, root=None):
    for name, expected in hashes.items():
        path = Path(name) if root is None else Path(root) / name
        if sha256(path) != expected:
            raise ValueError(f'frozen source changed: {path}')


def visual_inputs(project, cfg, data):
    """Verify and replay the original training-only RGB PCA before reuse."""
    visual = project / cfg['visual_study']
    probe = visual / 'probe'
    completion = json.loads((probe / 'completed.json').read_text())
    if completion['status'] != 'completed':
        raise ValueError('source RGB study is incomplete')
    if sha256(probe / 'artifact_hashes.json') != completion['artifact_hashes_sha256']:
        raise ValueError('source RGB artifact manifest changed')
    if sha256(probe / 'protocol.json') != completion['protocol_sha256']:
        raise ValueError('source RGB protocol changed')
    hashes = json.loads((probe / 'artifact_hashes.json').read_text())
    for name in ('prepared_features.npz', 'pca_rgb.npz'):
        verify({name: hashes[name]}, probe)
    prior = json.loads((probe / 'protocol.json').read_text())
    source_files = [visual / 'embeddings.npz', visual / 'encoder_manifest.json']
    source_files += [project / cfg['source_run'] / 'data' / name
                     for name in ('dataset.npz', 'stats.json', 'manifest.json')]
    verify({str(p): prior['source_input_hashes'][str(p.resolve())] for p in source_files})
    embedded, pca, prepared = [archive(p) for p in
        (visual / 'embeddings.npz', probe / 'pca_rgb.npz', probe / 'prepared_features.npz')]
    mapping = embedded['sample_capture_index']
    if not np.array_equal(mapping, prepared['sample_capture_index']):
        raise ValueError('RGB sample/capture alignment changed')
    if not np.array_equal(embedded['capture_time_ns'][mapping], data['visual_time_ns']):
        raise ValueError('RGB capture time differs from original observed visual time')
    expected_train = np.unique(mapping[data['train_idx']])
    if not np.array_equal(expected_train, pca['train_capture_indices']):
        raise ValueError('PCA must be fitted on unique training captures only')
    reconstructed = ((np.asarray(embedded['rgb'], dtype=np.float64) - pca['mean'])
                     @ pca['components'].T)[mapping]
    if reconstructed.shape != (len(mapping), 32) or not np.allclose(
            reconstructed, prepared['rgb32'], rtol=0, atol=1e-10):
        raise ValueError('saved RGB32 differs from encoder/PCA replay')
    if not np.array_equal(pca['capture_time_ns'], embedded['capture_time_ns']):
        raise ValueError('PCA capture identity mismatch')
    source_files += [probe / name for name in
        ('completed.json', 'protocol.json', 'artifact_hashes.json', 'prepared_features.npz', 'pca_rgb.npz')]
    return prepared['rgb32'], source_files, {
        'pca_train_unique_captures': len(expected_train),
        'pca_replay_max_difference': float(np.max(np.abs(reconstructed-prepared['rgb32']))),
        'encoder': 'frozen ImageNet ResNet18; prior ROI and global pooling; fixed train-only PCA32',
    }


def prepare(config_file):
    cfg, project, out = paths(config_file)
    if out.exists():
        raise FileExistsError('use a fresh study directory; prior artifacts are immutable')
    data, stats, _ = load_data(project / cfg['source_run'] / 'data')
    _check_data(data, stats)
    selected, checkpoint, base_study, ridge = resolve_predictor(project, cfg['current_predictor'])
    if not np.array_equal(ridge.weights['delta_scale'], np.asarray(stats['delta_scale'])):
        raise ValueError('baseline and new models require identical target scaling')
    rgb, inputs, visual_audit = visual_inputs(project, cfg, data)
    chains = {s: continuous_chains(data, s, cfg['horizon']) for s in ('val', 'test')}
    out.mkdir(parents=True)
    (out / 'models').mkdir(); (out / 'memories').mkdir()
    shutil.copyfile(checkpoint, out / 'models/ridge.npz')
    write_json(out / 'config.json', cfg); write_json(out / 'stats.json', stats)
    np.savez_compressed(out / 'chains.npz', **chains)
    prepared = {'observed52': np.asarray(data['visual'], dtype=np.float64),
                'observed_rgb32': np.asarray(rgb, dtype=np.float64)}
    retrieval_audit = {}
    for width, visual in (('52', data['visual']), ('rgb32', rgb)):
        for mode in ('real', 'shuffled'):
            memory = NumericalVisualMemory(data, data['train_idx'], visual,
                max_items=cfg['memory_items'],
                permutation_seed=cfg['permutation_seed'] if mode == 'shuffled' else None,
                exclusion_permutation_seed=cfg['permutation_seed'])
            memory.save(out / f'memories/{width}_{mode}.npz')
            prefix = f'{width}_{mode}'
            fields = {'visual': np.zeros_like(visual, dtype=np.float64),
                'key_indices': np.full(len(visual), -1, dtype=np.int64),
                'donor_indices': np.full(len(visual), -1, dtype=np.int64),
                'scores': np.zeros(len(visual), dtype=np.float64)}
            for split in ('train', 'val', 'test'):
                idx = data[split + '_idx']
                result = memory.query(data['u_hist'][idx], data['z_hist'][idx],
                                      query_indices=idx if split == 'train' else None)
                for name in fields:
                    fields[name][idx] = result[name]
                retrieval_audit[f'{prefix}/{split}'] = {
                    'samples': len(idx), 'unique_keys': len(np.unique(result['key_indices'])),
                    'unique_donors': len(np.unique(result['donor_indices'])),
                    'min_cosine': float(np.min(result['scores'])),
                    'mean_cosine': float(np.mean(result['scores'])),
                }
            prepared.update({prefix + '_' + key: value for key, value in fields.items()})
    for width in ('52', 'rgb32'):
        if not np.array_equal(prepared[width+'_real_key_indices'], prepared[width+'_shuffled_key_indices']):
            raise ValueError('real and shuffled controls must use identical retrieval keys before recursion')
    if not np.array_equal(prepared['52_real_key_indices'], prepared['rgb32_real_key_indices']):
        raise ValueError('both visual representations must use the same nearest-history query')
    np.savez_compressed(out / 'prepared.npz', **prepared)
    inputs += [project / cfg['current_predictor'], checkpoint,
               base_study / 'selection.json', base_study / 'selection_frozen.json']
    protocol = {
        'schema_version': 1, 'baseline': selected, 'visual_audit': visual_audit,
        'partitions': {s: int(len(data[s+'_idx'])) for s in ('train', 'val', 'test')},
        'recursive_starts': {s: len(c) for s, c in chains.items()},
        'fit_methods': {k: list(v) for k,v in FIT_METHODS.items()},
        'memory': '512 uniformly spaced training anchors; StandardScaler on 178 numerical history columns from training only, then L2-normalized cosine; top1, deterministic first tie. No GRU key.',
        'training_query_exclusion': 'Exclude source-overlapping or same-capture key anchors AND their paired shuffled donors. Identical eligibility masks for real/shuffled controls. Entire training library is available during offline fitting; this is not a chronological online training simulation.',
        'shuffled_control': 'One fixed seeded permutation cycle without anchor fixed points; shuffle visual donors, preserve numerical keys. Trace actual donor separately. One randomization only.',
        'ridge_fit': 'Full direct increment Ridge on 178 numerical columns plus retrieved visual columns, training-only feature standardization, canonical training increment scales. Validation one-step NMSE selects alpha from fixed grid, tie favors greater alpha. No validation/test refit.',
        'observed_training_diagnostic': 'Fit using matched observed visual inputs, select alpha using retrieved validation inputs, deploy retrieved visuals. Observed-input one-step scores are a separate diagnostic of this SAME frozen model.',
        'selection': 'Only validation one-step error selects models. Ten-step endpoint is evaluation, not optimization. All six fits and code are frozen before test prediction.',
        'primary_endpoint': 'test logged-MV h10 nine-channel increment-scale normalized MSE',
        'secondary': 'full-test one-step; recursive h1/h5; four physical MAE/RMSE; held-MV sensitivity; matched shuffled and held-initial-visual controls',
        'recursive': 'All complete existing ten-step chains, same starts for all methods. Predicted CV feedback only. Dynamic queries use updated numerical histories at every step including first. Held visual keeps the first retrieved feature. No future true CV or future observed images enter predictions.',
        'logged_mv': 'Recorded future operations are conditioning inputs; this is conditional replay, not autonomous online forecasting.',
        'hold_mv': 'Keep initial operation from step2. Comparing with logged outcomes is a sensitivity analysis, not observed counterfactual ground truth.',
        'uncertainty': 'Paired start-calendar-day block bootstrap, 10000 draws, 95% exploratory unadjusted intervals, single deterministic Ridge fit, no artificial seed replication.',
        'limits': 'Previously inspected test period. Retrieved visuals are deterministic functions of numeric history and training memory; gains do not establish independent current-image information, causal plant responses, or RL control benefits.',
        'no_clipping_or_dropped_chains': True,
        'source_input_hashes': {str(p.resolve()): sha256(p) for p in inputs},
        'software': {'python': sys.version, 'numpy': np.__version__, 'platform': platform.platform()},
    }
    write_json(out / 'protocol.json', protocol)
    write_json(out / 'retrieval_preparation_audit.json', retrieval_audit)
    files = ['config.json','stats.json','chains.npz','prepared.npz','protocol.json',
             'retrieval_preparation_audit.json','models/ridge.npz']
    files += [f'memories/{width}_{mode}.npz' for width in ('52','rgb32') for mode in ('real','shuffled')]
    write_json(out / 'prepare_frozen.json', {'status':'complete','files':{p:sha256(out/p) for p in files}})
    print('Preparation complete:', protocol['recursive_starts'], flush=True)
    return out


def load_prepared(config_file):
    cfg, project, out = paths(config_file)
    if cfg != json.loads((out / 'config.json').read_text()):
        raise ValueError('configuration changed after preparation')
    frozen = json.loads((out / 'prepare_frozen.json').read_text())
    verify(frozen['files'], out)
    protocol = json.loads((out / 'protocol.json').read_text())
    verify(protocol['source_input_hashes'])
    data, stats, _ = load_data(project / cfg['source_run'] / 'data')
    return cfg, project, out, data, stats, archive(out / 'prepared.npz')


def fit(config_file):
    cfg, project, out, data, stats, prepared = load_prepared(config_file)
    if (out / 'selection.json').exists():
        raise FileExistsError('selection already exists')
    x = numeric_features(data)
    previous = np.asarray(data['z_prev'], dtype=np.float64)
    truth = np.asarray(data['z_target'], dtype=np.float64)
    delta = truth - previous
    rows = []
    for method, (width, mode, training) in FIT_METHODS.items():
        visual = prepared[f'{width}_{mode}_visual'].copy()
        if training == 'observed':
            visual[data['train_idx']] = prepared['observed52' if width == '52' else 'observed_rgb32'][data['train_idx']]
        design = np.concatenate((x, visual), axis=1)
        weights, candidates, chosen = fit_linear_candidates(design, delta, previous, truth,
            data['train_idx'], data['val_idx'], stats['delta_scale'], cfg['ridge_alphas'])
        model = RidgeWithVisual(weights)
        model.save(out / f'models/{method}.npz')
        row = {'method':method, 'visual_width':int(width) if width=='52' else 32,
               'memory':f'memories/{width}_{mode}.npz', 'training_visual':training,
               'model_path':f'models/{method}.npz', 'selected':chosen, 'candidates':candidates}
        rows.append(row)
        print('Fitted', method, chosen, flush=True)
    write_json(out / 'selection.json', {'status':'complete','models':rows,
        'selection_rule':'minimum validation one-step NMSE; test not scored',
        'prepare_frozen_sha256':sha256(out/'prepare_frozen.json')})
    frozen = dict(json.loads((out / 'prepare_frozen.json').read_text())['files'])
    for path in ['prepare_frozen.json','selection.json'] + [r['model_path'] for r in rows]:
        frozen[path] = sha256(out / path)
    snapshot = out / 'code_snapshot'; snapshot.mkdir()
    code_names = ['ridge_visual_retrieval.py','ridge_visual_retrieval_study.py','ridge_visual_retrieval_report.py',
                  'numeric_baselines.py','numeric_baselines_report.py','ridge_dynamics.py','ridge_validation.py',
                  'ridge_validation_report.py','visual_diagnostics_statistics.py','data.py']
    source_code = {}
    for name in code_names:
        path = project / 'mswi_experiments' / name
        shutil.copyfile(path, snapshot / name)
        frozen['code_snapshot/'+name] = sha256(snapshot/name)
        source_code[str(path)] = sha256(path)
    write_json(out / 'selection_frozen.json', {'status':'complete','files':frozen,'source_code_hashes':source_code})
    print('All selections and code frozen before test prediction.', flush=True)
    return out


def predict(config_file):
    cfg, project, out, data, stats, prepared = load_prepared(config_file)
    if (out / 'predictions_manifest.json').exists():
        raise FileExistsError('predictions already completed')
    frozen = json.loads((out / 'selection_frozen.json').read_text())
    verify(frozen['files'], out); verify(frozen['source_code_hashes'])
    selections = json.loads((out / 'selection.json').read_text())['models']
    ridge = RidgeDynamics.load(out / 'models/ridge.npz')
    models = {r['method']:RidgeWithVisual.load(out/r['model_path']) for r in selections}
    memories = {r['method']:NumericalVisualMemory.load(out/r['memory']) for r in selections}
    chains = archive(out / 'chains.npz')
    files = []

    def save(name, content, **metadata):
        dest = out / name; dest.parent.mkdir(parents=True, exist_ok=True)
        if dest.exists(): raise FileExistsError(dest)
        np.savez_compressed(dest, **content)
        files.append({'path':name,'sha256':sha256(dest),**metadata})

    for split in ('val','test'):
        idx = data[split+'_idx']; n = len(idx)
        common = {'indices':idx,'time_ns':data['time_ns'][idx],'truth_cv':data['z_target'][idx]}
        pred = ridge.predict_next(data['u_hist'][idx], data['z_hist'][idx])
        empty = {'key_indices':np.full(n,-1,dtype=np.int64),'donor_indices':np.full(n,-1,dtype=np.int64),'scores':np.zeros(n)}
        save(f'one_step/{split}/ridge.npz', {**common,'pred_cv':pred,**empty},kind='one_step',split=split,method='ridge')
        for method, model in models.items():
            retrieved = memories[method].query(data['u_hist'][idx], data['z_hist'][idx])
            pred = model.predict_next(data['u_hist'][idx], data['z_hist'][idx], retrieved['visual'])
            trace = {key:retrieved[key] for key in empty}
            save(f'one_step/{split}/{method}.npz',{**common,'pred_cv':pred,**trace},kind='one_step',split=split,method=method)
            if method.startswith('observed'):
                name = method.replace('_retrieved','_observed')
                width = FIT_METHODS[method][0]
                visual = prepared['observed52' if width=='52' else 'observed_rgb32'][idx]
                pred = model.predict_next(data['u_hist'][idx],data['z_hist'][idx],visual)
                # Observed-input diagnostics use this sample's actual matched past capture.
                trace = {'key_indices':np.full(n,-1,dtype=np.int64),'donor_indices':idx,'scores':np.zeros(n)}
                save(f'one_step/{split}/{name}.npz',{**common,'pred_cv':pred,**trace},kind='one_step',split=split,method=name)
        print('Single-step completed',split,n,flush=True)
        chain = chains[split]; start = chain[:,0]
        common = {'indices':chain,'start_time_ns':data['time_ns'][start],
            'time_ns':data['time_ns'][chain],'truth_cv':data['z_target'][chain],
            'initial_zprev':data['z_prev'][start]}
        for mv_mode in ('logged','hold_mv'):
            mv = np.asarray(data['u_hist'][chain,-1],dtype=np.float64)
            if mv_mode == 'hold_mv': mv = np.repeat(mv[:,:1],cfg['horizon'],axis=1)
            common['mv_path'] = mv
            u,z = data['u_hist'][start],data['z_hist'][start]
            base_pred = recursive_rollout(ridge,u,z,mv)
            empty = {'key_indices':np.full(chain.shape,-1,dtype=np.int64),
                     'donor_indices':np.full(chain.shape,-1,dtype=np.int64),'scores':np.zeros(chain.shape)}
            save(f'rollouts/{split}/{mv_mode}/ridge.npz',{**common,'pred_cv':base_pred,**empty},
                 kind='rollout',split=split,mv_mode=mv_mode,method='ridge')
            for method, model in models.items():
                modes = ('dynamic','hold') if method in ('retrieved52','retrieved_rgb32') else ('dynamic',)
                for visual_mode in modes:
                    name = method if visual_mode=='dynamic' else method+'_hold_visual'
                    result = retrieved_rollout(model,memories[method],u,z,mv,mode=visual_mode)
                    content = {**common,'pred_cv':result['predictions'],
                               **{key:result[key] for key in empty}}
                    save(f'rollouts/{split}/{mv_mode}/{name}.npz',content,
                         kind='rollout',split=split,mv_mode=mv_mode,method=name)
                    print('Rollout completed',split,mv_mode,name,len(start),flush=True)
    verify(frozen['files'],out); verify(frozen['source_code_hashes'])
    write_json(out/'predictions_manifest.json',{'status':'complete','files':files,
        'selection_sha256':sha256(out/'selection.json'),
        'selection_frozen_sha256':sha256(out/'selection_frozen.json'),
        'trajectories_dropped':0,'predictions_clipped':False,'horizon':cfg['horizon']})
    return out


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage',choices=('prepare','fit','predict','all'))
    parser.add_argument('--config',default='ridge_visual_retrieval_20261105.json')
    args = parser.parse_args()
    cfg, _, _ = paths(args.config)
    with threadpool_limits(limits=cfg['threads']):
        stages = ('prepare','fit','predict') if args.stage=='all' else (args.stage,)
        for stage in stages: globals()[stage](args.config)


if __name__ == '__main__':
    main()
