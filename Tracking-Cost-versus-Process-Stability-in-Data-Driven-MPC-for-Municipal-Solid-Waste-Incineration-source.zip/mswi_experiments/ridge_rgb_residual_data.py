"""Source-separated, forward-time Ridge residuals and frozen visual inputs.

Only the three expanding-window numerical Ridge fits are trained here. Their
future-block predictions provide residual labels for the new correctors. Outer
validation and test predictions use the already selected full-training Ridge.
The inherited PCA and image encoder remain fixed training-only transforms.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from threadpoolctl import threadpool_limits

from .data import MINUTE_NS, _mean_scale, load_data
from .numeric_baselines import (
    _check_data, fit_linear_candidates, linear_increment, numeric_features,
    sha256, write_json,
)
from .ridge_validation import resolve_predictor
from .visual_representation_probe import (
    validate_capture_inputs, validate_encoder_artifact, validate_null_donors,
)


PARTITIONS = ('train', 'val', 'test')
OOF_FRACTIONS = (.4, .6, .8, 1.0)
DESIGN_SLICES = {'numeric': [0, 178], 'timing': [178, 182],
                 'quality': [182, 194], 'rgb': [194, 226]}


def _archive(path):
    with np.load(path, allow_pickle=False) as saved:
        return {key: saved[key] for key in saved.files}


def forward_folds(data, fractions=OOF_FRACTIONS):
    """Use train-index cut times with strict source separation at each cut.

    Targets in the first 40% are not corrector training labels. A later target
    enters exactly one block, only if every recorded source starts after that
    block's fit cutoff. A fixed 21-minute purge would not suffice for all image
    histories, so the actual recorded source range controls exclusion.
    """
    fractions = tuple(float(v) for v in fractions)
    if fractions != OOF_FRACTIONS:
        raise ValueError('this frozen study requires fractions [0.4,0.6,0.8,1.0]')
    times = np.asarray(data['time_ns'])
    start = np.asarray(data['source_start_ns'])
    end = np.asarray(data['source_end_ns'])
    rows = np.asarray(data['train_idx'])
    if (times.ndim != 1 or not len(times) or not np.issubdtype(times.dtype, np.integer)
            or np.any(np.diff(times) <= 0) or start.shape != times.shape or end.shape != times.shape
            or not np.issubdtype(start.dtype, np.integer) or not np.issubdtype(end.dtype, np.integer)
            or np.any(start > times) or np.any(end < times)):
        raise ValueError('invalid chronological source ranges')
    if (rows.ndim != 1 or len(rows) < 20 or not np.issubdtype(rows.dtype, np.integer)
            or rows.min() < 0 or rows.max() >= len(times) or np.any(np.diff(rows) <= 0)):
        raise ValueError('invalid training indices for forward folds')
    cuts = [int(times[rows[int(len(rows) * f)]]) for f in fractions[:-1]]
    cuts.append(int(times[rows[-1]]) + 1)
    result = []
    used = set()
    for number, (cut, upper) in enumerate(zip(cuts[:-1], cuts[1:]), 1):
        fit = rows[(times[rows] < cut) & (end[rows] < cut)]
        pred = rows[(times[rows] >= cut) & (times[rows] < upper) & (start[rows] > cut)]
        raw_fit_count = int(np.sum(times[rows] < cut))
        raw_pred_count = int(np.sum((times[rows] >= cut) & (times[rows] < upper)))
        if len(fit) < 2 or not len(pred):
            raise ValueError('empty source-separated fit or prediction block')
        if int(end[fit].max()) >= int(start[pred].min()) or used.intersection(pred.tolist()):
            raise ValueError('forward folds overlap in source time or prediction rows')
        used.update(pred.tolist())
        result.append({'fold': number, 'fit_indices': fit, 'prediction_indices': pred,
                       'cut_time_ns': cut, 'upper_time_ns_exclusive': upper,
                       'fit_rows_removed_by_source_purge': raw_fit_count - len(fit),
                       'prediction_rows_removed_by_source_purge': raw_pred_count - len(pred),
                       'fit_min_source_start_ns': int(start[fit].min()),
                       'fit_max_source_end_ns': int(end[fit].max()),
                       'prediction_min_source_start_ns': int(start[pred].min()),
                       'prediction_max_source_end_ns': int(end[pred].max())})
    return result


def fit_oof_predictions(data, outdir, *, fractions=OOF_FRACTIONS, alpha=100.0):
    """Fit fixed-alpha folds; each predicted row was absent from its fit.

    The shared Ridge fitter is called with one fixed alpha. Its returned block
    score is descriptive only; no fold alpha or checkpoint selection is made.
    """
    if float(alpha) != 100.0:
        raise ValueError('OOF Ridge alpha is fixed at 100')
    out = Path(outdir)
    folds = forward_folds(data, fractions)
    x = numeric_features(data)
    previous = np.asarray(data['z_prev'], dtype=np.float64)
    truth = np.asarray(data['z_target'], dtype=np.float64)
    if previous.shape != (len(x), 9) or truth.shape != previous.shape:
        raise ValueError('OOF residual labels require aligned nine-channel targets')
    if not np.array_equal(previous, np.asarray(data['z_hist'])[:, -1]):
        raise ValueError('z_prev must be the last observed CV')
    delta = truth - previous
    indices, predictions, identifiers, records = [], [], [], []
    for fold in folds:
        fit, pred = fold['fit_indices'], fold['prediction_indices']
        _, scale = _mean_scale(delta[fit])
        model, _, chosen = fit_linear_candidates(
            x, delta, previous, truth, fit, pred, np.asarray(scale), [100.0])
        absolute = previous[pred] + linear_increment(model, x[pred])
        if absolute.shape != (len(pred), 9) or not np.isfinite(absolute).all():
            raise FloatingPointError('nonfinite out-of-fold Ridge prediction')
        dest = out / f"fold_{fold['fold']:02d}"
        dest.mkdir(parents=True, exist_ok=False)
        np.savez_compressed(dest / 'model.npz', **model)
        np.savez_compressed(dest / 'indices.npz', fit_indices=fit, prediction_indices=pred)
        np.savez_compressed(dest / 'predictions.npz', indices=pred,
                            time_ns=np.asarray(data['time_ns'])[pred],
                            base=absolute, truth=truth[pred])
        record = {key: value for key, value in fold.items() if not key.endswith('_indices')}
        record.update(fit_count=len(fit), prediction_count=len(pred), alpha=100.0,
                      parameter_selection='none; alpha fixed before fitting',
                      block_normalized_mse_descriptive=chosen['val_normalized_mse'],
                      model_sha256=sha256(dest / 'model.npz'),
                      indices_sha256=sha256(dest / 'indices.npz'),
                      predictions_sha256=sha256(dest / 'predictions.npz'))
        records.append(record)
        indices.append(pred)
        predictions.append(absolute)
        identifiers.append(np.full(len(pred), fold['fold'], dtype=np.int64))
    return np.concatenate(indices), np.concatenate(predictions), np.concatenate(identifiers), records


def assemble_design(data, timing, quality, rgb, donors):
    """A shared 226-column design; the null alters only 32 RGB columns."""
    x = numeric_features(data)
    matrices = (np.asarray(timing, dtype=np.float64), np.asarray(quality, dtype=np.float64),
                np.asarray(rgb, dtype=np.float64))
    for array, width in zip(matrices, (4, 12, 32)):
        if array.shape != (len(x), width) or not np.isfinite(array).all():
            raise ValueError('invalid timing, quality, or RGB feature shape')
    donors = np.asarray(donors)
    if (donors.shape != (len(x),) or not np.issubdtype(donors.dtype, np.integer)
            or donors.min() < 0 or donors.max() >= len(x)):
        raise ValueError('invalid null donor sample indices')
    aligned = np.concatenate((x, *matrices), axis=1)
    null = aligned.copy()
    null[:, 194:] = matrices[2][donors]
    return aligned, null


def _verify_hash(path, expected):
    if sha256(path) != expected:
        raise ValueError(f'frozen input hash changed: {path}')


def _visual_inputs(data, visual, descriptors, input_paths):
    probe = visual / 'probe'
    complete = json.loads((probe / 'completed.json').read_text())
    if complete.get('status') != 'completed':
        raise ValueError('the inherited RGB study is incomplete')
    _verify_hash(probe / 'artifact_hashes.json', complete['artifact_hashes_sha256'])
    _verify_hash(probe / 'protocol.json', complete['protocol_sha256'])
    artifacts = json.loads((probe / 'artifact_hashes.json').read_text())
    prior = json.loads((probe / 'protocol.json').read_text())
    paths = {
        'embeddings': visual / 'embeddings.npz',
        'encoder': visual / 'encoder_manifest.json',
        'quality': visual / 'image_audit/quality_features.npz',
        'variants': descriptors / 'feature_variants.npz',
        'metadata': descriptors / 'feature_metadata.npz',
    }
    # This is a same-project continuation. Exact paths in the old manifest bind
    # inputs; a relocation should use an explicit package migration instead.
    for path in [*paths.values(), *input_paths]:
        key = str(path.resolve())
        if key not in prior['source_input_hashes']:
            raise ValueError(f'input is absent from the frozen visual study: {path}')
        _verify_hash(path, prior['source_input_hashes'][key])
    for name in ('pca_rgb.npz', 'prepared_features.npz'):
        _verify_hash(probe / name, artifacts[name])
    validate_encoder_artifact(paths['encoder'], paths['embeddings'])
    embeddings, quality = _archive(paths['embeddings']), _archive(paths['quality'])
    variants, metadata = _archive(paths['variants']), _archive(paths['metadata'])
    matrix, columns, captures = validate_capture_inputs(data, embeddings, quality)
    mapping = embeddings['sample_capture_index']
    donors, donor_info = validate_null_donors(data, mapping, metadata['null_donor_sample_index'])
    for name in PARTITIONS:
        rows = np.asarray(data[name + '_idx'])
        _, first = np.unique(mapping[rows], return_index=True)
        representatives = rows[first]
        donor_info[name].update({
            'future_donor_definition': 'donor capture is later than recipient capture; window-weighted inherited fraction',
            'future_donor_fraction_unique_captures': float(np.mean(
                np.asarray(data['visual_time_ns'])[donors[representatives]] > np.asarray(data['visual_time_ns'])[representatives])),
            'unchanged_capture_fraction_unique_captures': float(np.mean(
                mapping[donors[representatives]] == mapping[representatives])),
            'donor_exceeds_origin_input_cutoff_fraction_windows': float(np.mean(
                np.asarray(data['visual_time_ns'])[donors[rows]] > np.asarray(data['time_ns'])[rows] - MINUTE_NS)),
        })
    pca, features = _archive(probe / 'pca_rgb.npz'), _archive(probe / 'prepared_features.npz')
    if (pca['components'].shape != (32, 512) or pca['mean'].shape != (512,)
            or not np.isfinite(pca['components']).all() or not np.isfinite(pca['mean']).all()
            or not np.array_equal(pca['train_capture_indices'], captures['train'])
            or not np.array_equal(pca['capture_time_ns'], embeddings['capture_time_ns'])):
        raise ValueError('PCA is not the fixed 32-dimensional training-capture transform')
    computed = (np.asarray(embeddings['rgb'], dtype=np.float64) - pca['mean']) @ pca['components'].T
    if not np.allclose(features['rgb32'], computed[mapping], rtol=0, atol=1e-10):
        raise ValueError('saved RGB features disagree with encoder/PCA replay')
    if (not np.array_equal(features['sample_capture_index'], mapping)
            or not np.array_equal(features['null_donor_sample_index'], donors)
            or not np.array_equal(features['quality_columns'], columns)
            or not np.array_equal(features['quality'], matrix[mapping])
            or not np.array_equal(features['null_rgb32'], features['rgb32'][donors])):
        raise ValueError('saved visual features disagree with quality/capture/donor identity')
    x, null = assemble_design(data, variants['timing4'], features['quality'], features['rgb32'], donors)
    relevant = [*paths.values(), probe / 'completed.json', probe / 'protocol.json',
                probe / 'artifact_hashes.json', probe / 'pca_rgb.npz', probe / 'prepared_features.npz']
    return x, null, mapping, donors, metadata, donor_info, relevant, {
        'quality_columns': columns.tolist(),
        'unique_capture_counts': {name: len(ids) for name, ids in captures.items()},
        'pca_replay_max_absolute_difference': float(np.max(np.abs(features['rgb32'] - computed[mapping]))),
        'pca_fitting_scope': 'fixed previous PCA on unique outer-training captures only; no new PCA fit',
    }


def prepare_data(config, outdir):
    """Write prepared.npz plus OOF weights and a source-bound preparation record.

    Parameters use project-relative paths. ``project_root`` defaults to the
    canonical Python project. Saving test labels here is archival only; the
    training stage must explicitly load training/validation keys, never test.
    """
    project = Path(config.get('project_root', Path(__file__).resolve().parents[1])).resolve()
    source = (project / config.get('source_run', 'experiment_runs/corrected_vision')).resolve()
    visual = (project / config.get('visual_study', 'experiment_runs/visual_representation_20261104')).resolve()
    descriptors = (project / config.get('descriptor_study', 'experiment_runs/visual_information_20261104')).resolve()
    selector_file = config.get('current_predictor', 'current_predictor.json')
    out = Path(outdir).resolve()
    if (out / 'prepared.npz').exists() or (out / 'oof').exists():
        raise FileExistsError('prepared study is immutable; use a new output directory')
    out.mkdir(parents=True, exist_ok=True)
    selected, checkpoint, ridge_study, ridge = resolve_predictor(project, selector_file)
    if ridge.weights['alpha'] != 100.0:
        raise ValueError('this residual study fixes the selected Ridge alpha at 100')
    data, stats, _ = load_data(source / 'data')
    _check_data(data, stats)
    if not np.array_equal(ridge.weights['delta_scale'], np.asarray(stats['delta_scale'])):
        raise ValueError('current Ridge target scales differ from source training statistics')
    input_paths = [source / 'data' / name for name in ('dataset.npz', 'stats.json', 'manifest.json')]
    threads = int(config.get('training', {}).get('threads', config.get('threads', 2)))
    if threads < 1:
        raise ValueError('preparation threads must be positive')
    with threadpool_limits(limits=threads):
        x, null, mapping, donors, feature_metadata, donor_info, paths, visual_info = _visual_inputs(
            data, visual, descriptors, input_paths)
        all_paths = [*input_paths, *paths, project / selector_file, checkpoint,
                     ridge_study / 'selection.json', ridge_study / 'selection_frozen.json']
        hashes = {str(path.resolve()): sha256(path) for path in all_paths}
        # Conservative combined ranges include the original six-capture source
        # envelope and the timing4 inputs, even though RGB itself is one image.
        source_start = np.minimum(data['source_start_ns'], feature_metadata['variant_source_start_ns_timing4'])
        source_end = np.maximum(data['source_end_ns'], feature_metadata['variant_source_end_ns_timing4'])
        ranged = dict(data, source_start_ns=source_start, source_end_ns=source_end)
        train_idx, oof, fold_id, folds = fit_oof_predictions(
            ranged, out / 'oof', fractions=config.get('oof_fractions', OOF_FRACTIONS), alpha=100.0)
        indices = {'train': train_idx, 'val': data['val_idx'], 'test': data['test_idx']}
        arrays = {'delta_scale': ridge.weights['delta_scale'], 'train_fold_id': fold_id}
        for name, rows in indices.items():
            base = oof if name == 'train' else ridge.predict_next(data['u_hist'][rows], data['z_hist'][rows])
            arrays.update({name + '_indices': rows, name + '_x': x[rows], name + '_null_x': null[rows],
                           name + '_base': base, name + '_truth': np.asarray(data['z_target'])[rows],
                           name + '_time_ns': np.asarray(data['time_ns'])[rows],
                           name + '_capture_index': mapping[rows],
                           name + '_null_donor_sample_index': donors[rows],
                           name + '_null_capture_index': mapping[donors[rows]],
                           name + '_source_start_ns': source_start[rows],
                           name + '_source_end_ns': source_end[rows]})
        np.savez_compressed(out / 'prepared.npz', **arrays)
        np.savez_compressed(out / 'source_records.npz', time_ns=data['time_ns'],
                            source_start_ns=source_start, source_end_ns=source_end,
                            original_train_indices=data['train_idx'], original_val_indices=data['val_idx'],
                            original_test_indices=data['test_idx'])
    for path, expected in hashes.items():
        _verify_hash(path, expected)
    write_json(out / 'input_hashes.json', hashes)
    record = {'status': 'complete', 'schema_version': 1, 'model': selected,
              'prepared_sha256': sha256(out / 'prepared.npz'),
              'source_records_sha256': sha256(out / 'source_records.npz'),
              'design_columns': DESIGN_SLICES, 'design_width': 226,
              'partition_counts': {name: len(rows) for name, rows in indices.items()},
              'original_partition_counts': {name: len(data[name + '_idx']) for name in PARTITIONS},
              'oof_fractions': list(OOF_FRACTIONS), 'oof_folds': folds,
              'oof_scope': 'forward-time training-only predictions, alpha fixed; no source overlap within each fold',
              'training_base': 'three earlier-data Ridge fits; not the full-training model in-sample predictions',
              'evaluation_base': 'same frozen full-training Ridge for every validation/test corrector',
              'distribution_note': 'OOF base fits use less history than the final full-training evaluation base',
              'target_scale': 'fixed full-training Ridge delta_scale for corrector training and evaluation',
              'fold_target_scale': 'computed separately on each fold fit rows, used only to fit that Ridge',
              'negative_control': {'scope': 'only RGB coordinates mismatched; may use later donors in same outer partition; not causal input',
                                   'partitions': donor_info},
              'visual': visual_info, 'input_hashes': hashes,
              'test_scope': 'previously inspected period; preparation stores test labels but performs no test scoring'}
    write_json(out / 'preparation.json', record)
    return record
