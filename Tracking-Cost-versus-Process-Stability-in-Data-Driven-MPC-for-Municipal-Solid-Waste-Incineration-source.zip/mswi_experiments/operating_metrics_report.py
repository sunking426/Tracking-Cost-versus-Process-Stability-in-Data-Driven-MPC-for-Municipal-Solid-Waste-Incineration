"""Read saved validation arrays; no model or controller inference is imported."""
from __future__ import annotations
import argparse,csv,datetime,json,hashlib,shutil,platform,sys
from pathlib import Path
import numpy as np
from .frozen_mpc import ROOT,load_frozen_mpc,file_sha256
from .operating_metrics import METRICS,UNITS,operating_endpoints
from .data import MINUTE_NS
from .visual_diagnostics_statistics import paired_block_interval,DAY_NS

DESIGN=ROOT/'experiment_protocols/operating_metrics_20261107'
OUT=ROOT/'experiment_runs/operating_metrics_20261107'
PROTOCOL_SHA='aa34a5aab84b4397d31ab2ade0f922b62bc18a1ed648f7b0a06c77b1db8707a4'

def save(path,value):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

def write_csv(path,rows,fields=None):
    names=fields if fields is not None else list(rows[0])
    with Path(path).open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=names);writer.writeheader();writer.writerows(rows)

def config():
    if file_sha256(DESIGN/'protocol.json')!=PROTOCOL_SHA:raise ValueError('metric definitions changed')
    p=json.loads((DESIGN/'protocol.json').read_text())
    load_frozen_mpc(ROOT/p['parent_config']['path'],p['parent_config']['sha256'])
    for name,digest in p['dependencies'].items():
        if file_sha256(ROOT/name)!=digest:raise ValueError('metric source changed: '+name)
    for row in p['trajectory_manifest']:
        if file_sha256(ROOT/row['path'])!=row['sha256']:raise ValueError('saved trajectory changed')
    return p

def seal():
    p=config()
    files=[ROOT/'mswi_experiments'/n for n in ('frozen_mpc.py','operating_metrics.py','operating_metrics_report.py')]
    files+=[ROOT/'tests/test_operating_metrics.py',DESIGN/'protocol.json',DESIGN/'DEFINITIONS_zh.txt',DESIGN/'GRU_NEXT_STEP.json',DESIGN/'GRU_NEXT_STEP_zh.txt']
    hashes={str(f.relative_to(ROOT)):file_sha256(f) for f in files};path=OUT/'implementation_frozen.json'
    if path.exists():
        if json.loads(path.read_text())['hashes']!=hashes:raise ValueError('metric implementation changed after sealing')
    else:
        save(path,dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),hashes=hashes))
        for f in files:
            dest=OUT/'code_snapshot'/f.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dest)
    for f in (DESIGN/'protocol.json',DESIGN/'DEFINITIONS_zh.txt'):
        if not (OUT/f.name).exists():shutil.copy2(f,OUT/f.name)
    save(OUT/'runtime.json',dict(python=sys.version,platform=platform.platform(),numpy=np.__version__,new_model_inferences=0,new_controller_decisions=0))
    return p


def scalar_audit(pred,hist,initial,horizon,vector):
    """Independent explicit per-step arithmetic; no rolling helper reuse."""
    n=len(pred);out=np.zeros((n,6));max_rolling_difference=0.
    for i in range(n):
        initial_t=float(np.sum(initial[i,:6],dtype=float)/6.)
        temps=[float(np.sum(hist[i,j,:6],dtype=float)/6.) for j in (7,8,9)]+[initial_t]
        last=[initial_t,float(initial[i,7]),float(initial[i,8])];changes=[0.,0.,0.];oxygen_inside=0;rolls=[]
        for k in range(horizon):
            cur=[float(np.sum(pred[i,k,:6],dtype=float)/6.),float(pred[i,k,7]),float(pred[i,k,8])]
            temps.append(cur[0]);rolls.append(sum(temps[-5:])/5)
            oxygen_inside+=3.5<=cur[2]<=4.
            for j in range(3):changes[j]+=abs(cur[j]-last[j])
            last=cur
        out[i]=[min(rolls),sum(v<850 for v in rolls)/horizon,oxygen_inside/horizon,*[v/horizon for v in changes]]
    error=float(np.max(np.abs(out-vector)))
    np.testing.assert_allclose(out,vector,atol=1e-10,rtol=0)
    return error


def calculate():
    p=seal();report=OUT/'report';report.mkdir(exist_ok=True)
    with np.load(ROOT/'experiment_runs/ridge_control_probe_20261106/inputs/val.npz',allow_pickle=False) as src:
        inputs={k:src[k] for k in ('indices','time_ns','z_hist','z_current')}
    if len(inputs['indices'])!=256 or len(np.unique(inputs['indices']))!=256:raise AssertionError('256 unique starts')
    days=inputs['time_ns']//DAY_NS
    values={};per_seed=[];flags=[];low_summary=[];audits=[];ep_rows=[];processed_steps=0
    flag_fields=['model','method','seed','horizon','start_index','start_time_utc','step','step_time_utc','step_time_Asia_Shanghai','flag_type','temperature','raw_six_mean','rolling5_mean']
    for entry in p['trajectory_manifest']:
        path=ROOT/entry['path']
        with np.load(path,allow_pickle=False) as raw:
            row={k:raw[k] for k in ('pred_cv','indices','time_ns','initial_z_current','physical_executed_action','requested_action')}
        for k in ('indices','time_ns'):np.testing.assert_array_equal(row[k],inputs[k])
        np.testing.assert_array_equal(row['initial_z_current'],inputs['z_current'])
        if row['pred_cv'].shape!=(256,50,9) or not np.isfinite(row['pred_cv']).all():raise AssertionError('saved trajectory shape or value')
        if np.any(row['physical_executed_action'][:,:,[1,2,4,5,6,7]]!=0) or np.any(row['requested_action'][:,:,[1,2,4,5,6,7]]!=0):raise AssertionError('not a two-channel trajectory')
        method=entry['method'];model=entry['model'];seed=entry['seed'];case_errors=[]
        for h in p['horizons']:
            endpoint,rolling,cv=operating_endpoints(row['pred_cv'],inputs['z_hist'],inputs['z_current'],h)
            err=scalar_audit(row['pred_cv'],inputs['z_hist'],inputs['z_current'],h,endpoint);case_errors.append(dict(horizon=h,max_abs_difference=err))
            values[model,method,seed,h]=endpoint
            per_seed.append(dict(model=model,method=method,seed=seed,horizon=h,**dict(zip(METRICS,endpoint.mean(0).tolist()))))
            for i in range(256):ep_rows.append(dict(model=model,method=method,seed=seed,horizon=h,start_index=int(inputs['indices'][i]),**dict(zip(METRICS,endpoint[i].tolist()))))
            for kind,temps in [('trailing5',rolling),('raw_six_mean',cv[:,:,0])]:
                mask=temps<850.
                low_summary.append(dict(model=model,method=method,seed=seed,horizon=h,temperature_type=kind,global_minimum=float(temps.min()),low_steps=int(mask.sum()),episodes_with_low=int(mask.any(1).sum())))
                for i,k in np.argwhere(mask):
                    ns=int(inputs['time_ns'][i]+(int(k)+1)*MINUTE_NS)
                    utc=datetime.datetime.fromtimestamp(ns/1e9,datetime.timezone.utc)
                    start=datetime.datetime.fromtimestamp(int(inputs['time_ns'][i])/1e9,datetime.timezone.utc)
                    flags.append(dict(model=model,method=method,seed=seed,horizon=h,start_index=int(inputs['indices'][i]),start_time_utc=start.isoformat(),step=int(k)+1,
                        step_time_utc=utc.isoformat(),step_time_Asia_Shanghai=utc.astimezone(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),flag_type=kind,
                        temperature=float(temps[i,k]),raw_six_mean=float(cv[i,k,0]),rolling5_mean=float(rolling[i,k])))
        audits.append(dict(path=entry['path'],sha256=entry['sha256'],metrics_audit=case_errors,identity_equal=True,initial_equal=True,two_channels=True))
        processed_steps+=256*50
    means=[];contrasts=[];details={};arrays={}
    for model in p['models']:
        for h in p['horizons']:
            for method,seeds in p['methods'].items():
                v=np.stack([values[model,method,s,h] for s in seeds]);arrays[model,method,h]=v
                means.append(dict(model=model,method=method,horizon=h,instances=len(seeds),starts_per_instance=256,**dict(zip(METRICS,v.mean((0,1)).tolist()))))
            for reference in ('hold','BC'):
                delta=arrays[model,'C',h]-arrays[model,reference,h]
                ci=paired_block_interval(delta,days,draws=p['contrasts']['draws'],seed=p['contrasts']['seed'],confidence_level=.95)
                ci.update(estimand='raw C minus reference endpoint, equal seed/start means; positive fluctuation means C fluctuates more',
                    deterministic_C_instances=1,reference_instances=delta.shape[0],sign='C minus reference; not universally positive-is-better')
                if reference=='BC':ci['warnings'].append('C broadcast solely for pairing, not five independent C fits')
                label=f'{model}/{h}/C_vs_{reference}';details[label]=ci
                for j,metric in enumerate(METRICS):
                    contrasts.append(dict(model=model,horizon=h,reference=reference,metric=metric,unit=UNITS[j],difference=ci['difference'][j],
                        ci_lower=ci['ci_lower'][j],ci_upper=ci['ci_upper'][j],reference_instances=delta.shape[0],time_blocks=ci['time_blocks'],samples=256))
    write_csv(report/'endpoint_means.csv',means);write_csv(report/'endpoint_by_seed.csv',per_seed)
    write_csv(report/'endpoint_by_episode.csv',ep_rows);write_csv(report/'contrasts.csv',contrasts)
    write_csv(report/'low_temperature_summary.csv',low_summary);write_csv(report/'low_temperature_steps.csv',flags,flag_fields)
    save(report/'contrasts.json',details)
    np.savez_compressed(report/'episode_endpoints.npz',**{'__'.join(map(str,k)):v for k,v in arrays.items()})
    save(OUT/'audit.json',dict(status='passed',cases=audits,source_files=28,source_episodes=28*256,unique_saved_steps=processed_steps,
        endpoint_episode_horizon_rows=len(ep_rows),all_metrics_scalar_recomputed=True,max_abs_error=max(c['max_abs_difference'] for a in audits for c in a['metrics_audit']),
        fresh_model_inferences=0,fresh_control_decisions=0,new_test_evaluations=0,source_hashes_verified=True,trajectories_dropped=0,
        rolling_prefix='observed t-3..t0',C_parent_sha256=p['parent_config']['sha256'],new_metrics_protocol_sha256=PROTOCOL_SHA))
    render(report,p,details);write_readout(report,p,means,details,low_summary,flags)
    config()
    print(json.dumps(dict(status='complete',means=len(means),contrasts=len(contrasts),flag_rows=len(flags),source_files=28),ensure_ascii=False))


def render(out,p,details):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':180})
    fig,axs=plt.subplots(2,3,figsize=(14,8));x=np.arange(4)
    labels=['Temperature (deg C/step)','Steam (t/h per step)','Oxygen (percentage points/step)']
    for row,h in enumerate(p['horizons']):
        for col,j in enumerate((3,4,5)):
            ax=axs[row,col]
            for ref,color,offset in [('hold','#1f77b4',-.10),('BC','#ff7f0e',.10)]:
                items=[details[f'{m}/{h}/C_vs_{ref}'] for m in p['models']]
                mean=np.array([r['difference'][j] for r in items]);lo=np.array([r['ci_lower'][j] for r in items]);hi=np.array([r['ci_upper'][j] for r in items])
                # Draw interval segments directly: bootstrap CI need not contain the point estimate.
                ax.vlines(x+offset,lo,hi,color=color,lw=1.6)
                ax.scatter(x+offset,mean,s=27,color=color,label='C - '+ref)
            ax.axhline(0,color='black',lw=.8);ax.set_xticks(x,p['models'],rotation=15);ax.set_title(f'{h} steps: '+labels[col]);ax.set_ylabel('Difference in mean absolute step change')
    axs[0,0].legend();fig.suptitle('Positive values: C fluctuates more; exploratory paired 95% bootstrap intervals',fontsize=11)
    fig.tight_layout();fig.savefig(out/'fluctuation_contrasts.png');plt.close(fig)


def write_readout(out,p,means,details,lows,flags):
    lines=[]
    def add(s=''):lines.append(s)
    add('冻结C后的运行指标补充：只读已保存轨迹')
    add('两通道C现已正式冻结。父配置SHA256：'+p['parent_config']['sha256'])
    add('指标协议SHA256：'+PROTOCOL_SHA)
    add('数据：4个非规划Ridge评价器，每个256个固定验证起点；C与保持操作各一个固定实例，两通道学习BC为11/23/37/53/71五个种子。三种方法均有50步保存轨迹，10步主报告、50步压力测试。BC含此前策略的视觉上下文，未改用线性BC或挑选种子。')
    add('本轮没有重新调用预测器、策略或CEM，没有新控制实验、模型训练、GRU运行、测试集评价或论文改写。全部28份旧轨迹文件哈希、起点与初值核验通过。')
    add()
    add('一、定义和读表方式')
    add('温度为六路均值。温度最低值及低温比例先做向后5点完整滚动平均：首窗口观测t−3,t−2,t−1,t0加预测t1，只对t1..tH计分。每条轨迹先取最低值，再对256起点和种子平均；它不等于全部轨迹的总体最小值。')
    add('氧区间[3.5,4.0]%包含端点，直接统计原始逐步值。三类波动均按原始物理量相邻一步绝对差的均值，首步差从观测初始值算起。温度波动不进行滚动平滑。')
    add('差值统一为C−对照；波动正差表示C更大。比例表以%显示，比例差若查看CSV仍是0–1尺度。没有新增通过门槛。850只作指定报告标记，不是本研究获得的现场或法规合规证明。')
    for h in p['horizons']:
        add();add(f'二、{h}步各模型均值'+('（主要）' if h==10 else '（压力测试）'))
        add('模型/方法 | 逐轨迹最低5分钟温度均值℃ | 5分钟低于850比例% | 氧区间内比例% | 温度波动℃/步 | 蒸汽波动(t/h)/步 | 氧波动百分点/步')
        for m in p['models']:
            for method in ('C','hold','BC'):
                r=next(r for r in means if r['model']==m and r['method']==method and r['horizon']==h)
                a=[r[k] for k in METRICS];a[1]*=100;a[2]*=100
                add(m+'/'+method+' | '+' | '.join(f'{v:.6f}' for v in a))
        add();add(f'{h}步波动差与探索性95%区间：C减对照')
        add('模型/对照 | 温度波动差[区间] | 蒸汽波动差[区间] | 氧波动差[区间]')
        for m in p['models']:
            for ref in ('hold','BC'):
                r=details[f'{m}/{h}/C_vs_{ref}']
                add(m+'/'+ref+' | '+' | '.join(f"{r['difference'][j]:+.7f} [{r['ci_lower'][j]:+.7f}, {r['ci_upper'][j]:+.7f}]" for j in (3,4,5)))
    add();add('三、低于850℃的记录')
    for h in p['horizons']:
        for kind in ('trailing5','raw_six_mean'):
            r=[x for x in lows if x['horizon']==h and x['temperature_type']==kind]
            add(f"{h}步/{kind}: 低温控制步{sum(x['low_steps'] for x in r)}，含低温的模型/方法/种子轨迹数{sum(x['episodes_with_low'] for x in r)}；全体最小值{min(x['global_minimum'] for x in r):.6f}℃。")
    if flags:add('逐步明细见low_temperature_steps.csv。10步事件也包含在50步报告里，不能把两时域相加当作独立事件数。BC各种子是不同策略模拟轨迹，不是不同现场事件。')
    else:add('所有方法、模型、种子、两个时域均未出现上述两种口径的低于850℃步骤。这仅说明这些保存的模型轨迹未触发指定标记，不能证明实际炉况无低温风险。')
    add();add('四、波动结果概览（描述性，不作新门槛）')
    for h in p['horizons']:
        for ref in ('hold','BC'):
            for j,cn in [(3,'温度'),(4,'蒸汽'),(5,'氧含量')]:
                rs=[details[f'{m}/{h}/C_vs_{ref}'] for m in p['models']]
                add(f"{h}步 C相对{ref}/{cn}：均值差为正的模型数{sum(r['difference'][j]>0 for r in rs)}/4，区间全正{sum(r['ci_lower'][j]>0 for r in rs)}/4，区间全负{sum(r['ci_upper'][j]<0 for r in rs)}/4。")
    add('波动变大意味着每分钟状态变化更明显；它可能来自主动调整，也可能反映不平稳，不能仅凭变化量判断是否发生来回振荡。这里没有以新指标重新选择C，也不把原综合回报改善等同于所有物理量更平稳。')
    add();add('五、统计边界与文件')
    add('沿用整日期块和训练种子交叉配对bootstrap10000次、种子20261106、95%区间，未校正多重比较。C对保持仅1个固定实例；C对BC仅为配对而广播，C并没有5个独立训练结果。只有7个日期块，且起点重用、模型间有关联，不能当作独立现场干预证据。')
    add('本轮新增指标是看过原实验结果之后预定义的描述性分析，不追溯声称为最初研究的预注册指标。定义和代码均在本轮指标计算前封存。')
    add('输出：endpoint_means.csv（24行均值）、endpoint_by_seed.csv、endpoint_by_episode.csv、contrasts.csv/json（全部六指标差值及区间）、episode_endpoints.npz、low_temperature_summary.csv、low_temperature_steps.csv、fluctuation_contrasts.png。')
    add('后续GRU说明单独保存在指标预设目录GRU_NEXT_STEP_zh.txt；本轮已停止，未执行。')
    (out/'REPORT_zh.txt').write_text('\n'.join(lines)+'\n')

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['seal','calculate']);args=parser.parse_args()
    if args.stage=='seal':seal()
    else:calculate()
