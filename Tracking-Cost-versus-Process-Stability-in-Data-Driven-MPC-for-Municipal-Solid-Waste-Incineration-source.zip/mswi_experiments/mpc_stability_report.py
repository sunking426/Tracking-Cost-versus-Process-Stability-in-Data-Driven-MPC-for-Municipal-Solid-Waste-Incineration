"""Audit and report all sealed lambda outcomes without replacing frozen C."""
from __future__ import annotations
import json
import numpy as np
import torch
from threadpoolctl import threadpool_limits
from .mpc_stability_study import OUT,REF,OLD,PRIOR,ROOT,MODELS,WEIGHTS,SEEDS,SAMPLE_KEYS,shared,protocol,freeze,verify_sources
from .mpc_stability import choose_stability
from .ridge_policy_study import read_npz,write_json
from .frozen_mpc import file_sha256
from .ridge_policy import RidgePolicyEnv
from .ridge_dynamics import RidgeDynamics
from .ridge_policy_report import endpoints,csv_write
from .ridge_control_probe_report import METRICS as ORIGINAL_METRICS
from .operating_metrics import operating_endpoints,METRICS as OPERATING_METRICS
from .visual_diagnostics_statistics import paired_block_interval,DAY_NS
from .data import MINUTE_NS
from .control import reward_and_violation
NAMES=tuple(ORIGINAL_METRICS)+OPERATING_METRICS
LABELS=('C0','S1','S2','S4','S8');LAMBDAS=(0,1,2,4,8)


def audit_case(row,weight,mid,e,full,inputs):
    if row['pred_cv'].shape!=(256,50,9):raise AssertionError('dimensions')
    for k in ('indices','time_ns'):np.testing.assert_array_equal(row[k],inputs[k])
    np.testing.assert_array_equal(row['initial_z_current'],inputs['z_current'])
    reward,v,c=reward_and_violation(row['pred_cv'],row['executed_action'],e.stats)
    for k,a in dict(reward=reward,violation=v,**c).items():np.testing.assert_array_equal(row[k],a)
    if np.any(row['physical_executed_action'][:,:,[1,2,4,5,6,7]]!=0):raise AssertionError('inactive action')
    if np.any(np.abs(row['physical_executed_action'])>.1*e.bound+1e-10):raise AssertionError('action budget')
    if np.any(row['u_path']<np.asarray(e.stats['u_low'])) or np.any(row['u_path']>np.asarray(e.stats['u_high'])):raise AssertionError('MV bounds')
    if np.any(np.any(row['executed_action']!=0,axis=-1)&~row['action_supported']):raise AssertionError('unsupported nonzero action')
    np.testing.assert_array_equal(row['selected_planning_score'],row['selected_original_return']-3*row['selected_temperature_cost']-weight*row['selected_stability_cost'])
    np.testing.assert_array_equal(row['selected_stability_cost'],row['selected_steam_variation_cost']+row['selected_oxygen_variation_cost'])
    env=RidgePolicyEnv(RidgeDynamics.load(REF/f'evaluation_models/{mid}.npz'),e,horizon=50);env.reset(options={'inputs':inputs})
    for step in range(50):
        _,_,_,_,info=env.step_request(row['requested_action'][:,step])
        for k,a in info.items():np.testing.assert_array_equal(a,row[k][:,step])
    ids=np.array([0,127,255]);small={k:inputs[k][ids] for k in SAMPLE_KEYS};rescores=[]
    for step in (0,9,24,49):
        if step==0:hist=small
        else:
            hist=dict(u_hist=np.concatenate((small['u_hist'],row['u_path'][ids,:step]),1)[:,-11:],
                z_hist=np.concatenate((small['z_hist'],small['z_current'][:,None],row['pred_cv'][ids,:step-1]),1)[:,-10:],
                z_current=row['pred_cv'][ids,step-1],time_ns=small['time_ns']+step*MINUTE_NS,indices=small['indices'])
        pe=RidgePolicyEnv(full,e,horizon=10);pe.reset(options={'inputs':hist})
        r=np.zeros(3);jt=np.zeros(3);jf=np.zeros(3);jo=np.zeros(3);prev=hist['z_current'].copy()
        for j in range(10):
            _,reward,_,_,info=pe.step(row['best_requested_plan_b'][ids,step,j]);r+=reward.astype(float);jt+=info['tracking_cost'][:,0].astype(float)
            nxt=info['pred_cv'];jf+=abs(nxt[:,7]-prev[:,7])/5;jo+=abs(nxt[:,8]-prev[:,8])/.5;prev=nxt
        expected=dict(selected_original_return=r,selected_temperature_cost=jt,selected_steam_variation_cost=jf,
            selected_oxygen_variation_cost=jo,selected_stability_cost=jf+jo,selected_planning_score=r-3*jt-weight*(jf+jo))
        errors={k:float(np.max(np.abs(value-row[k][ids,step]))) for k,value in expected.items()}
        for k,value in expected.items():np.testing.assert_allclose(value,row[k][ids,step],atol=1e-5,rtol=0)
        rescores.append(dict(step=step,errors=errors))
    return dict(model=mid,lambda_value=weight,full_feedback_bitwise_equal=True,plan_rescores=rescores)


def summarize():
    freeze();verify_sources();p=protocol();parent,e,full=shared();inputs=read_npz(REF/'inputs/val.npz');days=inputs['time_ns']//DAY_NS
    out=OUT/'report';out.mkdir(exist_ok=True)
    values={};means=[];byseed=[];actions=[];lowrows=[];flagrows=[];audits=[];fingerprint=None;manifest=[]
    for mid in MODELS:
        entries=[('hold',0,PRIOR/f'trajectories/val/{mid}/hold/seed0.npz'),('C0',0,OLD/f'trajectories/C/{mid}.npz')]
        entries += [('BC',s,PRIOR/f'trajectories/val/{mid}/bc/seed{s}.npz') for s in SEEDS]
        entries += [('S'+str(w),0,OUT/f'trajectories/S{w}/{mid}.npz') for w in WEIGHTS]
        old=read_npz(OLD/f'trajectories/C/{mid}.npz')
        for label,seed,path in entries:
            row=read_npz(path)
            for k in ('indices','time_ns'):np.testing.assert_array_equal(row[k],inputs[k])
            meta=json.loads(path.with_suffix('.json').read_text())
            if file_sha256(path)!=meta['sha256']:raise AssertionError('saved file hash')
            if label.startswith('S'):
                w=int(label[1:]);audits.append(audit_case(row,w,mid,e,full,inputs))
                np.testing.assert_array_equal(row['noise_sha256'],old['noise_sha256'])
                if fingerprint is None:fingerprint=row['noise_sha256'].copy()
                np.testing.assert_array_equal(row['noise_sha256'],fingerprint)
                manifest.append(dict(path=str(path.relative_to(OUT)),sha256=file_sha256(path)))
                print('audited',label,mid,flush=True)
            for h in (10,50):
                op,rolling,cv=operating_endpoints(row['pred_cv'],inputs['z_hist'],inputs['z_current'],h)
                value=np.concatenate((endpoints(row,h),op),axis=1);values[mid,label,seed,h]=value
                byseed.append(dict(model=mid,method=label,seed=seed,horizon=h,**dict(zip(NAMES,value.mean(0).tolist()))))
                for kind,temp in [('trailing5',rolling),('raw_six_mean',cv[:,:,0])]:
                    mask=temp<850
                    lowrows.append(dict(model=mid,method=label,seed=seed,horizon=h,kind=kind,global_minimum=float(temp.min()),low_steps=int(mask.sum()),low_episodes=int(mask.any(1).sum())))
                    for i,k in np.argwhere(mask):flagrows.append(dict(model=mid,method=label,seed=seed,horizon=h,kind=kind,start_index=int(inputs['indices'][i]),step=int(k)+1,time_ns=int(inputs['time_ns'][i]+(int(k)+1)*MINUTE_NS),temperature=float(temp[i,k])))
                d=row['physical_executed_action'][:,:h]
                actions.append(dict(model=mid,method=label,seed=seed,horizon=h,nonzero_fraction=float(np.any(d!=0,axis=-1).mean()),
                    blocked_nonzero_fraction=float(row['blocked_nonzero'][:,:h].mean()),unsupported_hold_fraction=float(row['zero_action_unsupported'][:,:h].mean()),
                    movement_cost=float(row['movement_cost'][:,:h].mean()),primary_mean_abs_increment=float(abs(d[:,:,0]).mean()),induced_mean_abs_increment=float(abs(d[:,:,3]).mean())))
    arrays={}
    for m in MODELS:
        for h in (10,50):
            for label in ('hold','BC')+LABELS:
                seeds=SEEDS if label=='BC' else (0,);v=np.stack([values[m,label,s,h] for s in seeds]);arrays[m,label,h]=v
                means.append(dict(model=m,method=label,horizon=h,instances=len(seeds),starts=256,**dict(zip(NAMES,v.mean((0,1)).tolist()))))
    reference=np.stack([arrays[m,'hold',10].mean((0,1))[:6] for m in MODELS])
    bc=np.stack([arrays[m,'BC',10].mean((0,1))[10:12] for m in MODELS])
    candidates={w:(np.stack([arrays[m,l,10].mean((0,1))[:6] for m in MODELS]),np.stack([arrays[m,l,10].mean((0,1))[10:12] for m in MODELS])) for l,w in zip(LABELS,LAMBDAS)}
    choice=choose_stability(reference,bc,candidates)
    comparisons=[];details={};guardrows=[]
    for m in MODELS:
        for h in (10,50):
            for label in LABELS:
                for ref in ('hold','BC','C0'):
                    if label==ref:continue
                    delta=arrays[m,label,h]-arrays[m,ref,h]
                    ci=paired_block_interval(delta,days,draws=10000,seed=20261106)
                    ci.update(estimand='raw candidate minus reference per-episode endpoints; only return/min-temperature/band-time have larger-is-higher meanings; losses and fluctuations positive mean increase',fixed_CEM_instances=1)
                    if ref=='BC':ci['warnings'].append('fixed CEM trajectory broadcast for pairing, not five independent CEM policies')
                    key=f'{m}/{h}/{label}_vs_{ref}';details[key]=ci
                    for j,name in enumerate(NAMES):comparisons.append(dict(model=m,horizon=h,method=label,reference=ref,metric=name,difference=ci['difference'][j],ci_lower=ci['ci_lower'][j],ci_upper=ci['ci_upper'][j]))
                hold=arrays[m,'hold',h].mean((0,1));v=arrays[m,label,h].mean((0,1));b=arrays[m,'BC',h].mean((0,1))
                for j in range(1,6):guardrows.append(dict(model=m,horizon=h,method=label,metric=NAMES[j],reference='hold',reference_mean=float(hold[j]),candidate_mean=float(v[j]),limit=float(1.01*hold[j]),pass_mean=bool(v[j]<=1.01*hold[j])))
                for j in (10,11):guardrows.append(dict(model=m,horizon=h,method=label,metric=NAMES[j],reference='BC',reference_mean=float(b[j]),candidate_mean=float(v[j]),limit=float(b[j]),pass_mean=bool(v[j]<=b[j])))
    monotonic=[]
    for m in MODELS:
        for h in (10,50):
            for j in (10,11):
                v=np.array([arrays[m,l,h].mean((0,1))[j] for l in LABELS]);d=np.diff(v)
                monotonic.append(dict(model=m,horizon=h,metric=NAMES[j],values=v.tolist(),monotone_nonincreasing=bool(np.all(d<=0)),increasing_transitions=[f'{LAMBDAS[i]}->{LAMBDAS[i+1]}' for i in np.flatnonzero(d>0)],first_tested_lambda_at_or_below_BC=next((w for l,w in zip(LABELS,LAMBDAS) if arrays[m,l,h].mean((0,1))[j]<=arrays[m,'BC',h].mean((0,1))[j]),None)))
    csv_write(out/'endpoint_means.csv',means);csv_write(out/'endpoint_by_seed.csv',byseed);csv_write(out/'contrasts.csv',comparisons)
    csv_write(out/'guardrails.csv',guardrows);csv_write(out/'actions_and_support.csv',actions);csv_write(out/'low_temperature_summary.csv',lowrows)
    # Keep an explicit empty header when no850 event occurs.
    import csv
    with (out/'low_temperature_steps.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=['model','method','seed','horizon','kind','start_index','step','time_ns','temperature']);writer.writeheader();writer.writerows(flagrows)
    write_json(out/'contrasts.json',details);write_json(out/'recommendation.json',choice);write_json(out/'monotonicity.json',monotonic)
    np.savez_compressed(out/'episode_endpoints.npz',**{'__'.join(map(str,k)):v for k,v in arrays.items()})
    write_json(OUT/'audit.json',dict(status='passed',cases=audits,recomputed_original_rewards=204800,reexecuted_feedback_steps=204800,
        selected_plan_rescores=192,all16_noise_arrays_equal_to_old_C0=True,new_test_evaluations=0,trajectories_dropped=0,predictions_clipped=False,main_configuration_refrozen=False))
    write_json(OUT/'trajectory_manifest.json',dict(files=manifest,cases=16,episodes=4096,control_steps=204800,validation_only=True))
    render(out,arrays);readout(out,arrays,choice,details,monotonic,lowrows)
    verify_sources()


def render(out,arrays):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':180})
    colors=['#1f77b4','#ff7f0e','#2ca02c','#d62728','#9467bd']
    for j,title,name in [(10,'Steam mean absolute step change (t/h per step)','steam'),(11,'Oxygen mean absolute step change (percentage points/step)','oxygen')]:
        fig,axs=plt.subplots(2,2,figsize=(11,8))
        for ax,m in zip(axs.ravel(),MODELS):
            hold=arrays[m,'hold',10].mean((0,1));bc=arrays[m,'BC',10].mean((0,1));pts=[]
            for l,w,col in zip(LABELS,LAMBDAS,colors):
                v=arrays[m,l,10].mean((0,1));pt=(v[j],v[0]-hold[0]);pts.append(pt);ax.scatter(*pt,color=col,s=48);ax.annotate(str(w),pt,xytext=(4,4),textcoords='offset points')
            ax.plot(*np.array(pts).T,color='gray',ls=':',lw=.8);ax.axvline(bc[j],color='black',ls='--',label='BC fluctuation');ax.axhline(0,color='black',lw=.7)
            ax.set_title(m);ax.set_xlabel(title);ax.set_ylabel('Original10-step return gain vs hold')
        axs[0,0].legend(fontsize=8);fig.suptitle('Labels are stability weights; dashed line is the BC mean, not a plant limit',fontsize=10)
        fig.tight_layout();fig.savefig(out/f'cost_{name}_tradeoff.png');plt.close(fig)
    fig,axs=plt.subplots(2,2,figsize=(11,8));x=np.array(LAMBDAS)
    for m,col in zip(MODELS,colors):
        bc=arrays[m,'BC',10].mean((0,1));hold=arrays[m,'hold',10].mean((0,1));v=np.array([arrays[m,l,10].mean((0,1)) for l in LABELS]);stress=np.array([arrays[m,l,50].mean((0,1)) for l in LABELS])
        axs[0,0].plot(x,100*v[:,10]/bc[10],'o-',color=col,label=m)
        axs[0,1].plot(x,100*v[:,11]/bc[11],'o-',color=col)
        axs[1,0].plot(x,v[:,0]-hold[0],'o-',color=col)
        axs[1,1].plot(x,100*stress[:,8],'o-',color=col)
    axs[0,0].set_ylabel('10-step steam fluctuation (% of BC)');axs[0,1].set_ylabel('10-step oxygen fluctuation (% of BC)')
    axs[1,0].set_ylabel('Original10-step return gain vs hold');axs[1,1].set_ylabel('50-step oxygen time in band (%)')
    for ax in axs[0]:ax.axhline(100,color='black',ls='--',lw=.8)
    for ax in axs.ravel():ax.set_xlabel('Stability weight');ax.set_xticks(x)
    axs[0,0].legend(fontsize=8);fig.tight_layout();fig.savefig(out/'lambda_response.png');plt.close(fig)


def readout(out,arrays,choice,details,monotonic,lows):
    lines=[]
    def add(s=''):lines.append(s)
    add('MPC稳定性修订v2：λ=0/1/2/4/8验证结果')
    add('执行范围：四个新配置S1/S2/S4/S8，四个非规划Ridge模型，各256起点、50步。前10步选择；50步只作压力测试。旧C0、保持及五种子BC复用已保存轨迹。没有GRU、测试集评价、自动重新冻结或论文更新。')
    add('仅规划目标加入λ×Σ(|Δ蒸汽|/5+|Δ氧|/0.5)，温度权重4与其他C设置不变。原始回报仍是原负成本，越大越好。')
    add('λ0完整256起点前3步与旧C0/full逐值一致；16组新轨迹的204800步原奖励和反馈均重新核对；另192条所选计划经标准递归独立复核。16组噪声指纹均与旧C0相同。')
    add();add('一、按事先规则得到的建议（尚未重新冻结）')
    add(f"通过两道门槛的λ：{choice['eligible_lambda']}；建议λ：{choice['recommended_lambda']}；未找到时保留旧参考λ：{choice['retained_reference_lambda']}。")
    add('λ | 最差模型原回报改善G | 蒸汽/氧稳定性通过数(共8) | 原指标1%通过数(共20) | 四模型成本均改善 | 两道门槛通过')
    for w in LAMBDAS:
        r=choice['configurations'][str(w)]
        add(f"{w} | {r['original']['worst_cost_gain']:+.7f} | {sum(map(sum,r['stability_per_model_metric']))}/8 | {sum(map(sum,r['original']['guard_pass']))}/20 | {all(r['original']['cost_pass'])} | {r['eligible']}")
    add('门槛按均值判定，不代表每个起点或每个种子都不退化，也不是统计等效性证明。BC是学习的模仿策略，其波动门槛不是工厂签署的验收限值。')
    if choice['recommended_lambda'] is None:add('本次固定网格未找到同时满足所有要求的配置。保留C0为旧参考不能称作通过新稳定性要求，也不能据此证明存在不可避免的物理冲突。按预设停止，不追加权重或改门槛。')
    add();add('二、10步成本—波动取舍')
    add('模型/配置 | 原回报改善 | 蒸汽波动 | 相对BC蒸汽变化% | 氧波动 | 相对BC氧变化%')
    for m in MODELS:
        hold=arrays[m,'hold',10].mean((0,1));bc=arrays[m,'BC',10].mean((0,1))
        for l in LABELS:
            v=arrays[m,l,10].mean((0,1));add(f'{m}/{l} | {v[0]-hold[0]:+.7f} | {v[10]:.7f} | {100*(v[10]/bc[10]-1):+.4f} | {v[11]:.7f} | {100*(v[11]/bc[11]-1):+.4f}')
    add();add('三、波动是否随λ单调下降、何时达到BC水平')
    for r in monotonic:
        if r['horizon']==10:add(f"{r['model']}/{r['metric']}: 单调不增={r['monotone_nonincreasing']}；升高段={r['increasing_transitions']}；首次达到BC的已试λ={r['first_tested_lambda_at_or_below_BC']}")
    add('这只是有限λ网格与固定随机搜索预算的观察，不能插值声称存在某个精确临界λ；评价模型中的闭环指标也不保证随规划惩罚单调变化。')
    add();add('四、50步氧区间内时间比例（%，不参与选择）')
    add('模型 | hold | BC | C0 | S1 | S2 | S4 | S8')
    for m in MODELS:add(m+' | '+' | '.join(f'{100*arrays[m,l,50].mean((0,1))[8]:.5f}' for l in ('hold','BC')+LABELS))
    add('氧区间[3.5,4.0]%包含端点。减少相邻变化不等于保证长期留在目标区间；原成本、原五项和全部新指标的10/50步结果见endpoint_means.csv。')
    add();add('五、未通过的10步项目')
    for w in LAMBDAS:
        r=choice['configurations'][str(w)]
        for mi,m in enumerate(MODELS):
            for j,name in enumerate(('steam','oxygen')):
                if not r['stability_per_model_metric'][mi][j]:add(f"λ{w}/{m}/{name}波动高于BC：差值{r['stability_difference'][mi][j]:+.8f}")
            for j,name in enumerate(ORIGINAL_METRICS[1:]):
                if not r['original']['guard_pass'][mi][j]:add(f"λ{w}/{m}/{name}超过1%：增加{r['original']['guard_degradation'][mi][j]:+.8f}，允许{r['original']['allowed_degradation'][mi][j]:.8f}")
    add();add('六、低温标记')
    for h in (10,50):
        for kind in ('trailing5','raw_six_mean'):
            rs=[r for r in lows if r['horizon']==h and r['kind']==kind]
            add(f"{h}步/{kind}: 低于850步骤{sum(r['low_steps'] for r in rs)}；全体最低{min(r['global_minimum'] for r in rs):.6f}℃。")
    add('不把10步与50步重叠事件相加当独立事件；这是模型轨迹标记，不是现场合规证明。')
    add();add('七、区间与证据范围')
    add('每个模型、时域、配置相对C0/保持/BC的12项指标差值及区间均保存。差值统一候选−对照：回报正为改善，误差/波动正为增加。区间沿用整日期块及BC种子交叉bootstrap10000次、种子20261106、95%，未校正多重比较。仅7个日期块、单个固定CEM随机流，不能声称全面统计保证。')
    add('本轮是根据既有验证结果与用户新增运行偏好作出的透明修订。历史测试集曾被查看，本轮未使用它进行选择；不能称后续测试为全新盲测。目标遗漏可能是波动原因，但本轮结果不能自动证明它解释全部模型误差或50步漂移。')
    add('读旧数据核对：C0的10步氧步间变化约0.056–0.065个百分点、蒸汽约0.115–0.130t/h，λ1附加惩罚约每步0.138–0.155；不是运行前粗估的0.46。该核对未改变已确定网格和门槛。')
    add('文件：endpoint_means.csv、endpoint_by_seed.csv、contrasts.csv/json、guardrails.csv、recommendation.json、monotonicity.json、episode_endpoints.npz、actions_and_support.csv、低温明细；图：cost_steam_tradeoff.png、cost_oxygen_tradeoff.png、lambda_response.png。')
    (out/'REPORT_zh.txt').write_text('\n'.join(lines)+'\n')

if __name__=='__main__':
    torch.set_num_threads(4)
    with threadpool_limits(4):summarize()
