"""Trace real JPGs to recorded descriptors, learned representations and feedback.

This is post-hoc visualization of fixed saved models. It does not retrain models,
re-extract the training CSV, or generate counterfactual furnace images.
"""
from __future__ import annotations

import csv
import hashlib
import json
import os
from pathlib import Path

import numpy as np
import torch
from PIL import Image

from .control import ActorPolicy, TwinEnv
from .data import load_data
from .models import make_state
from .retrieval import VisualMemory
from .training import load_actor, load_twin, seed_everything


ROI = [(288,81,455,178), (120,81,288,178),
       (120,178,288,285), (288,178,455,285)]


def _stamp(value):
    return np.datetime_as_string(np.datetime64(int(value),'ns'),unit='s').replace('T',' ')


def _read_descriptor_records(manifest, feature_file=None):
    """Resolve an explicit relocated CSV while preserving its recorded identity."""
    path = Path(manifest['visual']['path'] if feature_file is None else feature_file)
    if hashlib.sha256(path.read_bytes()).hexdigest() != manifest['visual']['sha256']:
        raise ValueError('Visual descriptor CSV does not match the prepared dataset')
    normalized_regions = None
    # Schema 1 was the original single-capture export; schema 2 explicitly
    # records whether its descriptors include a causal capture history.
    timing = ('single recorded capture' if manifest['schema_version'] == 1
              else manifest['visual']['source_timing'])
    if timing == 'explicit causal descriptor history':
        descriptor_record = json.loads(path.with_suffix('.manifest.json').read_text())
        if descriptor_record['output_sha256'] != manifest['visual']['sha256']:
            raise ValueError('Descriptor ROI provenance does not match the actual feature CSV')
        normalized_regions = [descriptor_record['regions_normalized_xyxy'][f'area{i}']
                              for i in range(1, 5)]
    with path.open(newline='') as stream:
        records = {row['time']: row for row in csv.DictReader(stream)}
    return records, normalized_regions


def make_flame_figures(output, image_dir, *, feature_file=None):
    output, image_dir = Path(output), Path(image_dir).resolve()
    data, stats, manifest = load_data(output/'data')
    directory=output/'visual_trace';directory.mkdir(exist_ok=True)
    figures=output/'figures'
    seed_everything(11,4)
    twin=load_twin(output/'models/twin_multi/twin.pt')
    eval_twin=load_twin(output/'models/twin_eval/twin.pt')
    actor=load_actor(output/'control/full_td3bc/seed_11/actor.pt')
    columns=manifest['visual']['feature_columns']
    records, normalized_regions = _read_descriptor_records(manifest, feature_file)
    sources={}

    def source(index):
        index=int(index);timestamp=_stamp(data['visual_time_ns'][index]);row=records[timestamp]
        recorded=np.asarray([float(row[c]) for c in columns],dtype=np.float32)
        np.testing.assert_array_equal(recorded,data['visual'][index])
        path=image_dir/row['img_name']
        if not path.is_file():raise FileNotFoundError(path)
        with Image.open(path) as im:picture=np.asarray(im.convert('RGB'))
        sources[str(index)]={'sample_index':index,'sample_time':_stamp(data['time_ns'][index]),
            'image_time':timestamp,'image_path':str(path),'image_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'size':[picture.shape[1],picture.shape[0]],'feature_csv_row_matches':True}
        return picture,timestamp

    # Fixed selection by time, independent of prediction quality or image appearance.
    test=data['test_idx'];indices=test[np.linspace(0,len(test)-1,3).round().astype(int)]
    visual=torch.as_tensor(data['visual'][indices])
    normalized=(visual-twin.v_mean)/twin.v_scale
    with torch.no_grad():
        visual_latent=twin.visual_encoder(twin.visual_norm(normalized)).numpy()
        fused=twin.encode(torch.as_tensor(data['u_hist'][indices]),
                          torch.as_tensor(data['z_hist'][indices]),visual).numpy()
    np.savez_compressed(directory/'representation_examples.npz',indices=indices,
        time_ns=data['time_ns'][indices],visual_time_ns=data['visual_time_ns'][indices],
        visual_raw=visual.numpy(),visual_standardized=normalized.numpy(),
        visual_latent=visual_latent,fused_latent=fused,feature_columns=np.asarray(columns))

    # Recreate the exact saved 50-reset batch. This captures retrieval provenance
    # without changing a policy, reset, model, action rule or reported result.
    stored=np.load(output/'control/full_td3bc/seed_11/evaluation.npz',allow_pickle=False)
    representative=json.loads((figures/'figure_sources.json').read_text())['representative_episode']
    memory=VisualMemory(eval_twin,data,data['train_idx'],max_items=512,k=3)
    env=TwinEnv(eval_twin,memory,stats,data,{})
    policy=ActorPolicy(actor,twin)
    observation=env.reset(stored['start_indices']);policy.reset(observation)
    rewards=[];values=[];actions=[];selected=[]
    policy_latents=[];visual_inputs=[]
    with torch.no_grad():
        for step in range(50):
            state=make_state(twin,**observation)
            policy_latents.append(state[representative,:128].numpy())
            visual_inputs.append(observation['visual'][representative].numpy())
            observation,reward,info=env.step(policy(observation))
            rewards.append(reward);values.append(info['control']);actions.append(info['normalized_executed_action'])
            selected.append(info['visual_sample_indices'])
    reward_array=np.stack(rewards,axis=1);cv_array=np.stack(values,axis=1)
    action_array=np.stack(actions,axis=1);source_indices=np.stack(selected,axis=1)
    np.testing.assert_allclose(reward_array,stored['rewards'],atol=1e-6,rtol=1e-6)
    np.testing.assert_allclose(cv_array,stored['control'],atol=1e-5,rtol=1e-6)
    np.testing.assert_allclose(action_array,stored['normalized_actions'],atol=1e-5,rtol=1e-6)
    if not np.isin(source_indices,data['train_idx']).all():raise AssertionError('Non-training image source')
    np.savez_compressed(directory/'closed_loop_visual_trace.npz',
        source_indices=source_indices,start_indices=stored['start_indices'],
        representative_episode=np.asarray(representative),rewards=reward_array,
        control=cv_array,normalized_actions=action_array,
        policy_latent=np.stack(policy_latents),policy_visual_input=np.stack(visual_inputs))

    os.environ.setdefault('MPLCONFIGDIR',str(directory/'matplotlib_cache'))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.patches import Rectangle
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10})
    fig=plt.figure(figsize=(8.5,7.2),layout='constrained')
    grid=fig.add_gridspec(4,3,height_ratios=[2.2,1,1,1])
    for j,index in enumerate(indices):
        picture,timestamp=source(index);ax=fig.add_subplot(grid[0,j]);ax.imshow(picture)
        support=ROI if normalized_regions is None else [
            (int(picture.shape[1]*x0),int(picture.shape[0]*y0),int(picture.shape[1]*x1),int(picture.shape[0]*y1))
            for x0,y0,x1,y1 in normalized_regions]
        for region,(x0,y0,x1,y1) in enumerate(support):
            ax.add_patch(Rectangle((x0,y0),x1-x0,y1-y0,fill=False,
                                  edgecolor=['#17becf','#e377c2','#2ca02c','#ffee00'][region],linewidth=1.1))
        ax.axis('off');ax.set_title(f'Example {"ABC"[j]}\n{timestamp}',fontsize=10)
    # Display grouping only; network inference above preserves the canonical order.
    display_order=[]
    for area in range(1,5):
        display_order += [columns.index(f'ft_{k}_area{area}') for k in range(1,13)]
        display_order += [columns.index(f'fire_line_area{area}')]
    ax=fig.add_subplot(grid[1,:]);im=ax.imshow(normalized.numpy()[:,display_order],aspect='auto',cmap='coolwarm',vmin=-3,vmax=3)
    ax.set(yticks=[0,1,2],yticklabels=list('ABC'),xticks=[6,19,32,45],xticklabels=['Area 1','Area 2','Area 3','Area 4'])
    for x in [12.5,25.5,38.5]:ax.axvline(x,color='black',linewidth=.6)
    ax.set_title('Recorded 52-D descriptors (training-standardized; display clipped to ±3)',fontsize=10)
    fig.colorbar(im,ax=ax,shrink=.8,pad=.015)
    for row,raw,title,cmap in [(2,visual_latent,'Visual MLP output (128 dimensions)','coolwarm'),
                                (3,fused,'Fused GRU + visual representation h (128 dimensions)','viridis')]:
        ax=fig.add_subplot(grid[row,:]);im=ax.imshow(raw,aspect='auto',cmap=cmap)
        ax.set(yticks=[0,1,2],yticklabels=list('ABC'),xlabel='Learned feature dimension')
        ax.set_title(title,fontsize=10);fig.colorbar(im,ax=ax,shrink=.8,pad=.015)
    fig.savefig(figures/'Fig8.png',dpi=300,bbox_inches='tight');plt.close(fig)

    chosen_steps=[1,25,50]
    fig=plt.figure(figsize=(8.5,6.7),layout='constrained')
    grid=fig.add_gridspec(3,6,height_ratios=[2.1,1.7,1.5])
    for j,step in enumerate(chosen_steps):
        index=int(source_indices[representative,step-1]);picture,timestamp=source(index)
        ax=fig.add_subplot(grid[0,2*j:2*j+2]);ax.imshow(picture);ax.axis('off')
        ax.set_title(f'Step {step}: retrieved training frame\n{timestamp}',fontsize=10)
    x=np.arange(1,51)
    for key,(values,label) in enumerate([(cv_array[representative,:,0],'Predicted temperature (°C)'),
                                      (reward_array[representative],'Instantaneous reward')]):
        ax=fig.add_subplot(grid[1,3*key:3*key+3]);ax.plot(x,values,color='#34678a')
        ax.scatter(chosen_steps,values[np.array(chosen_steps)-1],color='#c36540',zorder=3)
        for step in chosen_steps:ax.axvline(step,color='#888888',linestyle=':',linewidth=.8)
        ax.set(xlabel='Feedback control step',ylabel=label);ax.grid(alpha=.2)
    ax=fig.add_subplot(grid[2,:]);im=ax.imshow(action_array[representative].T,aspect='auto',cmap='coolwarm',vmin=-1,vmax=1,extent=[.5,50.5,8.5,.5])
    ax.set(yticks=np.arange(1,9),yticklabels=[f'MV{j}' for j in range(1,9)],xlabel='Feedback control step')
    ax.set_title('Actually executed normalized MV increments',fontsize=10)
    fig.colorbar(im,ax=ax,shrink=.8,pad=.015)
    fig.savefig(figures/'Fig9.png',dpi=300,bbox_inches='tight');plt.close(fig)
    record={'schema':1,'image_directory':str(image_dir),'representation_indices':indices.tolist(),
        'representation_selection':'first, middle, last chronological test windows; no appearance/error selection',
        'roi_absolute_pixels_xyxy':ROI if normalized_regions is None else None,
        'roi_normalized_xyxy':normalized_regions,
        'temporal_descriptors':'single-capture export' if normalized_regions is None else 'most recent six captures; top photos show latest capture only',
        'descriptors':'existing CSV; not re-extracted or replaced in this visualization operation',
        'heatmap_display_order':[columns[i] for i in display_order],
        'closed_loop':{'policy_seed':11,'episode':int(representative),'start_index':int(stored['start_indices'][representative]),
            'selection':'same median-return first-seed episode as Fig6','display_steps':chosen_steps,
            'reward_max_abs_difference':float(abs(reward_array-stored['rewards']).max()),
            'control_max_abs_difference':float(abs(cv_array-stored['control']).max()),
            'actions_max_abs_difference':float(abs(action_array-stored['normalized_actions']).max()),
            'all_2500_retrieval_sources_in_training_partition':True},
        'sources':sources,'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'checkpoint_sha256':{str(p.relative_to(output)):hashlib.sha256(p.read_bytes()).hexdigest() for p in
             [output/'models/twin_multi/twin.pt',output/'models/twin_eval/twin.pt',output/'control/full_td3bc/seed_11/actor.pt']},
        'interpretation':'Real historical frames linked to numeric descriptors; no RGB CNN, image synthesis, spatial attention or field intervention'}
    (directory/'visual_trace_manifest.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'flame_figures_complete':True,'images':len(sources),'replay':record['closed_loop']},ensure_ascii=False))
    return record
