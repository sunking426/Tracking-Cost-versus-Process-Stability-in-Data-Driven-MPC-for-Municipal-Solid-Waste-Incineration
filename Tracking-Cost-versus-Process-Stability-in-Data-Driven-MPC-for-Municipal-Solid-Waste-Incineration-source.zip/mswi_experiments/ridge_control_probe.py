"""Bounded deterministic control probe on separately fitted Ridge evaluators.

The full-training Ridge always owns MPC planning. Five evaluators receive the
same three policies and initial observed states. No hypothetical trajectory is
compared with the factual recorded trajectory as causal ground truth.
"""
from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path
import shutil
import time

import numpy as np
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits
import torch

from .control import project_normalized_actions, reward_and_violation
from .data import MINUTE_NS, load_data
from .numeric_baselines import numeric_features, sha256, write_json
from .ridge_dynamics import RidgeDynamics
from .ridge_response import analytic_responses, decision_rollout
from .ridge_response_report import admission, coverage_summary, physical_responses, response_screen
from .ridge_response_study import MODEL_IDS, archive, support_query, verify

POLICIES=('hold','linear_bc','grid_mpc')
SPLITS=('val','test')
FIXED={'horizon':10,'planner_horizon':10,'fraction':.1,'eligible_channels':[0,3],
       'bc_alpha':100.,'projection_tolerance':1e-10,'grid_levels':[-1,0,1],
       'planner_model':'full','policies':list(POLICIES)}
SNAPSHOT_NAMES=('ridge_control_probe.py','ridge_control_probe_report.py','ridge_response.py',
    'ridge_response_study.py','ridge_response_report.py','ridge_dynamics.py','ridge_validation.py',
    'numeric_baselines.py','numeric_baselines_report.py','ridge_validation_report.py','control.py','data.py',
    'visual_diagnostics_statistics.py')


def paths(config_file):
    path=Path(config_file).resolve();cfg=json.loads(path.read_text())
    if any(cfg.get(k)!=v for k,v in FIXED.items()):raise ValueError('configuration differs from fixed limited-control protocol')
    if not isinstance(cfg.get('threads'),int) or cfg['threads']<1:raise ValueError('positive integer thread count required')
    return cfg,path.parent,path.parent/cfg['output_dir']


def bc_features(u_hist,z_hist,z_current):
    x=numeric_features({'u_hist':u_hist,'z_hist':z_hist})
    current=np.asarray(z_current,dtype=np.float64)
    if current.shape!=(len(x),9) or not np.isfinite(current).all():raise ValueError('finite aligned observed current CV required')
    return np.concatenate((x,current),axis=1)


def maximum_request(stats,cfg):
    scale=np.asarray(stats['action_scale'],dtype=np.float64);bound=np.asarray(stats['action_bound'],dtype=np.float64)
    if scale.shape!=(8,) or bound.shape!=(8,) or np.any(scale<=0) or np.any(bound<=0):raise ValueError('positive canonical action scales/bounds required')
    result=np.zeros(8);eligible=np.asarray(cfg['eligible_channels'],dtype=np.int64)
    result[eligible]=float(cfg['fraction'])*bound[eligible]/scale[eligible]
    if np.any(result>1):raise ValueError('limited requests must be inside canonical normalized action box')
    return result


def fixed_candidates(stats,cfg):
    maximum=maximum_request(stats,cfg);eligible=cfg['eligible_channels']
    levels=[(0,0)]+[v for v in itertools.product(cfg['grid_levels'],repeat=2) if v!=(0,0)]
    result=np.zeros((9,8),dtype=np.float64)
    for i,pair in enumerate(levels):result[i,eligible]=np.asarray(pair)*maximum[eligible]
    return result


def _project(request,u,stats):
    values=project_normalized_actions(torch.from_numpy(np.asarray(request,dtype=np.float64).copy()),
        torch.from_numpy(np.asarray(u,dtype=np.float64).copy()),stats)
    return tuple(v.numpy() for v in values)


def bc_training_inputs(data,stats,cfg):
    train=np.asarray(data['train_idx'],dtype=np.int64);times=np.asarray(data['time_ns'],dtype=np.int64)
    following=np.asarray(data['next_idx'],dtype=np.int64);child=following[train];safe=np.maximum(child,0)
    allowed=np.zeros(len(times),dtype=bool);allowed[train]=True
    u=np.asarray(data['u_current'],dtype=np.float64)
    low,high=[np.asarray(stats[k],dtype=np.float64) for k in ('u_low','u_high')]
    keep=(child>=0)&allowed[safe]&(times[safe]-times[train]==MINUTE_NS)&((u[train]>=low)&(u[train]<=high)).all(1)
    rows=train[keep]
    if not len(rows):raise ValueError('no bounded consecutive training action pairs')
    physical=np.asarray(data['action'],dtype=np.float64)[rows]
    check=u[following[rows]]-u[rows]
    tolerance=np.finfo(np.float32).eps*(np.abs(u[following[rows]])+np.abs(u[rows])+1)
    if np.any(np.abs(physical-check)>tolerance):raise ValueError('BC action targets do not match recorded next increments')
    maximum=maximum_request(stats,cfg);request=np.clip(physical/np.asarray(stats['action_scale']),-maximum,maximum)
    target,delta,next_u=_project(request,u[rows],stats)
    eligible=np.asarray(cfg['eligible_channels'],dtype=np.int64)
    return {'indices':rows,'features':bc_features(data['u_hist'][rows],data['z_hist'][rows],data['z_current'][rows]),
        'normalized_target':target[:,eligible],'requested_target':request,'physical_target':delta,'next_u_target':next_u}


def fit_bc(x,y,alpha=100.):
    x,y=np.asarray(x,dtype=np.float64),np.asarray(y,dtype=np.float64)
    if x.ndim!=2 or x.shape[1]!=187 or y.shape!=(len(x),2) or not len(x) or not np.isfinite(x).all() or not np.isfinite(y).all():
        raise ValueError('BC fitting needs finite nonempty 187D observations and 2D targets')
    if float(alpha)!=100.:raise ValueError('BC alpha is fixed before validation/test')
    scaler=StandardScaler().fit(x);model=Ridge(alpha=float(alpha),solver='cholesky',fit_intercept=True)
    model.fit(scaler.transform(x),y)
    return {'x_mean':scaler.mean_,'x_scale':scaler.scale_,'coef':model.coef_,
            'intercept':model.intercept_,'alpha':np.asarray(alpha),'kind':np.asarray('limited_linear_bc')}


def bc_request(weights,u_hist,z_hist,z_current,stats,cfg):
    x=bc_features(u_hist,z_hist,z_current)
    mean,scale,coef,intercept=[np.asarray(weights[k],dtype=np.float64) for k in ('x_mean','x_scale','coef','intercept')]
    if mean.shape!=(187,) or scale.shape!=(187,) or coef.shape!=(2,187) or intercept.shape!=(2,) or np.any(scale<=0):
        raise ValueError('invalid limited BC model shapes/scales')
    prediction=((x-mean)/scale)@coef.T+intercept
    if not np.isfinite(prediction).all():raise FloatingPointError('nonfinite BC request')
    result=np.zeros((len(x),8));eligible=np.asarray(cfg['eligible_channels']);maximum=maximum_request(stats,cfg)
    result[:,eligible]=np.clip(prediction,-maximum[eligible],maximum[eligible])
    return result


def screen_request(request,u,z_current,time_ns,support,stats,cfg):
    request=np.asarray(request,dtype=np.float64);u=np.asarray(u,dtype=np.float64)
    maximum=maximum_request(stats,cfg)
    if request.shape!=u.shape or request.ndim!=2 or request.shape[1]!=8 or not np.isfinite(request).all():raise ValueError('invalid bounded policy requests')
    if np.any(np.abs(request)>maximum+1e-12):raise ValueError('policy requested inactive or oversized action')
    executed,delta,next_u=_project(request,u,stats)
    desired=request*np.asarray(stats['action_scale'])
    complete=np.all(np.abs(delta-desired)<=cfg['projection_tolerance'],axis=1)
    distance,supported,_=support_query(support,u,z_current,delta,time_ns)
    nonzero=np.any(request!=0.,axis=1)
    admitted=(complete&supported)|~nonzero
    return {'executed':executed,'physical':delta,'next_u':next_u,'distance':distance,'supported':supported,
        'complete':complete,'nonzero':nonzero,'admitted':admitted}


def grid_plan(planner,step_kernel,u_hist,z_hist,z_current,time_ns,support,stats,cfg):
    """Nine fixed single-step-then-hold plans; the supplied planner is always full."""
    candidates=fixed_candidates(stats,cfg);n=len(u_hist);h=cfg['planner_horizon'];u=np.asarray(u_hist[:,-1],dtype=np.float64)
    repeated_request=np.broadcast_to(candidates,(n,9,8)).reshape(n*9,8)
    repeated_u=np.repeat(u[:,None],9,axis=1).reshape(n*9,8)
    repeated_z=np.repeat(np.asarray(z_current)[:,None],9,axis=1).reshape(n*9,9)
    screen=screen_request(repeated_request,repeated_u,repeated_z,np.repeat(time_ns,9),support,stats,cfg)
    base=decision_rollout(planner,u_hist,z_hist,z_current,np.repeat(u[:,None],h,axis=1))
    kernel=np.asarray(step_kernel,dtype=np.float64)
    if kernel.shape!=(h,9,8) or not np.isfinite(kernel).all():raise ValueError('finite full-model step kernel required')
    delta=screen['physical'].reshape(n,9,8)
    predicted=base[:,None]+np.einsum('hzm,ncm->nchz',kernel,delta)
    actions=np.zeros((n,9,h,8));actions[:,:,0]=screen['executed'].reshape(n,9,8)
    reward,_,_=reward_and_violation(predicted,actions,stats);scores=reward.sum(axis=-1)
    admitted=screen['admitted'].reshape(n,9)
    if not admitted[:,0].all() or not np.isfinite(scores).all():raise AssertionError('zero-plan must remain available and all candidate scores finite')
    # All scores are retained; only admission masks affect argmax. Exact ties
    # prefer the first candidate, which is the zero-action plan.
    chosen=np.argmax(np.where(admitted,scores,-np.inf),axis=1)
    return candidates[chosen],{'candidate_scores':scores,'candidate_admissible':admitted,
        'candidate_support_distance':screen['distance'].reshape(n,9),
        'candidate_supported':screen['supported'].reshape(n,9),
        'candidate_full_execution':screen['complete'].reshape(n,9),'chosen_candidate':chosen}


def rollout_policy(evaluator,planner,policy,inputs,bc_weights,support,stats,cfg):
    if policy not in POLICIES:raise ValueError('unknown bounded policy')
    u,z,current=[np.asarray(inputs[k],dtype=np.float64).copy() for k in ('u_hist','z_hist','z_current')]
    n=len(u);h=cfg['horizon'];initial_time=np.asarray(inputs['time_ns'],dtype=np.int64)
    step_kernel=analytic_responses(planner,cfg['planner_horizon'])['step'] if policy=='grid_mpc' else None
    buffers={};candidate_buffers={}
    for step in range(h):
        stamp=initial_time+step*MINUTE_NS
        if policy=='hold':request=np.zeros((n,8))
        elif policy=='linear_bc':request=bc_request(bc_weights,u,z,current,stats,cfg)
        else:
            request,diagnostic=grid_plan(planner,step_kernel,u,z,current,stamp,support,stats,cfg)
            for k,v in diagnostic.items():candidate_buffers.setdefault(k,[]).append(v)
        proposal=screen_request(request,u[:,-1],current,stamp,support,stats,cfg)
        blocked=proposal['nonzero']&~proposal['admitted']
        if policy=='grid_mpc' and blocked.any():raise AssertionError('MPC chose a rejected nonzero plan')
        applied=request.copy();applied[blocked]=0.
        actual=screen_request(applied,u[:,-1],current,stamp,support,stats,cfg)
        if not actual['admitted'].all():raise AssertionError('applied action escaped the predefined screen')
        next_z=decision_rollout(evaluator,u,z,current,actual['next_u'][:,None])[:,0]
        reward,violation,costs=reward_and_violation(next_z,actual['executed'],stats)
        values={'pred_cv':next_z,'u_path':actual['next_u'],'requested_action':request,
            'executed_action':actual['executed'],'physical_executed_action':actual['physical'],
            'proposal_support_distance':proposal['distance'],'proposal_supported':proposal['supported'],
            'proposal_full_execution':proposal['complete'],'action_support_distance':actual['distance'],
            'action_supported':actual['supported'],'blocked_nonzero':blocked,
            'zero_action_unsupported':~actual['nonzero']&~actual['supported'],
            'reward':reward,'violation':violation,**costs}
        for k,v in values.items():buffers.setdefault(k,[]).append(v)
        z=np.concatenate((z[:,1:],current[:,None]),axis=1)
        u=np.concatenate((u[:,1:],actual['next_u'][:,None]),axis=1);current=next_z
    result={k:np.stack(v,axis=1) for k,v in buffers.items()}
    result.update({k:np.stack(v,axis=1) for k,v in candidate_buffers.items()})
    result.update(indices=inputs['indices'],time_ns=inputs['time_ns'],future_time_ns=inputs['future_time_ns'],
        truth_cv=inputs['truth_cv'],initial_u=inputs['u_hist'][:,-1],initial_z_current=inputs['z_current'])
    for k,v in result.items():
        if np.issubdtype(v.dtype,np.number) and not np.isfinite(v).all():raise FloatingPointError('nonfinite saved trajectory: '+k)
    return result


def prepare(config_file):
    cfg,project,out=paths(config_file)
    if out.exists() and any(out.iterdir()):raise FileExistsError('new empty control output directory required')
    out.mkdir(parents=True,exist_ok=True);diagnostic=project/cfg['diagnostic_study']
    frozen=json.loads((diagnostic/'selection_frozen.json').read_text());verify(frozen['files'],diagnostic);verify(frozen['source_code_hashes'])
    prior_report=json.loads((diagnostic/'report_manifest.json').read_text());verify(prior_report['files'],diagnostic)
    previous_run=json.loads((diagnostic/'run_manifest.json').read_text())
    if (previous_run.get('status')!='complete' or prior_report.get('status')!='complete'
            or previous_run['source_selection_sha256']!=sha256(diagnostic/'selection.json')
            or previous_run['source_selection_frozen_sha256']!=sha256(diagnostic/'selection_frozen.json')
            or prior_report['source_run_manifest_sha256']!=sha256(diagnostic/'run_manifest.json')
            or previous_run['response_checks_sha256']!=sha256(diagnostic/'response_checks.json')):
        raise ValueError('diagnostic run/report no longer binds frozen selection and response checks')
    response_records=[r for r in previous_run['files'] if r['path']=='responses.npz']
    if len(response_records)!=1:raise ValueError('diagnostic run must bind exactly one response archive')
    verify({r['path']:r['sha256'] for r in previous_run['files']},diagnostic)
    if json.loads((diagnostic/'response_checks.json').read_text()).get('status')!='passed':
        raise ValueError('diagnostic response implementation checks not passed')
    verify(json.loads((diagnostic/'input_hashes.json').read_text()))
    diag_cfg=json.loads((diagnostic/'config.json').read_text());responses=archive(diagnostic/'responses.npz')
    val=archive(diagnostic/'inputs/val.npz');screen=response_screen(physical_responses(responses['step'],responses['amp']),responses['phys_scale'],diag_cfg)
    gate=admission(screen,coverage_summary(val),diag_cfg)
    if gate['eligible_channels']!=cfg['eligible_channels'] or gate['status']!='limited_control_candidate':
        raise ValueError('predefined limited-control channels differ from training/validation admission')
    source=project/cfg['source_run']/'data';data,stats,_=load_data(source)
    if json.loads((diagnostic/'stats.json').read_text())!=stats:raise ValueError('control and diagnostic statistics differ')
    previous_hashes=json.loads((diagnostic/'input_hashes.json').read_text())
    if previous_hashes.get(str((source/'dataset.npz').resolve()))!=sha256(source/'dataset.npz'):
        raise ValueError('control and diagnostic datasets differ')
    bc=bc_training_inputs(data,stats,cfg);np.savez_compressed(out/'bc_prepared.npz',**bc)
    (out/'inputs').mkdir();(out/'evaluation_models').mkdir()
    copied=[];selection=json.loads((diagnostic/'selection.json').read_text())
    if tuple(r['model_id'] for r in selection['models'])!=MODEL_IDS:raise ValueError('evaluation model order changed')
    for row in selection['models']:
        source_model=diagnostic/row['model_path'];dest=out/'evaluation_models'/f"{row['model_id']}.npz";shutil.copyfile(source_model,dest)
        copied.append({'model_id':row['model_id'],'model_path':str(dest.relative_to(out)),'source_path':str(source_model.resolve()),'sha256':sha256(dest)})
    for split in SPLITS:shutil.copyfile(diagnostic/'inputs'/f'{split}.npz',out/'inputs'/f'{split}.npz')
    shutil.copyfile(diagnostic/'support.npz',out/'support.npz');shutil.copyfile(source/'stats.json',out/'stats.json')
    np.savez_compressed(out/'candidate_grid.npz',requested_actions=fixed_candidates(stats,cfg))
    write_json(out/'config.json',cfg);write_json(out/'gate.json',gate)
    protocol={'scope':'Limited deterministic learned-model control experiment; no real plant actuation or causal validation.',
        'initial_state':'Same frozen256 validation/test anchors as response study; initially observed CV_t and histories. Future CV feedback uses the selected evaluator only.',
        'evaluation_models':'full/early/middle/late/pooled_matched from response study. Full is within-model evaluation; four others are overlapping-data or time-block model transfer, not independent plants.',
        'planner':'Always the full-training model, including while evaluating every other model. It receives the current evaluator-generated state but never substitutes evaluator coefficients for planning.',
        'actions':'Only admitted MV0 and MV3; normalized bounds fraction*action_bound/action_scale with fraction0.1. Other six requests exactly zero. Every nonzero action must project without truncation within1e-10 and pass frozen25D initial support screen at its current simulated state.',
        'zero_action':'Always allowed as explicit hold fallback even when its support screen fails; zero_action_unsupported is retained, not a safety guarantee.',
        'linear_bc':'New fixedalpha100 StandardScaler+Ridge on187D [numeric178,observedCV9], training bounded consecutive pairs only; eligible recorded physical increments clipped to±0.1bound then canonical projected; two normalized executed increments are the targets. Not the previous GRU actor or a strong neural BC baseline.',
        'grid_mpc':'Nine deterministic two-channel requests from{-limit,0,+limit}; zero first then lexicographic remaining pairs. Each plan changes levels once then holds them for10steps; canonical undiscounted reward sum. Reject nonzero unsupported/truncated candidates; exact score ties select first. Replan every minute. Not a global arbitrary-sequence optimum.',
        'reward':'Unchanged canonical reward_and_violation: negative tracking, oxygen-band, movement and empirical-envelope costs.',
        'model_identity':'All trained/frozen sources and policies fixed before evaluation. No validation tuning, policy ranking selection, or test-based plan choice.',
        'truth_cv':'Saved factual future values only for alignment/reference. They are not ground truth for hypothetical actions and no counterfactual accuracy claim is made.',
        'limits':['Training/validation gate is heuristic, not causal or plant-safety certification.',
                  'Old evaluation periods have already been inspected; exploratory study.',
                  'Simulated closed loops can remain outside historical joint support through zero fallback; all such steps reported.',
                  'The two-input finite grid and constrained linear BC are deliberately bounded baselines, not full optimization or reinforcement learning.']}
    write_json(out/'protocol.json',protocol)
    write_json(out/'preparation.json',{'status':'complete','bc_training_rows':len(bc['indices']),
        'bc_feature_width':187,'bc_target_width':2,'gate':gate,'evaluation_models':copied,
        'anchors':{s:len(archive(out/'inputs'/f'{s}.npz')['indices']) for s in SPLITS}})
    input_files=[source/n for n in ('dataset.npz','stats.json','manifest.json')]
    input_files += [diagnostic/n for n in ('selection.json','selection_frozen.json','input_hashes.json','report_manifest.json',
        'config.json','run_manifest.json','response_checks.json','responses.npz','support.npz','statistics/summary.json',*[f'inputs/{s}.npz' for s in SPLITS])]
    input_files += [diagnostic/r['model_path'] for r in selection['models']]
    hashes={str(q.resolve()):sha256(q) for q in input_files};write_json(out/'input_hashes.json',hashes)
    names=['bc_prepared.npz','support.npz','stats.json','candidate_grid.npz','config.json','gate.json','protocol.json','preparation.json','input_hashes.json',
           *[f'inputs/{s}.npz' for s in SPLITS],*[r['model_path'] for r in copied]]
    verify(hashes);write_json(out/'prepare_frozen.json',{'status':'complete','files':{name:sha256(out/name) for name in names}})
    print('Prepared admitted two-input control study and training-only linear BC targets.',flush=True)
    return out


def load_prepared(config_file):
    cfg,project,out=paths(config_file)
    if cfg!=json.loads((out/'config.json').read_text()):raise ValueError('configuration changed after prepare')
    frozen=json.loads((out/'prepare_frozen.json').read_text());verify(frozen['files'],out);verify(json.loads((out/'input_hashes.json').read_text()))
    stats=json.loads((out/'stats.json').read_text());support=archive(out/'support.npz')
    return cfg,project,out,stats,support


def train(config_file):
    cfg,project,out,stats,support=load_prepared(config_file)
    if (out/'models').exists() or (out/'selection.json').exists():raise FileExistsError('control policy fitting already started')
    (out/'models').mkdir();bc=archive(out/'bc_prepared.npz');weights=fit_bc(bc['features'],bc['normalized_target'],cfg['bc_alpha'])
    np.savez_compressed(out/'models/linear_bc.npz',**weights,eligible_channels=np.asarray(cfg['eligible_channels'],dtype=np.int64))
    preparation=json.loads((out/'preparation.json').read_text())
    write_json(out/'selection.json',{'status':'complete','policies':list(POLICIES),'planner_model':'full',
        'evaluation_models':preparation['evaluation_models'],'bc_model_path':'models/linear_bc.npz',
        'bc_training_samples':len(bc['indices']),'bc_alpha':100.,'policy_selection':'none; all three fixed policies evaluated',
        'prepare_frozen_sha256':sha256(out/'prepare_frozen.json')})
    frozen=dict(json.loads((out/'prepare_frozen.json').read_text())['files'])
    for name in ('prepare_frozen.json','selection.json','models/linear_bc.npz'):frozen[name]=sha256(out/name)
    (out/'code_snapshot').mkdir();source_hashes={}
    for name in SNAPSHOT_NAMES:
        source=project/'mswi_experiments'/name;shutil.copyfile(source,out/'code_snapshot'/name)
        frozen['code_snapshot/'+name]=sha256(out/'code_snapshot'/name);source_hashes[str(source)]=sha256(source)
    verify(json.loads((out/'input_hashes.json').read_text()))
    write_json(out/'selection_frozen.json',{'status':'complete','files':frozen,'source_code_hashes':source_hashes})
    print('Linear BC trained once; policies/planner/evaluators/reporting code frozen.',flush=True)
    return out


def run(config_file):
    cfg,project,out,stats,support=load_prepared(config_file)
    frozen=json.loads((out/'selection_frozen.json').read_text());verify(frozen['files'],out);verify(frozen['source_code_hashes'])
    if (out/'trajectories').exists() or (out/'run_manifest.json').exists():raise FileExistsError('control evaluation already started')
    selection=json.loads((out/'selection.json').read_text());models={r['model_id']:RidgeDynamics.load(out/r['model_path']) for r in selection['evaluation_models']}
    if tuple(models)!=MODEL_IDS or selection['planner_model']!='full' or selection['policies']!=list(POLICIES):raise ValueError('fixed control inventory changed')
    planner=models['full'];bc=archive(out/selection['bc_model_path']);(out/'trajectories').mkdir();records=[];started=time.monotonic()
    for split in SPLITS:
        inputs=archive(out/'inputs'/f'{split}.npz')
        for model_id in MODEL_IDS:
            folder=out/'trajectories'/split/model_id;folder.mkdir(parents=True)
            for policy in POLICIES:
                values=rollout_policy(models[model_id],planner,policy,inputs,bc,support,stats,cfg)
                dest=folder/f'{policy}.npz';np.savez_compressed(dest,**values)
                records.append({'split':split,'model_id':model_id,'policy':policy,'path':str(dest.relative_to(out)),
                    'sha256':sha256(dest),'anchors':len(inputs['indices']),'horizon':cfg['horizon'],'planner_model':'full' if policy=='grid_mpc' else None})
                print(split,model_id,policy,'saved',len(inputs['indices'])*cfg['horizon'],'steps',flush=True)
    verify(frozen['files'],out);verify(frozen['source_code_hashes'])
    write_json(out/'run_manifest.json',{'status':'complete','files':records,'source_selection_sha256':sha256(out/'selection.json'),
        'source_selection_frozen_sha256':sha256(out/'selection_frozen.json'),'elapsed_seconds':time.monotonic()-started,
        'trajectories_dropped':0,'predictions_clipped':False,'planner_model':'full','rl_trained':False})
    return out


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('stage',choices=('prepare','train','run','all'))
    parser.add_argument('--config',default='ridge_control_probe_20261106.json');args=parser.parse_args()
    cfg,_,_=paths(args.config)
    with threadpool_limits(limits=cfg['threads']):
        for stage in ('prepare','train','run') if args.stage=='all' else (args.stage,):globals()[stage](args.config)


if __name__=='__main__':main()
