"""Causal decision-time inputs and observed labels for limited RGB diagnostics.

These are forecasting and logged-operation association tasks, not safety labels
or estimates of optimal control. Both tasks share the same retained origins and
all visual variants use the same decision-time numerical information.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
from threadpoolctl import threadpool_limits

from .data import MINUTE_NS, MV_NAMES, CV_NAMES, control_values, load_data
from .numeric_baselines import _check_data, numeric_features, sha256, write_json
from .ridge_dynamics import continuous_chains
from .ridge_rgb_residual_data import _visual_inputs


PARTITIONS = ('train', 'val', 'test')
FEATURE_DIMENSIONS = {'numeric': 219, 'quality': 235, 'rgb': 267, 'stale': 267}
PHYSICAL_NAMES = ('temperature', 'pressure', 'steam', 'oxygen')
SUMMARY_NAMES = ('change_1m', 'change_5m', 'change_10m', 'abs_change_1m',
                 'abs_change_5m', 'abs_change_10m', 'std_11points', 'range_11points')


def _archive(path):
    with np.load(path, allow_pickle=False) as saved:
        return {key: saved[key] for key in saved.files}


def numerical_decision_features(data):
    """Known histories, measured CV_t and 32 predefined nonlinear summaries."""
    history = numeric_features(data)
    current = np.asarray(data['z_target'], dtype=np.float64)
    if current.shape != (len(history), 9) or not np.isfinite(current).all():
        raise ValueError('decision origin requires finite observed CV_t')
    cv = np.concatenate((np.asarray(data['z_hist'], dtype=np.float64), current[:, None]), axis=1)
    physical = control_values(cv)
    summaries = []
    for channel in range(4):
        values = physical[:, :, channel]
        change = values[:, -1, None] - values[:, [-2, -6, -11]]
        summaries.append(np.column_stack((change, np.abs(change), values.std(axis=1, ddof=0),
                                          np.ptp(values, axis=1))))
    result = np.concatenate((history, current, *summaries), axis=1)
    if result.shape != (len(history), 219) or not np.isfinite(result).all():
        raise ValueError('invalid numerical decision design')
    columns = [f'MV_t{lag:+d}:{name}' for lag in range(-10, 1) for name in MV_NAMES]
    columns += [f'CV_t{lag:+d}:{name}' for lag in range(-10, 0) for name in CV_NAMES]
    columns += [f'CV_t:{name}' for name in CV_NAMES]
    columns += [f'{name}:{summary}' for name in PHYSICAL_NAMES for summary in SUMMARY_NAMES]
    return result, columns


def select_common_origins(data, capture_time_ns, sample_capture_index, *, horizon=5,
                          stale_min_minutes=60, stale_max_minutes=70):
    """Select by availability alone; each stale image remains inside its split."""
    if horizon != 5 or stale_min_minutes != 60 or stale_max_minutes != 70:
        raise ValueError('this protocol fixes five future minutes and 60--70 minute stale captures')
    capture_times = np.asarray(capture_time_ns)
    mapping = np.asarray(sample_capture_index)
    times = np.asarray(data['time_ns'])
    if (capture_times.ndim != 1 or not len(capture_times)
            or not np.issubdtype(capture_times.dtype, np.integer)
            or np.any(np.diff(capture_times) <= 0)
            or mapping.shape != times.shape or not np.issubdtype(mapping.dtype, np.integer)
            or mapping.min() < 0 or mapping.max() >= len(capture_times)):
        raise ValueError('invalid ordered captures or sample capture mapping')
    if not np.array_equal(capture_times[mapping], data['visual_time_ns']):
        raise ValueError('capture mapping differs from the measured visual input')
    if np.any(capture_times[mapping] > times - MINUTE_NS):
        raise ValueError('current image occurs after the decision image cutoff')
    memberships = {split: np.unique(mapping[data[split+'_idx']]) for split in PARTITIONS}
    for i, split in enumerate(PARTITIONS):
        for later in PARTITIONS[i+1:]:
            if np.intersect1d(memberships[split], memberships[later]).size:
                raise ValueError('capture membership overlaps partitions')
    selected, counts = {}, {}
    for split in PARTITIONS:
        chains = continuous_chains(data, split, horizon + 1)
        origins = chains[:, 0]
        allowed = memberships[split]
        cutoff = times[origins] - MINUTE_NS
        positions = np.searchsorted(capture_times[allowed], cutoff - stale_min_minutes*MINUTE_NS,
                                    side='right') - 1
        valid = positions >= 0
        stale = allowed[np.maximum(positions, 0)]
        age = cutoff - capture_times[stale]
        valid &= (age >= stale_min_minutes*MINUTE_NS) & (age <= stale_max_minutes*MINUTE_NS)
        valid &= capture_times[stale] >= np.asarray(data['source_start_ns'])[data[split+'_idx']].min()
        if not valid.any():
            raise ValueError(f'no complete {split} origins with a causal same-partition stale image')
        selected[split] = {'chains': chains[valid], 'stale_capture_index': stale[valid],
                           'current_capture_index': mapping[origins[valid]]}
        counts[split] = {'original_partition_rows': len(data[split+'_idx']),
                         'complete_six_step_chains': len(chains),
                         'removed_without_stale_image': int((~valid).sum()),
                         'retained_origins': int(valid.sum())}
    return selected, counts


def build_prepared(data, design226, capture_time_ns, mapping, capture_rgb32, config):
    """Pure construction helper: thresholds see final common training rows only."""
    design = np.asarray(design226, dtype=np.float64)
    rgb = np.asarray(capture_rgb32, dtype=np.float64)
    n = len(data['time_ns'])
    if (design.shape != (n, 226) or not np.isfinite(design).all()
            or rgb.shape != (len(capture_time_ns), 32) or not np.isfinite(rgb).all()):
        raise ValueError('expected aligned frozen 226-column features and capture RGB32')
    if not np.array_equal(design[:, :178], numeric_features(data)):
        raise ValueError('inherited numerical features differ from the source histories')
    if not np.allclose(design[:, 194:], rgb[mapping], rtol=0, atol=1e-10):
        raise ValueError('observed RGB design differs from capture transform')
    selected, counts = select_common_origins(data, capture_time_ns, mapping,
        horizon=config.get('horizon', 5), stale_min_minutes=config.get('stale_min_minutes', 60),
        stale_max_minutes=config.get('stale_max_minutes', 70))
    numeric, numeric_columns = numerical_decision_features(data)
    thermal_quantile = float(config.get('thermal_quantile', .8))
    action_quantile = float(config.get('action_quantile', .9))
    tolerance = float(config.get('action_nonzero_tolerance', 1e-6))
    if thermal_quantile != .8 or action_quantile != .9 or tolerance != 1e-6:
        raise ValueError('this study fixes training quantiles .8/.9 and nonzero tolerance 1e-6')
    temperatures = control_values(np.asarray(data['z_target'], dtype=np.float64))[:, 0]
    action = np.asarray(data['action'], dtype=np.float64)
    if action.shape != (n, 8) or not np.isfinite(action).all():
        raise ValueError('logged next-minute action must contain eight finite channels')
    arrays, label_audit, previous_end = {}, {}, None
    for split, selection in selected.items():
        chains = selection['chains']; rows = chains[:, 0]
        if not np.array_equal(np.asarray(data['next_idx'])[rows], chains[:, 1]):
            raise ValueError('next-minute label is not the first future chain member')
        first_u = np.asarray(data['u_hist'][rows, -1], dtype=np.float64)
        next_u = np.asarray(data['u_hist'][chains[:, 1], -1], dtype=np.float64)
        # Source action was differenced before the source histories were cast to
        # float32. Allow only the corresponding input-quantization error bound.
        bound = np.finfo(np.float32).eps * (np.abs(first_u) + np.abs(next_u) + 1)
        error = np.abs((next_u - first_u) - action[rows])
        if np.any(error > bound):
            raise ValueError('action label disagrees with consecutive recorded MV changes')
        stale_index = selection['stale_capture_index']; fresh_index = selection['current_capture_index']
        start = np.minimum(np.min(np.asarray(data['source_start_ns'])[chains], axis=1),
                           np.asarray(capture_time_ns)[stale_index])
        end = np.max(np.asarray(data['source_end_ns'])[chains], axis=1)
        if previous_end is not None and start.min() <= previous_end:
            raise ValueError('combined decision and label source ranges cross partitions')
        previous_end = int(end.max())
        prefix = split+'_'
        quality = np.concatenate((numeric[rows], design[rows, 178:194]), axis=1)
        arrays.update({prefix+'indices': rows, prefix+'time_ns': data['time_ns'][rows],
            prefix+'chains': chains, prefix+'numeric': numeric[rows], prefix+'quality': quality,
            prefix+'rgb': np.concatenate((quality, design[rows, 194:]), axis=1),
            prefix+'stale': np.concatenate((quality, rgb[stale_index]), axis=1),
            prefix+'thermal_magnitude': np.max(np.abs(temperatures[chains[:, 1:]] - temperatures[rows, None]), axis=1),
            prefix+'action_magnitudes': np.abs(action[rows]), prefix+'signed_action': action[rows],
            prefix+'current_capture_index': fresh_index, prefix+'stale_capture_index': stale_index,
            prefix+'current_capture_time_ns': np.asarray(capture_time_ns)[fresh_index],
            prefix+'stale_capture_time_ns': np.asarray(capture_time_ns)[stale_index],
            prefix+'source_start_ns': start, prefix+'source_end_ns': end})
        label_audit[split] = {'action_reconstruction_max_absolute_difference': float(error.max()),
            'action_reconstruction_max_allowed_bound': float(bound.max()),
            'current_image_age_from_cutoff_minutes': _range((data['time_ns'][rows]-MINUTE_NS-np.asarray(capture_time_ns)[fresh_index])/MINUTE_NS),
            'stale_image_age_from_cutoff_minutes': _range((data['time_ns'][rows]-MINUTE_NS-np.asarray(capture_time_ns)[stale_index])/MINUTE_NS),
            'current_unique_captures': len(np.unique(fresh_index)), 'stale_unique_captures': len(np.unique(stale_index)),
            'source_start_ns': int(start.min()), 'source_end_ns': int(end.max())}
    thermal_threshold = float(np.quantile(arrays['train_thermal_magnitude'], thermal_quantile, method='linear'))
    thresholds, active_counts = [], []
    for j in range(8):
        values = arrays['train_action_magnitudes'][:, j]
        active = values[values > tolerance]
        active_counts.append(len(active))
        thresholds.append(float(np.quantile(active, action_quantile, method='linear')) if len(active) else None)
    for split in PARTITIONS:
        arrays[split+'_thermal_change'] = (arrays[split+'_thermal_magnitude'] > thermal_threshold).astype(np.int8)
        mask = np.zeros_like(arrays[split+'_action_magnitudes'], dtype=bool)
        for j, value in enumerate(thresholds):
            if value is not None:
                mask[:, j] = (arrays[split+'_action_magnitudes'][:, j] > tolerance) & (arrays[split+'_action_magnitudes'][:, j] >= value)
        arrays[split+'_action_channel_trigger'] = mask
        arrays[split+'_action_change'] = mask.any(axis=1).astype(np.int8)
        label_audit[split]['labels'] = {task: {'positive': int(arrays[split+'_'+task].sum()),
            'negative': int(len(arrays[split+'_'+task])-arrays[split+'_'+task].sum()),
            'prevalence': float(arrays[split+'_'+task].mean())} for task in ('thermal_change','action_change')}
    metadata = {'feature_dimensions': FEATURE_DIMENSIONS,
        'numeric_columns': numeric_columns,
        'thresholds': {'source': 'final common training origins only',
            'thermal_quantile': thermal_quantile, 'thermal_abs_temperature_change_degC': thermal_threshold,
            'thermal_comparison': 'strictly greater than threshold',
            'action_quantile': action_quantile, 'action_nonzero_tolerance': tolerance,
            'action_per_channel_threshold': thresholds, 'action_nonzero_training_count': active_counts,
            'action_comparison': 'any abs(delta)>tolerance and abs(delta)>=channel threshold',
            'action_channel_names': list(MV_NAMES)},
        'partitions': {split: {**counts[split], **label_audit[split]} for split in PARTITIONS}}
    return arrays, metadata


def _range(values):
    return {'min': float(np.min(values)), 'median': float(np.median(values)), 'max': float(np.max(values))}


def prepare_data(config, outdir):
    """Write immutable data, provenance, and training-only label thresholds."""
    project = Path(config.get('project_root', Path(__file__).resolve().parents[1])).resolve()
    source = project / config.get('source_run', 'experiment_runs/corrected_vision')
    visual = project / config.get('visual_study', 'experiment_runs/visual_representation_20261104')
    descriptors = project / config.get('descriptor_study', 'experiment_runs/visual_information_20261104')
    out = Path(outdir).resolve()
    names = ('prepared.npz', 'source_records.npz', 'input_hashes.json', 'preparation.json')
    if any((out/name).exists() for name in names):
        raise FileExistsError('prepared diagnostic artifacts are immutable; use a new output directory')
    data, stats, _ = load_data(source/'data')
    _check_data(data, stats)
    inputs = [source/'data'/name for name in ('dataset.npz','stats.json','manifest.json')]
    with threadpool_limits(limits=int(config.get('threads', 2))):
        design, _, mapping, _, feature_metadata, _, visual_files, visual_info = _visual_inputs(data, visual, descriptors, inputs)
        embedded, pca = _archive(visual/'embeddings.npz'), _archive(visual/'probe/pca_rgb.npz')
        capture_rgb = (np.asarray(embedded['rgb'], dtype=np.float64) - pca['mean']) @ pca['components'].T
        # Include the four timing features' actual capture sources in the
        # conservative original numeric/descriptor source envelopes.
        source_start = np.minimum(data['source_start_ns'], feature_metadata['variant_source_start_ns_timing4'])
        source_end = np.maximum(data['source_end_ns'], feature_metadata['variant_source_end_ns_timing4'])
        ranged = dict(data, source_start_ns=source_start, source_end_ns=source_end)
        arrays, metadata = build_prepared(ranged, design, embedded['capture_time_ns'], mapping, capture_rgb, config)
    hashes = {str(path.resolve()):sha256(path) for path in [*inputs, *visual_files]}
    out.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(out/'prepared.npz', **arrays)
    np.savez_compressed(out/'source_records.npz', time_ns=data['time_ns'], source_start_ns=source_start,
        source_end_ns=source_end, capture_time_ns=embedded['capture_time_ns'], sample_capture_index=mapping,
        **{split+'_idx':data[split+'_idx'] for split in PARTITIONS})
    for path, digest in hashes.items():
        if sha256(path) != digest: raise ValueError('input changed during preparation: '+path)
    write_json(out/'input_hashes.json', hashes)
    record = {'status':'complete', 'schema_version':1, **metadata,
        'prepared_sha256':sha256(out/'prepared.npz'), 'source_records_sha256':sha256(out/'source_records.npz'),
        'visual':visual_info, 'input_hashes':hashes,
        'feature_columns': {'numeric':[0,219], 'quality_extra':[219,235], 'rgb_or_stale_extra':[235,267],
            'timing_columns':['capture_age_minutes','log1p_capture_count10m','capture_span10m_minutes','has_two_captures10m'],
            'quality_columns':visual_info['quality_columns'],
            'rgb_columns':[f'fixed_train_pca_rgb_{j}' for j in range(32)]},
        'decision_time':'t; CV_t measured and available. Histories end at t, images are at or before t-1 minute.',
        'numerical_summary':'Four physical quantities from CV t-10..t: signed changes at1/5/10 minutes, their absolute values, population standard deviation and range; same32 features in every variant.',
        'thermal_task':'maximum absolute mean-furnace-temperature movement during t+1..t+5 from measured T_t; not a safety/danger label',
        'action_task':'any large recorded next-minute MV change; no claim of manual operator provenance or optimality',
        'stale_control':'latest same-partition encoded capture at or before (t-1)-60 minutes, at most70 minutes old from t-1; current timing and quality features unchanged',
        'selection':'all complete six-row chains with causal stale-image availability; no label/error-based inclusion',
        'source_policy':'conservative original source intervals plus timing captures, stale capture, and all six rows including future outcome sources; no shared sources across splits',
        'action_precision':'source action differs raw recorded MVs before float32 histories are saved; comparison allows only eps32*(abs(current)+abs(next)+1) input-quantization bound',
        'test_scope':'previously inspected period; preparation stores labels and prevalences but does not train, select or score any predictor',
        'inherited_null_features':'prior validation helper also verifies old negative-control artifacts; none of those null vectors enters this study'}
    write_json(out/'preparation.json', record)
    return record
