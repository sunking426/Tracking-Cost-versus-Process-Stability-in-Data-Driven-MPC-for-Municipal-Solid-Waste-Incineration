"""Common frozen-start, 50-step evaluation; first ten steps are primary."""
from __future__ import annotations
import argparse
import json
import time
from pathlib import Path
import numpy as np
import torch
from threadpoolctl import threadpool_limits
from .ridge_policy_study import OUT, REF, ROOT, MODELS, GROUPS, SEEDS, read_npz, write_json, sha, shared
from .ridge_policy import RidgePolicyEnv
from .ridge_dynamics import RidgeDynamics
from .ridge_control_probe import bc_request, grid_plan, FIXED
from .ridge_response import analytic_responses
from .ridge_policy_planning import CEMPlanner
from .ridge_policy_training import load_actor, mode_for

BASELINES=('hold','linear_bc','grid_mpc','cem_mpc')

def actor_path(group,seed):
    return OUT/f'models/{"bc_full" if group=="bc" else group}/seed{seed}/actor.pt'

class DecisionPolicy:
    def __init__(self,group,seed,planner,execution,context):
        self.group=group;self.execution=execution;self.context=context;self.planner=planner
        self.actor=load_actor(actor_path(group,seed)) if group in GROUPS else None
        self.bc=read_npz(REF/'models/linear_bc.npz') if group=='linear_bc' else None
        self.kernel=analytic_responses(planner,10)['step'] if group=='grid_mpc' else None
        self.cem=CEMPlanner(planner,execution) if group=='cem_mpc' else None

    def decide(self,env,state,step):
        if self.actor is not None:
            with torch.no_grad():b=self.actor(torch.from_numpy(state)).numpy()
            return self.execution.request(b),{}
        if self.group=='hold':return np.zeros((len(env.u),8)),{}
        if self.group=='linear_bc':return bc_request(self.bc,env.u,env.z,env.current,self.execution.stats,FIXED),{}
        if self.group=='grid_mpc':
            return grid_plan(self.planner,self.kernel,env.u,env.z,env.current,env.times,self.execution.support.values,self.execution.stats,FIXED)
        return self.cem.plan(env.u,env.z,env.current,env.times,env.indices,step)

def rollout(split,mid,group,seed):
    path=OUT/f'trajectories/{split}/{mid}/{group}/seed{seed}.npz'
    if path.exists() and path.with_suffix('.json').exists():return
    path.parent.mkdir(parents=True,exist_ok=True)
    stats,execution,context,planner=shared();policy=DecisionPolicy(group,seed,planner,execution,context)
    model=RidgeDynamics.load(REF/f'evaluation_models/{mid}.npz');inputs=read_npz(REF/f'inputs/{split}.npz')
    env=RidgePolicyEnv(model,execution,context if group in GROUPS else None,horizon=50,visual_mode=mode_for(group))
    state,_=env.reset(options={'inputs':inputs});buffers={};start=time.perf_counter()
    for step in range(50):
        donor=env.last_donors.copy() if group in GROUPS else None
        request,diagnostics=policy.decide(env,state,step)
        state,reward,terminated,truncated,info=env.step_request(request)
        if terminated.any() or truncated.all()!=(step==49):raise AssertionError('evaluation terminal semantics')
        if donor is not None:info['visual_donor']=donor
        info.update(diagnostics)
        for k,v in info.items():buffers.setdefault(k,[]).append(v)
        if group=='cem_mpc' and (step+1)%10==0:print('CEM progress',split,mid,step+1,'seconds',round(time.perf_counter()-start,1),flush=True)
    arrays={k:np.stack(v,axis=1) for k,v in buffers.items()}
    arrays.update(indices=inputs['indices'],time_ns=inputs['time_ns'],initial_u=inputs['u_hist'][:,-1],initial_z_current=inputs['z_current'])
    for k,v in arrays.items():
        if np.issubdtype(v.dtype,np.number) and not np.isfinite(v).all():raise FloatingPointError('trajectory '+k)
    temp=path.with_suffix('.partial.npz');np.savez_compressed(temp,**arrays);temp.replace(path)
    elapsed=time.perf_counter()-start
    write_json(path.with_suffix('.json'),{'group':group,'seed':seed,'split':split,'model':mid,'horizon':50,'episodes':256,
        'elapsed_seconds':elapsed,'primary_return':float(arrays['reward'][:,:10].astype(float).sum(1).mean()),
        'secondary_return':float(arrays['reward'].astype(float).sum(1).mean()),'sha256':sha(path),
        'support_certificates':policy.cem.support.counts if policy.cem is not None else None})
    print('evaluated',split,mid,group,seed,'seconds',round(elapsed,2),flush=True)

def freeze_evaluation():
    if json.loads((OUT/'environment_compatibility.json').read_text())['status']!='passed':raise RuntimeError('compatibility gate')
    # Missing prose implementation details are set before new control outcomes.
    note={'cem_initial_gaussian_mean':'shifted warm requested plan; zeros at episode reset',
        'cem_score_accumulation':'float64 sum of ten canonical float32 step rewards',
        'optimization':'exact Euclidean membership certificates and affine step-response superposition; tested against canonical recursive environment',
        'no_changed_scientific_settings':True}
    files=[Path(__file__),ROOT/'mswi_experiments/ridge_policy_planning.py']
    value={'code':{str(p):sha(p) for p in files},'implementation_notes':note}
    path=OUT/'evaluation_code_hashes.json'
    if path.exists() and json.loads(path.read_text())!=value:raise AssertionError('evaluation implementation changed after freeze')
    if not path.exists():write_json(path,value)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['baselines','learned','cem']);args=parser.parse_args()
    torch.set_num_threads(4)
    with threadpool_limits(4):
        freeze_evaluation()
        groups=GROUPS if args.stage=='learned' else ('cem_mpc',) if args.stage=='cem' else BASELINES[:3]
        for split in ('val','test'):
            for mid in MODELS:
                for group in groups:
                    for seed in SEEDS if group in GROUPS else (0,):rollout(split,mid,group,seed)

if __name__=='__main__':main()
