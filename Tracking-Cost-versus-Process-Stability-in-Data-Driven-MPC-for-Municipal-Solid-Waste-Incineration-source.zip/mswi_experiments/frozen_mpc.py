"""Read the sole frozen main-MPC configuration and verify its bound artifacts.

Future evaluation runners must record the returned parent hash. Named ablation
changes belong in separate child protocols, never in this frozen configuration.
No controller, model, or experiment is executed by this loader.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
C_CONFIG=ROOT/'experiment_protocols/mpc_C_frozen_20261107/config.json'
C_SHA256='37c689910f725b8f33d2c6ca4c4889ee84df293dc0c7469e13cec355f59e840c'


def file_sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_frozen_mpc(path=C_CONFIG,expected_sha256=C_SHA256,*,root=ROOT):
    path=Path(path)
    if file_sha256(path)!=expected_sha256:raise ValueError('frozen C configuration hash mismatch')
    config=json.loads(path.read_text())
    if config['schema_version']!=1 or config['status']!='main_configuration_frozen':
        raise ValueError('unsupported or unfrozen main configuration')
    for relative,expected in config['dependencies'].items():
        dependency=(Path(root)/relative).resolve()
        dependency.relative_to(Path(root).resolve())
        if file_sha256(dependency)!=expected:raise ValueError('frozen C dependency changed: '+relative)
    return config
