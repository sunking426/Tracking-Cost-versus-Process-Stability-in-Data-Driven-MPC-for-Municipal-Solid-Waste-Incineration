"""Sealed validation-only lambda scan; result review precedes any main refreeze."""
from __future__ import annotations
import argparse,datetime,json,shutil,time
from pathlib import Path
import numpy as np
import torch
from threadpoolctl import threadpool_limits
from .frozen_mpc import ROOT,load_frozen_mpc,file_sha256
from .ridge_policy_study import read_npz,write_json
from .ridge_policy import Execution,RidgePolicyEnv
from .ridge_dynamics import RidgeDynamics
from .mpc_stability import StabilityCEM
DESIGN=ROOT/'experiment_protocols/mpc_stability_v2_20261108'
OUT=ROOT/'experiment_runs/mpc_stability_v2_20261108'
REF=ROOT/'experiment_runs/ridge_control_probe_20261106'
OLD=ROOT/'experiment_runs/mpc_temperature_20261107'
PRIOR=ROOT/'experiment_runs/ridge_policy_pipeline_20261107'
MODELS=('early','middle','late','pooled_matched');WEIGHTS=(1,2,4,8);SEEDS=(11,23,37,53,71)
SAMPLE_KEYS=('u_hist','z_hist','z_current','time_ns','indices')
PROTOCOL_SHA='7bc52ca3cbbea341b6666e60980dd04c8582161fe4177e6102f720e1a49625fd'


def protocol():
    if file_sha256(DESIGN/'protocol.json')!=PROTOCOL_SHA:raise AssertionError('study protocol changed')
    return json.loads((DESIGN/'protocol.json').read_text())

def verify_sources():
    protocol();load_frozen_mpc()
    for path,digest in json.loads((DESIGN/'source_bindings.json').read_text()).items():
        if file_sha256(ROOT/path)!=digest:raise AssertionError('source changed: '+path)

def shared():
    parent=load_frozen_mpc();stats=json.loads((REF/'stats.json').read_text())
    return parent,Execution(stats,read_npz(REF/'support.npz')),RidgeDynamics.load(ROOT/parent['planner']['checkpoint'])

def prepare():
    verify_sources()
    if (OUT/'trajectories').exists():raise AssertionError('readiness must precede new outcomes')
    for name in ('protocol.json','source_bindings.json','AMENDMENT_zh.txt'):shutil.copy2(DESIGN/name,OUT/name)
    inputs=read_npz(REF/'inputs/val.npz');parent,e,full=shared();planner=StabilityCEM(full,e,0,parent)
    env=RidgePolicyEnv(full,e,horizon=50);env.reset(options={'inputs':inputs})
    old=read_npz(OLD/'trajectories/C/full.npz');checks=[]
    for step in range(3):
        request,diag=planner.plan(env.u,env.z,env.current,env.times,env.indices,step)
        _,_,_,_,info=env.step_request(request)
        for k in ('pred_cv','u_path','requested_action','executed_action','reward'):np.testing.assert_array_equal(info[k],old[k][:,step])
        for k in old:
            if k in diag:np.testing.assert_array_equal(diag[k],old[k][:,step])
        checks.append(dict(step=step,all_shared_planner_and_feedback_fields_bitwise_equal=True))
    write_json(OUT/'compatibility_before_run.json',dict(status='passed',starts=256,steps=3,checks=checks))
    print('lambda0 compatibility passed:256 starts x3 decisions',flush=True)


def freeze():
    verify_sources()
    if json.loads((OUT/'compatibility_before_run.json').read_text())['status']!='passed':raise AssertionError('readiness')
    files=[ROOT/'mswi_experiments'/n for n in ('mpc_stability.py','mpc_stability_study.py','mpc_stability_report.py')]
    files+=[ROOT/'tests/test_mpc_stability.py',DESIGN/'protocol.json',DESIGN/'source_bindings.json',DESIGN/'AMENDMENT_zh.txt']
    hashes={str(p.relative_to(ROOT)):file_sha256(p) for p in files};path=OUT/'implementation_frozen.json'
    if path.exists():
        if json.loads(path.read_text())['hashes']!=hashes:raise AssertionError('implementation changed after freeze')
    else:
        write_json(path,dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),hashes=hashes))
        deps=[ROOT/p for p in json.loads((DESIGN/'source_bindings.json').read_text()) if p.startswith('mswi_experiments/')]
        for p in files+deps:
            dest=OUT/'code_snapshot'/p.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)


def run_case(weight,mid):
    path=OUT/f'trajectories/S{weight}/{mid}.npz'
    if path.exists():
        if file_sha256(path)!=json.loads(path.with_suffix('.json').read_text())['sha256']:raise AssertionError('existing result hash')
        return
    parent,e,full=shared();planner=StabilityCEM(full,e,weight,parent)
    env=RidgePolicyEnv(RidgeDynamics.load(REF/f'evaluation_models/{mid}.npz'),e,horizon=50)
    inputs=read_npz(REF/'inputs/val.npz');env.reset(options={'inputs':inputs});buffers={};begin=time.perf_counter()
    for step in range(50):
        request,diag=planner.plan(env.u,env.z,env.current,env.times,env.indices,step)
        _,_,done,cut,info=env.step_request(request)
        if done.any() or cut.all()!=(step==49):raise AssertionError('truncation semantics')
        info.update(diag)
        for k,v in info.items():buffers.setdefault(k,[]).append(v)
        if (step+1)%10==0:print('S'+str(weight),mid,'step',step+1,'seconds',round(time.perf_counter()-begin,1),flush=True)
    arrays={k:np.stack(v,axis=1) for k,v in buffers.items()}
    arrays.update(indices=inputs['indices'],time_ns=inputs['time_ns'],initial_u=inputs['u_hist'][:,-1],initial_z_current=inputs['z_current'])
    for k,v in arrays.items():
        if np.issubdtype(v.dtype,np.number) and not np.isfinite(v).all():raise FloatingPointError(k)
    path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix('.partial.npz');np.savez_compressed(tmp,**arrays);tmp.replace(path)
    write_json(path.with_suffix('.json'),dict(stability_weight=weight,model=mid,episodes=256,horizon=50,split='val',
        sha256=file_sha256(path),elapsed_seconds=time.perf_counter()-begin,source_protocol_sha256=PROTOCOL_SHA,
        parent_C_sha256=protocol()['parent']['sha256'],support_certificate_counts=planner.support.counts))
    print('complete','S'+str(weight),mid,flush=True)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=('prepare','freeze','run'));parser.add_argument('--shard',type=int,default=0);parser.add_argument('--shards',type=int,default=1)
    args=parser.parse_args();torch.set_num_threads(4)
    with threadpool_limits(4):
        if args.stage=='prepare':prepare()
        elif args.stage=='freeze':freeze()
        else:
            if not 0<=args.shard<args.shards:raise ValueError('shard')
            freeze()
            for w,m in [(w,m) for w in WEIGHTS for m in MODELS][args.shard::args.shards]:run_case(w,m)
if __name__=='__main__':main()
