"""Read-only paired-start analysis of the prospective S8 layer ablations."""
import json,datetime
from pathlib import Path
import numpy as np
from threadpoolctl import threadpool_limits
from .s8_ablation_study import ROOT,OUT,DESIGN,REF,CROSS,OLD,MODELS,verify
from .s8_cross_report import NAMES,VARIABLES,metric_values,bootstrap_weights,csv_write
from .ridge_policy_study import read_npz,write_json,OUT as POLICY,SEEDS
from .frozen_mpc import file_sha256

BEHAVIOR=('blocked_fraction','blocked_fraction_nonzero_requests','unsupported_request_fraction',
    'incomplete_request_fraction','nonzero_request_fraction')+tuple(f'{k}_MV{j}' for k in ('net_change','absolute_cumulative_change','nonzero_action_fraction') for j in range(8))
ALL_NAMES=NAMES+BEHAVIOR


def path_for(layer,mid,method,seed=0,rep=0):
    if method in ('hold','bc'):
        return CROSS/f'trajectories/C/{mid}/{method}/seed{seed}_rep{rep}.npz' if layer=='C' else POLICY/f'trajectories/val/{mid}/{method}/seed{seed}.npz'
    if method=='S8' and layer=='C':return CROSS/f'trajectories/C/{mid}/S8/seed0_rep{rep}.npz'
    if method=='S8' and layer=='D':return OLD/f'trajectories/S8/{mid}.npz'
    return OUT/f'trajectories/{layer}/{mid}/{method}/rep{rep}.npz'


def behavior(a,h):
    req=np.any(a['requested_action'][:,:h]!=0,axis=2);blocked=a['blocked_nonzero'][:,:h]
    numerator=blocked.sum(1);denom=req.sum(1)
    # No requested action: interception proportion defined as zero; counts reported in audit.
    conditional=np.divide(numerator,denom,out=np.zeros(len(req),dtype=float),where=denom!=0)
    phys=a['physical_executed_action'][:,:h]
    return np.column_stack((blocked.mean(1),conditional,(req&~a['proposal_supported'][:,:h]).mean(1),
        (req&~a['proposal_full_execution'][:,:h]).mean(1),req.mean(1),
        a['u_path'][:,h-1]-a['initial_u'],abs(phys).sum(1),(abs(phys)>1e-10).mean(1)))


def collect(methods,overrides=None):
    inputs=read_npz(REF/'inputs/val.npz');data={};bindings={};audit=[]
    for layer in ('P','D','C'):
        for mid in ('full',) if layer=='P' else MODELS:
            for method in ('hold','bc')+methods:
                by_h={h:[] for h in ((10,) if layer=='P' else (10,50))}
                for seed in SEEDS if method=='bc' else (0,):
                    for rep in range(5) if layer=='C' else (0,):
                        p=path_for(layer,mid,method,seed,rep)
                        if overrides:p=overrides.get(p,p)
                        a=read_npz(p);digest=file_sha256(p)
                        if p.with_suffix('.json').exists():
                            meta=json.loads(p.with_suffix('.json').read_text())
                            if 'sha256' in meta and meta['sha256']!=digest:raise AssertionError('input hash changed')
                        bindings[str(p.relative_to(ROOT))]=digest
                        for h in by_h:
                            v,detail=metric_values(a,inputs,h);b=behavior(a,h)
                            by_h[h].append(np.column_stack((v,b)))
                            audit.append(dict(layer=layer,model=mid,method=method,seed=seed,replicate=rep,horizon=h,
                                no_nonzero_request_starts=int((~np.any(a['requested_action'][:,:h]!=0,(1,2))).sum()),**detail))
                for h,values in by_h.items():data[layer,mid,method,h]=np.mean(values,axis=0)
    return data,bindings,audit


def interval(a,w):
    m=np.mean(a,axis=0);lo,hi=np.quantile(w@a,[.025,.975],axis=0)
    return m,lo,hi


def primary(data,methods,w):
    result=[];categories={};ri=ALL_NAMES.index('original_return')
    si=[ALL_NAMES.index('detrended_sd_'+v) for v in VARIABLES]
    for mid in MODELS:
        hold_plan=data['P','full','hold',10][:,ri];hold_eval=data['D',mid,'hold',10][:,ri]
        bc=data['C',mid,'bc',10][:,si];denom=bc.mean(0);denom_boot=w@bc
        base_plan=data['P','full','S8',10][:,ri]-hold_plan
        base_eval=data['D',mid,'S8',10][:,ri]-hold_eval
        base_gap=base_plan-base_eval
        base=data['C',mid,'S8',10][:,si];base_stab=(base.mean(0)/denom).mean()
        base_stab_boot=((w@base)/denom_boot).mean(1)
        for method in methods:
            plan=data['P','full',method,10][:,ri]-hold_plan
            ev=data['D',mid,method,10][:,ri]-hold_eval;gap=plan-ev
            sd=data['C',mid,method,10][:,si];stab=(sd.mean(0)/denom).mean()
            stab_boot=((w@sd)/denom_boot).mean(1)
            row=dict(model=mid,method=method)
            for label,values in [('G_plan',plan),('G_eval',ev),('gap',gap),('gap_minus_S8',gap-base_gap)]:
                m,lo,hi=interval(values,w);row.update({label:float(m),label+'_ci_low':float(lo),label+'_ci_high':float(hi)})
            for label,value,boot in [('stability_ratio',stab,stab_boot),('stability_ratio_minus_S8',stab-base_stab,stab_boot-base_stab_boot)]:
                lo,hi=np.quantile(boot,[.025,.975]);row.update({label:float(value),label+'_ci_low':float(lo),label+'_ci_high':float(hi)})
            dg=row['gap_minus_S8'];ds=row['stability_ratio_minus_S8']
            category='value' if (dg>0 and ds>=0) or (ds>0 and dg>=0) else 'tradeoff' if dg*ds<0 else 'not_demonstrated'
            row['classification']=category if method!='S8' else 'reference';result.append(row)
    for method in methods:
        if method=='S8':continue
        rows=[r for r in result if r['method']==method]
        counts={k:sum(r['classification']==k for r in rows) for k in ('value','tradeoff','not_demonstrated')}
        outcome=next((k for k,v in counts.items() if v>=3),'inconsistent')
        categories[method]=dict(classification=outcome,counts=counts)
    return result,categories


def tables(data,w):
    summaries=[];contrasts=[];ratios=[]
    for (layer,mid,method,h),v in data.items():
        mean,lo,hi=interval(v,w)
        for j,name in enumerate(ALL_NAMES):summaries.append(dict(layer=layer,model=mid,method=method,horizon=h,metric=name,
            mean=float(mean[j]),ci_low=float(lo[j]),ci_high=float(hi[j])))
        for ref in ('hold','bc','S8'):
            if method in ('hold','bc') or method==ref:continue
            delta=v-data[layer,mid,ref,h];mean,lo,hi=interval(delta,w)
            for j,name in enumerate(ALL_NAMES):contrasts.append(dict(layer=layer,model=mid,method=method,reference=ref,horizon=h,metric=name,
                difference=float(mean[j]),ci_low=float(lo[j]),ci_high=float(hi[j])))
        for kind in ('detrended_sd','raw_sd'):
            for var in VARIABLES:
                name=kind+'_'+var;j=ALL_NAMES.index(name);b=data[layer,mid,'bc',h][:,j]
                val=v[:,j].mean()/b.mean();lo,hi=np.quantile((w@v[:,j])/(w@b),[.025,.975])
                ratios.append(dict(layer=layer,model=mid,method=method,horizon=h,metric=name,ratio_to_BC=float(val),ci_low=float(lo),ci_high=float(hi)))
    return summaries,contrasts,ratios


def by_model(rows,folder):
    """Convenience view of the same estimates, with models in separate columns."""
    grouped={}
    for row in rows:
        key=tuple(row[k] for k in ('layer','method','horizon','metric'))
        target=grouped.setdefault(key,dict(zip(('layer','method','horizon','metric'),key)))
        for field in ('mean','ci_low','ci_high'):target[row['model']+'_'+field]=row[field]
    # P has only full; D/C have the four evaluation models.
    for layer in ('P','D','C'):
        csv_write(folder/f'metrics_by_model_{layer}.csv',[r for r in grouped.values() if r['layer']==layer])


def replay_sensitivity(qc,folder):
    """Quantify computational replay changes; do not treat reruns as samples."""
    inp=read_npz(REF/'inputs/val.npz');changes={}
    for row in qc['checks']:
        if row['resolution']!='adopt_matching_independent_pair':continue
        p=OUT/row['case'];meta=json.loads(p.with_suffix('.json').read_text())
        a=read_npz(OUT/row['quarantined_original']);b=read_npz(p)
        for h in (10,) if meta['layer']=='P' else (10,50):
            before=np.column_stack((metric_values(a,inp,h)[0],behavior(a,h)))
            after=np.column_stack((metric_values(b,inp,h)[0],behavior(b,h)))
            key=(meta['layer'],meta['model'],meta['method'],h)
            changes.setdefault(key,np.zeros_like(after))
            changes[key]+=(after-before)/(5 if meta['layer']=='C' else 1)
    rows=[]
    for (layer,mid,method,h),diff in changes.items():
        for j,name in enumerate(ALL_NAMES):
            rows.append(dict(layer=layer,model=mid,method=method,horizon=h,metric=name,
                final_minus_initial_mean=float(diff[:,j].mean()),
                maximum_absolute_per_start_change=float(abs(diff[:,j]).max()),
                changed_starts=int(np.count_nonzero(diff[:,j]))))
    if rows:csv_write(folder/'numerical_replay_sensitivity.csv',rows)
    write_json(folder/'numerical_replay_sensitivity.json',dict(replaced_cases=qc['replacement_cases'],
        all_H10_reported_metrics_unchanged=all(r['maximum_absolute_per_start_change']==0 for r in rows if r['horizon']==10),
        interpretation='Computational repeatability check, not extra experimental samples or a controller selection.'))


def plots(rows,ratios,methods,folder):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    colors=['#1f77b4','#ff7f0e','#2ca02c','#d62728'];width=.8/len(methods)
    fig,ax=plt.subplots(figsize=(9,4.8))
    for j,(method,color) in enumerate(zip(methods,colors)):
        items=[next(r for r in rows if r['model']==m and r['method']==method) for m in MODELS]
        x=np.arange(4)+(j-(len(methods)-1)/2)*width;y=[r['gap'] for r in items]
        ax.bar(x,y,width*.93,label=method,color=color)
        ax.vlines(x,[r['gap_ci_low'] for r in items],[r['gap_ci_high'] for r in items],color='black',lw=1)
    ax.axhline(0,color='gray',lw=.7);ax.set_xticks(range(4),MODELS);ax.set_ylabel('Planning gain minus evaluation gain');ax.set_title('Deterministic 10-step planning–evaluation gap');ax.legend();ax.grid(axis='y',alpha=.15)
    fig.tight_layout();fig.savefig(folder/'planning_evaluation_gap.png',dpi=200);fig.savefig(folder/'planning_evaluation_gap.pdf');plt.close(fig)
    fig,axes=plt.subplots(2,2,figsize=(10,7),sharey=True)
    for mid,ax in zip(MODELS,axes.flat):
        for j,(method,color) in enumerate(zip(methods,colors)):
            items=[next(r for r in ratios if (r['layer'],r['model'],r['method'],r['horizon'],r['metric'])==('C',mid,method,10,'detrended_sd_'+v)) for v in VARIABLES]
            x=np.arange(3)+(j-(len(methods)-1)/2)*width
            ax.scatter(x,[r['ratio_to_BC'] for r in items],s=24,label=method,color=color,zorder=3)
            ax.vlines(x,[r['ci_low'] for r in items],[r['ci_high'] for r in items],color=color,lw=1.3)
            ax.scatter(x,[r['ci_low'] for r in items],marker='_',color=color,s=24)
            ax.scatter(x,[r['ci_high'] for r in items],marker='_',color=color,s=24)
        ax.axhline(1,color='gray',ls='--',lw=1);ax.set_xticks(range(3),['Temperature','Steam','Oxygen']);ax.set_title(mid);ax.grid(axis='y',alpha=.15)
        ax.set_ylabel('Detrended SD / BC')
    axes[0,0].legend();fig.suptitle('Residual-injected 10-step stability (paired 95% intervals)');fig.tight_layout()
    fig.savefig(folder/'stability_ratios.png',dpi=200);fig.savefig(folder/'stability_ratios.pdf');plt.close(fig)


def readout(rows,categories,contrasts,ratios,trigger,qc,folder):
    labels={'value':'有价值','tradeoff':'存在取舍','not_demonstrated':'未体现价值','inconsistent':'证据不一致，未达到3/4同类规则'}
    lines=['S8通道/状态层消融结果','仅验证集；配置未调参；未执行GRU、测试集或论文修改。','',
        '一、验收与预算','256起点×50步主配置和额外六维固定为零的D1均通过旧S8逐值复现。所有扰动及原两通道候选噪声核验一致。',
        '完整Ridge的原始10步回报：S8 %.8f，D1 %.8f，差 %.8f；4倍预算触发：%s。'%(trigger['main_original_return'],trigger['D1_original_return'],trigger['difference'],trigger['trigger_D1_512']),
        '', '二、主要终点（消融减S8；正值表示变差）','配置 | 模型 | 落差变化 [95%区间] | 稳定性比值变化 [95%区间] | 模型内分类']
    for r in rows:
        if r['method']=='S8':continue
        lines.append('%s | %s | %.6f [%.6f, %.6f] | %.6f [%.6f, %.6f] | %s'%(r['method'],r['model'],r['gap_minus_S8'],r['gap_minus_S8_ci_low'],r['gap_minus_S8_ci_high'],r['stability_ratio_minus_S8'],r['stability_ratio_minus_S8_ci_low'],r['stability_ratio_minus_S8_ci_high'],labels[r['classification']]))
    lines+=['','确定性H10原始回报差（消融减S8；正值表示回报提高，与上表两个终点的方向不同）','配置 | 模型 | 回报差 [95%区间]']
    for method in categories:
        for mid in MODELS:
            r=next(r for r in contrasts if (r['layer'],r['model'],r['method'],r['reference'],r['horizon'],r['metric'])==('D',mid,method,'S8',10,'original_return'))
            lines.append('%s | %s | %.6f [%.6f, %.6f]'%(method,mid,r['difference'],r['ci_low'],r['ci_high']))
    lines+=['','三、按预设逐层判定']
    for method,c in categories.items():lines.append(f"{method}：{labels[c['classification']]}；模型计数 {c['counts']}。判定按均值，区间仅展示不确定性。")
    for method in categories:
        subset=[r for r in rows if r['method']==method]
        gap_supported=sum(r['gap_minus_S8_ci_low']>0 or r['gap_minus_S8_ci_high']<0 for r in subset)
        stability_supported=sum(r['stability_ratio_minus_S8_ci_low']>0 or r['stability_ratio_minus_S8_ci_high']<0 for r in subset)
        lines.append(f'{method}：落差变化区间不含零 {gap_supported}/4，稳定性比值变化区间不含零 {stability_supported}/4。不能将均值分类等同于所有组成终点均已得到明确支持。')
    if 'D1_512' in categories and categories['D1']['classification']!=categories['D1_512']['classification']:
        lines.append('通道层结论随搜索预算变化，存在预算混杂，不能把低预算消融结果单独作为可信度设计有效的证据。')
    choice=json.loads((DESIGN/'D2_choice.json').read_text())
    lines.append('D2准入方式：'+choice['admission']+'；'+choice['interpretation'])
    lines+=['','四、安全和压力测试：差值为消融减S8，必须独立于主终点看待','配置 | 模型 | H10高温比例差(pp) | H50低氧比例差(pp) | H50低温测点×步数差/轨迹']
    for method in categories:
        for mid in MODELS:
            def get(h,name):return next(r['difference'] for r in contrasts if (r['layer'],r['model'],r['method'],r['reference'],r['horizon'],r['metric'])==('C',mid,method,'S8',h,name))
            lines.append('%s | %s | %.4f | %.4f | %.4f'%(method,mid,100*get(10,'any_high1050_fraction'),100*get(50,'oxygen_low3p5_fraction'),get(50,'point_low850_count')))
    lines+=['','五、重复核验和异常留痕',
        f"D1、D2与D1_512共{len(qc['checks'])}个批次均有独立重复执行证据；按已记录的质量控制规则，替换工作副本{len(qc['replacement_cases'])}个。",
        '被替换的初次结果完整保存在quarantine_originals中。仅在两次独立重跑的所有数组一致时采用重跑结果，未按性能优劣选择；重复执行不增加统计样本量。',
        '初次执行曾出现评分一致性断言失败及少量轨迹差异，其中有两批状态差异分别从第1步和第6步开始、影响10步主终点，根因尚未确定，两类异常是否同源也未证实。上述核验支持当前归档结果的复现，不等于证明所有运行环境下都能逐位复现。',
        '一次失败现场的整批奖励，可由跟踪成本数组中连续16 KiB内容置零精确重构；捕获输入连续重算200次均正常。另一次现场的候选执行动作副本中16 KiB为零，但重算状态预测和逐步奖励均与现场一致，执行动作的该块不同。此证据用于说明运行异常，不用于归因于某一操作系统或数值库。降低到四进程后仍出现过异常，不能宣称已修复；原控制算法与断言均未修改。',
        'D/early/D1_512的第一次与第二次独立重放也不一致。停止采用结果并重建首次分歧决策后，另按事先保存的恢复记录完成第三次重放；仅在第二、三次完整数组一致时采用该连续配对，前三份记录均保留。']
    for r in qc['checks']:
        if r['resolution']=='adopt_matching_independent_pair':
            d=r['comparison']
            if d['first_changed_state_step_one_based'] is None:
                changed=[k for k,v in d['fields_equal'].items() if not v]
                lines.append(f"{r['case']}：状态轨迹一致；其他差异字段为{changed}。报告指标的变化见numerical_replay_sensitivity。")
            else:
                lines.append(f"{r['case']}：初次结果与复核结果的首个状态差异在第{d['first_changed_state_step_one_based']}步，涉及{d['changed_state_start_count']}个起点；十步全部字段一致：{d['first10_all_fields_equal']}。")
    lines+=['','六、解读边界',
        '有符号规划—评价落差不是模型误差利用的唯一指标；模型响应差异、行动范围与搜索效率均可能影响它。',
        'D1保留原两通道固定候选，并在全八维随机搜索；同预算不能保证八维问题同等接近最优。',
        '支持过滤只阻止不受支持的非零请求，零动作仍放行，不保证整条轨迹处于训练支持域。',
        '短时域模型内去趋势标准差不代表现场长期稳定性，50步只作压力测试。绝对累计动作与净变化、请求拦截率的不同分母均单列。',
        '早期开发曾查看测试集，本轮所有新增结果仅验证集；区间为探索性，未多重校正。',
        '补充材料沿用secondary_air_control_20261107的2/3通道结果，属于C0温度权重配置，不能冒充本轮λ8消融。',
        '本轮结果用于界定贡献强度，不选取新的主配置；停在此处，等待后续安排。']
    (folder/'REPORT_zh.txt').write_text('\n'.join(lines)+'\n')


def main():
    verify();trigger=json.loads((OUT/'budget_trigger.json').read_text());methods=('S8','D1','D2')+(('D1_512',) if trigger['trigger_D1_512'] else ())
    qc=json.loads((OUT/'REPLAY_QC_COMPLETE.json').read_text())
    if qc['status']!='passed':raise AssertionError('independent replay quality control not completed')
    for row in qc['checks']:
        if file_sha256(OUT/row['case'])!=row['final_sha256']:raise AssertionError('QC input changed')
    folder=OUT/'report';folder.mkdir(exist_ok=True)
    data,bindings,audit=collect(methods);w=bootstrap_weights();summaries,contrasts,ratios=tables(data,w)
    rows,categories=primary(data,methods,w)
    for name,items in [('metrics',summaries),('paired_differences',contrasts),('ratios_to_BC',ratios),('primary_endpoints',rows),('trajectory_metric_audit',audit)]:csv_write(folder/(name+'.csv'),items)
    by_model(summaries,folder)
    write_json(folder/'classification.json',categories);write_json(folder/'source_bindings.json',bindings)
    replay_sensitivity(qc,folder)
    overrides={OUT/r['case']:OUT/r['quarantined_original'] for r in qc['checks'] if r['resolution']=='adopt_matching_independent_pair'}
    if overrides:
        initial,initial_bindings,_=collect(methods,overrides)
        initial_rows,initial_categories=primary(initial,methods,w)
        csv_write(folder/'numerical_replay_initial_primary_endpoints.csv',initial_rows)
        write_json(folder/'numerical_replay_primary_comparison.json',dict(
            initial_classification=initial_categories,verified_classification=categories,
            classifications_unchanged=initial_categories==categories,
            meaning='Audit of computational correction only; initial archives are not additional scientific samples.',
            initial_source_bindings=initial_bindings))
    plots(rows,ratios,methods,folder);readout(rows,categories,contrasts,ratios,trigger,qc,folder)
    write_json(folder/'analysis_metadata.json',dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),starts=256,bootstrap_repetitions=10000,bootstrap_seed=20261108,unit='paired original start',methods=methods,classification=categories,replay_qc_sha256=file_sha256(OUT/'REPLAY_QC_COMPLETE.json')))
    print(json.dumps(categories,ensure_ascii=False),flush=True)
if __name__=='__main__':
    with threadpool_limits(limits=2):main()
