"""Paired uncertainty summaries for shared-reset learned-surrogate comparisons.

Training seeds and reset histories are separate crossed factors. Repeated starts
under different policy seeds are never described as independent trained agents.
Intervals below are exploratory fixed-protocol re-evaluation, not a new blind
confirmatory test or evidence of plant-level control effects.
"""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

import numpy as np


METRICS = ('episode_return', 'temperature_mae', 'pressure_mae', 'steam_mae',
           'oxygen_mae', 'violation_rate', 'zero_violation_episode')
DIRECTIONS = ('higher', 'lower', 'lower', 'lower', 'lower', 'lower', 'higher')


def episode_metrics(rewards, control, violation, horizon, targets):
    """Return one physical outcome vector per reset, never one row per step."""
    rewards = np.asarray(rewards, dtype=np.float64)
    control = np.asarray(control, dtype=np.float64)
    violation = np.asarray(violation, dtype=bool)
    targets = np.asarray(targets, dtype=np.float64)
    if rewards.ndim != 2 or control.shape != (*rewards.shape, 4) or violation.shape != rewards.shape or targets.shape != (4,):
        raise ValueError('Saved trajectory arrays or physical targets have incompatible shapes')
    if not (1 <= horizon <= rewards.shape[1]):
        raise ValueError('Requested prefix horizon exceeds saved feedback trajectory')
    if not np.isfinite(rewards).all() or not np.isfinite(control).all() or not np.isfinite(targets).all():
        raise FloatingPointError('Nonfinite saved control outcome')
    if (rewards > 1e-7).any():
        raise ValueError('Negative-cost control trajectory contains positive reward')
    r, c, v = rewards[:, :horizon], control[:, :horizon], violation[:, :horizon]
    return np.column_stack((r.sum(axis=1), np.abs(c-targets).mean(axis=1),
                            v.mean(axis=1), (~v.any(axis=1)).astype(float)))


def paired_bootstrap(differences, draws=10000, seed=2026):
    """Exploratory percentile CIs resampling paired seed and reset factors.

    ``differences`` has shape (trained policy seeds, shared resets, metrics).
    Each draw uses one sampled seed vector and one sampled reset vector for all
    methods/outcomes, preserving the same reset across repeated policy seeds.
    A singleton seed axis is retained for deterministic-vs-deterministic pairs;
    no training-run uncertainty is invented in that case.
    """
    delta = np.asarray(differences, dtype=np.float64)
    if delta.ndim != 3 or min(delta.shape) < 1 or not np.isfinite(delta).all():
        raise ValueError('Paired bootstrap expects finite seed x reset x metric differences')
    if draws < 100:
        raise ValueError('At least 100 bootstrap draws are required')
    n_seed, n_reset, n_metric = delta.shape
    rng = np.random.default_rng(seed)
    crossed = np.empty((draws, n_metric))
    seed_only = np.empty_like(crossed)
    reset_only = np.empty_like(crossed)
    seed_means = delta.mean(axis=1)
    reset_means = delta.mean(axis=0)
    for begin in range(0, draws, 256):
        end = min(draws, begin+256)
        s = rng.integers(0, n_seed, size=(end-begin, n_seed))
        e = rng.integers(0, n_reset, size=(end-begin, n_reset))
        seed_only[begin:end] = seed_means[s].mean(axis=1)
        reset_only[begin:end] = reset_means[e].mean(axis=1)
        crossed[begin:end] = delta[s[:, :, None], e[:, None, :], :].mean(axis=(1, 2))
    return {
        'mean_difference': delta.mean(axis=(0, 1)).tolist(),
        'seed_mean_differences': delta.mean(axis=1).tolist(),
        'seed_only_ci95': np.quantile(seed_only, [.025, .975], axis=0).T.tolist(),
        'reset_only_ci95': np.quantile(reset_only, [.025, .975], axis=0).T.tolist(),
        'seed_reset_crossed_ci95': np.quantile(crossed, [.025, .975], axis=0).T.tolist(),
        'seed_count': n_seed, 'shared_reset_count': n_reset,
        'bootstrap_draws': int(draws), 'bootstrap_seed': int(seed),
    }


def _load_control_runs(directory, expected_seeds=None):
    directory = Path(directory)
    result_path = directory/'results.json'
    record = json.loads(result_path.read_text())
    if not record.get('results'):
        raise ValueError('Control results are empty or incomplete')
    required_seeds = list(expected_seeds if expected_seeds is not None else record['rl_seeds'])
    if not required_seeds or len(set(required_seeds)) != len(required_seeds):
        raise ValueError('Expected policy seeds must be unique and nonempty')
    runs, input_hashes = {}, {'results.json': hashlib.sha256(result_path.read_bytes()).hexdigest()}
    common_starts = common_times = None
    common_horizon = None
    for name, entry in record['results'].items():
        paths, by_seed = entry['evaluation_files'], entry['by_seed']
        if not paths or len(paths) != len(by_seed):
            raise ValueError(f'{name}: missing saved run or seed metadata')
        seeds = [int(x['seed']) for x in by_seed]
        is_static = len(seeds) == 1 and seeds[0] == 0
        if not is_static and seeds != required_seeds:
            raise ValueError(f'{name}: policy optimization seeds differ from fixed protocol')
        values = []
        for relative, seed in zip(paths, seeds):
            path = directory/relative
            with np.load(path, allow_pickle=False) as raw:
                item = {k: raw[k].copy() for k in ('rewards', 'control', 'violation', 'start_indices', 'start_time_ns')}
            rewards = item['rewards']
            if rewards.ndim != 2 or rewards.shape[0] < 3:
                raise ValueError(f'{name}: require at least three paired reset trajectories')
            starts, times = item['start_indices'], item['start_time_ns']
            if starts.shape != (len(rewards),) or times.shape != starts.shape or len(np.unique(starts)) != len(starts):
                raise ValueError(f'{name}: invalid or duplicate reset metadata')
            if common_starts is None:
                common_starts, common_times, common_horizon = starts, times, rewards.shape[1]
            elif not np.array_equal(starts, common_starts) or not np.array_equal(times, common_times) or rewards.shape[1] != common_horizon:
                raise ValueError(f'{name}: comparisons require identical ordered resets, times and saved horizons')
            values.append(item)
            input_hashes[str(relative)] = hashlib.sha256(path.read_bytes()).hexdigest()
        runs[name] = {'seeds': seeds, 'static': is_static, 'arrays': values,
                      'label': entry.get('label', name)}
    return record, runs, np.asarray(common_starts), np.asarray(common_times), int(common_horizon), input_hashes


def _pair_matrix(first, second):
    """Broadcast a static policy; require exact pairing of optimization seeds."""
    if first['static'] and second['static']:
        return first['metrics']-second['metrics'], [0]
    if first['static']:
        return np.repeat(first['metrics'], len(second['seeds']), axis=0)-second['metrics'], second['seeds']
    if second['static']:
        return first['metrics']-np.repeat(second['metrics'], len(first['seeds']), axis=0), first['seeds']
    if first['seeds'] != second['seeds']:
        raise ValueError('Learned-method comparison has unpaired training seeds')
    return first['metrics']-second['metrics'], first['seeds']


def run_paired_statistics(control_dir, outdir, config=None, horizons=None):
    """Analyze predeclared prefixes from existing same-start raw control arrays.

    No fitting, reset selection, policy training or return-dependent exclusions
    occur here. Default comparisons use full_td3bc against every other recorded
    method. ``statistics.comparisons`` can supply explicit [method, comparator]
    pairs. ``statistics.horizons`` defaults to [10,50], with 10 the primary and
    50 the stress-test prefix of the very same saved trajectory.
    """
    config = {} if config is None else config
    cfg = config.get('statistics', {})
    expected = config.get('rl', {}).get('seeds')
    record, runs, starts, times, available, hashes = _load_control_runs(control_dir, expected)
    horizons = list(cfg.get('horizons', [10, 50]) if horizons is None else horizons)
    if not horizons or len(set(horizons)) != len(horizons) or any(int(h) != h or not 1 <= h <= available for h in horizons):
        raise ValueError('Statistics prefixes must be unique integer horizons within saved trajectories')
    horizons = [int(h) for h in horizons]
    draws, seed = int(cfg.get('bootstrap_draws', 10000)), int(cfg.get('bootstrap_seed', 2026))
    pairs = cfg.get('comparisons', [['full_td3bc', name] for name in runs if name != 'full_td3bc'])
    if not pairs or any(len(p) != 2 or p[0] not in runs or p[1] not in runs or p[0] == p[1] for p in pairs):
        raise ValueError('Comparisons must name two different recorded methods')
    ordered = np.argsort(times, kind='stable')
    if (np.diff(times[ordered]) <= 0).any():
        raise ValueError('Shared reset timestamps must be distinct')
    blocks = [np.asarray(x, dtype=np.int64) for x in np.array_split(ordered, 3)]
    targets = record.get('tracking_targets', [1000., -50., 32., 3.8])
    result = {'schema': 1, 'metric_names': list(METRICS), 'better_direction': list(DIRECTIONS),
              'difference_definition': 'method minus comparator in original physical units; positive favors method only for higher-is-better metrics',
              'primary_horizon': int(cfg.get('primary_horizon', 10)), 'available_trajectory_horizon': available,
              'optimization_seeds': record['rl_seeds'], 'shared_reset_count': len(starts),
              'horizons': {}, 'temporal_blocks': [
                  {'block': b+1, 'reset_count': len(idx), 'first_start_time_ns': int(times[idx[0]]),
                   'last_start_time_ns': int(times[idx[-1]])} for b, idx in enumerate(blocks)],
              'interpretation': 'Fixed post-development re-evaluation of a previously inspected test period, not a fresh blind confirmatory test; individual exploratory CIs are not multiplicity-adjusted',
              'uncertainty_scope': 'Policy optimization seeds and empirical reset histories; shared pretrained encoder/twin fits are held fixed; no physical-model or field-intervention uncertainty is estimated'}
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    seed_rows, effect_rows = [], []
    saved_matrices = {}
    for horizon in horizons:
        methods = {}
        for name, run in runs.items():
            matrix = np.stack([episode_metrics(x['rewards'], x['control'], x['violation'], horizon, targets) for x in run['arrays']])
            methods[name] = {**run, 'metrics': matrix}
            saved_matrices[f'h{horizon}_{name}'] = matrix
        values = {'methods': {}, 'comparisons': []}
        for name, run in methods.items():
            matrix = run['metrics']
            means = matrix.mean(axis=1)
            values['methods'][name] = {
                'label': run['label'], 'training_seed_count': 0 if run['static'] else len(run['seeds']),
                'evaluated_policy_count': len(run['seeds']), 'seed_ids': run['seeds'],
                'mean': matrix.mean(axis=(0,1)).tolist(), 'per_seed_means': means.tolist(),
                'seed_mean_sd': np.std(means, axis=0, ddof=1).tolist() if len(means)>1 else [0.]*len(METRICS),
                'blocks': [{'block': b+1, 'mean': matrix[:,idx].mean(axis=(0,1)).tolist()} for b,idx in enumerate(blocks)],
            }
            for policy_seed, row in zip(run['seeds'], means):
                seed_rows.append([horizon, name, policy_seed, *row.tolist()])
        for method, comparator in pairs:
            delta, pair_seeds = _pair_matrix(methods[method], methods[comparator])
            comparison = {'method': method, 'comparator': comparator,
                          'paired_seed_ids': pair_seeds, **paired_bootstrap(delta, draws, seed), 'blocks': []}
            for block, idx in enumerate(blocks):
                comparison['blocks'].append({'block': block+1,
                    **paired_bootstrap(delta[:,idx], draws, seed)})
            values['comparisons'].append(comparison)
            for j, metric in enumerate(METRICS):
                effect_rows.append([horizon,method,comparator,metric,DIRECTIONS[j],comparison['mean_difference'][j],
                                    *comparison['seed_only_ci95'][j],*comparison['seed_reset_crossed_ci95'][j]])
        result['horizons'][str(horizon)] = values
    np.savez_compressed(out/'episode_metric_matrices.npz', start_indices=starts, start_time_ns=times,
                        metric_names=np.asarray(METRICS), **saved_matrices)
    with (out/'per_seed_metrics.csv').open('w',newline='') as stream:
        writer=csv.writer(stream);writer.writerow(['horizon','method','seed',*METRICS]);writer.writerows(seed_rows)
    with (out/'paired_effects.csv').open('w',newline='') as stream:
        writer=csv.writer(stream);writer.writerow(['horizon','method','comparator','metric','better_direction',
            'mean_difference','seed_only_ci95_low','seed_only_ci95_high','seed_reset_ci95_low','seed_reset_ci95_high']);writer.writerows(effect_rows)
    (out/'paired_statistics.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    manifest = {'schema':1,'source_files_sha256':hashes,'config':cfg,'horizons':horizons,
                'bootstrap_draws':draws,'bootstrap_seed':seed,
                'resampling':'Crossed seed/reset factor bootstrap; common resamples preserve method pairing and shared-reset dependence',
                'static_policies':'Single deterministic run broadcast for paired comparison, not counted as trained optimization seeds',
                'no_rows_selected_by_outcomes':True,'previously_inspected_test_period':True,
                'source_code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (out/'statistics_manifest.json').write_text(json.dumps(manifest,indent=2,allow_nan=False)+'\n')
    return result
