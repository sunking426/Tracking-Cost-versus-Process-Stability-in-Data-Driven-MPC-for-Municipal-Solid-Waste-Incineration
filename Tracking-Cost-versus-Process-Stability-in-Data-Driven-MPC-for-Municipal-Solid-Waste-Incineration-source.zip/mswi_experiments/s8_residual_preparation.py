"""Training-only joint residual blocks for the sealed S8 cross-evaluation."""
from __future__ import annotations
import argparse
import datetime
import json
import shutil
from pathlib import Path
import numpy as np
from threadpoolctl import threadpool_limits
from .s8_cross_evaluation import ROOT, DESIGN, OUT, DATA, RESPONSE, REF, MODELS, verify
from .ridge_dynamics import RidgeDynamics
from .ridge_policy_study import read_npz,write_json
from .frozen_mpc import file_sha256

MINUTE=60_000_000_000
DAY=86_400_000_000_000


def prepare_model(mid,scope):
    path=OUT/f'residuals/{mid}_sequences.npz'
    if path.exists():
        meta=json.loads(path.with_suffix('.json').read_text())
        if meta['scope']!=scope or file_sha256(path)!=meta['sha256']:raise AssertionError('existing noise binding')
        return
    with np.load(RESPONSE/'rows.npz') as a:fit=np.array(a[mid+'_indices'])
    with np.load(DATA/'dataset.npz') as a:
        train=a['train_idx'];rows=train if scope=='all_original_training_rows' else fit
        if not np.isin(rows,train).all():raise AssertionError('nontraining residual row')
        u=a['u_hist'][rows];z=a['z_hist'][rows];truth=a['z_target'][rows];times=a['time_ns'][rows]
    model=RidgeDynamics.load(REF/f'evaluation_models/{mid}.npz')
    pred=np.concatenate([model.predict_next(u[i:i+512],z[i:i+512]) for i in range(0,len(rows),512)])
    residual=truth.astype(float)-pred
    positions=np.lib.stride_tricks.sliding_window_view(np.arange(len(rows)),10)
    blocktimes=times[positions]
    valid=(np.diff(blocktimes,axis=1)==MINUTE).all(1)&(blocktimes[:,0]//DAY==blocktimes[:,-1]//DAY)
    positions=positions[valid]
    if not len(positions):raise ValueError('no true consecutive ten-minute training block: '+mid)
    blocks=residual[positions]
    starts=read_npz(REF/'inputs/val.npz')['indices']
    chosen=np.empty((len(starts),5,5),np.int64)
    for i,ix in enumerate(starts):
        for rep in range(5):
            rng=np.random.default_rng(np.random.SeedSequence([20261108,MODELS.index(mid),int(ix),rep]))
            chosen[i,rep]=rng.integers(0,len(blocks),5)
    noise=blocks[chosen].reshape(len(starts),5,50,9)
    # Marginal moments of the block population and repeated finite samples.
    sums=blocks.sum(1);squares=np.square(blocks).sum(1)
    pool_mean=sums.mean(0)/10
    pool_sd=np.sqrt(np.maximum(squares.mean(0)/10-pool_mean**2,0))
    sampled_sd=noise.std(axis=(0,1,2),ddof=0)
    count=chosen.size;mc=[];rng=np.random.default_rng(31000+MODELS.index(mid))
    for begin in range(0,2000,25):
        draws=rng.integers(0,len(blocks),(min(25,2000-begin),count))
        means=sums[draws].sum(1)/(count*10)
        mc.append(np.sqrt(np.maximum(squares[draws].sum(1)/(count*10)-means**2,0)))
    mc=np.concatenate(mc);tail=.01/(2*36);lo,hi=np.quantile(mc,[tail,1-tail],axis=0)
    checks=(sampled_sd>=lo)&(sampled_sd<=hi)
    path.parent.mkdir(parents=True,exist_ok=True)
    bank=path.with_name(mid+'_bank.npz')
    np.savez_compressed(bank,residual=residual,indices=rows,time_ns=times,block_positions=positions,
        original_fit_indices=fit,monte_carlo_sampled_sd=mc)
    np.savez_compressed(path,residual=noise,start_indices=starts,chosen_block_positions=chosen,
        residual_source_indices=rows[positions[chosen]].reshape(len(starts),5,50),
        residual_source_time_ns=times[positions[chosen]].reshape(len(starts),5,50))
    write_json(path.with_suffix('.json'),{'model':mid,'scope':scope,'source_rows':len(rows),'fit_rows':len(fit),
        'residual_rows_used_for_this_model_fit':int(np.isin(rows,fit).sum()),'eligible_blocks':len(blocks),
        'all_rows_original_training_partition':True,'all_blocks_consecutive_minutes_and_single_day':True,
        'raw_residual_mean':residual.mean(0).tolist(),'all_residual_sd':residual.std(0).tolist(),
        'eligible_block_pool_sd':pool_sd.tolist(),'sampled_sd':sampled_sd.tolist(),
        'sampled_to_pool_sd_ratio':(sampled_sd/pool_sd).tolist(),
        'monte_carlo_interval_low':lo.tolist(),'monte_carlo_interval_high':hi.tolist(),
        'sd_fidelity_pass_per_channel':checks.tolist(),'sd_fidelity_all_pass':bool(checks.all()),
        'Monte_Carlo_interval_note':'2000 draws; finite Monte Carlo tail resolution; diagnostic, no reselection/rescaling',
        'sha256':file_sha256(path),'bank_sha256':file_sha256(bank),
        'generator_sha256':file_sha256(Path(__file__))})
    print('RESIDUALS',mid,'rows',len(rows),'blocks',len(blocks),'SD ratios',sampled_sd/pool_sd,'passed',checks.all(),flush=True)


def seal_C(scope,authorization):
    verify()
    if scope!='all_original_training_rows':raise ValueError('pooled exact fit rows have zero ten-minute blocks; C cannot be completed')
    if not authorization.strip():raise ValueError('user authorization for pooled clarification required')
    if (DESIGN/'C_addendum.json').exists():
        if file_sha256(DESIGN/'C_addendum.json')!=(DESIGN/'C_addendum.sha256').read_text().strip():raise AssertionError('C seal changed')
        return
    if (OUT/'trajectories/C/pooled_matched').exists():raise AssertionError('pooled addendum must precede pooled C outcomes')
    record={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'base_config_sha256':file_sha256(DESIGN/'config.json'),
        'pooled_residual_scope':scope,'authorization':authorization,
        'reason':'pooled fit rows are about three minutes apart; zero eligible ten-minute blocks. No interpolation or false row-contiguity assumption.',
        'other_models':'own actual fit rows only','noise_source':'raw physical nine-channel one-step truth minus prediction, no recentering',
        'generator_sha256':file_sha256(Path(__file__)),
        'controller_and_positioning_rules_unchanged':True}
    write_json(DESIGN/'C_addendum.json',record)
    (DESIGN/'C_addendum.sha256').write_text(file_sha256(DESIGN/'C_addendum.json')+'\n')
    for f in ('C_addendum.json','C_addendum.sha256'):shutil.copy2(DESIGN/f,OUT/f)
    shutil.copy2(__file__,OUT/'code_snapshot/mswi_experiments/s8_residual_preparation.py')


def main():
    p=argparse.ArgumentParser();p.add_argument('stage',choices=('three','pooled'))
    p.add_argument('--authorization',default='');args=p.parse_args()
    verify()
    with threadpool_limits(2):
        if args.stage=='three':
            for mid in MODELS[:3]:prepare_model(mid,'own_fit_rows')
        else:
            seal_C('all_original_training_rows',args.authorization)
            prepare_model('pooled_matched','all_original_training_rows')

if __name__=='__main__':main()
