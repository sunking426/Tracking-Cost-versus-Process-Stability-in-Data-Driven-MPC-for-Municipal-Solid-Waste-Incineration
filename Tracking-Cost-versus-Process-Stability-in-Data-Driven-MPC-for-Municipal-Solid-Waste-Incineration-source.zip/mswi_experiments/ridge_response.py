"""Model-implied operation responses for the saved numerical Ridge dynamics.

The response is a property of an affine fitted predictor, not an identified
plant intervention effect. All trajectory predictions and action projection
remain owned by the canonical dynamics and control modules.
"""
from __future__ import annotations

import numpy as np
import torch

from .control import project_normalized_actions
from .numeric_baselines import numeric_features
from .ridge_dynamics import RidgeDynamics, recursive_rollout


PATTERNS = ('pulse', 'step')
EXECUTION_TOLERANCE = 1e-10


def _horizon(horizon):
    if (isinstance(horizon, (bool, np.bool_))
            or not isinstance(horizon, (int, np.integer)) or horizon < 1):
        raise ValueError('horizon must be a positive integer')
    return int(horizon)


def physical_coefficients(model):
    """Return next-CV coefficients U(9,11,8), Z(9,10,9), oldest lag first.

    U multiplies physical MV levels and Z multiplies physical CV levels. The
    latest-CV block includes the identity from the increment-to-level update.
    Centering and fitted intercepts cancel when two paths are differenced.
    """
    if not isinstance(model, RidgeDynamics):
        raise TypeError('a validated direct RidgeDynamics model is required')
    w = model.weights
    matrix = w['delta_scale'][:, None] * w['coef'] / w['x_scale'][None, :]
    u = matrix[:, :88].reshape(9, 11, 8).copy()
    z = matrix[:, 88:].reshape(9, 10, 9).copy()
    z[:, -1, :] += np.eye(9)
    if not np.isfinite(u).all() or not np.isfinite(z).all():
        raise FloatingPointError('nonfinite physical Ridge coefficients')
    return u, z


def analytic_responses(model, horizon=10):
    """Exact unit MV-level response from the first future decision t+1.

    Each result has shape (horizon, 9 CVs, 8 perturbed MVs). A pulse changes
    u_(t+1) by one physical unit and returns to the baseline level at t+2. A
    step changes the level at t+1 and holds it, without repeated increments.
    Historical MV/CV differences and the observed current-CV difference are
    zero. The affine model therefore has no operating-state dependence before
    action projection; state-dependent responses must not be inferred from it.
    """
    horizon = _horizon(horizon)
    u_coef, z_coef = physical_coefficients(model)
    result = {}
    for pattern in PATTERNS:
        u = np.zeros((8, 11, 8), dtype=np.float64)
        z = np.zeros((8, 10, 9), dtype=np.float64)
        response = np.empty((horizon, 9, 8), dtype=np.float64)
        for step in range(horizon):
            level = np.eye(8) if pattern == 'step' or step == 0 else np.zeros((8, 8))
            u = np.concatenate((u[:, 1:], level[:, None]), axis=1)
            with np.errstate(over='raise', invalid='raise'):
                prediction = (np.einsum('nlu,olu->no', u, u_coef)
                              + np.einsum('nlz,olz->no', z, z_coef))
            if not np.isfinite(prediction).all():
                raise FloatingPointError('nonfinite analytic response')
            response[step] = prediction.T
            z = np.concatenate((z[:, 1:], prediction[:, None]), axis=1)
        result[pattern] = response
    return result


def autoregressive_stability(model):
    """Homogeneous ten-CV-lag companion spectrum with fixed future MV.

    The state ordering is oldest to newest CV, each with nine channels. Its
    spectral radius describes this fitted linear recursion only; neither
    a plant-stability guarantee nor a sufficient controller-admission test.
    """
    _, z = physical_coefficients(model)
    companion = np.zeros((90, 90), dtype=np.float64)
    companion[:81, 9:] = np.eye(81)
    companion[81:, :] = z.reshape(9, 90)
    eigenvalues = np.linalg.eigvals(companion)
    if not np.isfinite(eigenvalues).all():
        raise FloatingPointError('nonfinite companion spectrum')
    return {'companion': companion, 'eigenvalues': eigenvalues,
            'spectral_radius': float(np.max(np.abs(eigenvalues)))}


def decision_rollout(model, u_hist, z_hist, z_current, future_mv):
    """Forecast z_(t+1)..z_(t+H) using observations available at decision t.

    u_hist covers t-10..t, z_hist covers t-10..t-1, and z_current is observed
    z_t. future_mv contains the proposed u_(t+1)..u_(t+H). The first history
    shift is explicit; canonical recursive_rollout then feeds predictions
    back without any future observed CV. No caller array is modified.
    """
    u, z = np.asarray(u_hist, dtype=np.float64), np.asarray(z_hist, dtype=np.float64)
    numeric_features({'u_hist': u, 'z_hist': z})
    current = np.asarray(z_current, dtype=np.float64)
    path = np.asarray(future_mv, dtype=np.float64)
    if len(u) == 0 or current.shape != (len(u), 9) or not np.isfinite(current).all():
        raise ValueError('finite observed current CV must have nonempty shape (N,9)')
    if (path.ndim != 3 or path.shape[0] != len(u) or path.shape[1] < 1
            or path.shape[2] != 8 or not np.isfinite(path).all()):
        raise ValueError('finite future MV levels must have shape (N,positive horizon,8)')
    initial_u = np.concatenate((u[:, 1:], path[:, 0, None]), axis=1)
    initial_z = np.concatenate((z[:, 1:], current[:, None]), axis=1)
    return recursive_rollout(model, initial_u, initial_z, path)


def project_trial_paths(u_current, stats, fraction=.1, horizon=10):
    """Construct held, pulse and step paths using canonical action execution.

    There are 16 cases, ordered MV0 minus/plus, MV1 minus/plus, ..., MV7
    minus/plus. Requested initial displacement is fraction*action_bound.
    Projection uses float64 and the same increment/absolute-MV envelopes as
    control.py. Pulse reversal is also projected, not assumed executable.
    Returned execution masks describe projection only, not historical joint
    support, physical actuator resolution or plant safety.
    """
    horizon = _horizon(horizon)
    if (isinstance(fraction, (bool, np.bool_)) or not np.isscalar(fraction)
            or not np.isfinite(fraction) or not 0 < fraction <= 1):
        raise ValueError('fraction must be finite and in (0,1]')
    current = np.asarray(u_current, dtype=np.float64)
    if current.ndim != 2 or current.shape[1] != 8 or not len(current) or not np.isfinite(current).all():
        raise ValueError('finite current MV must have nonempty shape (N,8)')
    current_tensor = torch.from_numpy(current.copy())
    # Let the canonical owner validate every projection statistic before use.
    project_normalized_actions(torch.zeros_like(current_tensor), current_tensor, stats)
    low, high = (np.asarray(stats[key], dtype=np.float64) for key in ('u_low', 'u_high'))
    if np.any(current < low) or np.any(current > high):
        raise ValueError('initial MV lies outside the declared empirical envelope')
    scale = np.asarray(stats['action_scale'], dtype=np.float64)
    bound = np.asarray(stats['action_bound'], dtype=np.float64)
    cases_mv = np.repeat(np.arange(8, dtype=np.int64), 2)
    cases_sign = np.tile(np.asarray([-1., 1.]), 8)
    requested_delta = np.zeros((16, 8), dtype=np.float64)
    requested_delta[np.arange(16), cases_mv] = cases_sign * float(fraction) * bound[cases_mv]
    requested_normalized = requested_delta / scale
    n = len(current)
    repeated = np.repeat(current[:, None], 16, axis=1).reshape(-1, 8)
    requests = np.broadcast_to(requested_normalized, (n, 16, 8)).copy().reshape(-1, 8)
    normal, delta, next_u = project_normalized_actions(
        torch.from_numpy(requests), torch.from_numpy(repeated.copy()), stats)
    normal, delta, next_u = [value.numpy().reshape(n, 16, 8) for value in (normal, delta, next_u)]
    paths = np.repeat(next_u[:, None, :, None, :], 2, axis=1)
    paths = np.repeat(paths, horizon, axis=3)
    actions = np.zeros_like(paths)
    actions[:, :, :, 0] = normal[:, None]
    if horizon > 1:
        reverse_request = (repeated - next_u.reshape(-1, 8)) / scale
        reverse_normal, _, restored = project_normalized_actions(
            torch.from_numpy(reverse_request.copy()), torch.from_numpy(next_u.reshape(-1, 8).copy()), stats)
        restored = restored.numpy().reshape(n, 16, 8)
        paths[:, 0, :, 1:] = restored[:, :, None, :]
        actions[:, 0, :, 1] = reverse_normal.numpy().reshape(n, 16, 8)
    return {
        'baselinefuture_mv': np.repeat(current[:, None], horizon, axis=1),
        'trialfuture_mv': paths, 'executed_delta': delta,
        'normalized_actions': actions, 'requested_delta': requested_delta,
        'requested_normalized': requested_normalized,
        'nonzero_executed': np.any(np.abs(delta) > EXECUTION_TOLERANCE, axis=-1),
        'full_request_executed': np.all(np.isclose(
            delta, requested_delta[None], rtol=0., atol=EXECUTION_TOLERANCE), axis=-1),
        'cases_mv': cases_mv, 'cases_sign': cases_sign,
        'pattern_names': np.asarray(PATTERNS),
    }
