"""Paired, time-blocked statistics for the frozen visual-information study.

The unit of observation is a shared retained process window. Training seeds and
calendar/time blocks are resampled as crossed axes; windows inside each selected
block remain together. These are exploratory intervals conditional on the fixed
dataset and fitted pipelines, not independent plant-intervention evidence.
"""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

import numpy as np

from .data import MINUTE_NS, control_values


METHODS = ("sensor", "original52", "static40", "fixed10", "fixed60",
           "timing4", "null_fixed10")
CONTROL_NAMES = ("temperature", "pressure", "steam", "oxygen")
CONTROL_UNITS = ("degC", "Pa", "t/h", "vol%")
DAY_NS = 1440 * MINUTE_NS


def _write_json(path: Path, value) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2,
                               allow_nan=False) + "\n", encoding="utf-8")


def _write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        raise ValueError("cannot write an empty statistics table")
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def paired_block_interval(differences: np.ndarray, block_ids: np.ndarray, *,
                          draws: int = 10000, seed: int = 20261104,
                          confidence_level: float = .95) -> dict:
    """Bootstrap a paired error difference of shape (seed, sample, channel).

    Positive differences must already mean a better candidate (for MAE:
    abs(reference error) - abs(candidate error)). Resampling operates on the
    differences, so both methods retain exactly the same seeds and observations.
    Blocks are drawn uniformly with replacement; each drawn block contributes
    all of its observations, retaining the sample-weighted estimand even when
    partial calendar days contain different numbers of observations.
    """
    values = np.asarray(differences, dtype=np.float64)
    labels = np.asarray(block_ids)
    if values.ndim != 3 or min(values.shape) == 0 or not np.isfinite(values).all():
        raise ValueError("differences must be finite nonempty (seed, sample, channel)")
    if labels.ndim != 1 or len(labels) != values.shape[1]:
        raise ValueError("block_ids must identify every sample")
    if not isinstance(draws, (int, np.integer)) or draws <= 0:
        raise ValueError("draws must be a positive integer")
    if not 0 < confidence_level < 1:
        raise ValueError("confidence_level must lie strictly between zero and one")
    unique, inverse, counts = np.unique(labels, return_inverse=True, return_counts=True)
    n_seed, _, n_channel = values.shape
    n_block = len(unique)
    sums = np.stack([values[:, inverse == index].sum(axis=1)
                     for index in range(n_block)], axis=1)
    # Independent streams keep the block draws unchanged if identical seed
    # repetitions are added. Replicating a fitted seed is not extra evidence.
    seed_sequence, block_sequence = np.random.SeedSequence(int(seed)).spawn(2)
    seed_rng = np.random.default_rng(seed_sequence)
    block_rng = np.random.default_rng(block_sequence)
    bootstrap = np.empty((draws, n_channel), dtype=np.float64)
    for begin in range(0, draws, 256):
        size = min(256, draws - begin)
        seed_weight = seed_rng.multinomial(n_seed, np.full(n_seed, 1 / n_seed), size)
        block_weight = block_rng.multinomial(n_block, np.full(n_block, 1 / n_block), size)
        numerator = np.einsum("ds,db,sbc->dc", seed_weight, block_weight, sums,
                              optimize=True)
        denominator = n_seed * (block_weight @ counts)
        bootstrap[begin:begin + size] = numerator / denominator[:, None]
    tail = (1 - confidence_level) / 2
    lower, upper = np.quantile(bootstrap, [tail, 1 - tail], axis=0)
    warnings = []
    if n_block == 1:
        warnings.append("one_time_block: interval contains no between-time-block variation")
    elif n_block < 10:
        warnings.append("fewer_than_ten_time_blocks: time uncertainty is weakly identified")
    if n_seed == 1:
        warnings.append("one_training_seed: interval contains no between-fit variation")
    if np.array_equal(values, np.broadcast_to(values[:1], values.shape)) and n_seed > 1:
        warnings.append("identical_seed_differences: seed copies add no independent information")
    return {
        "difference": values.mean(axis=(0, 1)).tolist(),
        "ci_lower": lower.tolist(), "ci_upper": upper.tolist(),
        "confidence_level": float(confidence_level), "draws": int(draws),
        "seed": int(seed), "training_seeds": n_seed, "time_blocks": n_block,
        "samples": values.shape[1], "block_sample_counts": counts.tolist(),
        "block_labels": [str(value) for value in unique],
        "estimand": "mean paired per-window error reduction, averaged over training seeds",
        "resampling": "crossed seed and whole time-block percentile bootstrap; sample-count weighted",
        "exploratory": True, "multiple_comparison_adjustment": "none",
        "warnings": warnings,
    }


def build_strata(data: dict, metadata_arrays: dict) -> tuple[dict[str, np.ndarray], dict]:
    """Define all strata using image age and only pre-target process histories."""
    history = np.asarray(data["z_hist"])
    if history.ndim != 3 or history.shape[1] < 2 or history.shape[2] != 9:
        raise ValueError("z_hist must contain at least two pre-target nine-CV observations")
    n = len(history)
    train = np.asarray(data["train_idx"], dtype=np.int64)
    if train.ndim != 1 or not len(train) or train.min() < 0 or train.max() >= n:
        raise ValueError("invalid training indices for stratum thresholds")
    ages = np.asarray(metadata_arrays["age_minutes"], dtype=np.float64)
    if ages.shape != (n,) or not np.isfinite(ages).all() or ages.min() < -1e-8 or ages.max() > 10 + 1e-8:
        raise ValueError("age_minutes must follow the frozen zero-to-ten-minute matching rule")
    first = control_values(history[:, 0]).astype(np.float64)
    last = control_values(history[:, -1]).astype(np.float64)
    if not np.isfinite(first).all() or not np.isfinite(last).all():
        raise ValueError("nonfinite observed process history")
    lower, upper = np.quantile(last[train], [.25, .75], axis=0)
    iqr = upper - lower
    scale = np.where(iqr >= 1e-6, iqr, 1.)
    dynamic_score = np.max(np.abs(last - first) / scale, axis=1)
    dynamic_cut = float(np.quantile(dynamic_score[train], .75))
    steam_low, steam_high = np.quantile(last[train, 2], [.25, .75])
    masks = {
        "overall": np.ones(n, dtype=bool),
        "freshness_0_2_minutes": ages <= 2,
        "freshness_2_5_minutes": (ages > 2) & (ages <= 5),
        "freshness_5_10_minutes": ages > 5,
        "ordinary_dynamics": dynamic_score <= dynamic_cut,
        "high_dynamics": dynamic_score > dynamic_cut,
        "low_steam_load": last[:, 2] <= steam_low,
        "middle_steam_load": (last[:, 2] > steam_low) & (last[:, 2] <= steam_high),
        "high_steam_load": last[:, 2] > steam_high,
    }
    description = {
        "fit_partition": "train_idx only", "training_samples": len(train),
        "freshness_boundaries_minutes": [2., 5., 10.],
        "freshness_definition": "prediction time minus one minute minus selected capture time",
        "dynamic_definition": "maximum absolute last-minus-first observed history change divided by training last-history IQR",
        "dynamic_control_iqr": iqr.tolist(), "dynamic_control_scale": scale.tolist(),
        "dynamic_training_quantile": .75, "dynamic_threshold": dynamic_cut,
        "steam_load_definition": "last observed pre-target main steam flow",
        "steam_training_quantiles": [.25, .75],
        "steam_thresholds_t_h": [float(steam_low), float(steam_high)],
        "future_targets_used": False,
        "empty_strata_policy": "retain with zero counts and empty metric cells",
    }
    return masks, description


def _metrics(errors: np.ndarray) -> dict:
    if errors.ndim != 3 or errors.shape[-1] != 4 or not errors.shape[1]:
        raise ValueError("metrics require nonempty (seed, sample, four-control) errors")
    per_seed_mae = np.abs(errors).mean(axis=1)
    per_seed_rmse = np.sqrt(np.square(errors).mean(axis=1))
    return {
        "mae": per_seed_mae.mean(axis=0).tolist(),
        "rmse": np.sqrt(np.square(errors).mean(axis=(0, 1))).tolist(),
        "mean_seed_rmse": per_seed_rmse.mean(axis=0).tolist(),
        "seed_mae_sd": per_seed_mae.std(axis=0, ddof=0).tolist(),
        "seed_rmse_sd": per_seed_rmse.std(axis=0, ddof=0).tolist(),
    }


def summarize_predictions(data: dict, variants: dict, metadata_arrays: dict,
                          study_dir, config: dict) -> dict:
    """Load all fixed main comparisons and save recomputable result tables."""
    root = Path(study_dir)
    out = root / "statistics"
    out.mkdir(parents=True, exist_ok=True)
    options = config["diagnostics"]
    seeds = [int(seed) for seed in options["seeds"]]
    if not seeds or len(set(seeds)) != len(seeds):
        raise ValueError("distinct training seeds are required; repeated files are not new fits")
    indices = np.asarray(data["test_idx"], dtype=np.int64)
    if indices.ndim != 1 or not len(indices) or len(np.unique(indices)) != len(indices):
        raise ValueError("test_idx must contain unique retained windows")
    n_total = len(data["time_ns"])
    for name in METHODS[1:]:
        if name not in variants or len(variants[name]) != n_total:
            raise ValueError(f"missing or inconsistent frozen feature variant: {name}")
    times = np.asarray(data["time_ns"])[indices]
    if np.any(np.diff(times) <= 0):
        raise ValueError("test predictions must retain chronological order")
    y = np.asarray(data["z_target"])[indices]
    truth = control_values(y).astype(np.float64)
    capture_times = np.asarray(data["visual_time_ns"])[indices]
    day_ids = times // DAY_NS
    sources = {}
    errors = {}
    for method in METHODS:
        repetitions = []
        for seed in seeds:
            path = root / "models" / method / f"seed_{seed}" / "test_predictions.npz"
            with np.load(path, allow_pickle=False) as raw:
                if not np.array_equal(raw["indices"], indices) or not np.array_equal(raw["time_ns"], times):
                    raise ValueError(f"misaligned prediction identities: {path}")
                if not np.array_equal(raw["y"], y):
                    raise ValueError(f"prediction truth differs from fixed dataset: {path}")
                prediction = raw["pred"]
                if prediction.shape != y.shape or not np.isfinite(prediction).all():
                    raise ValueError(f"invalid predictions: {path}")
                if not np.array_equal(raw["error"], prediction - y):
                    raise ValueError(f"saved error does not match saved prediction: {path}")
                repetitions.append(control_values(prediction).astype(np.float64) - truth)
            sources[path.relative_to(root).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
        errors[method] = np.stack(repetitions)
    masks, stratum_metadata = build_strata(data, metadata_arrays)
    masks = {name: mask[indices] for name, mask in masks.items()}
    result = {
        "status": "completed", "methods": list(METHODS), "seeds": seeds,
        "control_names": list(CONTROL_NAMES), "control_units": list(CONTROL_UNITS),
        "test_samples": len(indices), "test_unique_captures": int(len(np.unique(capture_times))),
        "calendar_days": int(len(np.unique(day_ids))),
        "test_start": str(np.datetime64(int(times[0]), "ns")),
        "test_end": str(np.datetime64(int(times[-1]), "ns")),
        "metric_definition": "MAE averaged over all common windows and fits; pooled RMSE also provided",
        "difference_direction": "reference MAE minus candidate MAE; positive favors candidate",
        "inference_scope": "exploratory, previously inspected test period; no multiplicity correction; conditional on this dataset",
        "stratum_definition": stratum_metadata, "overall": {}, "comparisons": {},
        "strata": {}, "source_prediction_sha256": sources,
    }
    overall_rows, seed_rows, day_rows, stratum_rows = [], [], [], []
    for method in METHODS:
        result["overall"][method] = _metrics(errors[method])
        for channel, (name, unit) in enumerate(zip(CONTROL_NAMES, CONTROL_UNITS)):
            overall_rows.append({"variant": method, "quantity": name, "unit": unit,
                "samples": len(indices), "training_seeds": len(seeds),
                **{key: value[channel] for key, value in result["overall"][method].items()}})
        for position, seed in enumerate(seeds):
            summary = _metrics(errors[method][position:position + 1])
            for channel, (name, unit) in enumerate(zip(CONTROL_NAMES, CONTROL_UNITS)):
                seed_rows.append({"variant": method, "seed": seed, "quantity": name, "unit": unit,
                    "samples": len(indices), "mae": summary["mae"][channel],
                    "rmse": summary["rmse"][channel]})
        for day in np.unique(day_ids):
            selected = day_ids == day
            summary = _metrics(errors[method][:, selected])
            baseline_summary = _metrics(errors["sensor"][:, selected])
            for channel, (name, unit) in enumerate(zip(CONTROL_NAMES, CONTROL_UNITS)):
                day_rows.append({"variant": method, "day": str(np.datetime64(int(day), "D")),
                    "quantity": name, "unit": unit, "samples": int(selected.sum()),
                    "unique_captures": int(len(np.unique(capture_times[selected]))),
                    "mae": summary["mae"][channel], "rmse": summary["rmse"][channel],
                    "mae_reduction_vs_sensor": baseline_summary["mae"][channel] - summary["mae"][channel]})
    for label, mask in masks.items():
        counts = {"samples": int(mask.sum()),
                  "unique_captures": int(len(np.unique(capture_times[mask]))),
                  "calendar_days": int(len(np.unique(day_ids[mask]))),
                  "blocks_60_minutes": int(len(np.unique(times[mask] // (60 * MINUTE_NS)))),
                  "blocks_180_minutes": int(len(np.unique(times[mask] // (180 * MINUTE_NS))))}
        result["strata"][label] = {**counts, "methods": {}}
        for method in METHODS:
            metrics = _metrics(errors[method][:, mask]) if counts["samples"] else None
            result["strata"][label]["methods"][method] = metrics
            baseline = _metrics(errors["sensor"][:, mask]) if counts["samples"] else None
            for channel, (name, unit) in enumerate(zip(CONTROL_NAMES, CONTROL_UNITS)):
                stratum_rows.append({"stratum": label, "variant": method, "quantity": name,
                    "unit": unit, **counts,
                    "mae": None if metrics is None else metrics["mae"][channel],
                    "rmse": None if metrics is None else metrics["rmse"][channel],
                    "mae_reduction_vs_sensor": None if metrics is None else baseline["mae"][channel] - metrics["mae"][channel]})
    pairs = [(method, "sensor") for method in METHODS if method != "sensor"]
    pairs += [("fixed10", "timing4"), ("fixed10", "original52"), ("fixed10", "null_fixed10")]
    primary = {("fixed10", "sensor"), ("fixed10", "timing4")}
    block_sets = {"calendar_day": day_ids,
                  "60_minutes": times // (60 * MINUTE_NS),
                  "180_minutes": times // (180 * MINUTE_NS)}
    comparison_rows = []
    for candidate, reference in pairs:
        key = f"{candidate}_vs_{reference}"
        difference = np.abs(errors[reference]) - np.abs(errors[candidate])
        is_primary_pair = (candidate, reference) in primary
        exploration_label = ("exploratory_negative_control" if reference == "null_fixed10"
                             else "exploratory")
        endpoint_priorities = {
            name: ("prespecified_primary" if name == "temperature" else "prespecified_secondary")
            if is_primary_pair else exploration_label
            for name in CONTROL_NAMES
        }
        result["comparisons"][key] = {"candidate": candidate, "reference": reference,
            "pair_priority": "prespecified_primary" if is_primary_pair else exploration_label,
            "primary_quantity": "temperature" if is_primary_pair else None,
            "endpoint_priorities": endpoint_priorities,
            "intervals": {}}
        for block_name, blocks in block_sets.items():
            interval = paired_block_interval(difference, blocks,
                draws=int(options.get("bootstrap_draws", 10000)),
                seed=int(options.get("bootstrap_seed", 20261104)),
                confidence_level=float(options.get("confidence_level", .95)))
            result["comparisons"][key]["intervals"][block_name] = interval
            for channel, (name, unit) in enumerate(zip(CONTROL_NAMES, CONTROL_UNITS)):
                comparison_rows.append({"candidate": candidate, "reference": reference,
                    "pair_priority": result["comparisons"][key]["pair_priority"],
                    "endpoint_priority": endpoint_priorities[name], "block_definition": block_name,
                    "quantity": name, "unit": unit, "mae_reduction": interval["difference"][channel],
                    "ci_lower": interval["ci_lower"][channel], "ci_upper": interval["ci_upper"][channel],
                    "samples": len(indices), "training_seeds": len(seeds),
                    "time_blocks": interval["time_blocks"], "confidence_level": interval["confidence_level"],
                    "exploratory": True, "multiplicity_adjustment": "none"})
    for name, rows in [("overall", overall_rows), ("per_seed", seed_rows), ("per_day", day_rows),
                       ("strata", stratum_rows), ("comparisons", comparison_rows)]:
        _write_csv(out / f"{name}.csv", rows)
    np.savez_compressed(out / "paired_error_arrays.npz", indices=indices, time_ns=times,
        capture_time_ns=capture_times, seed=np.asarray(seeds),
        **{f"error_{method}": value for method, value in errors.items()},
        **{f"stratum_{label}": mask for label, mask in masks.items()})
    _write_json(out / "stratum_definitions.json", stratum_metadata)
    _write_json(out / "summary.json", result)
    return result
