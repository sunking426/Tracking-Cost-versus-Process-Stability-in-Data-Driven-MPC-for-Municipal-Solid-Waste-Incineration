"""Limited, observed-outcome RGB diagnostics before control-policy training.

Thermal movement and recorded MV change are historical labels, not rewards or
optimal-action labels. All feature groups share rows and numerical summaries.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

import numpy as np
from threadpoolctl import threadpool_limits

from .numeric_baselines import sha256, write_json
from .rgb_control_diagnostic_data import prepare_data
from .rgb_control_diagnostic_models import (fit_candidates, load_model, predict_proba,
                                             save_model)


TASKS = ('thermal_change', 'action_change')
VARIANTS = ('numeric', 'quality', 'rgb', 'stale')


def archive(path):
    with np.load(path, allow_pickle=False) as source:
        return {key: source[key] for key in source.files}


def paths(config_file):
    path = Path(config_file).resolve()
    cfg = json.loads(path.read_text())
    if (cfg['horizon'] != 5 or cfg['thermal_quantile'] != .8 or cfg['action_quantile'] != .9
            or cfg['stale_min_minutes'] != 60 or cfg['stale_max_minutes'] != 70
            or cfg['primary_task'] != 'thermal_change' or cfg['primary_contrast'] != 'rgb_vs_quality'):
        raise ValueError('configuration differs from this fixed limited diagnostic protocol')
    return cfg, path.parent, path.parent / cfg['output_dir']


def verify(hashes, root=None):
    for name, expected in hashes.items():
        path = Path(name) if root is None else Path(root) / name
        if sha256(path) != expected:
            raise ValueError('frozen input changed: '+str(path))


def prepare(config_file):
    cfg, project, out = paths(config_file)
    if out.exists():
        raise FileExistsError('use a fresh output directory; existing study artifacts are immutable')
    out.mkdir(parents=True)
    prepare_data({**cfg, 'project_root': str(project)}, out)
    write_json(out / 'config.json', cfg)
    protocol = {
        'schema_version': 1,
        'scope': 'small supervised observed-outcome diagnostic; no simulator, RL policy, or reward evaluation',
        'decision_origin': 'time t; numerical histories and actual observed CV_t are known. Actual selected image capture is no later than t-1min.',
        'feature_groups': {'numeric':219,'quality':235,'rgb':267,'stale':267},
        'numeric_features': '178 historical MV/CV values +9 current CV values +32 fixed physical trend/volatility features. Per physical quantity: signed/absolute changes at 1/5/10min, 11-point population std and range. Identical across all groups.',
        'quality_features': 'Numeric +4 timing descriptors +12 simple image color/quality statistics. These include real visual information and are a deliberately stronger comparator than numeric alone.',
        'rgb_features': 'Quality +32 fixed PCA coordinates of the actual past selected ResNet18 RGB encoding.',
        'stale_features': 'Same CURRENT numeric/timing/quality as RGB; only replace RGB32 by a capture aged60–70min at input cutoff. This is a causal image-recency comparator, not a random permutation or no-vision baseline.',
        'labels': {'thermal_change':'max of abs(mean furnace T_(t+h)-mean furnace T_t), h1..5, exceeds final-common-training80th percentile. A relative large-movement label, not a safety/danger label.',
                   'action_change':'Any next-minute MV change exceeds1e-6 and reaches its channel training90th nonzero absolute-change percentile. Historical setting changes; no manual/automatic attribution or optimal-action label.'},
        'primary_endpoint': 'test thermal_change average_precision, RGB minus quality',
        'supporting_comparisons': 'RGB versus numeric and stale for both tasks; all comparisons declared before testing',
        'model': 'Train-standardized L2 binary logistic regression; C grid fixed in config; no class weighting; deterministic solver configuration documented in model module.',
        'selection': 'Minimum validation log loss, ties favor smaller C. Same grid and algorithm for all variants. No test tuning/refit; all eight selected models frozen before test probabilities.',
        'alarm_threshold': 'Per-model validation90th score percentile frozen before testing; test alarm fraction is measured, not forced to10%.',
        'metrics': 'AP primary; ROC AUC, Brier, log loss, precision/recall/FPR/alarm rate and full counts secondary. Report prevalence and sample counts. AP reflects ranking, not calibration.',
        'uncertainty': 'Paired start-date block bootstrap,10000 draws,95% exploratory intervals, same block weights for both models, nonlinear AP recomputed with weights. Single fitted model per group. Degenerate draws explicitly reported.',
        'interpretation': 'An RGB gain can support further warning/operation-information research, not optimal-action selection, identified hidden-combustion-state effects, or improved real closed-loop control.',
        'limits': ['Historical test period was inspected in previous research; this is not a new blind evaluation.',
                   'Future temperatures are observed under logged subsequent operations; future actions are not inputs, and no alternative-action outcomes are identified.',
                   'Only a fixed frozen RGB representation and a small diagnostic classifier family are tested; absence of gains does not exclude all visual information.',
                   'Overlapping five-minute label windows and few calendar-day blocks limit uncertainty estimation.',
                   'Original numerical Ridge predictor, manuscript, and release package are unchanged.'],
    }
    write_json(out / 'protocol.json', protocol)
    files = ['prepared.npz','preparation.json','input_hashes.json','source_records.npz','config.json','protocol.json']
    write_json(out / 'prepare_frozen.json', {'status':'complete','files':{f:sha256(out/f) for f in files}})
    print('Data prepared; training/validation/test labels and causal input provenance saved.',flush=True)
    return out


def load_prepared(config_file):
    cfg, project, out = paths(config_file)
    if cfg != json.loads((out / 'config.json').read_text()):
        raise ValueError('configuration changed after preparation')
    frozen = json.loads((out / 'prepare_frozen.json').read_text())
    verify(frozen['files'], out)
    verify(json.loads((out / 'input_hashes.json').read_text()))
    return cfg, project, out, archive(out / 'prepared.npz')


def fit(config_file):
    cfg, project, out, data = load_prepared(config_file)
    if (out / 'selection.json').exists():
        raise FileExistsError('model selection already exists')
    (out / 'models').mkdir(exist_ok=True)
    rows = []
    for task in TASKS:
        for variant in VARIANTS:
            weights, candidates, chosen = fit_candidates(
                data['train_'+variant], data['train_'+task],
                data['val_'+variant], data['val_'+task], cfg['C_grid'],
                alarm_quantile=cfg['alarm_quantile'])
            name = f'models/{task}_{variant}.npz'
            save_model(out / name, weights)
            row = {'task':task,'variant':variant,'model_path':name,
                   'selected':chosen,'candidates':candidates,
                   'alarm_threshold':float(weights['threshold'])}
            rows.append(row)
            print('Fitted',task,variant,chosen,flush=True)
    write_json(out / 'selection.json', {'status':'complete','models':rows,
        'prepare_frozen_sha256':sha256(out / 'prepare_frozen.json'),
        'selection_rule':'validation log loss only; test not scored'})
    frozen = dict(json.loads((out/'prepare_frozen.json').read_text())['files'])
    for name in ['prepare_frozen.json','selection.json']+[row['model_path'] for row in rows]:
        frozen[name] = sha256(out/name)
    snapshot = out / 'code_snapshot'; snapshot.mkdir()
    source_hashes = {}
    names = ['rgb_control_diagnostic_data.py','rgb_control_diagnostic_models.py',
             'rgb_control_diagnostic_study.py','rgb_control_diagnostic_report.py',
             'ridge_rgb_residual_data.py','ridge_dynamics.py','numeric_baselines.py',
             'visual_representation_probe.py','data.py']
    for name in names:
        p = project/'mswi_experiments'/name
        shutil.copyfile(p, snapshot/name)
        frozen['code_snapshot/'+name] = sha256(snapshot/name)
        source_hashes[str(p)] = sha256(p)
    write_json(out/'selection_frozen.json',{'status':'complete','files':frozen,'source_code_hashes':source_hashes})
    print('All eight models and code frozen before test prediction.',flush=True)
    return out


def predict(config_file):
    cfg, project, out, data = load_prepared(config_file)
    if (out/'predictions_manifest.json').exists():
        raise FileExistsError('predictions already completed')
    frozen = json.loads((out/'selection_frozen.json').read_text())
    verify(frozen['files'],out); verify(frozen['source_code_hashes'])
    selected = json.loads((out/'selection.json').read_text())['models']
    files = []
    for row in selected:
        model = load_model(out/row['model_path'])
        task,variant = row['task'],row['variant']
        for split in ('val','test'):
            x = data[split+'_'+variant]
            probability = predict_proba(model,x)
            threshold = float(model['threshold'])
            name = f'predictions/{split}/{task}_{variant}.npz'
            path = out/name; path.parent.mkdir(parents=True,exist_ok=True)
            if path.exists(): raise FileExistsError(path)
            np.savez_compressed(path,indices=data[split+'_indices'],time_ns=data[split+'_time_ns'],
                y=data[split+'_'+task],probability=probability,
                alarm=(probability>=threshold).astype(np.int8),threshold=np.asarray(threshold))
            files.append({'path':name,'sha256':sha256(path),'split':split,'task':task,'variant':variant})
    verify(frozen['files'],out); verify(frozen['source_code_hashes'])
    write_json(out/'predictions_manifest.json',{'status':'complete','files':files,
        'selection_sha256':sha256(out/'selection.json'),
        'selection_frozen_sha256':sha256(out/'selection_frozen.json')})
    print('Saved all sixteen validation/test probability archives.',flush=True)
    return out


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('stage',choices=('prepare','fit','predict','all'))
    p.add_argument('--config',default='rgb_control_diagnostic_20261106.json')
    args=p.parse_args(); cfg,_,_=paths(args.config)
    with threadpool_limits(limits=cfg['threads']):
        stages=('prepare','fit','predict') if args.stage=='all' else (args.stage,)
        for stage in stages: globals()[stage](args.config)


if __name__=='__main__': main()
