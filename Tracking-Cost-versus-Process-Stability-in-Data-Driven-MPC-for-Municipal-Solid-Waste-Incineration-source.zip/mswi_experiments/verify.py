"""Independently recompute control tables and reward from saved physical arrays."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

import numpy as np


def verify(output: Path):
    control=output/'control'
    result=json.loads((control/'results.json').read_text())
    config=json.loads((control/'run_manifest.json').read_text())['config']
    episodes=int(config['evaluation']['episodes']);horizon=int(config['evaluation']['horizon'])
    seeds=[int(x) for x in config['rl']['seeds']]
    stats=json.loads((output/'data/stats.json').read_text())
    data=np.load(output/'data/dataset.npz',allow_pickle=False)
    low,high=np.asarray(stats['control_low']),np.asarray(stats['control_high'])
    u_low,u_high=np.asarray(stats['u_low']),np.asarray(stats['u_high'])
    scale,bound=np.asarray(stats['action_scale']),np.asarray(stats['action_bound'])
    starts=np.asarray(result['evaluation_start_indices'])
    checks=[]; stored={}; rows=0
    def check(condition,label):
        if not condition:raise AssertionError(label)
        checks.append(label)
    def close(x,y,label,atol=1e-5):
        check(np.allclose(x,y,atol=atol,rtol=1e-5),label)
    check(len(starts)==len(np.unique(starts))==episodes,f'{episodes} distinct paired starts')
    check(np.isin(starts,data['test_idx']).all(),'resets belong to test partition')
    check((np.diff(np.sort(data['time_ns'][starts]))>=horizon*60_000_000_000).all(),f'reset histories separated by {horizon} minutes')
    expected={'linear_feedback','nearest_logged','bc','twin_td3','sensor_td3bc','full_td3bc','no_bc_init','no_bc_reg','no_policy_retrieval'}
    expected |= set(config['evaluation'].get('additional_baselines',[]))
    static={'linear_feedback','nearest_logged','bc','cem_mpc'} & expected
    check(set(result['results'])==expected,'all predeclared method and ablation results complete')
    check(result['rl_seeds']==seeds,'optimization seed list matches run configuration')
    for method,entry in result['results'].items():
        runs=[]; seedmeans=[]
        check(len(entry['evaluation_files'])==len(entry['by_seed']),f'{method}: metadata and run count agree')
        expected_seeds=[0] if method in static else seeds
        check([r['seed'] for r in entry['by_seed']]==expected_seeds,f'{method}: all predetermined seeds')
        for relative,seed_summary in zip(entry['evaluation_files'],entry['by_seed']):
            run=np.load(control/relative,allow_pickle=False);runs.append(run)
            key=(method,seed_summary['seed']);stored[key]=run
            check(run['rewards'].shape==(episodes,horizon),f'{key}: complete {episodes}x{horizon} transitions')
            close(run['start_indices'],starts,f'{key}: paired reset IDs',0)
            check(all(np.isfinite(run[k]).all() for k in ('rewards','control','z','u','actions','normalized_actions')),f'{key}: finite arrays')
            physical=np.concatenate((run['z'][...,:6].mean(axis=-1,keepdims=True),run['z'][...,6:]),axis=-1)
            close(physical,run['control'],f'{key}: consistent CV mapping')
            violation=((physical<low)|(physical>high)).any(axis=-1)
            close(violation,run['violation'],f'{key}: independent empirical-envelope flags',0)
            o=physical[...,3]
            cost=(abs(physical[...,0]-1000)/50+abs(physical[...,1]+50)/20+abs(physical[...,2]-32)/5
                  +np.maximum(np.maximum(3.5-o,o-4),0)/.5
                  +.05*(run['normalized_actions']**2).mean(axis=-1)+.5*violation)
            close(-cost,run['rewards'],f'{key}: reward recomputed from physical next CV and executed actions')
            check((run['rewards']<=0).all(),f'{key}: nonpositive reward')
            previous_u=np.concatenate((data['u_current'][starts,None,:],run['u'][:,:-1]),axis=1)
            close(run['u']-previous_u,run['actions'],f'{key}: actual MV increments',2e-4)
            close(run['actions']/scale,run['normalized_actions'],f'{key}: action scale')
            check((np.abs(run['actions'])<=bound+2e-4).all(),f'{key}: increment bounds')
            check(((run['u']>=u_low-2e-4)&(run['u']<=u_high+2e-4)).all(),f'{key}: absolute MV bounds')
            seedmeans.append(run['rewards'].astype(float).sum(axis=1).mean())
            close(seedmeans[-1],seed_summary['mean_return'],f'{key}: seed return')
            if 'training' in seed_summary:
                train=seed_summary['training']
                updates=int(config['rl']['updates']);delay=int(config['rl']['policy_delay'])
                check(train['updates']==updates and train['actor_updates']==updates//delay,f'{key}: actual update budget')
                refresh=int(config['rl'].get('rollout_every',100))
                expected_generated=(1+(updates-1)//refresh)*int(config['rl']['rollout_batch_size'])*int(config['rl']['rollout_horizon'])
                if method=='offline_td3bc':
                    expected_generated=0
                    check(train['replay_mode']=='logged_only',f'{key}: strictly logged-only baseline')
                check(train['generated_transitions']==expected_generated,f'{key}: actual generated replay')
            rows+=episodes*horizon
        rewards=np.concatenate([r['rewards'] for r in runs]).astype(float)
        quantities=np.concatenate([r['control'] for r in runs]).astype(float)
        flags=np.concatenate([r['violation'] for r in runs])
        s=entry['summary']
        close(rewards.sum(axis=1).mean(),s['mean_return'],f'{method}: pooled return')
        close(abs(quantities-np.array([1000,-50,32,3.8])).mean(axis=(0,1)),s['tracking_mae'],f'{method}: tracking MAE')
        close(flags.mean(),s['violation_rate'],f'{method}: step violation rate')
        check(int(flags.sum())==s['violation_steps'],f'{method}: violation count')
        check(int((~flags.any(axis=1)).sum())==s['stable_episodes'],f'{method}: zero-violation episode count')
        close((~flags.any(axis=1)).mean(),s['stability_rate'],f'{method}: stability rate')
        check(len(flags)==s['episodes'] and flags.size==s['steps'],f'{method}: denominators')
        close(np.std(seedmeans,ddof=1) if len(seedmeans)>1 else 0,s['seed_mean_return_std'],f'{method}: seed mean SD')
    count=0
    with (control/'trajectories.csv').open() as stream:
        for row in csv.DictReader(stream):
            key=(row['method'],int(row['seed']));e=int(row['episode']);t=int(row['step'])-1
            run=stored[key]
            if abs(float(row['reward'])-float(run['rewards'][e,t]))>1e-8:raise AssertionError('CSV reward mismatch')
            if int(row['start_index'])!=int(starts[e]):raise AssertionError('CSV start mismatch')
            count+=1
    expected_rows=episodes*horizon*(len(static)+len(expected-static)*len(seeds))
    check(count==rows==expected_rows,f'all {expected_rows} CSV transitions match saved NPZ rewards and reset IDs')
    ad=result['advisory']
    with (control/'advisory/advisory_replay.csv').open() as stream:records=list(csv.DictReader(stream))
    check(len(records)==ad['observed_steps']==int(config['evaluation']['advisory_steps']),'all requested advisory observations recorded')
    idx=np.array([int(r['sample_index']) for r in records]);check(np.isin(idx,data['test_idx']).all(),'advisory only held-out samples')
    check((np.diff(data['time_ns'][idx])==60_000_000_000).all(),'advisory consecutive minutes')
    requested=np.array([[float(r[f'recommended_action_{j}']) for j in range(8)] for r in records])
    logged=np.array([[float(r[f'logged_action_{j}']) for j in range(8)] for r in records])
    close(logged,data['action'][idx],'advisory logs are real held-out increments')
    next_u=data['u_current'][idx]+requested
    supported=((abs(requested)<=bound+1e-5).all(axis=1)&(next_u>=u_low-1e-5).all(axis=1)&(next_u<=u_high+1e-5).all(axis=1))
    close(supported.mean(),ad['action_support_ratio'],'advisory support ratio')
    chosen=requested/scale;actual=logged/scale;tol=ad['direction_zero_tolerance_normalized']
    sign1=np.where(abs(chosen)<=tol,0,np.sign(chosen));sign2=np.where(abs(actual)<=tol,0,np.sign(actual));active=sign2!=0
    close((sign1==sign2).mean(),ad['direction_agreement_all_channels'],'advisory all-channel direction')
    close((sign1==sign2)[active].mean(),ad['direction_agreement_active_logged_channels'],'advisory active direction')
    close(np.linalg.norm(chosen-actual,axis=1).mean(),ad['mean_normalized_action_deviation'],'advisory normalized deviation')
    check(ad['operator_adoption_rate'] is None and ad['alarm_rate'] is None,'unobserved field outcomes remain absent')
    report={'status':'passed','checks':len(checks),'details':checks,'control_trajectory_rows':rows,
            'results_sha256':hashlib.sha256((control/'results.json').read_bytes()).hexdigest(),
            'current_code_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(Path(__file__).parent.glob('*.py'))},
            'checkpoint_sha256':{str(p.relative_to(output)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((output/'models').glob('*/*.pt'))}}
    (control/'verification_report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'verification':'passed','checks':len(checks),'trajectory_rows':rows}))
    return report


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('output',type=Path)
    verify(parser.parse_args().output)
