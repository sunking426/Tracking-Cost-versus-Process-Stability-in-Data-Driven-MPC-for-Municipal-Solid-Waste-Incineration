"""Observed-label metrics for a bounded RGB control-information diagnostic."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np

from .numeric_baselines import sha256, write_json
from .rgb_control_diagnostic_models import binary_metrics, paired_day_bootstrap


TASKS=('thermal_change','action_change')
VARIANTS=('numeric','quality','rgb','stale')
CONTRASTS=('numeric','quality','stale')
LABELS={'numeric':'Numerical','quality':'Image statistics','rgb':'Current RGB','stale':'Older RGB'}
TITLES={'thermal_change':'Future temperature movement','action_change':'Next-minute MV change'}
COLORS={'numeric':'#1f77b4','quality':'#777777','rgb':'#ff7f0e','stale':'#2ca02c'}


def archive(path):
    with np.load(path,allow_pickle=False) as raw: return {key:raw[key] for key in raw.files}


def csv_write(path,rows):
    with Path(path).open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)


def validate_probability_archive(row):
    required={'indices','time_ns','y','probability','alarm','threshold'}
    if not required.issubset(row): raise ValueError('missing probability archive arrays')
    n=len(row['indices'])
    for name in ('indices','time_ns','y','probability','alarm'):
        if row[name].shape!=(n,) or not np.isfinite(row[name]).all():
            raise ValueError('invalid aligned prediction array: '+name)
    for name in ('indices','time_ns'):
        if not np.issubdtype(row[name].dtype,np.integer) or np.any(np.diff(row[name])<=0):
            raise ValueError('nonchronological integer identity')
    if n==0 or not np.isin(row['y'],[0,1]).all() or not np.isin(row['alarm'],[0,1]).all():
        raise ValueError('empty/nonbinary labels or alarms')
    if np.any((row['probability']<0)|(row['probability']>1)):
        raise ValueError('invalid binary probability')
    if row['threshold'].shape!=() or not 0<=float(row['threshold'])<=1:
        raise ValueError('invalid fixed threshold')
    if not np.array_equal(row['alarm'],row['probability']>=float(row['threshold'])):
        raise ValueError('saved alarm differs from frozen threshold')


def load_study(root):
    root=Path(root).resolve()
    cfg=json.loads((root/'config.json').read_text())
    frozen=json.loads((root/'selection_frozen.json').read_text())
    manifest=json.loads((root/'predictions_manifest.json').read_text())
    selection=json.loads((root/'selection.json').read_text())
    if (frozen['status']!='complete' or manifest['status']!='complete'
            or manifest['selection_sha256']!=sha256(root/'selection.json')
            or manifest['selection_frozen_sha256']!=sha256(root/'selection_frozen.json')):
        raise ValueError('completed frozen selection required')
    for name,digest in frozen['files'].items():
        if sha256(root/name)!=digest: raise ValueError('frozen artifact changed: '+name)
    for name,digest in frozen['source_code_hashes'].items():
        if sha256(Path(name))!=digest: raise ValueError('frozen source changed: '+name)
    prepared=archive(root/'prepared.npz')
    selected={(r['task'],r['variant']):r for r in selection['models']}
    expected={(s,t,v) for s in ('val','test') for t in TASKS for v in VARIANTS}
    rows={};checks=[]
    for item in manifest['files']:
        key=(item['split'],item['task'],item['variant'])
        if key in rows or key not in expected or sha256(root/item['path'])!=item['sha256']:
            raise ValueError('prediction inventory/hash mismatch')
        row=archive(root/item['path']);validate_probability_archive(row)
        split,task,variant=key
        for name in ('indices','time_ns'):
            if not np.array_equal(row[name],prepared[split+'_'+name]):
                raise ValueError('prediction differs from prepared identity')
        if not np.array_equal(row['y'],prepared[split+'_'+task]):
            raise ValueError('prediction target differs from prepared observed label')
        if float(row['threshold'])!=selected[(task,variant)]['alarm_threshold']:
            raise ValueError('alarm threshold differs from frozen validation selection')
        rows[key]=row
        checks.append({'split':split,'task':task,'variant':variant,'n':len(row['y']),'sha256':item['sha256']})
    if set(rows)!=expected: raise ValueError('all16 probability archives required')
    return root,cfg,rows,checks


def summarize(study_dir):
    root,cfg,rows,checks=load_study(study_dir)
    metrics={s:{t:{} for t in TASKS} for s in ('val','test')}
    metric_rows=[]
    for (split,task,variant),row in rows.items():
        m=binary_metrics(row['y'],row['probability'],float(row['threshold']))
        metrics[split][task][variant]=m
        # Keep scalar fields in the human-readable table; full metadata is JSON.
        flat={k:v for k,v in m.items() if v is None or isinstance(v,(int,float,str,bool))}
        metric_rows.append({'split':split,'task':task,'variant':variant,**flat})
    contrasts={};contrast_rows=[]
    for task in TASKS:
        contrasts[task]={}
        candidate=rows[('test',task,'rgb')]
        for ref in CONTRASTS:
            reference=rows[('test',task,ref)]
            if not np.array_equal(reference['y'],candidate['y']):
                raise ValueError('paired labels differ')
            result=paired_day_bootstrap(candidate['y'],reference['probability'],candidate['probability'],
                candidate['time_ns'],draws=cfg['bootstrap_draws'],seed=cfg['bootstrap_seed'],
                confidence_level=cfg['confidence_level'])
            contrasts[task]['rgb_vs_'+ref]=result
            for j,name in enumerate(result['endpoint_names']):
                contrast_rows.append({'task':task,'contrast':'rgb_vs_'+ref,'metric':name,
                    'difference':result['difference'][j],'ci_lower':result['ci_lower'][j],
                    'ci_upper':result['ci_upper'][j]})
    result={'status':'complete','primary_task':cfg['primary_task'],
        'primary_contrast':cfg['primary_contrast'],'primary_metric':cfg['primary_metric'],
        'metrics':metrics,'contrasts':contrasts,'prediction_checks':checks,
        'limits':json.loads((root/'protocol.json').read_text())['limits'],
        'source_prediction_manifest_sha256':sha256(root/'predictions_manifest.json')}
    stats=root/'statistics';stats.mkdir(exist_ok=True)
    write_json(stats/'summary.json',result)
    csv_write(stats/'metrics.csv',metric_rows);csv_write(stats/'paired_comparisons.csv',contrast_rows)
    return result


def render_figures(root,result):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    dest=Path(root)/'figures';dest.mkdir(exist_ok=True)
    fig,axes=plt.subplots(2,2,figsize=(10.5,7.0));plot_rows=[]
    for col,task in enumerate(TASKS):
        for row,metric in enumerate(('average_precision','brier')):
            ax=axes[row,col]
            vals=[result['metrics']['test'][task][v][metric] for v in VARIANTS]
            heights=[np.nan if v is None else v for v in vals]
            ax.bar(range(4),heights,color=[COLORS[v] for v in VARIANTS])
            ax.set_xticks(range(4),[LABELS[v] for v in VARIANTS],rotation=15,ha='right')
            ax.set_ylabel('Average precision (higher better)' if row==0 else 'Brier score (lower better)')
            if row==0: ax.set_title(TITLES[task])
            ax.grid(axis='y',alpha=.2);ax.margins(y=.18)
            for x,value in enumerate(vals):
                if value is not None: ax.annotate(f'{value:.4f}',(x,value),xytext=(0,4),textcoords='offset points',ha='center',fontsize=9)
                plot_rows.append({'task':task,'variant':VARIANTS[x],'metric':metric,'value':value})
    fig.tight_layout()
    for ext in ('png','svg'):fig.savefig(dest/f'control_diagnostic_scores.{ext}',dpi=180,bbox_inches='tight')
    plt.close(fig);csv_write(dest/'control_diagnostic_scores_data.csv',plot_rows)
    fig,axes=plt.subplots(1,2,figsize=(11,4.0));plot_rows=[]
    for ax,task in zip(axes,TASKS):
        for i,ref in enumerate(CONTRASTS):
            r=result['contrasts'][task]['rgb_vs_'+ref]
            mean,lo,hi=r['difference'][0],r['ci_lower'][0],r['ci_upper'][0]
            if mean is not None and lo is not None and hi is not None:
                ax.plot([lo,hi],[i,i],color=COLORS[ref],linewidth=2)
                ax.scatter([mean],[i],color=COLORS[ref],s=36,zorder=3)
            else:ax.text(0,i,'Not estimable',ha='center')
            plot_rows.append({'task':task,'reference':ref,'difference':mean,'ci_lower':lo,'ci_upper':hi})
        ax.axvline(0,color='black',linestyle='--',linewidth=.8)
        ax.set_yticks(range(3),['RGB vs numerical','RGB vs image statistics','RGB vs older RGB'])
        ax.invert_yaxis();ax.set_title(TITLES[task]);ax.grid(axis='x',alpha=.2)
        ax.set_xlabel('AP increase (positive favors current RGB)')
    fig.suptitle('Paired calendar-day exploratory 95% intervals')
    fig.tight_layout()
    for ext in ('png','svg'):fig.savefig(dest/f'control_diagnostic_ap_effects.{ext}',dpi=180,bbox_inches='tight')
    plt.close(fig);csv_write(dest/'control_diagnostic_ap_effects_data.csv',plot_rows)


def write_readout(root,result):
    lines=['Observed-outcome RGB control-information diagnostics','',
        'Primary endpoint: current RGB vs image statistics, future temperature movement AP.',
        'Labels come from real logged outcomes; no Ridge-simulator rewards or RL policies are used.',
        'All feature groups include the same numerical trend, absolute-change and volatility summaries.','']
    for task in TASKS:
        lines.extend([TITLES[task], 'variant | AP | ROC AUC | Brier | log loss | precision | recall | alarm fraction'])
        for v in VARIANTS:
            m=result['metrics']['test'][task][v]
            keys=['average_precision','roc_auc','brier','log_loss','precision','recall','alarm_fraction']
            lines.append(v+' | '+' | '.join('NA' if m[k] is None else f'{m[k]:.9g}' for k in keys))
        for name,r in result['contrasts'][task].items():
            lines.append(name+': AP increase='+str(r['difference'][0])+'; 95% interval=['+str(r['ci_lower'][0])+', '+str(r['ci_upper'][0])+']')
        lines.append('')
    lines.extend(['Interpretation:',
        '- Temperature movement is not a safety violation; MV-change prediction is not an optimal-action classifier.',
        '- The older-image group keeps CURRENT simple image statistics; only the deep RGB coordinates are older.',
        '- Validation log loss selected regularization; test AP did not select models.',
        '- Alarm thresholds are frozen validation quantiles; test alert rates are not forced to ten percent.',
        '- Any positive result is limited to this representation/classifier and logged operating regime.',
        '- AP depends on event prevalence; see statistics/summary.json for counts and prevalence.',
        *['- '+x for x in result['limits']]])
    (Path(root)/'RESULTS.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')


def build_report(study_dir):
    root=Path(study_dir).resolve();result=summarize(root)
    render_figures(root,result);write_readout(root,result)
    outputs=[*sorted((root/'statistics').glob('*')),*sorted((root/'figures').glob('*')),root/'RESULTS.txt']
    write_json(root/'report_manifest.json',{'status':'complete',
        'source_manifest_sha256':sha256(root/'predictions_manifest.json'),
        'files':{str(p.relative_to(root)):sha256(p) for p in outputs if p.is_file()}})
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('study_dir');args=p.parse_args()
    result=build_report(args.study_dir)
    print(json.dumps({'status':result['status'],'prediction_archives':len(result['prediction_checks'])}))


if __name__=='__main__':main()
