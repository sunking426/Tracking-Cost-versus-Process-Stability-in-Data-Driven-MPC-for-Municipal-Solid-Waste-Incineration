"""Prospective channel/admission ablations of immutable S8 experiments.

Only this experimental owner generalizes action dimensions and admission.
Physics, projection, support distance, reward and ranking stay canonical.
"""
import hashlib
import itertools
import numpy as np
import torch
from .mpc_channels import ChannelExecution
from .ridge_policy_planning import PlanningSupport
from .ridge_response import analytic_responses, decision_rollout
from .control import project_normalized_actions, reward_and_violation
from .data import MINUTE_NS
from .mpc_temperature import rank_candidates
from .mpc_stability import stability_components


class AblationExecution(ChannelExecution):
    def __init__(self, stats, support, channels=2, admission='supported', zero_extra=False):
        super().__init__(stats, support, secondary=False)
        if channels not in (2,8) or admission not in ('supported','complete','projection'):
            raise ValueError('unregistered ablation')
        self.admission=admission
        self.active=np.array([0,3] if channels==2 else [0,3,1,2,4,5,6,7])
        self.inactive=np.array([j for j in range(8) if j not in self.active],dtype=int)
        self.m=.1*self.bound[self.active]/self.scale[self.active]
        self.lower=-np.ones(channels);self.upper=np.ones(channels)
        # Zero budgets are legitimate fixed actuators, including the acceptance test.
        fixed=self.m==0
        if zero_extra:fixed[2:]=True
        self.lower[fixed]=0;self.upper[fixed]=0
        self.response_active=self.active[~fixed]

    def admit(self,complete,supported,nonzero):
        if self.admission=='supported':return (complete & supported)|~nonzero
        if self.admission=='complete':return complete|~nonzero
        return np.ones_like(nonzero,dtype=bool)

    def screen(self,request,u,z,times):
        result=super().screen(request,u,z,times)
        result['admitted']=self.admit(result['complete'],result['supported'],result['nonzero'])
        return result


class CandidateNoise:
    """Per-start old 2-D stream, independent added dimensions/budget streams."""
    def __init__(self,indices,step,d,population):
        self.d=d;self.extra_count=population-128
        def streams(tag):
            return [np.random.default_rng(np.random.SeedSequence([2026,int(i),int(step)]+tag)) for i in indices]
        self.core=streams([]);self.added=[streams([4000+j]) for j in range(d-2)]
        self.more=streams([6000]);self.more_added=[streams([5000+j]) for j in range(d-2)]
        self.hashes=[hashlib.sha256() for _ in indices]
        self.extra_hashes=[hashlib.sha256() for _ in indices]

    def draw(self):
        old=np.stack([r.normal(size=(117,10,2)) for r in self.core])
        for h,v in zip(self.hashes,old):h.update(v.tobytes(order='C'))
        parts=[old]+[np.stack([r.normal(size=(117,10,1)) for r in streams]) for streams in self.added]
        core=np.concatenate(parts,axis=-1)
        for h,v in zip(self.extra_hashes,core[...,2:]):h.update(v.tobytes(order='C'))
        if not self.extra_count:return core
        parts=[np.stack([r.normal(size=(self.extra_count,10,2)) for r in self.more])]
        parts += [np.stack([r.normal(size=(self.extra_count,10,1)) for r in streams]) for streams in self.more_added]
        return np.concatenate((core,np.concatenate(parts,axis=-1)),axis=1)


class AblationCEM:
    def __init__(self,model,execution,population=128):
        if population not in (128,512):raise ValueError('registered budgets only')
        self.model=model;self.execution=execution;self.population=population;self.elite=population//8
        self.support=PlanningSupport(execution);self.d=len(execution.active)
        self.kernel=analytic_responses(model,10)['step'][:,:,execution.response_active]
        self.fixed=np.zeros((9,10,self.d))
        self.fixed[:,0,:2]=[(0,0)]+[v for v in itertools.product((-1,0,1),repeat=2) if v!=(0,0)]
        self.warm=None

    def objective_components(self,plans,u_hist,z_hist,current,times,return_trace=False):
        n,c,h,d=plans.shape
        if (h,d)!=(10,self.d):raise ValueError('plan dimensions')
        e=self.execution;u=np.repeat(u_hist[:,-1,None],c,axis=1).astype(float)
        baseline=decision_rollout(self.model,u_hist,z_hist,current,np.repeat(u_hist[:,-1,None],10,axis=1))
        effects=np.zeros((n,c,10,9));z=np.repeat(current[:,None],c,axis=1).astype(float)
        original=np.zeros((n,c));trace={'prediction':[],'executed':[],'reward':[]}
        for step in range(10):
            request=e.request(plans[:,:,step].reshape(-1,d));flat_u=u.reshape(-1,8)
            a,delta,nu=project_normalized_actions(torch.from_numpy(request),torch.from_numpy(flat_u),e.stats)
            a,delta,nu=[v.numpy() for v in (a,delta,nu)]
            complete=np.all(np.abs(delta-request*e.scale)<=1e-10,axis=1)
            if e.admission=='supported':
                stamp=np.repeat(times+step*MINUTE_NS,c)
                supported=self.support.supported(flat_u,z.reshape(-1,9),delta,stamp,n,c)
            else:supported=np.ones(len(flat_u),dtype=bool) # unused by admission, no approximation of support
            admitted=e.admit(complete,supported,np.any(request!=0,axis=1))
            a[~admitted]=0;delta[~admitted]=0;nu[~admitted]=flat_u[~admitted]
            physical=delta.reshape(n,c,8)
            effects[:,:,step:]+=np.einsum('ncj,hzj->nchz',physical[:,:,e.response_active],self.kernel[:10-step])
            z=baseline[:,None,step]+effects[:,:,step]
            reward,_,_=reward_and_violation(z,a.reshape(n,c,8),e.stats);original+=reward.astype(float)
            trace['prediction'].append(z.copy());trace['executed'].append(a.reshape(n,c,8).copy());trace['reward'].append(reward.copy())
            u=nu.reshape(n,c,8)
        trace={k:np.stack(v,axis=2) for k,v in trace.items()}
        rewards,_,parts=reward_and_violation(trace['prediction'],trace['executed'],e.stats)
        if not np.array_equal(rewards,trace['reward']):raise AssertionError('canonical reward')
        jt=parts['tracking_cost'][...,0].astype(float).sum(axis=2)
        jf,jo=stability_components(trace['prediction'],current)
        values=(original-3*jt-8*(jf+jo),original,jt,jf,jo)
        return (values,trace) if return_trace else values

    def plan(self,u,z,current,times,indices,decision_step):
        n=len(u);d=self.d
        warm=np.zeros((n,10,d)) if self.warm is None else np.concatenate((self.warm[:,1:],np.zeros((n,1,d))),axis=1)
        mean=warm.copy();std=np.full_like(mean,.35);incumbent=np.zeros_like(mean)
        best_score=np.full(n,-np.inf);best=np.zeros_like(mean);best_original=np.zeros(n);best_jt=np.zeros(n)
        iteration_scores=[];counts=[];noise=CandidateNoise(indices,decision_step,d,self.population)
        for iteration in range(4):
            eps=noise.draw()
            random=np.clip(mean[:,None]+std[:,None]*eps,self.execution.lower,self.execution.upper)
            plans=np.concatenate((np.broadcast_to(self.fixed,(n,9,10,d)),warm[:,None],incumbent[:,None],random),axis=1)
            score,original,jt,_,_=self.objective_components(plans,u,z,current,times)
            winner,elite_indices,count=rank_candidates(score,np.ones_like(score,dtype=bool),self.elite)
            incumbent=plans[np.arange(n),winner].copy();iteration_score=score[np.arange(n),winner]
            better=iteration_score>best_score
            best[better]=incumbent[better];best_score[better]=iteration_score[better]
            best_original[better]=original[np.arange(n),winner][better];best_jt[better]=jt[np.arange(n),winner][better]
            tie=score[:,0]==best_score;best[tie]=0;best_original[tie]=original[tie,0];best_jt[tie]=jt[tie,0]
            elite=plans[np.arange(n)[:,None],elite_indices];mean=elite.mean(1);std=np.maximum(elite.std(1,ddof=0),.05)
            iteration_scores.append(iteration_score);counts.append(count)
        self.warm=best.copy()
        chosen,original2,jt2,jf,jo=self.objective_components(best[:,None],u,z,current,times)
        for a,b in ((chosen[:,0],best_score),(original2[:,0],best_original),(jt2[:,0],best_jt)):np.testing.assert_array_equal(a,b)
        return self.execution.request(best[:,0]),dict(best_requested_plan_b=best,
            selected_planning_score=best_score,selected_original_return=best_original,selected_temperature_cost=best_jt,
            hold_temperature_cost=jt[:,0],planned_temperature_margin=jt[:,0]-best_jt,
            iteration_best_score=np.stack(iteration_scores,1),feasible_candidate_counts=np.stack(counts,1),
            noise_sha256=np.asarray([h.hexdigest() for h in noise.hashes],dtype='S64'),
            extra_noise_sha256=np.asarray([h.hexdigest() for h in noise.extra_hashes],dtype='S64'),
            selected_steam_variation_cost=jf[:,0],selected_oxygen_variation_cost=jo[:,0],selected_stability_cost=(jf+jo)[:,0])
