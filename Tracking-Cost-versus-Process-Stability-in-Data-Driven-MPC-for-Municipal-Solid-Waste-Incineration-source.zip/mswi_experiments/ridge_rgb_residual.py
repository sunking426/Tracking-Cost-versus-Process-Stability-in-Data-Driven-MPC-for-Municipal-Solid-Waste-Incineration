"""Stage-separated entry point for the fixed Ridge/RGB residual experiment."""
from __future__ import annotations

import argparse
import importlib.metadata
import json
from pathlib import Path
import platform
import shutil
import sys

from .numeric_baselines import sha256, write_json


def check_records(records):
    """Fail on changed or missing frozen inputs; never silently rebuild them."""
    for name, expected in records.items():
        path = Path(name)
        if not path.is_file() or sha256(path) != expected:
            raise ValueError(f"frozen artifact changed or missing: {path}")


def freeze_code(project, config_path, out):
    manifest = out / 'code_frozen.json'
    if manifest.exists():
        check_records(json.loads(manifest.read_text()))
        return
    # Reporting is separately frozen before test prediction; it may be authored
    # while the already specified model fitting is running.
    sources = [p for p in (project/'mswi_experiments').glob('*.py')
               if p.name != 'ridge_rgb_residual_report.py']
    sources += [p for p in (project/'tests').glob('test_ridge_rgb*.py')
                if p.name != 'test_ridge_rgb_residual_report.py']
    sources += [config_path, project/'current_predictor.json', project/'requirements-lock.txt']
    sources.append(out/'PROTOCOL.txt')
    records = {}
    for source in sources:
        relative = (Path('study')/'PROTOCOL.txt' if source == out/'PROTOCOL.txt'
                    else source.relative_to(project))
        destination = out/'code_snapshot_before_prepare'/relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        records[str(source)] = sha256(source)
    write_json(manifest, records)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', required=True, type=Path)
    parser.add_argument('--stage', required=True, choices=('prepare', 'fit', 'predict', 'report'))
    args = parser.parse_args()
    project = Path(__file__).resolve().parents[1]
    config_path = args.config.resolve()
    config = json.loads(config_path.read_text())
    out = (project/config['output_dir']).resolve()
    out.mkdir(parents=True, exist_ok=True)
    if args.stage == 'prepare':
        if (out/'prepared_frozen.json').exists():
            raise FileExistsError('prepared study is frozen; use a new output_dir for a fresh study')
        freeze_code(project, config_path, out)
        write_json(out/'config.json', config)
        env = {'python':sys.version, 'platform':platform.platform(),
               'libraries':{name:importlib.metadata.version(name) for name in
                            ('numpy','scipy','scikit-learn','torch','matplotlib')},
               'threads':config['training']['threads'], 'device':'cpu'}
        write_json(out/'environment.json', env)
        from .ridge_rgb_residual_data import prepare_data
        prepare_data({**config, 'project_root':str(project)}, out)
        paths = [out/name for name in ('prepared.npz','source_records.npz','preparation.json','input_hashes.json','config.json')]
        paths += sorted((out/'oof').rglob('*.npz'))
        write_json(out/'prepared_frozen.json', {str(p):sha256(p) for p in paths})
        print('Prepared and frozen', out, flush=True)
        return
    check_records(json.loads((out/'code_frozen.json').read_text()))
    check_records(json.loads((out/'prepared_frozen.json').read_text()))
    if json.loads((out/'config.json').read_text()) != config:
        raise ValueError('configuration differs from prepared study')
    if args.stage == 'fit':
        from .ridge_rgb_residual_model import fit_all
        fit_all(out/'prepared.npz', config, out)
    elif args.stage == 'predict':
        report_manifest = out/'report_code_frozen.json'
        if report_manifest.exists():
            check_records(json.loads(report_manifest.read_text()))
        else:
            paths = [project/'mswi_experiments/ridge_rgb_residual_report.py',
                     project/'tests/test_ridge_rgb_residual_report.py']
            records = {str(p):sha256(p) for p in paths}
            for source in paths:
                destination = out/'report_snapshot_before_prediction'/source.relative_to(project)
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, destination)
            write_json(report_manifest, records)
        from .ridge_rgb_residual_model import predict_all
        predict_all(out/'prepared.npz', config, out)
    else:
        check_records(json.loads((out/'report_code_frozen.json').read_text()))
        from .ridge_rgb_residual_report import summarize_study, render_figures
        summary = summarize_study(out)
        render_figures(out, summary)
    print('Complete:', args.stage, out, flush=True)


if __name__ == '__main__':
    main()
