"""Matched nine-channel numerical forecasting baselines.

Fit and model selection never score the test partition. A separate predict stage
reloads frozen selections and writes reproducible, aligned physical predictions.
The residual model is explicitly a two-stage in-sample residual regression, not
out-of-fold stacking or independent calibration.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import sys
import time

import numpy as np
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

from .data import load_data
from .training import fit_twin, load_twin, predict_twin, seed_everything


def write_json(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def numeric_features(data):
    """Only known MV t-10..t and CV t-10..t-1; no next action or CV t."""
    u, z = np.asarray(data['u_hist']), np.asarray(data['z_hist'])
    if u.ndim != 3 or z.ndim != 3 or u.shape[1:] != (11, 8) or z.shape[1:] != (10, 9):
        raise ValueError('this fixed-window study requires MV (N,11,8) and CV (N,10,9)')
    if len(u) != len(z) or not np.isfinite(u).all() or not np.isfinite(z).all():
        raise ValueError('numeric histories must be finite and sample-aligned')
    return np.concatenate((u.reshape(len(u), -1), z.reshape(len(z), -1)), axis=1).astype(np.float64)


def normalized_mse(y, pred, delta_scale):
    y, pred, scale = np.asarray(y, dtype=np.float64), np.asarray(pred, dtype=np.float64), np.asarray(delta_scale, dtype=np.float64)
    if y.shape != pred.shape or y.ndim != 2 or y.shape[1] != 9 or scale.shape != (9,):
        raise ValueError('normalized loss requires aligned nine-channel arrays and scales')
    if not (scale > 0).all() or not np.isfinite(scale).all() or not np.isfinite(y).all() or not np.isfinite(pred).all():
        raise ValueError('normalized loss inputs must be finite with positive scales')
    return float(np.mean(np.square((pred - y) / scale)))


def choose_candidate(candidates, tolerance=1e-12):
    """Validation only; tied losses prefer zero correction, then greater alpha."""
    if not candidates:
        raise ValueError('empty candidate list')
    losses = [float(row['val_normalized_mse']) for row in candidates]
    if not np.isfinite(losses).all():
        raise ValueError('nonfinite candidate loss')
    best = min(losses)
    tied = [row for row in candidates if row['val_normalized_mse'] <= best + tolerance]
    return min(tied, key=lambda row: (row['kind'] != 'zero', -float(row.get('alpha') or 0)))


def fit_linear_candidates(x, target_delta, reference, truth, train_idx, val_idx,
                          delta_scale, alphas, *, include_zero=False):
    """Fit in training only, weight all outputs using the shared target scale.

    ``target_delta`` is y-z_prev for Ridge and y-GRU for residual correction.
    ``reference`` is the corresponding absolute baseline prediction.
    """
    x = np.asarray(x, dtype=np.float64)
    delta = np.asarray(target_delta, dtype=np.float64)
    reference, truth = np.asarray(reference, dtype=np.float64), np.asarray(truth, dtype=np.float64)
    train_idx, val_idx = np.asarray(train_idx, dtype=np.int64), np.asarray(val_idx, dtype=np.int64)
    scale = np.asarray(delta_scale, dtype=np.float64)
    if len(np.intersect1d(train_idx, val_idx)):
        raise ValueError('training and validation must be disjoint')
    normalized_mse(truth[val_idx], reference[val_idx], scale)
    if delta.shape != truth.shape or len(x) != len(truth) or not np.isfinite(delta[train_idx]).all():
        raise ValueError('linear training targets must match the nine-channel truth')
    if any(not np.isfinite(a) or a <= 0 for a in alphas) or not alphas:
        raise ValueError('Ridge alphas must be finite and positive')
    scaler = StandardScaler().fit(x[train_idx])
    xs_train, xs_val = scaler.transform(x[train_idx]), scaler.transform(x[val_idx])
    targets = delta[train_idx] / scale
    candidates, weights = [], {}
    if include_zero:
        candidates.append({'kind': 'zero', 'alpha': None,
                           'val_normalized_mse': normalized_mse(truth[val_idx], reference[val_idx], scale)})
    for alpha in alphas:
        regressor = Ridge(alpha=float(alpha), fit_intercept=True, solver='cholesky')
        regressor.fit(xs_train, targets)
        pred = reference[val_idx] + regressor.predict(xs_val) * scale
        row = {'kind': 'ridge', 'alpha': float(alpha),
               'val_normalized_mse': normalized_mse(truth[val_idx], pred, scale)}
        candidates.append(row)
        weights[float(alpha)] = (regressor.coef_.copy(), regressor.intercept_.copy())
    chosen = choose_candidate(candidates)
    if chosen['kind'] == 'zero':
        coef, intercept = np.zeros((9, x.shape[1])), np.zeros(9)
    else:
        coef, intercept = weights[chosen['alpha']]
    model = {'x_mean': scaler.mean_, 'x_scale': scaler.scale_, 'coef': coef,
             'intercept': intercept, 'delta_scale': scale, 'kind': np.asarray(chosen['kind']),
             'alpha': np.asarray(np.nan if chosen['alpha'] is None else chosen['alpha'])}
    return model, candidates, chosen


def linear_increment(model, x):
    x = np.asarray(x, dtype=np.float64)
    standardized = (x - model['x_mean']) / model['x_scale']
    return (standardized @ model['coef'].T + model['intercept']) * model['delta_scale']


def _paths(config_file):
    config_path = Path(config_file).resolve()
    cfg = json.loads(config_path.read_text())
    return cfg, config_path.parent / cfg['source_run'], config_path.parent / cfg['output_dir']


def _check_data(data, stats):
    numeric_features(data)
    if not np.array_equal(data['z_prev'], data['z_hist'][:, -1]):
        raise ValueError('z_prev must be the final observed CV history row')
    if np.asarray(data['z_target']).shape != (len(data['time_ns']), 9):
        raise ValueError('target must have nine CV channels')
    previous_end = None
    for split in ('train', 'val', 'test'):
        idx = np.asarray(data[split + '_idx'])
        if len(idx) == 0 or len(np.unique(idx)) != len(idx) or np.any(np.diff(idx) <= 0):
            raise ValueError('each partition must contain unique ordered samples')
        times = np.asarray(data['time_ns'])[idx]
        if previous_end is not None and times.min() <= previous_end:
            raise ValueError('partitions must be chronological and nonoverlapping')
        previous_end = times.max()
    normalized_mse(data['z_target'][data['val_idx']], data['z_prev'][data['val_idx']], stats['delta_scale'])


def prepare(config_file):
    cfg, source, out = _paths(config_file)
    out.mkdir(parents=True, exist_ok=True)
    if (out / 'config.json').exists():
        if json.loads((out / 'config.json').read_text()) != cfg:
            raise ValueError('frozen configuration differs; use a new output directory')
        _load_prepared(config_file)
        return out
    data, stats, source_manifest = load_data(source / 'data')
    _check_data(data, stats)
    hashes = {str(path.resolve()): sha256(path) for path in
              [source / 'data' / name for name in ('dataset.npz', 'stats.json', 'manifest.json')]}
    splits = {}
    for split in ('train', 'val', 'test'):
        idx = data[split + '_idx']
        splits[split] = {'n': len(idx), 'start_ns': int(data['time_ns'][idx].min()),
                         'end_ns': int(data['time_ns'][idx].max()),
                         'indices_sha256': hashlib.sha256(np.asarray(idx).tobytes()).hexdigest()}
    protocol = {
        'schema_version': 1, 'scope': 'matched one-step nine-channel numerical baselines',
        'source_run': str(source.resolve()), 'partitions': splits,
        'input_definition': '178 flattened numeric history entries: MV t-10..t (11x8), CV t-10..t-1 (10x9)',
        'excluded_inputs': ['visual features', 'capture times', 'z_current', 'next-minute action'],
        'forecast_definition': 'z_t conditional on known u_t and previous CVs; not a long-horizon autonomous forecast',
        'target_definition': 'nine physical CV channels; fit increments from z_prev',
        'selection_loss': 'mean(((prediction - truth) / training delta_scale)^2) over all nine channels and validation samples',
        'linear_input_scaling': 'StandardScaler fit on outer training samples only',
        'residual_definition': 'frozen full-training GRU followed by Ridge on its in-sample training residuals, using the same 178 numeric inputs and delta_scale; not OOF or independent calibration',
        'residual_zero_candidate': True, 'tie_rule': 'within 1e-12 prefer zero correction, then larger alpha',
        'test_evaluation': 'separate predict stage after all GRU checkpoints and Ridge/residual selections are saved and hashed',
        'test_status': 'previously inspected historical test segment; all conclusions remain exploratory',
        'sample_scope': 'same retained image-available samples as the manuscript, although this study does not consume images',
        'primary_metric': 'nine_channel_normalized_mse',
        'secondary_metrics': ['four physical aggregate MAE/RMSE', 'nine channel MAE/RMSE'],
        'aggregation': 'temperature is mean of channels 0:6 before computing error; pressure/steam/oxygen are channels 6/7/8',
        'source_manifest': source_manifest,
    }
    write_json(out / 'config.json', cfg)
    write_json(out / 'stats.json', stats)
    write_json(out / 'input_hashes.json', hashes)
    write_json(out / 'protocol.json', protocol)
    versions = {name: importlib.metadata.version(name) for name in
                ('numpy', 'scipy', 'scikit-learn', 'torch', 'threadpoolctl')}
    write_json(out / 'environment.json', {'python': sys.version, 'platform': platform.platform(),
                                         'packages': versions, 'device': 'cpu'})
    return out


def _load_prepared(config_file):
    cfg, source, out = _paths(config_file)
    if not (out / 'protocol.json').exists() or json.loads((out / 'config.json').read_text()) != cfg:
        raise ValueError('run prepare with this exact configuration first')
    for path, expected in json.loads((out / 'input_hashes.json').read_text()).items():
        if sha256(path) != expected:
            raise ValueError(f'prepared source changed: {path}')
    data, stats, _ = load_data(source / 'data')
    if json.loads((out / 'stats.json').read_text()) != stats:
        raise ValueError('frozen statistics differ from source')
    _check_data(data, stats)
    return cfg, out, data, stats


def train(config_file):
    cfg, out, data, stats = _load_prepared(config_file)
    if (out / 'selection_frozen.json').exists() or (out / 'models').exists():
        raise ValueError('training output already exists; preserve it and use a new output directory')
    started = time.monotonic()
    x, y = numeric_features(data), np.asarray(data['z_target'], dtype=np.float64)
    prev = np.asarray(data['z_prev'], dtype=np.float64)
    train_idx, val_idx = data['train_idx'], data['val_idx']
    scale = np.asarray(stats['delta_scale'], dtype=np.float64)
    alphas = cfg['diagnostics']['ridge_alphas']
    models = [{'id': 'persistence', 'method': 'persistence', 'seed': None, 'model_path': None,
               'base_model_path': None, 'selected_kind': 'persistence', 'selected_alpha': None,
               'val_normalized_mse': normalized_mse(y[val_idx], prev[val_idx], scale)}]
    rows = []
    with threadpool_limits(limits=int(cfg['training']['threads'])):
        model, candidates, selected = fit_linear_candidates(x, y - prev, prev, y,
                                                          train_idx, val_idx, scale, alphas)
        ridge_path = out / 'models/ridge/model.npz'
        ridge_path.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(ridge_path, **model)
        models.append({'id': 'ridge', 'method': 'ridge', 'seed': None,
                       'model_path': str(ridge_path.relative_to(out)), 'base_model_path': None,
                       'selected_kind': selected['kind'], 'selected_alpha': selected['alpha'],
                       'val_normalized_mse': selected['val_normalized_mse']})
        rows.extend({'model_id': 'ridge', **row, 'selected': row is selected} for row in candidates)
        for seed in cfg['diagnostics']['seeds']:
            gru_id, residual_id = f'gru_seed_{seed}', f'gru_residual_seed_{seed}'
            gru_dir = out / 'models/gru' / f'seed_{seed}'
            twin, metrics = fit_twin(data, stats, 'sensor', int(seed), cfg, gru_dir, evaluate_test=False)
            base = np.full(y.shape, np.nan, dtype=np.float64)
            for idx in (train_idx, val_idx):
                base[idx] = predict_twin(twin, data, idx, batch_size=int(cfg['training']['batch_size']))
            path = str((gru_dir / 'twin.pt').relative_to(out))
            val_loss = normalized_mse(y[val_idx], base[val_idx], scale)
            models.append({'id': gru_id, 'method': 'gru', 'seed': int(seed), 'model_path': path,
                           'base_model_path': None, 'selected_kind': 'gru', 'selected_alpha': None,
                           'val_normalized_mse': val_loss, 'training_best_val_normalized_mse': metrics['best_val_normalized_mse']})
            model, candidates, selected = fit_linear_candidates(x, y - base, base, y,
                                                              train_idx, val_idx, scale, alphas,
                                                              include_zero=True)
            residual_path = out / 'models/gru_residual' / f'seed_{seed}' / 'model.npz'
            residual_path.parent.mkdir(parents=True, exist_ok=True)
            np.savez_compressed(residual_path, **model)
            models.append({'id': residual_id, 'method': 'gru_residual', 'seed': int(seed),
                           'model_path': str(residual_path.relative_to(out)), 'base_model_path': path,
                           'selected_kind': selected['kind'], 'selected_alpha': selected['alpha'],
                           'val_normalized_mse': selected['val_normalized_mse']})
            rows.extend({'model_id': residual_id, **row, 'selected': row is selected} for row in candidates)
            print(f'{residual_id}: selected={selected}', flush=True)
    with (out / 'selection_candidates.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=['model_id', 'kind', 'alpha', 'val_normalized_mse', 'selected'])
        writer.writeheader()
        writer.writerows(rows)
    write_json(out / 'selection.json', {'status': 'complete', 'models': models,
                                       'fit_elapsed_seconds': time.monotonic() - started,
                                       'test_predictions_computed': False})
    freeze_files = ['selection.json', 'selection_candidates.csv', 'config.json', 'stats.json', 'protocol.json']
    freeze_files += [row['model_path'] for row in models if row['model_path'] is not None]
    write_json(out / 'selection_frozen.json', {'status': 'complete', 'files': {
        name: sha256(out / name) for name in sorted(set(freeze_files))}})
    return models


def predict(config_file):
    cfg, out, data, stats = _load_prepared(config_file)
    frozen = json.loads((out / 'selection_frozen.json').read_text())
    if frozen['status'] != 'complete':
        raise ValueError('all model selections must be complete before prediction')
    for path, expected in frozen['files'].items():
        if sha256(out / path) != expected:
            raise ValueError(f'frozen selection or model changed: {path}')
    selection = json.loads((out / 'selection.json').read_text())
    if selection['status'] != 'complete':
        raise ValueError('selection incomplete')
    started, files = time.monotonic(), []
    x, y = numeric_features(data), np.asarray(data['z_target'], dtype=np.float64)
    prev = np.asarray(data['z_prev'], dtype=np.float64)
    seed_everything(0, cfg['training']['threads'])
    with threadpool_limits(limits=int(cfg['training']['threads'])):
        for row in selection['models']:
            twin, linear = None, None
            if row['method'] == 'gru':
                twin = load_twin(out / row['model_path'])
            if row['method'] == 'gru_residual':
                twin = load_twin(out / row['base_model_path'])
            if row['method'] in ('ridge', 'gru_residual'):
                with np.load(out / row['model_path'], allow_pickle=False) as archive:
                    linear = {key: archive[key] for key in archive.files}
            for split in ('train', 'val', 'test'):
                idx = np.asarray(data[split + '_idx'])
                if row['method'] == 'persistence':
                    pred = prev[idx].copy()
                elif row['method'] == 'ridge':
                    pred = prev[idx] + linear_increment(linear, x[idx])
                else:
                    pred = predict_twin(twin, data, idx, batch_size=cfg['training']['batch_size']).astype(np.float64)
                    if row['method'] == 'gru_residual':
                        pred += linear_increment(linear, x[idx])
                normalized_mse(y[idx], pred, stats['delta_scale'])
                path = out / 'predictions' / row['id'] / f'{split}.npz'
                path.parent.mkdir(parents=True, exist_ok=True)
                np.savez_compressed(path, indices=idx, time_ns=np.asarray(data['time_ns'])[idx],
                                    y=y[idx], pred=pred, error=pred - y[idx])
                files.append({'model_id': row['id'], 'method': row['method'], 'seed': row['seed'],
                              'split': split, 'path': str(path.relative_to(out)), 'sha256': sha256(path),
                              'n': len(idx), 'shape': list(pred.shape)})
    write_json(out / 'predictions_manifest.json', {'status': 'complete',
        'selection_sha256': sha256(out / 'selection.json'), 'files': files,
        'elapsed_seconds': time.monotonic() - started})
    return files


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', required=True)
    parser.add_argument('--stage', required=True, choices=['prepare', 'train', 'predict'])
    args = parser.parse_args()
    result = {'prepare': prepare, 'train': train, 'predict': predict}[args.stage](args.config)
    print(f'{args.stage} completed: {result if isinstance(result, Path) else len(result)}', flush=True)


if __name__ == '__main__':
    main()
