"""Source-bound reporting for numerical-neighbor visual Ridge dynamics.

This module scores saved predictions only. Model fitting and parameter selection
belong to the experiment runner. Retrieved visual features are functions of
numeric history and fixed training memory; these results cannot establish an
independent contemporaneous-image benefit or an intervention effect.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np

from .data import MINUTE_NS
from .numeric_baselines import sha256, write_json
from .numeric_baselines_report import metric_summary
from .ridge_validation_report import endpoint_differences
from .visual_diagnostics_statistics import DAY_NS, paired_block_interval


SPLITS = ("val", "test")
MV_MODES = ("logged", "hold_mv")
HORIZONS = (1, 5, 10)
ONE_STEP_METHODS = ("ridge", "retrieved52", "retrieved_rgb32", "shuffled52", "shuffled_rgb32",
                    "observed52_retrieved", "observed_rgb32_retrieved",
                    "observed52_observed", "observed_rgb32_observed")
ROLLOUT_METHODS = ONE_STEP_METHODS[:7] + ("retrieved52_hold_visual", "retrieved_rgb32_hold_visual")
QUANTITIES = ("temperature", "pressure", "steam", "oxygen")
UNITS = ("degC", "Pa", "t/h", "vol%")
ENDPOINTS = ("normalized_mse", *[q + "_mae" for q in QUANTITIES])
CONTRASTS = (
    ("retrieved52_vs_ridge", "ridge", "retrieved52"),
    ("retrieved_rgb32_vs_ridge", "ridge", "retrieved_rgb32"),
    ("retrieved52_vs_shuffled52", "shuffled52", "retrieved52"),
    ("retrieved_rgb32_vs_shuffled_rgb32", "shuffled_rgb32", "retrieved_rgb32"),
    ("retrieved52_vs_hold_visual", "retrieved52_hold_visual", "retrieved52"),
    ("retrieved_rgb32_vs_hold_visual", "retrieved_rgb32_hold_visual", "retrieved_rgb32"),
    ("retrieved_rgb32_vs_retrieved52", "retrieved52", "retrieved_rgb32"),
)
LABELS = {
    "ridge": "Numerical Ridge", "retrieved52": "Retrieved descriptors (52)",
    "retrieved_rgb32": "Retrieved RGB (32)", "shuffled52": "Shuffled descriptors",
    "shuffled_rgb32": "Shuffled RGB", "observed52_retrieved": "Observed-fit descriptors / retrieved",
    "observed_rgb32_retrieved": "Observed-fit RGB / retrieved",
    "observed52_observed": "Observed-fit descriptors / observed",
    "observed_rgb32_observed": "Observed-fit RGB / observed",
    "retrieved52_hold_visual": "Descriptors: initial retrieval held",
    "retrieved_rgb32_hold_visual": "RGB: initial retrieval held",
}
COLORS = {"ridge": "#1f77b4", "retrieved52": "#ff7f0e", "retrieved_rgb32": "#2ca02c",
          "shuffled52": "#ff7f0e", "shuffled_rgb32": "#2ca02c"}


def _csv(path, rows):
    if not rows:
        raise ValueError("a report table cannot be empty")
    with Path(path).open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)


def _integer(value, shape, name):
    if value.shape != shape or not np.issubdtype(value.dtype, np.integer):
        raise ValueError(f"invalid integer array {name}")


def validate_prediction_arrays(row, *, kind, method, horizon=10):
    """Validate temporal/physical contracts independently of manifest hashes."""
    required = {"indices", "time_ns", "truth_cv", "pred_cv", "key_indices", "donor_indices", "scores"}
    if kind == "rollout":
        required |= {"start_time_ns", "initial_zprev", "mv_path"}
    elif kind != "one_step":
        raise ValueError("unknown prediction kind")
    if not required.issubset(row):
        raise ValueError("prediction archive is missing required arrays")
    n = len(row["indices"])
    if n == 0:
        raise ValueError("prediction archives must be nonempty")
    prefix = (n, horizon) if kind == "rollout" else (n,)
    for name in ("indices", "time_ns", "key_indices", "donor_indices"):
        _integer(row[name], prefix, name)
    for name in ("truth_cv", "pred_cv"):
        if row[name].shape != prefix + (9,):
            raise ValueError("invalid nine-channel prediction shape")
    if row["scores"].shape != prefix:
        raise ValueError("retrieval score shape differs from forecast positions")
    if not all(np.isfinite(row[name]).all() for name in required):
        raise ValueError("nonfinite prediction or retrieval trace")
    if np.any(row["indices"] < 0):
        raise ValueError("negative process sample index")
    if kind == "rollout":
        _integer(row["start_time_ns"], (n,), "start_time_ns")
        if (row["initial_zprev"].shape != (n, 9) or row["mv_path"].shape != (n, horizon, 8)
                or not np.array_equal(row["time_ns"], row["start_time_ns"][:, None]
                                       + np.arange(horizon) * MINUTE_NS)
                or np.any(np.diff(row["start_time_ns"]) <= 0)
                or np.any(np.diff(row["indices"][:, 0]) <= 0)):
            raise ValueError("invalid recursive history or minute alignment")
        if method.endswith("_hold_visual"):
            for name in ("key_indices", "donor_indices", "scores"):
                if not np.array_equal(row[name], np.repeat(row[name][:, :1], horizon, axis=1)):
                    raise ValueError("held visual trace changes during recursion")
    elif np.any(np.diff(row["time_ns"]) <= 0) or np.any(np.diff(row["indices"]) <= 0):
        raise ValueError("one-step rows must be chronologically ordered")
    if method == "ridge":
        if (np.any(row["key_indices"] != -1) or np.any(row["donor_indices"] != -1)
                or np.any(row["scores"] != 0)):
            raise ValueError("non-retrieval method has an invented retrieval trace")
    elif method.endswith("_observed"):
        if (np.any(row["key_indices"] != -1) or not np.array_equal(row["donor_indices"], row["indices"])
                or np.any(row["scores"] != 0)):
            raise ValueError("observed visual context must identify its own source sample without a retrieval key")
    elif (np.any(row["key_indices"] < 0) or np.any(row["donor_indices"] < 0)
          or np.any(abs(row["scores"]) > 1 + 1e-10)):
        raise ValueError("retrieval indices or cosine scores outside their domain")


def load_completed_study(study_dir):
    root = Path(study_dir).resolve()
    names = ("config.json", "stats.json", "protocol.json", "selection.json",
             "selection_frozen.json", "predictions_manifest.json")
    cfg, stats, protocol, selection, frozen, manifest = [json.loads((root / name).read_text()) for name in names]
    if (manifest.get("status") != "complete" or frozen.get("status") != "complete"
            or manifest.get("selection_sha256") != sha256(root / "selection.json")
            or cfg["horizon"] != 10 or cfg["endpoints"] != list(HORIZONS)):
        raise ValueError("prediction selection or ten-step protocol is not complete and frozen")
    sources = {name: sha256(root / name) for name in names}
    if not isinstance(frozen.get("files"), dict) or "selection.json" not in frozen["files"]:
        raise ValueError("selection freeze does not bind selection.json")
    for name, digest in frozen["files"].items():
        if sha256(root / name) != digest:
            raise ValueError("frozen artifact changed: " + name)
        sources[name] = digest
    records = manifest["files"]
    indexed = {r["path"]: r for r in records}
    expected = {f"one_step/{s}/{m}.npz" for s in SPLITS for m in ONE_STEP_METHODS}
    expected |= {f"rollouts/{s}/{v}/{m}.npz" for s in SPLITS for v in MV_MODES for m in ROLLOUT_METHODS}
    if len(records) != len(indexed) or set(indexed) != expected:
        raise ValueError("prediction manifest must contain the complete unique forecast inventory")
    one_step = {s: {} for s in SPLITS}
    rollouts = {s: {v: {} for v in MV_MODES} for s in SPLITS}
    checks = []
    for relative in sorted(expected):
        record = indexed[relative]
        parts = relative.split("/")
        kind = "one_step" if parts[0] == "one_step" else "rollout"
        split, method = parts[1], Path(parts[-1]).stem
        if (record.get("kind") != kind or record["split"] != split or record["method"] != method
                or sha256(root / relative) != record["sha256"]):
            raise ValueError("prediction artifact identity or hash mismatch")
        if kind == "rollout" and record.get("mv_mode", parts[2]) != parts[2]:
            raise ValueError("rollout MV mode differs from path")
        with np.load(root / relative, allow_pickle=False) as archive:
            row = {name: archive[name].copy() for name in archive.files}
        validate_prediction_arrays(row, kind=kind, method=method, horizon=cfg["horizon"])
        target = one_step[split] if kind == "one_step" else rollouts[split][parts[2]]
        if target:
            previous = next(iter(target.values()))
            identity = ("indices", "time_ns", "truth_cv")
            if kind == "rollout":
                identity += ("start_time_ns", "initial_zprev", "mv_path")
            if any(not np.array_equal(row[name], previous[name]) for name in identity):
                raise ValueError("paired methods do not share targets and conditioning observations")
        target[method] = row
        sources[relative] = record["sha256"]
        checks.append({"path": relative, "samples": len(row["indices"]), "shape_hash_time_verified": True})
    for split in SPLITS:
        lookup = {int(index): j for j, index in enumerate(one_step[split]["ridge"]["indices"])}
        for mode in MV_MODES:
            group = rollouts[split][mode]
            base = group["ridge"]
            indices = base["indices"]
            try:
                positions = np.array([lookup[int(i)] for i in indices.ravel()]).reshape(indices.shape)
            except KeyError as error:
                raise ValueError("recursive targets are absent from one-step partition") from error
            if not np.array_equal(base["truth_cv"], one_step[split]["ridge"]["truth_cv"][positions]):
                raise ValueError("recursive labels differ from the common one-step labels")
            for method in ROLLOUT_METHODS:
                row = group[method]
                first_method = method.removesuffix("_hold_visual")
                if not np.allclose(row["pred_cv"][:, 0], one_step[split][first_method]["pred_cv"][positions[:, 0]],
                                   rtol=0, atol=1e-9):
                    raise ValueError("recursive first prediction differs from its one-step model")
                if method.endswith("_hold_visual"):
                    dynamic = group[first_method]
                    if any(not np.array_equal(row[key][:, 0], dynamic[key][:, 0])
                           for key in ("key_indices", "donor_indices", "scores")):
                        raise ValueError("held and dynamic retrieval start from different visual context")
            held, logged = rollouts[split]["hold_mv"]["ridge"], rollouts[split]["logged"]["ridge"]
            for name in ("indices", "time_ns", "truth_cv", "start_time_ns", "initial_zprev"):
                if not np.array_equal(held[name], logged[name]):
                    raise ValueError("MV scenarios do not share starts and observed targets")
            if not np.array_equal(held["mv_path"], np.repeat(logged["mv_path"][:, :1], cfg["horizon"], axis=1)):
                raise ValueError("held MV path is not constant at the known starting action")
    return root, cfg, stats, protocol, selection, one_step, rollouts, sources, checks


def retrieval_diagnostics(row):
    """Descriptive memory use; cosine similarity is not predictive confidence."""
    keys, donors, scores = [np.asarray(row[name]) for name in ("key_indices", "donor_indices", "scores")]
    active = keys >= 0
    if not active.any():
        return {"retrieval_positions": 0, "unique_keys": 0, "unique_donors": 0,
                "mean_cosine": None, "p05_cosine": None, "median_cosine": None,
                "p95_cosine": None, "donor_switch_fraction": None, "key_switch_fraction": None}
    if not active.all():
        raise ValueError("a method cannot mix missing and active retrieval traces")
    return {"retrieval_positions": int(donors.size), "unique_keys": int(len(np.unique(keys))),
            "unique_donors": int(len(np.unique(donors))), "mean_cosine": float(scores.mean()),
            "p05_cosine": float(np.quantile(scores, .05)), "median_cosine": float(np.median(scores)),
            "p95_cosine": float(np.quantile(scores, .95)),
            "donor_switch_fraction": float(np.mean(donors[:, 1:] != donors[:, :-1])) if donors.ndim == 2 else None,
            "key_switch_fraction": float(np.mean(keys[:, 1:] != keys[:, :-1])) if keys.ndim == 2 else None}


def _metric_row(metric, **identity):
    row = {**identity, "samples": metric["samples"], "normalized_mse": metric["normalized_mse"]}
    for j, q in enumerate(QUANTITIES):
        row[q + "_mae"] = metric["physical_mae"][j]
        row[q + "_rmse"] = metric["physical_rmse"][j]
    return row


def summarize(study_dir):
    root, cfg, stats, protocol, selection, one_step, rollouts, sources, checks = load_completed_study(study_dir)
    out = root / "statistics"; out.mkdir(exist_ok=True)
    scale = np.asarray(stats["delta_scale"], dtype=np.float64)
    single_metrics, recursive_metrics = {}, {}
    single_rows, curve_rows, channel_rows, retrieval_rows = [], [], [], []
    for split in SPLITS:
        single_metrics[split] = {}
        recursive_metrics[split] = {}
        for method in ONE_STEP_METHODS:
            row = one_step[split][method]
            metric = metric_summary(row["pred_cv"][None], row["truth_cv"], scale)
            single_metrics[split][method] = metric
            single_rows.append(_metric_row(metric, split=split, method=method))
            retrieval_rows.append({"kind": "one_step", "split": split, "mv_mode": "none", "method": method,
                                   **retrieval_diagnostics(row)})
        for mode in MV_MODES:
            recursive_metrics[split][mode] = {}
            for method in ROLLOUT_METHODS:
                row = rollouts[split][mode][method]
                recursive_metrics[split][mode][method] = {}
                retrieval_rows.append({"kind": "rollout", "split": split, "mv_mode": mode, "method": method,
                                       **retrieval_diagnostics(row)})
                for step in range(cfg["horizon"]):
                    metric = metric_summary(row["pred_cv"][:, step][None], row["truth_cv"][:, step], scale)
                    recursive_metrics[split][mode][method][str(step + 1)] = metric
                    curve_rows.append(_metric_row(metric, split=split, mv_mode=mode, method=method, horizon=step + 1))
                    if step + 1 in HORIZONS:
                        for channel in range(9):
                            channel_rows.append({"split": split, "mv_mode": mode, "method": method,
                                "horizon": step + 1, "channel": channel, "mae": metric["channel_mae"][channel],
                                "rmse": metric["channel_rmse"][channel]})
    comparisons, comparison_rows = {}, []
    for mode in MV_MODES:
        comparisons[mode] = {}
        group = rollouts["test"][mode]
        blocks = group["ridge"]["start_time_ns"] // DAY_NS
        for name, ref, cand in CONTRASTS:
            comparisons[mode][name] = {}
            for horizon in HORIZONS:
                diff = endpoint_differences(group[ref]["pred_cv"][:, horizon - 1],
                    group[cand]["pred_cv"][:, horizon - 1], group[ref]["truth_cv"][:, horizon - 1], scale)
                interval = paired_block_interval(diff, blocks, draws=cfg["bootstrap_draws"],
                    seed=cfg["bootstrap_seed"], confidence_level=cfg["confidence_level"])
                comparisons[mode][name][str(horizon)] = {"reference": ref, "candidate": cand,
                    "endpoint_names": list(ENDPOINTS), **interval}
                for j, endpoint in enumerate(ENDPOINTS):
                    comparison_rows.append({"mv_mode": mode, "contrast": name, "reference": ref, "candidate": cand,
                        "horizon": horizon, "endpoint": endpoint, "difference": interval["difference"][j],
                        "ci_lower": interval["ci_lower"][j], "ci_upper": interval["ci_upper"][j],
                        "samples": interval["samples"], "time_blocks": interval["time_blocks"],
                        "confidence_level": interval["confidence_level"], "draws": interval["draws"],
                        "positive_means": "candidate error is lower", "exploratory": True})
    _csv(out / "one_step_metrics.csv", single_rows)
    _csv(out / "step_curves.csv", curve_rows)
    _csv(out / "endpoints.csv", [row for row in curve_rows if row["horizon"] in HORIZONS])
    _csv(out / "channels.csv", channel_rows)
    _csv(out / "retrieval_diagnostics.csv", retrieval_rows)
    _csv(out / "paired_comparisons.csv", comparison_rows)
    result = {"status": "complete", "primary_endpoint": "test / logged MV / step 10 / nine-channel normalized MSE",
        "one_step": single_metrics, "rollouts": recursive_metrics, "comparisons": comparisons,
        "prediction_checks": checks, "retrieval_diagnostics": retrieval_rows,
        "inference": "Paired calendar-day percentile bootstrap; one deterministic fit per model, no fit-seed replication; exploratory and unadjusted.",
        "limits": ["The historical test period has been inspected in previous development.",
                   "Recorded future MV is a conditioning input, not an online forecast.",
                   "Held-MV errors use the observed factual target, not a measured counterfactual.",
                   "Retrieved features are determined by numeric history and fixed training memory; independent live-image value is not identified.",
                   "The shuffled control uses one fixed training-memory permutation.",
                   "No RL or plant intervention is evaluated in this study."],
        "source_hashes": sources}
    write_json(out / "summary.json", result)
    return result


def render_figures(root, result):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    root = Path(root); dest = root / "figures"; dest.mkdir(exist_ok=True)
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10,
                         "axes.spines.top": False, "axes.spines.right": False})
    main = ("ridge", "retrieved52", "retrieved_rgb32", "shuffled52", "shuffled_rgb32")
    fig, axes = plt.subplots(1, 2, figsize=(11.2, 4.1), sharey=True)
    plot_rows = []
    for ax, mode, title in zip(axes, MV_MODES, ("Recorded MV path", "MV held at origin")):
        for method in main:
            values = result["rollouts"]["test"][mode][method]
            x = np.arange(1, 11); y = [values[str(h)]["normalized_mse"] for h in x]
            ax.plot(x, y, color=COLORS[method], linestyle="--" if method.startswith("shuffled") else "-",
                    marker=None if method.startswith("shuffled") else "o", markersize=3, label=LABELS[method])
            plot_rows.extend({"mv_mode": mode, "method": method, "horizon": int(h), "normalized_mse": v}
                             for h, v in zip(x, y))
        ax.set(title=title, xlabel="Forecast horizon (min)", xticks=[1, 3, 5, 7, 10]); ax.grid(alpha=.2)
    axes[0].set_ylabel("Normalized MSE (9 channels)")
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=3, frameon=False, bbox_to_anchor=(.5, -.01))
    fig.tight_layout(rect=(0, .14, 1, 1))
    for ext in ("png", "svg"): fig.savefig(dest / f"retrieval_recursive_nmse.{ext}", dpi=180, bbox_inches="tight")
    plt.close(fig); _csv(dest / "retrieval_recursive_nmse_data.csv", plot_rows)

    fig, axes = plt.subplots(2, 2, figsize=(10.2, 6.3)); plot_rows = []
    selected = main[:3]; x = np.arange(3)
    for j, ax in enumerate(axes.flat):
        vals = [result["rollouts"]["test"]["logged"][method]["10"]["physical_mae"][j] for method in selected]
        ax.bar(x, vals, color=[COLORS[m] for m in selected], width=.6)
        ax.set_xticks(x, ["Numerical", "Retrieved 52", "Retrieved RGB"])
        ax.set_ylabel(f"MAE ({UNITS[j]})"); ax.set_title(QUANTITIES[j].capitalize()); ax.grid(axis="y", alpha=.2)
        ax.margins(y=.18)
        for p, value in zip(x, vals): ax.annotate(f"{value:.4g}", (p, value), xytext=(0, 4), textcoords="offset points", ha="center")
        plot_rows.extend({"method": m, "quantity": QUANTITIES[j], "unit": UNITS[j], "horizon": 10, "mae": v}
                         for m, v in zip(selected, vals))
    fig.suptitle("Step 10 physical errors — recorded MV path", y=1.01)
    fig.tight_layout()
    for ext in ("png", "svg"): fig.savefig(dest / f"retrieval_step10_physical_mae.{ext}", dpi=180, bbox_inches="tight")
    plt.close(fig); _csv(dest / "retrieval_step10_physical_mae_data.csv", plot_rows)

    fig, ax = plt.subplots(figsize=(10.5, 5.0)); plot_rows = []
    contrast_labels = ["Descriptors vs numerical Ridge", "RGB vs numerical Ridge", "Descriptors vs shuffled descriptors",
                       "RGB vs shuffled RGB", "Descriptors: updating vs holding", "RGB: updating vs holding", "RGB vs descriptors"]
    for i, (name, ref, cand) in enumerate(CONTRASTS):
        row = result["comparisons"]["logged"][name]["10"]
        mean, lo, hi = row["difference"][0], row["ci_lower"][0], row["ci_upper"][0]
        color = COLORS[cand]
        ax.plot([lo, hi], [i, i], color=color, linewidth=2)
        ax.scatter([mean], [i], color=color, s=35, zorder=3)
        plot_rows.append({"contrast": name, "horizon": 10, "endpoint": "normalized_mse", "difference": mean,
                          "ci_lower": lo, "ci_upper": hi, "time_blocks": row["time_blocks"]})
    ax.axvline(0, color="black", linewidth=.8, linestyle="--")
    ax.set_yticks(np.arange(len(CONTRASTS)), contrast_labels); ax.invert_yaxis()
    ax.set_xlabel("Step 10 NMSE reduction (positive favors candidate)")
    ax.set_title("Recorded MV path: paired day-block exploratory 95% intervals")
    ax.grid(axis="x", alpha=.2); fig.tight_layout()
    for ext in ("png", "svg"): fig.savefig(dest / f"retrieval_step10_paired_effects.{ext}", dpi=180, bbox_inches="tight")
    plt.close(fig); _csv(dest / "retrieval_step10_paired_effects_data.csv", plot_rows)


def write_readout(root, result):
    root = Path(root)
    lines = ["Ridge dynamics with nearest-neighbor visual retrieval", "",
             "Primary endpoint: test, recorded MV path, step 10, nine-channel normalized MSE.",
             "All methods use the same retained starts and targets. Lower error is better.", "",
             "Step 10 recorded-MV results:", "method | NMSE | temperature MAE | pressure MAE | steam MAE | oxygen MAE"]
    for method in ROLLOUT_METHODS:
        row = result["rollouts"]["test"]["logged"][method]["10"]
        lines.append(method + " | " + " | ".join(f"{x:.9g}" for x in [row["normalized_mse"], *row["physical_mae"]]))
    lines += ["", "Paired step 10 error reductions (reference minus candidate):"]
    for name, _, _ in CONTRASTS:
        row = result["comparisons"]["logged"][name]["10"]
        lo, hi = row["ci_lower"][0], row["ci_upper"][0]
        direction = "interval above zero" if lo > 0 else "interval below zero" if hi < 0 else "interval includes zero"
        lines.append(f"{name}: {row['difference'][0]:.9g} [{lo:.9g}, {hi:.9g}]; {direction}.")
    lines += ["", "Full-test one-step results (distinct denominator from complete recursive chains):"]
    for method in ONE_STEP_METHODS:
        row = result["one_step"]["test"][method]
        lines.append(f"{method}: N={row['samples']}, NMSE={row['normalized_mse']:.9g}")
    lines += ["", "Interpretation boundaries:", *["- " + x for x in result["limits"]],
              "- Similarity scores describe memory matching; they are not calibrated uncertainty estimates.",
              "- Validation selected regularization from one-step prediction error. Recursive test results did not select models.",
              "", "Inspect statistics/summary.json and CSV files for all methods, horizons, MV scenarios, physical metrics, and retrieval traces."]
    (root / "RESULTS.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")


def build_report(study_dir):
    result = summarize(study_dir)
    root = Path(study_dir).resolve()
    render_figures(root, result)
    write_readout(root, result)
    outputs = [*sorted((root / "statistics").glob("*")), *sorted((root / "figures").glob("*")), root / "RESULTS.txt"]
    write_json(root / "report_manifest.json", {"status": "complete",
        "source_manifest_sha256": sha256(root / "predictions_manifest.json"),
        "files": {str(path.relative_to(root)): sha256(path) for path in outputs if path.is_file()}})
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("study_dir")
    args = parser.parse_args()
    result = build_report(args.study_dir)
    print(json.dumps({"status": result["status"], "forecast_archives": len(result["prediction_checks"])}))


if __name__ == "__main__":
    main()
