"""TD3 with logged transitions, short surrogate rollouts and optional BC."""
from __future__ import annotations

import copy
import json
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import torch
from torch import nn
import torch.nn.functional as F

from .control import (
    observations_from_data, project_normalized_actions, project_state_actions,
    reward_and_violation,
)
from .models import Actor, actor_config, make_state


def seed_everything(seed: int) -> np.random.Generator:
    np.random.seed(int(seed))
    torch.manual_seed(int(seed))
    return np.random.default_rng(int(seed))


@dataclass
class LoggedTransitions:
    states: torch.Tensor
    actions: torch.Tensor
    rewards: torch.Tensor
    next_states: torch.Tensor
    indices: np.ndarray
    eligibility: dict

    def sample(self, n: int, rng: np.random.Generator):
        idx = torch.as_tensor(rng.integers(0, len(self.indices), size=int(n)), dtype=torch.long)
        return tuple(value[idx] for value in (self.states, self.actions, self.rewards, self.next_states))


def eligible_start_indices(data, stats, partition="train_idx") -> np.ndarray:
    idx = np.asarray(data[partition], dtype=np.int64)
    u = data["u_current"][idx]
    low = np.asarray(stats["u_low"], dtype=np.float32)
    high = np.asarray(stats["u_high"], dtype=np.float32)
    return idx[((u >= low - 1e-5) & (u <= high + 1e-5)).all(axis=1)]


@torch.no_grad()
def build_logged_transitions(data, stats, twin, policy_visual="retrieval", batch_size=1024):
    if policy_visual not in {"retrieval", "hold"}:
        raise ValueError("Unknown policy visual mode")
    train = np.asarray(data["train_idx"], dtype=np.int64)
    next_all = np.asarray(data["next_idx"], dtype=np.int64)
    idx = train[next_all[train] >= 0]
    idx = idx[np.isin(next_all[idx], train)]
    candidate_count = len(idx)
    next_idx = next_all[idx]
    scale = np.asarray(stats["action_scale"], dtype=np.float32)
    bound = np.asarray(stats["action_bound"], dtype=np.float32)
    low = np.asarray(stats["u_low"], dtype=np.float32)
    high = np.asarray(stats["u_high"], dtype=np.float32)
    raw_actions = data["action"][idx]
    actual_increment = data["u_current"][next_idx] - data["u_current"][idx]
    if not np.allclose(raw_actions, actual_increment, atol=2e-4, rtol=1e-5):
        raise ValueError("Logged action does not match the next sample MV increment")
    action_ok = (np.abs(raw_actions) <= bound + 1e-5).all(axis=1)
    current_ok = ((data["u_current"][idx] >= low - 1e-5) & (data["u_current"][idx] <= high + 1e-5)).all(axis=1)
    next_ok = ((data["u_current"][next_idx] >= low - 1e-5) & (data["u_current"][next_idx] <= high + 1e-5)).all(axis=1)
    idx = idx[action_ok & current_ok & next_ok]
    next_idx = next_all[idx]
    if len(idx) < 16:
        raise ValueError("Insufficient feasible training transitions for replay")
    states, next_states = [], []
    twin.eval()
    for start in range(0, len(idx), int(batch_size)):
        indices = idx[start:start + int(batch_size)]
        nxt = next_idx[start:start + int(batch_size)]
        current = observations_from_data(data, indices)
        following = observations_from_data(data, nxt)
        following_visual = current["visual"] if policy_visual == "hold" else following["visual"]
        states.append(make_state(twin, **current).detach())
        following["visual"] = following_visual
        next_states.append(make_state(twin, **following).detach())
    # Retained logged increments already satisfy the execution envelope. Use
    # the identical projection as generated replay and reject a mismatch rather
    # than pairing a materially changed action with the recorded next state.
    actions, executed, _ = project_normalized_actions(
        torch.as_tensor(data["action"][idx] / scale, dtype=torch.float32),
        torch.as_tensor(data["u_current"][idx], dtype=torch.float32), stats,
    )
    if not np.allclose(executed.numpy(), data["action"][idx], atol=2e-4, rtol=1e-5):
        raise ValueError("Feasible logged increment changes under the execution projection")
    actions = actions.numpy()
    rewards, _, _ = reward_and_violation(data["z_current"][next_idx], actions, stats)
    return LoggedTransitions(
        torch.cat(states), torch.as_tensor(actions, dtype=torch.float32),
        torch.as_tensor(rewards[:, None], dtype=torch.float32), torch.cat(next_states),
        idx, {"candidate_transitions": candidate_count, "retained_feasible_transitions": len(idx),
              "excluded_transitions": candidate_count - len(idx),
              "rule": "next sample in train; current/next MV within empirical envelope; increment within action bounds",
              "action_semantics": "executed increment after common action/MV projection, divided by action_scale"},
    )


class ReplayBuffer:
    """Fixed-capacity buffer for generated transitions, separate from immutable logs."""

    def __init__(self, capacity: int, state_dim: int, action_dim: int):
        if capacity <= 0:
            raise ValueError("Replay capacity must be positive")
        self.capacity = int(capacity)
        self.states = np.empty((capacity, state_dim), dtype=np.float32)
        self.actions = np.empty((capacity, action_dim), dtype=np.float32)
        self.rewards = np.empty((capacity, 1), dtype=np.float32)
        self.next_states = np.empty((capacity, state_dim), dtype=np.float32)
        self.size = self.position = 0

    def add(self, states, actions, rewards, next_states):
        values = [np.asarray(torch.as_tensor(v).detach().cpu(), dtype=np.float32)
                  for v in (states, actions, rewards, next_states)]
        values[2] = values[2].reshape(-1, 1)
        n = len(values[0])
        if not all(len(v) == n and np.isfinite(v).all() for v in values):
            raise ValueError("Generated replay batch is nonfinite or has mismatched lengths")
        if n > self.capacity:
            values = [v[-self.capacity:] for v in values]
            n = self.capacity
        positions = (np.arange(n) + self.position) % self.capacity
        for target, value in zip((self.states, self.actions, self.rewards, self.next_states), values):
            target[positions] = value
        self.position = (self.position + n) % self.capacity
        self.size = min(self.capacity, self.size + n)

    def sample(self, n: int, rng: np.random.Generator):
        if self.size == 0:
            raise ValueError("Cannot sample an empty generated replay")
        idx = rng.integers(0, self.size, size=int(n))
        return tuple(torch.as_tensor(v[idx], dtype=torch.float32)
                     for v in (self.states, self.actions, self.rewards, self.next_states))


class TwinCritic(nn.Module):
    def __init__(self, state_dim: int, action_dim: int, hidden: int = 128):
        super().__init__()
        def branch():
            return nn.Sequential(nn.Linear(state_dim + action_dim, hidden), nn.ReLU(),
                                 nn.Linear(hidden, hidden), nn.ReLU(), nn.Linear(hidden, 1))
        self.q1 = branch()
        self.q2 = branch()

    def forward(self, state, action):
        x = torch.cat((state, action), dim=1)
        return self.q1(x), self.q2(x)


def train_td3(actor, twin, env, data, stats, seed, config, outdir,
              bc_weight=1.0, bc_init=True, policy_visual="retrieval", logged=None):
    """Train an actual actor--critic; never treat supervised action fitting as RL."""
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    cfg = dict(config.get("rl", {}))
    threads = int(config.get("training", {}).get("threads", 4))
    torch.set_num_threads(threads)
    rng = seed_everything(seed)
    twin.eval()
    for parameter in twin.parameters():
        parameter.requires_grad_(False)
    if bc_init:
        policy = copy.deepcopy(actor)
    else:
        policy = Actor(actor.state_dim, actor.action_dim, actor.hidden)
    policy.train()
    target_policy = copy.deepcopy(policy).eval()
    critic = TwinCritic(policy.state_dim, policy.action_dim, int(cfg.get("critic_hidden", 128)))
    target_critic = copy.deepcopy(critic).eval()
    lr = float(cfg.get("lr", 3e-4))
    policy_optimizer = torch.optim.Adam(policy.parameters(), lr=lr)
    critic_optimizer = torch.optim.Adam(critic.parameters(), lr=lr)
    logged = logged or build_logged_transitions(data, stats, twin, policy_visual)
    buffer = ReplayBuffer(int(cfg.get("replay_capacity", 20000)), policy.state_dim, policy.action_dim)
    updates = int(cfg.get("updates", 1500))
    batch_size = int(cfg.get("batch_size", 256))
    rollout_batch = int(cfg.get("rollout_batch_size", 32))
    rollout_horizon = int(cfg.get("rollout_horizon", 10))
    rollout_every = int(cfg.get("rollout_every", 100))
    delay = int(cfg.get("policy_delay", 2))
    gamma = float(cfg.get("gamma", 0.99))
    tau = float(cfg.get("tau", 0.005))
    noise_std = float(cfg.get("policy_noise", 0.2))
    noise_clip = float(cfg.get("noise_clip", 0.5))
    exploration = float(cfg.get("exploration_noise", 0.1))
    alpha = float(cfg.get("q_scale_alpha", 2.5))
    synthetic_fraction = float(cfg.get("synthetic_fraction", 0.5))
    if not (0 <= synthetic_fraction <= 1) or min(updates, batch_size, delay) <= 0:
        raise ValueError("Invalid TD3 training configuration")
    if synthetic_fraction > 0:
        if env is None or min(rollout_batch, rollout_horizon, rollout_every) <= 0 or int(batch_size * synthetic_fraction) == 0:
            raise ValueError("Mixed replay requires an environment, positive rollout budget and synthetic batch items")
        starts = eligible_start_indices(data, stats, "train_idx")
        if not len(starts):
            raise ValueError("No feasible training reset states")
    else:
        starts = np.empty(0, dtype=np.int64)
    history = []
    generated_count = 0
    actor_updates = 0
    last_actor_loss = last_bc_loss = None
    for update in range(1, updates + 1):
        if synthetic_fraction > 0 and (update == 1 or (update - 1) % rollout_every == 0):
            indices = rng.choice(starts, size=rollout_batch, replace=True)
            observation = env.reset(indices)
            held_visual = observation["visual"].clone()
            for _ in range(rollout_horizon):
                visual = held_visual if policy_visual == "hold" else observation["visual"]
                with torch.no_grad():
                    state = make_state(twin, observation["u_hist"], observation["z_hist"], visual,
                                       observation["u_current"], observation["z_current"])
                    chosen = policy(state).numpy() + rng.normal(0, exploration, (rollout_batch, policy.action_dim))
                following, reward, info = env.step(np.clip(chosen, -1, 1))
                next_visual = held_visual if policy_visual == "hold" else following["visual"]
                with torch.no_grad():
                    next_state = make_state(twin, following["u_hist"], following["z_hist"], next_visual,
                                            following["u_current"], following["z_current"])
                buffer.add(state, info["normalized_executed_action"], reward, next_state)
                generated_count += rollout_batch
                observation = following
        n_synthetic = int(batch_size * synthetic_fraction) if buffer.size else 0
        parts = []
        if batch_size - n_synthetic:
            parts.append(logged.sample(batch_size - n_synthetic, rng))
        if n_synthetic:
            parts.append(buffer.sample(n_synthetic, rng))
        state, action, reward, next_state = (torch.cat([part[j] for part in parts], dim=0) for j in range(4))
        with torch.no_grad():
            noise = (torch.randn_like(action) * noise_std).clamp(-noise_clip, noise_clip)
            next_action = project_state_actions(target_policy(next_state) + noise, next_state, stats)
            next_q1, next_q2 = target_critic(next_state, next_action)
            target = reward + gamma * torch.minimum(next_q1, next_q2)
        q1, q2 = critic(state, action)
        critic_loss = F.mse_loss(q1, target) + F.mse_loss(q2, target)
        if not torch.isfinite(critic_loss):
            raise FloatingPointError(f"Nonfinite critic loss at update {update}")
        critic_optimizer.zero_grad(set_to_none=True)
        critic_loss.backward()
        torch.nn.utils.clip_grad_norm_(critic.parameters(), 10.0)
        critic_optimizer.step()
        if update % delay == 0:
            policy_action = project_state_actions(policy(state), state, stats)
            policy_q = critic.q1(torch.cat((state, policy_action), dim=1))
            if bc_weight > 0:
                bc_state, bc_action, _, _ = logged.sample(batch_size, rng)
                bc_action_prediction = project_state_actions(policy(bc_state), bc_state, stats)
                bc_loss = F.mse_loss(bc_action_prediction, bc_action)
                q_weight = alpha / (policy_q.abs().mean().detach() + 1e-6)
                actor_loss = -q_weight * policy_q.mean() + float(bc_weight) * bc_loss
                last_bc_loss = float(bc_loss.detach())
            else:
                actor_loss = -policy_q.mean()
                last_bc_loss = 0.0
            if not torch.isfinite(actor_loss):
                raise FloatingPointError(f"Nonfinite actor loss at update {update}")
            policy_optimizer.zero_grad(set_to_none=True)
            actor_loss.backward()
            torch.nn.utils.clip_grad_norm_(policy.parameters(), 10.0)
            policy_optimizer.step()
            last_actor_loss = float(actor_loss.detach())
            actor_updates += 1
            with torch.no_grad():
                for current, target_parameter in zip(policy.parameters(), target_policy.parameters()):
                    target_parameter.mul_(1 - tau).add_(current, alpha=tau)
                for current, target_parameter in zip(critic.parameters(), target_critic.parameters()):
                    target_parameter.mul_(1 - tau).add_(current, alpha=tau)
        if update == 1 or update % int(cfg.get("log_every", 100)) == 0 or update == updates:
            row = {"update": update, "critic_loss": float(critic_loss.detach()),
                   "actor_loss": last_actor_loss, "bc_loss": last_bc_loss,
                   "mean_sampled_reward": float(reward.mean()), "generated_transitions": generated_count}
            history.append(row)
            print(json.dumps({"td3_seed": seed, "variant": outdir.name, **row}), flush=True)
            (outdir / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    metrics = {"seed": int(seed), "updates": updates, "actor_updates": actor_updates,
               "bc_initialization": bool(bc_init), "bc_weight": float(bc_weight),
               "policy_visual": policy_visual, "generated_transitions": generated_count,
               "replay_mode": "logged_only" if synthetic_fraction == 0 else "logged_and_generated",
               "sampled_synthetic_fraction": int(batch_size * synthetic_fraction) / batch_size,
               "logged_replay": logged.eligibility,
               "configuration": cfg, "final_training_row": history[-1],
               "reward_definition": "negative normalized next-CV tracking + action + empirical-envelope costs",
               "critic_action_semantics": "executed increment after common state-dependent action/MV projection, divided by action_scale",
               "bc_regularization_action_semantics": "projected actor action versus logged executed action"}
    torch.save({"kind": "actor", "model_config": actor_config(policy),
                "state_dict": policy.state_dict(), "training": metrics}, outdir / "actor.pt")
    torch.save({"kind": "td3_training_state", "critic_state_dict": critic.state_dict(),
                "target_critic_state_dict": target_critic.state_dict(),
                "target_actor_state_dict": target_policy.state_dict(),
                "actor_optimizer_state_dict": policy_optimizer.state_dict(),
                "critic_optimizer_state_dict": critic_optimizer.state_dict(),
                "seed": int(seed), "updates": updates}, outdir / "training_state.pt")
    (outdir / "metrics.json").write_text(json.dumps(metrics, indent=2) + "\n")
    return policy.eval(), metrics
