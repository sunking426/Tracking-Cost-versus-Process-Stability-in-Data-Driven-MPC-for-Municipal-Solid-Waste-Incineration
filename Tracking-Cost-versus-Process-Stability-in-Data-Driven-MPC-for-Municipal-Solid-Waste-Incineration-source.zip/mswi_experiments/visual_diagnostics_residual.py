"""Source-disjoint calibration tests for visual prediction increments.

The sensor is fitted before the calibration interval. Ridge correction uses
only calibration residuals; outer validation selects alpha and test is scored
after selection. This module does not train a policy or change the main run.
"""
from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np

from .data import MINUTE_NS, control_values, training_statistics
from .training import fit_twin, predict_twin


ALPHAS = (0.1, 1.0, 10.0, 100.0, 1000.0)
CORRECTORS = ("numeric", "timing", "original52", "static40", "fixed10", "fixed60", "null_fixed10")
VARIANT_KEYS = ("timing4", "original52", "static40", "fixed10", "fixed60", "null_fixed10")
SPLITS = ("calibration", "val", "test")


def _write_json(path: Path, value) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def _source_disjoint_split(data: dict, metadata_arrays: dict, purge_minutes: int = 21) -> dict:
    """Split outer train at 60/80%, excluding complete source intervals."""
    time = np.asarray(data["time_ns"], dtype=np.int64)
    n = len(time)
    if time.ndim != 1 or len(np.unique(time)) != n:
        raise ValueError("residual diagnostics require unique one-dimensional timestamps")
    sources = {}
    for name in ("source_start_ns", "source_end_ns"):
        if name not in data or name not in metadata_arrays:
            raise ValueError(f"residual diagnostics require data and metadata {name}")
        values = [np.asarray(container[name], dtype=np.int64) for container in (data, metadata_arrays)]
        if any(value.shape != (n,) for value in values):
            raise ValueError(f"invalid residual source array: {name}")
        sources[name] = np.minimum(*values) if name == "source_start_ns" else np.maximum(*values)
    start, end = sources["source_start_ns"], sources["source_end_ns"]
    if np.any(start > time) or np.any(end < time) or np.any(start > end):
        raise ValueError("source intervals must contain each prediction timestamp")
    indices = {}
    for name in ("train", "val", "test"):
        idx = np.asarray(data[f"{name}_idx"], dtype=np.int64)
        if idx.ndim != 1 or not len(idx) or idx.min() < 0 or idx.max() >= n:
            raise ValueError(f"invalid residual {name} indices")
        if len(np.unique(idx)) != len(idx) or np.any(np.diff(time[idx]) <= 0):
            raise ValueError(f"residual {name} indices must be unique and chronological")
        indices[name] = idx
    if not (time[indices["train"][-1]] < time[indices["val"][0]]
            < time[indices["val"][-1]] < time[indices["test"][0]]):
        raise ValueError("outer residual partitions must be chronological and disjoint")
    train = indices["train"]
    first, second = int(len(train) * .6), int(len(train) * .8)
    if not 0 < first < second < len(train):
        raise ValueError("outer train is too short for residual calibration")
    if purge_minutes < 0:
        raise ValueError("residual purge cannot be negative")
    cut1, cut2 = int(time[train[first]]), int(time[train[second]])
    purge = int(purge_minutes) * MINUTE_NS
    early = train[:first]
    inner = train[first:second]
    late = train[second:]
    early = early[end[early] < cut1]
    inner = inner[(start[inner] >= cut1 + purge) & (end[inner] < cut2)]
    late = late[start[late] >= cut2 + purge]
    if any(len(idx) < 2 for idx in (early, inner, late)):
        raise ValueError("source purging leaves an empty/insufficient residual training interval")
    if not (end[early].max() < start[inner].min() and end[inner].max() < start[late].min()):
        raise ValueError("residual training intervals have overlapping source times")
    if not (end[late].max() < start[indices["val"]].min()
            and end[indices["val"]].max() < start[indices["test"]].min()):
        raise ValueError("outer residual partitions have overlapping source times")
    return {"early_fit": early, "inner_val": inner, "calibration": late,
            "val": indices["val"], "test": indices["test"],
            "source_start_ns": start, "source_end_ns": end,
            "cut_times_ns": np.asarray([cut1, cut2], dtype=np.int64),
            "purge_minutes": int(purge_minutes)}


def _fit_residual_ridge(calibration_x, calibration_residual, val_x, val_residual) -> dict:
    """Choose a calibration-fitted correction without accepting test inputs."""
    from sklearn.linear_model import Ridge
    from sklearn.preprocessing import StandardScaler

    x = np.asarray(calibration_x, dtype=np.float64)
    residual = np.asarray(calibration_residual, dtype=np.float64)
    vx, vr = np.asarray(val_x, dtype=np.float64), np.asarray(val_residual, dtype=np.float64)
    if (x.ndim != 2 or not len(x) or residual.shape != (len(x), 4)
            or vx.ndim != 2 or vx.shape[1] != x.shape[1] or vr.shape != (len(vx), 4)
            or not len(vx)):
        raise ValueError("invalid calibration/validation matrices for residual ridge")
    if any(not np.isfinite(array).all() for array in (x, residual, vx, vr)):
        raise ValueError("nonfinite residual ridge input")
    x_scaler = StandardScaler().fit(x)
    residual_scaler = StandardScaler().fit(residual)
    sx, sr = x_scaler.transform(x), residual_scaler.transform(residual)
    svx, svr = x_scaler.transform(vx), residual_scaler.transform(vr)
    candidates = []
    for alpha in ALPHAS:
        model = Ridge(alpha=alpha, solver="cholesky").fit(sx, sr)
        score = float(np.square(model.predict(svx) - svr).mean())
        if not np.isfinite(score):
            raise FloatingPointError("nonfinite residual validation score")
        candidates.append((score, alpha, model))
    score, alpha, model = min(candidates, key=lambda item: (item[0], item[1]))
    return {"x_mean": x_scaler.mean_, "x_scale": x_scaler.scale_,
            "residual_mean": residual_scaler.mean_, "residual_scale": residual_scaler.scale_,
            "coef": model.coef_, "intercept": model.intercept_,
            "alpha": np.asarray(alpha), "alphas": np.asarray(ALPHAS),
            "val_normalized_mse": np.asarray([item[0] for item in candidates])}


def _apply_residual_ridge(fitted: dict, features: np.ndarray) -> np.ndarray:
    x = np.asarray(features, dtype=np.float64)
    if x.ndim != 2 or x.shape[1] != len(fitted["x_mean"]) or not np.isfinite(x).all():
        raise ValueError("invalid features for saved residual ridge")
    standardized = (x - fitted["x_mean"]) / fitted["x_scale"]
    prediction = standardized @ fitted["coef"].T + fitted["intercept"]
    return prediction * fitted["residual_scale"] + fitted["residual_mean"]


def _design(data: dict, variants: dict, name: str, indices: np.ndarray) -> np.ndarray:
    numeric = np.concatenate([np.asarray(data[key])[indices].reshape(len(indices), -1)
                              for key in ("u_hist", "z_hist")], axis=1)
    if name == "numeric":
        return numeric
    visual = variants["timing4" if name == "timing" else name]
    return np.concatenate([numeric, np.asarray(visual)[indices]], axis=1)


def _metrics(truth, prediction) -> dict:
    error = np.asarray(prediction, dtype=np.float64) - np.asarray(truth, dtype=np.float64)
    if error.ndim != 2 or error.shape[1] != 4 or not len(error) or not np.isfinite(error).all():
        raise ValueError("invalid residual diagnostic prediction")
    return {"n": len(error), "mae": np.abs(error).mean(axis=0).tolist(),
            "rmse": np.sqrt(np.square(error).mean(axis=0)).tolist()}


def _save_prediction(outdir: Path, split: str, indices, time_ns, truth, sensor, correction) -> dict:
    outdir.mkdir(parents=True, exist_ok=True)
    prediction = np.asarray(sensor, dtype=np.float64) + np.asarray(correction, dtype=np.float64)
    raw = {"indices": indices, "time_ns": np.asarray(time_ns)[indices], "truth": truth,
           "sensor_prediction": sensor, "residual_prediction": correction,
           "prediction": prediction, "error": prediction - truth}
    np.savez_compressed(outdir / f"{split}_predictions.npz", **raw)
    with (outdir / f"{split}_predictions.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["sample_index", "time_ns"] + [f"truth_{i}" for i in range(4)]
                        + [f"sensor_{i}" for i in range(4)] + [f"correction_{i}" for i in range(4)]
                        + [f"prediction_{i}" for i in range(4)])
        writer.writerows([[int(index), int(ts), *y.tolist(), *s.tolist(), *c.tolist(), *p.tolist()]
                          for index, ts, y, s, c, p in zip(indices, raw["time_ns"], truth,
                                                         sensor, correction, prediction)])
    return _metrics(truth, prediction)


def run_residual_diagnostics(data, variants, metadata_arrays, config, outdir) -> dict:
    """Train source-separated sensors and calibration-only residual correctors."""
    from threadpoolctl import threadpool_limits

    n = len(data["time_ns"])
    for name in VARIANT_KEYS:
        if name not in variants:
            raise ValueError(f"missing residual visual variant: {name}")
        array = np.asarray(variants[name])
        if array.ndim != 2 or len(array) != n or not array.shape[1] or not np.isfinite(array).all():
            raise ValueError(f"invalid residual visual variant: {name}")
    seeds = [int(seed) for seed in config["diagnostics"]["seeds"]]
    if not seeds or len(set(seeds)) != len(seeds):
        raise ValueError("residual seeds must be nonempty and unique")
    split = _source_disjoint_split(data, metadata_arrays, purge_minutes=21)
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(out / "split_indices.npz", **split)
    split_record = {name: {"n": len(split[name]),
                          "first_time_ns": int(np.asarray(data["time_ns"])[split[name][0]]),
                          "last_time_ns": int(np.asarray(data["time_ns"])[split[name][-1]]),
                          "earliest_source_ns": int(split["source_start_ns"][split[name]].min()),
                          "latest_source_ns": int(split["source_end_ns"][split[name]].max())}
                    for name in ("early_fit", "inner_val", *SPLITS)}
    protocol = {"seeds": seeds, "outer_train_cut_fractions": [.6, .8], "purge_minutes": 21,
                "cut_times_ns": split["cut_times_ns"].tolist(), "alphas": list(ALPHAS),
                "checkpoint_partition": "inner_val", "corrector_fit_partition": "calibration",
                "alpha_selection_partition": "outer_val", "sensor_statistics_partition": "early_fit",
                "corrector_scaling_partition": "calibration", "targets": ["temperature", "pressure", "steam", "oxygen"],
                "null_control": "provided within-outer-partition capture-block permutation; diagnostic only",
                "test_usage": "one final sensor prediction per seed; corrector test predictions after alpha selection"}
    _write_json(out / "protocol.json", protocol)
    result = {"protocol": protocol, "split": split_record, "seeds": {}}
    sensor_data = dict(data)
    sensor_data.update(train_idx=split["early_fit"], val_idx=split["inner_val"],
                       test_idx=split["inner_val"])
    stats = training_statistics(sensor_data)
    _write_json(out / "sensor_training_statistics.json", stats)
    threads = int(config["training"].get("threads", 4))
    with threadpool_limits(limits=threads):
        for seed in seeds:
            seed_out = out / f"seed_{seed}"
            sensor, sensor_training = fit_twin(sensor_data, stats, "sensor", seed, config, seed_out / "sensor_model")
            batch = int(config["training"].get("batch_size", 256))
            predictions = {name: control_values(predict_twin(sensor, data, split[name], batch))
                           for name in SPLITS}
            truth = {name: control_values(np.asarray(data["z_target"])[split[name]]) for name in SPLITS}
            residual = {name: truth[name] - predictions[name] for name in ("calibration", "val")}
            sensor_metrics = {name: _save_prediction(seed_out / "sensor", name, split[name], data["time_ns"],
                                                   truth[name], predictions[name], np.zeros_like(predictions[name]))
                              for name in SPLITS}
            seed_result = {"sensor_training": sensor_training, "sensor": sensor_metrics, "correctors": {}}
            for name in CORRECTORS:
                print(f"residual diagnostics: seed={seed} corrector={name}", flush=True)
                design = {part: _design(data, variants, name, split[part]) for part in ("calibration", "val")}
                fitted = _fit_residual_ridge(design["calibration"], residual["calibration"],
                                             design["val"], residual["val"])
                method_out = seed_out / name
                method_out.mkdir(parents=True, exist_ok=True)
                np.savez_compressed(method_out / "ridge_weights.npz", **fitted)
                selection = {"alpha": float(fitted["alpha"]),
                             "alphas": fitted["alphas"].tolist(),
                             "val_normalized_mse": fitted["val_normalized_mse"].tolist(),
                             "feature_dimension": len(fitted["x_mean"])}
                _write_json(method_out / "selection.json", selection)
                metrics = {}
                for part in SPLITS:
                    features = design[part] if part in design else _design(data, variants, name, split[part])
                    correction = _apply_residual_ridge(fitted, features)
                    metrics[part] = _save_prediction(method_out, part, split[part], data["time_ns"],
                                                    truth[part], predictions[part], correction)
                seed_result["correctors"][name] = {**selection, "metrics": metrics,
                    "weights_file": f"seed_{seed}/{name}/ridge_weights.npz",
                    "prediction_files": {part: f"seed_{seed}/{name}/{part}_predictions.npz" for part in SPLITS}}
            result["seeds"][str(seed)] = seed_result
            _write_json(out / "residual_results.json", result)
    return result
