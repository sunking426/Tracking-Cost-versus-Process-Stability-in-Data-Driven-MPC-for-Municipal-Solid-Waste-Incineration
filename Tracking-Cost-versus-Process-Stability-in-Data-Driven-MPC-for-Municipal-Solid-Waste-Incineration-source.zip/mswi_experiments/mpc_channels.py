"""Channel-restricted CEM for the prospective secondary-air experiment.

This experimental owner parameterizes channel count and direction. Historical
2-channel implementations remain immutable scientific references. Projection,
reward, exact support and feedback dynamics retain their canonical owners.
"""
from __future__ import annotations
import hashlib
import itertools
import numpy as np
import torch
from .control import project_normalized_actions, reward_and_violation
from .data import MINUTE_NS
from .ridge_policy import ExactSupport
from .ridge_policy_planning import PlanningSupport
from .ridge_response import analytic_responses, decision_rollout
from .mpc_temperature import acceptance_tier, rank_candidates


class ChannelExecution:
    def __init__(self, stats, support, secondary=True):
        self.stats=stats;self.support=ExactSupport(support)
        self.active=np.array([0,3,2] if secondary else [0,3])
        self.inactive=np.array([i for i in range(8) if i not in self.active])
        self.lower=np.array([-1.,-1.,0.] if secondary else [-1.,-1.])
        self.upper=np.ones(len(self.active))
        self.scale=np.asarray(stats['action_scale'],dtype=float)
        self.bound=np.asarray(stats['action_bound'],dtype=float)
        self.m=.1*self.bound[self.active]/self.scale[self.active]
        if np.any(self.m<=0):raise ValueError('positive channel budgets required')

    def request(self,b):
        b=np.asarray(b,dtype=float)
        if b.ndim!=2 or b.shape[1]!=len(self.active) or not np.isfinite(b).all():
            raise ValueError('finite aligned channel coordinates required')
        a=np.zeros((len(b),8));a[:,self.active]=np.clip(b,self.lower,self.upper)*self.m
        return a

    def screen(self,request,u,z,times):
        a,u=(np.asarray(v,dtype=float) for v in (request,u))
        if a.shape!=u.shape or a.ndim!=2 or a.shape[1]!=8 or not np.isfinite(a).all():
            raise ValueError('aligned finite eight-channel request required')
        if (np.any(a[:,self.inactive]!=0) or np.any(a[:,self.active]<self.lower*self.m-1e-12)
            or np.any(a[:,self.active]>self.upper*self.m+1e-12)):
            raise ValueError('channel direction or budget exceeded')
        executed,delta,next_u=project_normalized_actions(torch.from_numpy(a.copy()),torch.from_numpy(u.copy()),self.stats)
        executed,delta,next_u=(x.numpy() for x in (executed,delta,next_u))
        complete=np.all(np.abs(delta-a*self.scale)<=1e-10,axis=1)
        dist,supported,_=self.support.query(u,z,delta,times)
        nonzero=np.any(a!=0,axis=1);admitted=(complete&supported)|~nonzero
        return dict(executed=executed,physical=delta,next_u=next_u,distance=dist,
                    supported=supported,complete=complete,nonzero=nonzero,admitted=admitted)

    def apply(self,request,u,z,times):
        proposal=self.screen(request,u,z,times);blocked=~proposal['admitted']
        if blocked.any():
            applied=np.asarray(request).copy();applied[blocked]=0
            actual=self.screen(applied,u,z,times)
        else:actual=proposal
        if np.any(actual['physical'][:,self.inactive]!=0):raise AssertionError('inactive MV changed')
        return actual,proposal,blocked


class ChannelCEM:
    def __init__(self,model,execution,temperature_weight):
        if temperature_weight not in (1,2,4,8):raise ValueError('unregistered temperature weight')
        self.model=model;self.execution=execution;self.weight=temperature_weight
        self.support=PlanningSupport(execution);self.d=len(execution.active)
        self.kernel=analytic_responses(model,10)['step'][:,:,execution.active]
        levels=[(0,0)]+[x for x in itertools.product((-1,0,1),repeat=2) if x!=(0,0)]
        self.fixed=np.zeros((9,10,self.d));self.fixed[:,0,:2]=levels;self.warm=None

    def candidate_metrics(self,plans,u_hist,z_hist,current,times):
        n,c,h,d=plans.shape
        if (h,d)!=(10,self.d):raise ValueError('wrong plan shape')
        e=self.execution;u=np.repeat(u_hist[:,-1,None],c,axis=1).astype(float)
        baseline=decision_rollout(self.model,u_hist,z_hist,current,np.repeat(u_hist[:,-1,None],10,axis=1))
        effects=np.zeros((n,c,10,9));z=np.repeat(current[:,None],c,axis=1).astype(float)
        original=np.zeros((n,c));temperatures=[]
        for step in range(10):
            request=e.request(plans[:,:,step].reshape(-1,self.d));flat_u=u.reshape(-1,8)
            a,delta,nu=project_normalized_actions(torch.from_numpy(request),torch.from_numpy(flat_u),e.stats)
            a,delta,nu=[v.numpy() for v in (a,delta,nu)]
            complete=np.all(np.abs(delta-request*e.scale)<=1e-10,axis=1)
            stamps=np.repeat(times+step*MINUTE_NS,c)
            supported=self.support.supported(flat_u,z.reshape(-1,9),delta,stamps,n,c)
            admit=(complete&supported)|~np.any(request!=0,axis=1)
            a[~admit]=0;delta[~admit]=0;nu[~admit]=flat_u[~admit]
            physical=delta.reshape(n,c,8)
            effects[:,:,step:]+=np.einsum('ncj,hzj->nchz',physical[:,:,e.active],self.kernel[:10-step])
            z=baseline[:,None,step]+effects[:,:,step]
            reward,_,components=reward_and_violation(z,a.reshape(n,c,8),e.stats)
            original+=reward.astype(float);temperatures.append(components['tracking_cost'][...,0])
            u=nu.reshape(n,c,8)
        jt=np.stack(temperatures,axis=2).astype(float).sum(2)
        return original-(self.weight-1)*jt,original,jt

    def plan(self,u,z,current,times,indices,decision_step):
        n=len(u);d=self.d
        warm=np.zeros((n,10,d)) if self.warm is None else np.concatenate((self.warm[:,1:],np.zeros((n,1,d))),axis=1)
        mean=warm.copy();std=np.full_like(mean,.35);incumbent=np.zeros_like(mean)
        best_score=np.full(n,-np.inf);best=np.zeros_like(mean);best_original=np.zeros(n);best_jt=np.zeros(n)
        iteration_scores=[]
        rngs=[np.random.default_rng(np.random.SeedSequence([2026,int(i),int(decision_step)])) for i in indices]
        extra=[np.random.default_rng(np.random.SeedSequence([2026,int(i),int(decision_step),2])) for i in indices]
        hashes=[hashlib.sha256() for _ in indices];extra_hashes=[hashlib.sha256() for _ in indices]
        for iteration in range(4):
            noise=np.stack([r.normal(size=(117,10,2)) for r in rngs])
            for h,v in zip(hashes,noise):h.update(v.tobytes(order='C'))
            if d==3:
                third=np.stack([r.normal(size=(117,10,1)) for r in extra])
                for h,v in zip(extra_hashes,third):h.update(v.tobytes(order='C'))
                noise=np.concatenate((noise,third),axis=-1)
            random=np.clip(mean[:,None]+std[:,None]*noise,self.execution.lower,self.execution.upper)
            plans=np.concatenate((np.broadcast_to(self.fixed,(n,9,10,d)),warm[:,None],incumbent[:,None],random),axis=1)
            score,original,jt=self.candidate_metrics(plans,u,z,current,times)
            winner,elite_indices,_=rank_candidates(score,np.ones_like(score,dtype=bool))
            incumbent=plans[np.arange(n),winner].copy();iteration_score=score[np.arange(n),winner]
            better=iteration_score>best_score
            best[better]=incumbent[better];best_score[better]=iteration_score[better]
            best_original[better]=original[np.arange(n),winner][better];best_jt[better]=jt[np.arange(n),winner][better]
            tie=score[:,0]==best_score;best[tie]=0
            best_original[tie]=original[tie,0];best_jt[tie]=jt[tie,0]
            elite=plans[np.arange(n)[:,None],elite_indices];mean=elite.mean(1);std=np.maximum(elite.std(1,ddof=0),.05)
            iteration_scores.append(iteration_score)
        self.warm=best.copy()
        return self.execution.request(best[:,0]),dict(best_requested_plan_b=best,
            selected_planning_score=best_score,selected_original_return=best_original,
            selected_temperature_cost=best_jt,hold_temperature_cost=jt[:,0],
            planned_temperature_margin=jt[:,0]-best_jt,iteration_best_score=np.stack(iteration_scores,1),
            noise_sha256=np.asarray([h.hexdigest() for h in hashes],dtype='S64'),
            secondary_noise_sha256=np.asarray([h.hexdigest() for h in extra_hashes],dtype='S64'))


def recommend(reference,candidates,old_c_gain):
    assessed={}
    for v in 'ABCD':
        strict=acceptance_tier(reference,candidates[v],0);relative=acceptance_tier(reference,candidates[v],.01)
        gain=strict['worst_cost_gain']
        assessed[v]=dict(strict=strict,relative=relative,strict_eligible=strict['pass'] and gain>=.9*old_c_gain,
                        relative_eligible=relative['pass'] and gain>=old_c_gain)
    result=dict(recommended='2C',route='retain_old_C',main_configuration_frozen=False,configurations=assessed)
    for flag,route in [('strict_eligible','strict_zero_degradation'),('relative_eligible','relative_1pct')]:
        eligible=[v for v in 'ABCD' if assessed[v][flag]]
        if eligible:
            best=max(eligible,key=lambda v:assessed[v]['strict']['worst_cost_gain'])
            if route=='relative_1pct' and assessed[best]['strict']['worst_cost_gain']==old_c_gain:return result
            result.update(recommended='3'+best,route=route);return result
    return result
