"""Post-run provenance, canonical feedback and checkpoint replay checks."""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import torch
from threadpoolctl import threadpool_limits
from .ridge_policy_study import ROOT, OUT, REF, SEEDS, GROUPS, MODELS, sha, read_npz, write_json, shared
from .ridge_policy_evaluation import BASELINES, DecisionPolicy, actor_path
from .ridge_policy import RidgePolicyEnv, policy_numeric
from .ridge_policy_training import mode_for
from .ridge_dynamics import RidgeDynamics
from .ridge_response import decision_rollout
from .control import reward_and_violation
from .data import MINUTE_NS

def audit():
    stats,execution,context,planner=shared();checks={}
    protected=json.loads((ROOT/'experiment_protocols/ridge_policy_pipeline_20261107/source_bindings.json').read_text())['files']
    for path,expected in protected.items():
        if sha(ROOT/path)!=expected:raise AssertionError('protected source changed '+path)
    checks['protected_original_files_unchanged']=len(protected)
    for name in ('input_hashes.json','training_code_hashes.json'):
        for path,expected in json.loads((OUT/name).read_text()).items():
            if sha(path)!=expected:raise AssertionError('frozen file changed '+path)
    for path,expected in json.loads((OUT/'evaluation_code_hashes.json').read_text())['code'].items():
        if sha(path)!=expected:raise AssertionError('evaluation code changed '+path)
    training=[]
    for group in GROUPS[1:]:
        for seed in SEEDS:
            folder=OUT/f'models/{group}/seed{seed}';meta=json.loads((folder/'complete.json').read_text())
            ck=torch.load(folder/'actor.pt',map_location='cpu',weights_only=False)
            if sha(folder/'actor.pt')!=meta['checkpoint_sha256'] or ck['updates']!=1500:raise AssertionError('checkpoint provenance')
            if ck['actor']['gate_head.weight'].shape!=(2,230) or ck['critic']['q1.0.weight'].shape!=(128,238):raise AssertionError('network interfaces')
            expected=0 if group=='offline_td3bc' else 4800
            if meta['generated_transitions']!=expected:raise AssertionError('wrong rollout count')
            if expected:
                g=read_npz(folder/'generated_replay.npz')
                if len(g['state'])!=4800 or not np.array_equal(np.unique(g['generation_update']),np.arange(1,1500,100)):raise AssertionError('generation budget')
                if np.any(g['action'][:,[1,2,4,5,6,7]]!=0):raise AssertionError('synthetic inactive action')
                r,_,_=reward_and_violation(g['next_z'],g['action'],stats)
                # Serialized actions are float32 critic inputs; rewards were
                # computed by canonical float32 action conversion at generation.
                np.testing.assert_array_equal(r,g['reward'][:,0])
                np.testing.assert_allclose(g['next_u']-g['u'],g['action']*execution.scale,atol=1e-7,rtol=1e-6)
                np.testing.assert_array_equal(g['next_times']-g['times'],np.full(4800,MINUTE_NS))
                # Recover physical numerical histories from saved policy state
                # (float32 standardized), sufficient to detect time shifts and
                # wrong physical-state interfaces, not bitwise exact history.
                x=g['state'][:,:178].astype(float)*context.v['scale']+context.v['mean']
                np.testing.assert_allclose(x[:,80:88],g['u'],atol=2e-4,rtol=1e-5)
                np.testing.assert_allclose(x[:,169:],g['z'],atol=2e-4,rtol=1e-5)
            training.append({'group':group,'seed':seed,'generated_transitions':expected,'checkpoint_verified':True})
    checks['training']=training
    feedback=[];reload=[];cemscores=[]
    for split in ('val','test'):
        inputs=read_npz(REF/f'inputs/{split}.npz');selection=np.array([0,127,255])
        small={k:inputs[k][selection] for k in ('u_hist','z_hist','z_current','time_ns','indices')}
        for mid in MODELS:
            model=RidgeDynamics.load(REF/f'evaluation_models/{mid}.npz')
            for group in BASELINES+GROUPS:
                for seed in SEEDS if group in GROUPS else (0,):
                    row=read_npz(OUT/f'trajectories/{split}/{mid}/{group}/seed{seed}.npz')
                    # Recompute all fifty sequential predictions on three fixed
                    # starts, using saved executed MV and exclusively own feedback.
                    predicted=decision_rollout(model,small['u_hist'],small['z_hist'],small['z_current'],row['u_path'][selection])
                    err=float(np.max(np.abs(predicted-row['pred_cv'][selection])))
                    if not np.allclose(predicted,row['pred_cv'][selection],atol=1e-8,rtol=1e-10):raise AssertionError('feedback mismatch')
                    feedback.append({'split':split,'model':mid,'method':group,'seed':seed,'max_state_error':err})
                    if group in GROUPS:
                        policy=DecisionPolicy(group,seed,planner,execution,context)
                        env=RidgePolicyEnv(model,execution,context,horizon=50,visual_mode=mode_for(group));state,_=env.reset(options={'inputs':small})
                        max_action=0.;max_state=0.;max_reward=0.
                        for step in range(50):
                            a,_=policy.decide(env,state,step);state,_,_,_,info=env.step_request(a)
                            max_action=max(max_action,float(np.max(np.abs(info['requested_action']-row['requested_action'][selection,step]))))
                            max_state=max(max_state,float(np.max(np.abs(info['pred_cv']-row['pred_cv'][selection,step]))))
                            max_reward=max(max_reward,float(np.max(np.abs(info['reward']-row['reward'][selection,step]))))
                        if max_action>1e-6 or max_state>1e-5 or max_reward>2e-5:raise AssertionError('checkpoint reload mismatch')
                        reload.append({'split':split,'model':mid,'method':group,'seed':seed,'action_error':max_action,'state_error':max_state,'reward_error':max_reward})
                    elif group=='cem_mpc':
                        # Re-score chosen requested plans using only the full
                        # planner and the unaccelerated canonical environment.
                        for step in (0,9,24,49):
                            if step==0:history=small
                            else:
                                up=np.concatenate((small['u_hist'],row['u_path'][selection,:step]),axis=1)[:,-11:]
                                zp=np.concatenate((small['z_hist'],small['z_current'][:,None],row['pred_cv'][selection,:step-1]),axis=1)[:,-10:]
                                history={'u_hist':up,'z_hist':zp,'z_current':row['pred_cv'][selection,step-1],
                                    'time_ns':small['time_ns']+step*MINUTE_NS,'indices':small['indices']}
                            env=RidgePolicyEnv(planner,execution,horizon=10);env.reset(options={'inputs':history});score=np.zeros(3)
                            for j in range(10):
                                _,r,_,_,_=env.step(row['best_requested_plan_b'][selection,step,j]);score+=r.astype(float)
                            error=float(np.max(np.abs(score-row['planner_score'][selection,step])))
                            if error>1e-5:raise AssertionError('CEM score not canonical')
                            cemscores.append({'split':split,'model':mid,'decision_step':step,'max_score_error':error})
            print('audited',split,mid,flush=True)
    checks.update(status='passed',feedback_checks=feedback,checkpoint_reloads=reload,cem_plan_score_checks=cemscores,
        feedback_checked_episodes=len(feedback)*3,reloaded_policy_episodes=len(reload)*3,
        finite_and_reward_full_population_check='report summarizer independently recomputes all4,352,000 saved rewards and components',
        numerical_reproducibility_note='Batch-size changes can alter float32 neural matrix products slightly; stated tolerances are numerical, not physical degradation allowances.')
    write_json(OUT/'post_run_audit.json',checks)

if __name__=='__main__':
    torch.set_num_threads(4)
    with threadpool_limits(4):audit()
