"""Training-only historical visual memory with explicit, non-pickle persistence."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F


def encoder_fingerprint(twin: torch.nn.Module) -> str:
    digest = hashlib.sha256()
    for name, value in sorted(twin.state_dict().items()):
        digest.update(name.encode())
        digest.update(value.detach().cpu().contiguous().numpy().tobytes())
    return digest.hexdigest()


class VisualMemory:
    """Retrieve recorded visual features, using only explicitly supplied train indices."""

    def __init__(self, twin, data, train_idx, max_items=512, k=3):
        indices = np.asarray(train_idx, dtype=np.int64)
        if indices.ndim != 1 or not len(indices):
            raise ValueError("VisualMemory requires nonempty one-dimensional training indices")
        if len(np.unique(indices)) != len(indices):
            raise ValueError("Duplicate memory source indices")
        if max_items <= 0 or k <= 0:
            raise ValueError("Memory size and k must be positive")
        indices = np.sort(indices)
        positions = np.linspace(0, len(indices) - 1, min(max_items, len(indices))).round().astype(int)
        self.indices = indices[np.unique(positions)]
        self.twin = twin.eval()
        self.k = min(int(k), len(self.indices))
        self.model_sha256 = encoder_fingerprint(twin)
        device = next(twin.parameters()).device
        self.visual = torch.as_tensor(data['visual'][self.indices], dtype=torch.float32, device=device)
        keys = []
        with torch.no_grad():
            for block in np.array_split(self.indices, max(1, (len(self.indices) + 127) // 128)):
                u = torch.as_tensor(data['u_hist'][block], dtype=torch.float32, device=device)
                z = torch.as_tensor(data['z_hist'][block], dtype=torch.float32, device=device)
                keys.append(twin.retrieval_key(u, z).detach())
        self.keys = F.normalize(torch.cat(keys), dim=1).contiguous()
        if not torch.isfinite(self.keys).all() or not torch.isfinite(self.visual).all():
            raise ValueError("Nonfinite historical memory")

    @torch.no_grad()
    def query(self, u_hist, z_hist):
        device = self.keys.device
        u = torch.as_tensor(u_hist, dtype=torch.float32, device=device)
        z = torch.as_tensor(z_hist, dtype=torch.float32, device=device)
        query = F.normalize(self.twin.retrieval_key(u, z), dim=1)
        if not torch.isfinite(query).all():
            raise ValueError("Nonfinite retrieval query")
        nearest = (query @ self.keys.T).topk(self.k, dim=1).indices[:, 0]
        return self.visual[nearest], self.indices[nearest.cpu().numpy()]

    def save(self, directory):
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(directory / 'visual_memory.npz', indices=self.indices,
                            keys=self.keys.cpu().numpy(), visual=self.visual.cpu().numpy())
        metadata = {'schema': 1, 'items': len(self.indices), 'k': self.k,
                    'key_dimension': self.keys.shape[1], 'visual_dimension': self.visual.shape[1],
                    'source_partition': 'train', 'model_sha256': self.model_sha256,
                    'selection': 'uniformly spaced training anchors; top-ranked of top-k cosine candidates'}
        (directory / 'visual_memory.json').write_text(json.dumps(metadata, indent=2) + '\n')
