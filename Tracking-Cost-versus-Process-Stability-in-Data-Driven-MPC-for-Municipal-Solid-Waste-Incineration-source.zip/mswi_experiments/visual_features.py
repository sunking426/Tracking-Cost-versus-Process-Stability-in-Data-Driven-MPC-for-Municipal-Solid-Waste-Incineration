"""Corrected, causal descriptors from the fixed set of recorded flame JPGs.

Spatial coordinates are fractions of each actual image, never coordinates in an
unresized reference frame. Original images are not annotated or modified before
measurement. This module does not inspect process targets, policies or rewards.
"""
from __future__ import annotations

import argparse
from collections import Counter, deque
from concurrent.futures import ThreadPoolExecutor
import csv
import hashlib
import io
import json
from pathlib import Path
from typing import Iterable

import numpy as np
from PIL import Image


# x_start, y_start, x_end_exclusive, y_end_exclusive as image fractions.
# Region order follows IN1--IN4 in the original descriptor configuration.
REGIONS = {
    'area1': (.50, .25, .79, .55),
    'area2': (.21, .25, .50, .55),
    'area3': (.21, .55, .50, .88),
    'area4': (.50, .55, .79, .88),
}
FEATURE_COLUMNS = tuple(f'ft_{k}_area{area}' for area in range(1,5) for k in range(1,13)) + tuple(
    f'fire_line_area{area}' for area in range(1,5))
THRESHOLDS = {'effective':110, 'hot':190, 'ignition':130, 'front':175}
ROLLING_IMAGES = 6


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def region_pixels(width: int, height: int) -> dict[str, tuple[int,int,int,int]]:
    if min(width,height) < 4:
        raise ValueError('Image dimensions are too small for the prescribed regions')
    result = {}
    for name,(x0,y0,x1,y1) in REGIONS.items():
        bounds=(int(width*x0),int(height*y0),int(width*x1),int(height*y1))
        if not (0 <= bounds[0] < bounds[2] <= width and 0 <= bounds[1] < bounds[3] <= height):
            raise ValueError(f'Invalid region for {width}x{height}: {name}={bounds}')
        result[name]=bounds
    return result


def gray_from_rgb(rgb: np.ndarray) -> np.ndarray:
    """BT.601 integer grayscale with uint8 RGB input and float-safe arithmetic."""
    if rgb.ndim != 3 or rgb.shape[-1] != 3 or rgb.dtype != np.uint8:
        raise ValueError('Expected uint8 RGB image with shape (height,width,3)')
    wide=rgb.astype(np.int32)
    return ((4899*wide[...,0]+9617*wide[...,1]+1868*wide[...,2]+8192)>>14).astype(np.uint8)


def region_descriptors(rgb: np.ndarray) -> dict[str,float]:
    """Twelve spatial slots (temporal slots initially zero) plus front proxy.

    Area slots are fractions to avoid resolution-dependent raw pixel counts.
    Gray-level slots retain 0--255 units. The old ft9/ft12 definitions address
    identical configured supports, so both explicitly remain the same statistic.
    """
    gray=gray_from_rgb(rgb)
    h,w=gray.shape
    if h == 0 or w == 0:
        raise ValueError('Empty descriptor region')
    effective=gray >= THRESHOLDS['effective']
    hot=gray >= THRESHOLDS['hot']
    ignition=gray >= THRESHOLDS['ignition']
    total=gray.size
    n_effective=int(effective.sum());n_hot=int(hot.sum())
    valid_mean=float(gray[effective].mean()) if n_effective else 0.
    hot_mean=float(gray[hot].mean()) if n_hot else 0.
    if n_hot and w > 1:
        # Horizontal, intensity-weighted hot-pixel centroid, normalized by width.
        hot_weights=np.where(hot,gray,0).astype(np.float64).sum(axis=0)
        x=float(hot_weights @ np.arange(w))/float(hot_weights.sum())
        displacement=abs(x/(w-1)-.5)
    else:
        displacement=0.
    gray_std=float(gray.std(ddof=0,dtype=np.float64))
    red=float(rgb[...,0].sum(dtype=np.float64));green=float(rgb[...,1].sum(dtype=np.float64))
    front_mask=gray >= THRESHOLDS['front']
    active=front_mask.any(axis=0)
    if active.any():
        first=front_mask[:,active].argmax(axis=0)
        front=float(np.median(first))/max(h-1,1)
    else:
        # Explicit absence code in the normalized bottom-edge position.
        front=1.
    result={
        'ft_1':n_effective/total,'ft_2':valid_mean,'ft_3':n_hot/total,
        'ft_4':hot_mean,'ft_5':n_hot/n_effective if n_effective else 0.,
        'ft_6':displacement,'ft_7':0.,'ft_8':0.,'ft_9':gray_std,
        'ft_10':green/red if red else 0.,'ft_11':float(ignition.mean()),
        'ft_12':gray_std,'fire_line':front,
    }
    if not np.isfinite(list(result.values())).all():
        raise FloatingPointError('Nonfinite spatial descriptor')
    return result


def spatial_descriptors(rgb: np.ndarray) -> dict[str,float]:
    """Measure only the original RGB pixels in the normalized ROI supports."""
    gray_from_rgb(rgb[:1,:1])  # validate without copying/converting a full frame
    h,w=rgb.shape[:2]
    result={}
    for name,(x0,y0,x1,y1) in region_pixels(w,h).items():
        result.update({f'{key}_{name}':value for key,value in region_descriptors(rgb[y0:y1,x0:x1]).items()})
    return result


def add_causal_temporal_features(rows: Iterable[dict], count: int = ROLLING_IMAGES):
    """Yield recent-count population SDs, including only current/past images.

    Actual earliest contributing image time is exported; consumers must include
    it in partition-source validation, including when captures have large gaps.
    """
    if count <= 0:
        raise ValueError('Temporal image count must be positive')
    history=deque(maxlen=count)
    previous=None
    for incoming in rows:
        row=dict(incoming)
        stamp=np.datetime64(row['time'],'ns')
        if np.isnat(stamp) or previous is not None and stamp <= previous:
            raise ValueError('Image timestamps must be finite, unique and increasing')
        previous=stamp
        history.append((row['time'],[row[f'ft_1_area{a}'] for a in range(1,5)],
                        [row[f'ft_2_area{a}'] for a in range(1,5)]))
        area=np.asarray([v[1] for v in history],dtype=np.float64)
        brightness=np.asarray([v[2] for v in history],dtype=np.float64)
        for a in range(1,5):
            row[f'ft_7_area{a}']=float(area[:,a-1].std(ddof=0))
            row[f'ft_8_area{a}']=float(brightness[:,a-1].std(ddof=0))
        row['feature_source_start_time']=history[0][0]
        yield row


def _read_selection(path: Path):
    with path.open(newline='',encoding='utf-8-sig') as stream:
        source=list(csv.DictReader(stream))
    if not source:
        raise ValueError('The fixed source selection is empty')
    rows=[]
    for original in source:
        name=original['img_name'];time=original['time']
        if Path(name).name != name or np.datetime64(Path(name).stem,'ns') != np.datetime64(time,'ns'):
            raise ValueError(f'Invalid or mismatched image filename/time: {name}')
        rows.append({'img_name':name,'time':time})
    rows.sort(key=lambda r:np.datetime64(r['time'],'ns'))
    if len({r['time'] for r in rows}) != len(rows):
        raise ValueError('Duplicate image times in the fixed source selection')
    return rows


def extract_corrected_features(selection_csv: Path, image_dir: Path, output_csv: Path,
                               workers: int = 4, examples: bool = True) -> dict:
    selection_csv,image_dir,output_csv=map(lambda p:Path(p).resolve(),(selection_csv,image_dir,output_csv))
    if output_csv == selection_csv:
        raise ValueError('Corrected output must not overwrite the original feature CSV')
    if workers <= 0:
        raise ValueError('Worker count must be positive')
    selected=_read_selection(selection_csv)
    output_csv.parent.mkdir(parents=True,exist_ok=True)
    sources=[];sizes=Counter();roi_by_size={}
    def process(row):
        path=image_dir/row['img_name'];raw=path.read_bytes()
        with Image.open(io.BytesIO(raw)) as picture:
            rgb=np.asarray(picture.convert('RGB'))
        h,w=rgb.shape[:2]
        measured=spatial_descriptors(rgb)
        source={'img_name':row['img_name'],'time':row['time'],'sha256':hashlib.sha256(raw).hexdigest(),
                'bytes':len(raw),'width':w,'height':h}
        return {**row,**measured},source
    temp=output_csv.with_suffix(output_csv.suffix+'.tmp')
    with ThreadPoolExecutor(max_workers=workers) as pool,temp.open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=[*FEATURE_COLUMNS,'img_name','time','feature_source_start_time'])
        writer.writeheader()
        def ordered_spatial():
            for index,(row,source) in enumerate(pool.map(process,selected)):
                sources.append(source);key=f"{source['width']}x{source['height']}";sizes[key]+=1
                roi_by_size[key]=region_pixels(source['width'],source['height'])
                if (index+1)%500 == 0:print(f'visual extraction {index+1}/{len(selected)}',flush=True)
                yield row
        for row in add_causal_temporal_features(ordered_spatial()):writer.writerow(row)
    temp.replace(output_csv)
    with output_csv.open(newline='') as stream:exported=list(csv.DictReader(stream))
    values=np.asarray([[float(row[c]) for c in FEATURE_COLUMNS] for row in exported])
    if values.shape != (len(selected),52) or not np.isfinite(values).all():
        raise AssertionError('Incorrect corrected-feature output shape or finite status')
    definitions={
        'ft_1':'fraction of ROI pixels with BT.601 grayscale >=110',
        'ft_2':'mean grayscale among ROI pixels >=110; 0 if empty',
        'ft_3':'fraction of ROI pixels with grayscale >=190',
        'ft_4':'mean grayscale among ROI pixels >=190; 0 if empty',
        'ft_5':'hot-pixel count / effective-pixel count; 0 if no effective pixels',
        'ft_6':'absolute horizontal hot-intensity-weighted centroid distance from ROI center / (width-1); 0 if no hot pixels',
        'ft_7':'population SD of ft_1 over at most the latest six captures including current',
        'ft_8':'population SD of ft_2 over at most the latest six captures including current',
        'ft_9':'population standard deviation of grayscale over the ROI',
        'ft_10':'sum of green / sum of red over original RGB ROI; 0 if red sum=0',
        'ft_11':'fraction of ROI pixels with grayscale >=130',
        'ft_12':'population grayscale SD over configured Rj support; same support as ft_9 in original IN1-IN4',
        'fire_line':'normalized median first row of grayscale>=175 over active columns; 1 if no active column; a threshold-front proxy, not a manually annotated fire line',
    }
    manifest={'schema':1,'protocol':'frozen corrected visual descriptors; no CV/reward/validation/test target access',
        'selection_csv':str(selection_csv),'selection_sha256':_sha256(selection_csv),
        'image_dir':str(image_dir),'output_csv':str(output_csv),'output_sha256':_sha256(output_csv),
        'code_sha256':_sha256(Path(__file__)),'rows':len(selected),'features':52,'feature_columns':list(FEATURE_COLUMNS),
        'regions_normalized_xyxy':REGIONS,'region_pixels_by_image_size':roi_by_size,
        'image_dimensions':dict(sizes),'thresholds':THRESHOLDS,'definitions':definitions,
        'temporal':{'recent_captures_including_current':ROLLING_IMAGES,'ddof':0,'future_images_used':False,
                    'source_metadata_column':'feature_source_start_time','gap_rule':'count-based; no unreported time truncation'},
        'measurement_images_resized':False,'measurement_images_annotated':False,
        'overlay_exclusion':'ROI y ranges .25-.88 exclude top 25% and bottom 12%; original time/name overlays remain in source JPG only',
        'all_source_images_accounted_for':len(sources)==len(selected),
        'all_zero_columns':[c for j,c in enumerate(FEATURE_COLUMNS) if np.all(values[:,j]==0)],
        'constant_columns':[c for j,c in enumerate(FEATURE_COLUMNS) if np.ptp(values[:,j])==0],
        'sources':sources}
    manifest_path=output_csv.with_suffix('.manifest.json')
    manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    if examples:make_roi_examples(selected,image_dir,output_csv.with_suffix('.roi_examples.png'))
    print(json.dumps({'visual_features_complete':True,'rows':len(selected),'features':52,
                      'output_csv':str(output_csv),'all_zero_columns':manifest['all_zero_columns']},ensure_ascii=False),flush=True)
    return manifest


def make_roi_examples(selected,image_dir,output):
    """Annotate copies only, after descriptor export, showing the actual repair."""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.patches import Rectangle
    choices=np.linspace(0,len(selected)-1,3).round().astype(int)
    fig,axes=plt.subplots(2,3,figsize=(12,6.5),layout='constrained')
    colors=['#17becf','#e377c2','#2ca02c','#ffee00']
    legacy=[(288,81,455,178),(120,81,288,178),(120,178,288,285),(288,178,455,285)]
    for j,index in enumerate(choices):
        row=selected[int(index)]
        with Image.open(Path(image_dir)/row['img_name']) as im:rgb=np.asarray(im.convert('RGB'))
        h,w=rgb.shape[:2]
        for line,boxes in enumerate([legacy,list(region_pixels(w,h).values())]):
            ax=axes[line,j];ax.imshow(rgb);ax.axis('off')
            for a,((x0,y0,x1,y1),color) in enumerate(zip(boxes,colors),1):
                ax.add_patch(Rectangle((x0,y0),x1-x0,y1-y0,fill=False,edgecolor=color,linewidth=1.6))
                ax.text(x0+2,y0+3,str(a),va='top',color=color,fontsize=9)
            ax.set_title(f'{"Legacy fixed pixels" if line==0 else "Corrected normalized ROI"}\n{row["time"]} ({w}×{h})',fontsize=10)
    fig.savefig(output,dpi=220,bbox_inches='tight');plt.close(fig)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--selection-csv',type=Path,required=True)
    parser.add_argument('--image-dir',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--workers',type=int,default=4)
    args=parser.parse_args()
    extract_corrected_features(args.selection_csv,args.image_dir,args.output,args.workers)


if __name__=='__main__':main()
