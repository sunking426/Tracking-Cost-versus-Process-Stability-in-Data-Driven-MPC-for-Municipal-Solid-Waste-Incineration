"""Train-memory visual context for numerical Ridge dynamics.

Keys are standardized numerical histories, not GRU embeddings. Forecasting uses
only those histories and a frozen training memory. Retrieval is deterministic;
all returned visual vectors retain their actual training donor indices.
"""
from __future__ import annotations

from pathlib import Path
from types import MappingProxyType

import numpy as np
from sklearn.preprocessing import StandardScaler

from .numeric_baselines import linear_increment, numeric_features
from .ridge_dynamics import _history_arrays, recursive_rollout


def _readonly(value, dtype=None):
    result = np.array(value, dtype=dtype, copy=True)
    result.flags.writeable = False
    return result


def _indices(value, name, n):
    result = np.asarray(value)
    if (result.ndim != 1 or not len(result) or not np.issubdtype(result.dtype, np.integer)
            or result.min() < 0 or result.max() >= n or len(np.unique(result)) != len(result)):
        raise ValueError(f'{name} requires nonempty unique valid integer indices')
    return result.astype(np.int64, copy=False)


def _seed(value):
    if value is None:
        return -1
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, np.integer)) or value < 0:
        raise ValueError('permutation seed must be a nonnegative integer or None')
    return int(value)


def _cycle_permutation(n, seed):
    """One random cycle through every anchor; no anchor maps to itself."""
    if seed == -1:
        return np.arange(n, dtype=np.int64)
    if n < 2:
        raise ValueError('a shuffled visual memory requires at least two anchors')
    order = np.random.default_rng(seed).permutation(n)
    result = np.empty(n, dtype=np.int64)
    result[order] = np.roll(order, -1)
    return result


def _normalized_rows(values):
    norms = np.linalg.norm(values, axis=1, keepdims=True)
    return values / np.maximum(norms, 1e-12)


class NumericalVisualMemory:
    """Training-only 178-column cosine keys and 52- or RGB-derived context.

    Training retrieval must pass ``query_indices``. It excludes overlapping
    source intervals and identical captures for both the key anchor and a
    paired exclusion donor. Setting the same ``exclusion_permutation_seed``
    for real and shuffled memories keeps their eligible key sets identical.
    Validation/recursive calls omit indices and search the frozen train memory.
    No CV targets are read in this class.
    """

    def __init__(self, data, train_idx, visual, max_items=512,
                 permutation_seed=None, exclusion_permutation_seed=None):
        x = numeric_features(data)
        n = len(x)
        train = np.sort(_indices(train_idx, 'training memory', n))
        if 'train_idx' in data and not np.array_equal(train, np.sort(np.asarray(data['train_idx']))):
            raise ValueError('memory membership must equal the declared training partition')
        if isinstance(max_items, (bool, np.bool_)) or not isinstance(max_items, (int, np.integer)) or max_items < 1:
            raise ValueError('max_items must be a positive integer')
        visual = np.asarray(visual, dtype=np.float64)
        if visual.ndim != 2 or len(visual) != n or visual.shape[1] < 1 or not np.isfinite(visual).all():
            raise ValueError('visual features must be finite and aligned to the source rows')
        source = {}
        for name in ('source_start_ns', 'source_end_ns', 'visual_time_ns'):
            value = np.asarray(data[name])
            if value.shape != (n,) or not np.issubdtype(value.dtype, np.integer):
                raise ValueError(f'{name} must contain one integer timestamp per sample')
            source[name] = value
        if np.any(source['source_start_ns'] > source['source_end_ns']):
            raise ValueError('invalid source time interval')
        positions = np.linspace(0, len(train)-1, min(int(max_items), len(train))).round().astype(np.int64)
        anchors = train[np.unique(positions)]
        permutation_seed = _seed(permutation_seed)
        exclusion_permutation_seed = _seed(exclusion_permutation_seed)
        # A nonidentity donor must always be covered by training exclusions.
        if permutation_seed != -1 and exclusion_permutation_seed != permutation_seed:
            raise ValueError('shuffled donor permutation must match the exclusion permutation')
        donors = anchors[_cycle_permutation(len(anchors), permutation_seed)]
        exclusion = anchors[_cycle_permutation(len(anchors), exclusion_permutation_seed)]
        scaler = StandardScaler().fit(x[train])
        keys = _normalized_rows(scaler.transform(x[anchors]))
        self._install({
            'schema_version': np.asarray(1, dtype=np.int64),
            'train_indices': train, 'indices': anchors, 'donor_indices': donors,
            'exclusion_donor_indices': exclusion, 'x_mean': scaler.mean_, 'x_scale': scaler.scale_,
            'keys': keys, 'visual': visual[donors],
            'permutation_seed': np.asarray(permutation_seed, dtype=np.int64),
            'exclusion_permutation_seed': np.asarray(exclusion_permutation_seed, dtype=np.int64),
            **source,
        })

    def _install(self, values):
        if np.asarray(values['schema_version']).shape != () or int(values['schema_version']) != 1:
            raise ValueError('unsupported visual memory schema')
        n = len(np.asarray(values['source_start_ns']))
        train = np.sort(_indices(values['train_indices'], 'saved train', n))
        anchors = _indices(values['indices'], 'saved anchors', n)
        donors = _indices(values['donor_indices'], 'saved donors', n)
        exclusion = _indices(values['exclusion_donor_indices'], 'saved exclusion donors', n)
        if (not np.array_equal(anchors, np.sort(anchors)) or not np.isin(anchors, train).all()
                or not np.array_equal(np.sort(donors), anchors)
                or not np.array_equal(np.sort(exclusion), anchors)):
            raise ValueError('memory anchors and donors must be permutations of training anchors')
        for name in ('source_start_ns', 'source_end_ns', 'visual_time_ns'):
            array = np.asarray(values[name])
            if array.shape != (n,) or not np.issubdtype(array.dtype, np.integer):
                raise ValueError(f'invalid saved {name}')
        if np.any(np.asarray(values['source_start_ns']) > np.asarray(values['source_end_ns'])):
            raise ValueError('invalid saved source time intervals')
        for name in ('x_mean', 'x_scale'):
            value = np.asarray(values[name])
            if value.shape != (178,) or not np.isfinite(value).all() or (name == 'x_scale' and np.any(value <= 0)):
                raise ValueError(f'invalid memory {name}')
        keys = np.asarray(values['keys'])
        visual = np.asarray(values['visual'])
        if keys.shape != (len(anchors), 178) or not np.isfinite(keys).all():
            raise ValueError('invalid normalized memory keys')
        norms = np.linalg.norm(keys, axis=1)
        if not np.all((np.abs(norms-1) < 1e-10) | (norms < 1e-10)):
            raise ValueError('memory keys must be normalized or zero')
        if visual.ndim != 2 or visual.shape[0] != len(anchors) or visual.shape[1] < 1 or not np.isfinite(visual).all():
            raise ValueError('invalid memory visual matrix')
        for field, actual in (('permutation_seed', donors), ('exclusion_permutation_seed', exclusion)):
            value = np.asarray(values[field])
            if value.shape != () or not np.issubdtype(value.dtype, np.integer) or int(value) < -1:
                raise ValueError(f'invalid saved {field}')
            if not np.array_equal(actual, anchors[_cycle_permutation(len(anchors), int(value))]):
                raise ValueError('saved donor indices disagree with their permutation seed')
        if int(values['permutation_seed']) != -1 and int(values['permutation_seed']) != int(values['exclusion_permutation_seed']):
            raise ValueError('saved shuffled donors are not covered by exclusions')
        self._values = MappingProxyType({key: _readonly(value) for key, value in values.items()})
        for name, value in self._values.items():
            setattr(self, name, value)
        self.visual_dim = int(visual.shape[1])
        self.source_path = None

    def query(self, u_hist, z_hist, query_indices=None, *, batch_size=2048):
        x = numeric_features({'u_hist': u_hist, 'z_hist': z_hist})
        if not len(x):
            raise ValueError('memory query requires at least one history')
        if isinstance(batch_size, (bool, np.bool_)) or not isinstance(batch_size, (int, np.integer)) or batch_size < 1:
            raise ValueError('query batch_size must be a positive integer')
        rows = None
        if query_indices is not None:
            rows = np.asarray(query_indices)
            if (rows.shape != (len(x),) or not np.issubdtype(rows.dtype, np.integer)
                    or not np.isin(rows, self.train_indices).all()):
                raise ValueError('training query indices must be aligned training members')
        selected, scores = np.empty(len(x), dtype=np.int64), np.empty(len(x), dtype=np.float64)
        for begin in range(0, len(x), batch_size):
            end = min(begin + batch_size, len(x))
            query = _normalized_rows((x[begin:end] - self.x_mean) / self.x_scale)
            similarity = query @ self.keys.T
            if not np.isfinite(similarity).all():
                raise FloatingPointError('nonfinite cosine retrieval scores')
            if rows is not None:
                row = rows[begin:end]
                excluded = np.zeros(similarity.shape, dtype=bool)
                for donors in (self.indices, self.exclusion_donor_indices):
                    overlap = ((self.source_start_ns[donors][None] <= self.source_end_ns[row, None])
                               & (self.source_end_ns[donors][None] >= self.source_start_ns[row, None]))
                    same_capture = self.visual_time_ns[donors][None] == self.visual_time_ns[row, None]
                    excluded |= overlap | same_capture
                if np.any(excluded.all(axis=1)):
                    raise ValueError('no eligible training neighbor after source/capture exclusions')
                similarity[excluded] = -np.inf
            # NumPy argmax returns the first position on ties: anchors are sorted.
            best = np.argmax(similarity, axis=1)
            selected[begin:end] = best
            scores[begin:end] = similarity[np.arange(end-begin), best]
        return {'visual': self.visual[selected].copy(), 'key_indices': self.indices[selected].copy(),
                'donor_indices': self.donor_indices[selected].copy(), 'scores': scores}

    def save(self, path):
        path = Path(path)
        if path.suffix != '.npz':
            raise ValueError('visual memory path must end in .npz')
        np.savez_compressed(path, **self._values)

    @classmethod
    def load(cls, path):
        path = Path(path).resolve()
        fields = {'schema_version', 'train_indices', 'indices', 'donor_indices',
                  'exclusion_donor_indices', 'x_mean', 'x_scale', 'keys', 'visual',
                  'permutation_seed', 'exclusion_permutation_seed',
                  'source_start_ns', 'source_end_ns', 'visual_time_ns'}
        with np.load(path, allow_pickle=False) as archive:
            if set(archive.files) != fields:
                raise ValueError('visual memory archive fields differ from schema')
            values = {name: archive[name] for name in fields}
        model = cls.__new__(cls)
        model._install(values)
        model.source_path = path
        return model


class RidgeWithVisual:
    """A nine-output direct Ridge on numerical history plus an explicit vector."""

    def __init__(self, weights):
        mean = np.asarray(weights['x_mean'])
        if mean.ndim != 1 or len(mean) <= 178:
            raise ValueError('visual Ridge requires 178 numerical plus positive visual dimensions')
        width = len(mean)
        shapes = {'x_mean': (width,), 'x_scale': (width,), 'coef': (9, width),
                  'intercept': (9,), 'delta_scale': (9,)}
        values = {}
        for name, shape in shapes.items():
            value = np.asarray(weights[name], dtype=np.float64)
            if value.shape != shape or not np.isfinite(value).all():
                raise ValueError(f'{name} must be finite with shape {shape}')
            if name.endswith('scale') and np.any(value <= 0):
                raise ValueError(f'{name} must be positive')
            values[name] = _readonly(value)
        kind, alpha = np.asarray(weights['kind']), np.asarray(weights['alpha'])
        if kind.shape != () or str(kind.item()) != 'ridge':
            raise ValueError('visual dynamics require a selected direct Ridge')
        if alpha.shape != () or not np.isfinite(float(alpha)) or float(alpha) <= 0:
            raise ValueError('visual Ridge alpha must be positive and finite')
        values.update(kind=np.asarray('ridge'), alpha=np.asarray(float(alpha)))
        self.weights = MappingProxyType(values)
        self.visual_dim = width - 178
        self.source_path = None

    def predict_delta(self, u_hist, z_hist, visual):
        u, z = _history_arrays(u_hist, z_hist)
        visual = np.asarray(visual, dtype=np.float64)
        if visual.shape != (len(u), self.visual_dim) or not np.isfinite(visual).all():
            raise ValueError('visual Ridge requires a finite aligned visual matrix')
        x = np.concatenate((numeric_features({'u_hist': u, 'z_hist': z}), visual), axis=1)
        with np.errstate(over='raise', invalid='raise', divide='raise'):
            result = linear_increment(self.weights, x)
        if result.shape != (len(u), 9) or not np.isfinite(result).all():
            raise FloatingPointError('nonfinite visual Ridge increment')
        return result

    def predict_next(self, u_hist, z_hist, visual):
        u, z = _history_arrays(u_hist, z_hist)
        with np.errstate(over='raise', invalid='raise'):
            result = z[:, -1] + self.predict_delta(u, z, visual)
        if not np.isfinite(result).all():
            raise FloatingPointError('nonfinite visual Ridge state')
        return result

    def save(self, path):
        path = Path(path)
        if path.suffix != '.npz':
            raise ValueError('visual Ridge path must end in .npz')
        np.savez_compressed(path, **self.weights)

    @classmethod
    def load(cls, path):
        path = Path(path).resolve()
        with np.load(path, allow_pickle=False) as archive:
            fields = ('x_mean', 'x_scale', 'coef', 'intercept', 'delta_scale', 'kind', 'alpha')
            if not set(fields).issubset(archive.files):
                raise ValueError('incomplete visual Ridge model archive')
            model = cls({name: archive[name] for name in fields})
        model.source_path = path
        return model


def retrieved_rollout(model, memory, u_hist, z_hist, mv_path, mode='dynamic'):
    """Use canonical numerical recursion, retaining every retrieved source.

    ``dynamic`` queries the training memory before each prediction, including
    the first. ``hold`` repeats the initially retrieved visual vector and its
    initial source/score for all steps. No future observed visual/CV input exists.
    Training retrieval exclusions belong to fitting, not held-out simulation.
    """
    if mode not in ('dynamic', 'hold'):
        raise ValueError('retrieval mode must be dynamic or hold')
    if model.visual_dim != memory.visual_dim:
        raise ValueError('model and memory visual dimensions differ')
    traces = []

    class RetrievedDynamics:
        def predict_next(self, u, z):
            retrieval = memory.query(u, z) if mode == 'dynamic' or not traces else traces[0]
            traces.append(retrieval)
            return model.predict_next(u, z, retrieval['visual'])

    predictions = recursive_rollout(RetrievedDynamics(), u_hist, z_hist, mv_path)
    return {'predictions': predictions,
            **{key: np.stack([row[key] for row in traces], axis=1)
               for key in ('key_indices', 'donor_indices', 'scores')}}
