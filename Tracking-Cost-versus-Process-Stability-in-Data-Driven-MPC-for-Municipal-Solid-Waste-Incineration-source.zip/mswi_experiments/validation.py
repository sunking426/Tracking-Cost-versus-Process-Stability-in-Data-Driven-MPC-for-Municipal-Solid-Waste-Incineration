"""Fixed-horizon and chronological-block validation of frozen process twins.

This module composes the canonical recursive forecasting implementation. It
never chooses a horizon, checkpoint or reset based on a held-out error.
"""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

import numpy as np
import torch

from .analysis import (
    _endpoint_metrics, _metrics, _recursive_rollouts, _select_rollout_chains,
    _validate_splits,
)
from .data import control_values
from .retrieval import VisualMemory, encoder_fingerprint
from .training import predict_twin


CONTROL_NAMES = ('temperature', 'pressure', 'steam', 'oxygen')
DEFAULT_HORIZONS = (1, 5, 10, 20, 50)


def chronological_blocks(indices, times, count=3):
    """Equal-count consecutive time blocks, fixed without reference to targets."""
    indices = np.asarray(indices, dtype=np.int64)
    times = np.asarray(times, dtype=np.int64)
    if count <= 0 or indices.ndim != 1 or len(indices) < count:
        raise ValueError('Insufficient indices for chronological blocks')
    if len(np.unique(indices)) != len(indices):
        raise ValueError('Chronological blocks require unique source indices')
    ordered = indices[np.argsort(times[indices], kind='stable')]
    if (np.diff(times[ordered]) <= 0).any():
        raise ValueError('Chronological source timestamps must be strictly increasing')
    return [np.asarray(x, dtype=np.int64) for x in np.array_split(ordered, count)]


def select_validation_chains(data, count=50, horizon=50, block_count=3):
    """Select complete disjoint chains within each predetermined time block."""
    if count < block_count or horizon <= 0:
        raise ValueError('Validation requires at least one chain in every time block')
    blocks = chronological_blocks(data['test_idx'], data['time_ns'], block_count)
    allocation = [len(x) for x in np.array_split(np.arange(count), block_count)]
    parts, labels, descriptions = [], [], []
    for block, (indices, wanted) in enumerate(zip(blocks, allocation)):
        chains = _select_rollout_chains({**data, 'test_idx': indices}, wanted, horizon)
        parts.append(chains)
        labels.extend([block] * len(chains))
        descriptions.append({
            'block': block + 1, 'test_samples': int(len(indices)),
            'first_time_ns': int(data['time_ns'][indices[0]]),
            'last_time_ns': int(data['time_ns'][indices[-1]]),
            'rollout_chains': int(len(chains)),
        })
    joined = np.concatenate(parts)
    if len(np.unique(joined)) != joined.size:
        raise AssertionError('Validation chains overlap')
    return joined, np.asarray(labels, dtype=np.int64), blocks, descriptions


def _step_metrics(truth, prediction):
    error = np.asarray(prediction, dtype=np.float64) - np.asarray(truth, dtype=np.float64)
    if error.ndim != 3 or error.shape[-1] != 4 or not np.isfinite(error).all():
        raise FloatingPointError('Invalid recursive physical prediction array')
    return {'mae': np.abs(error).mean(axis=0).tolist(),
            'rmse': np.sqrt(np.square(error).mean(axis=0)).tolist()}


def _rollout_summary(raw, block_ids, horizons):
    summary = {**_endpoint_metrics(raw['truth'], raw['prediction'], horizons),
               'per_step': _step_metrics(raw['truth'], raw['prediction']),
               'episodes': int(len(raw['indices'])), 'steps': int(raw['indices'].shape[1]),
               'blocks': []}
    for block in np.unique(block_ids):
        take = block_ids == block
        summary['blocks'].append({
            'block': int(block) + 1, 'episodes': int(take.sum()),
            **_endpoint_metrics(raw['truth'][take], raw['prediction'][take], horizons),
            'per_step': _step_metrics(raw['truth'][take], raw['prediction'][take]),
        })
    return summary


def _write_one_step(out, name, data, test, prediction_cv):
    truth_cv = np.asarray(data['z_target'])[test]
    truth, prediction = control_values(truth_cv), control_values(prediction_cv)
    np.savez_compressed(out / f'{name}_onestep.npz', indices=test,
                        time_ns=np.asarray(data['time_ns'])[test],
                        truth_cv=truth_cv, prediction_cv=prediction_cv,
                        truth=truth, prediction=prediction, error=prediction - truth)
    with (out / f'{name}_onestep.csv').open('w', newline='') as stream:
        writer = csv.writer(stream)
        writer.writerow(['sample_index', 'time_ns'] +
                        [f'{kind}_{v}' for kind in ('truth', 'prediction') for v in CONTROL_NAMES])
        for idx, ts, y, pred in zip(test, data['time_ns'][test], truth, prediction):
            writer.writerow([int(idx), int(ts), *y.tolist(), *pred.tolist()])
    return truth, prediction


def _write_rollout(out, name, raw, block_ids):
    np.savez_compressed(out / f'{name}_rollout.npz', **raw, block_ids=block_ids)
    with (out / f'{name}_rollout.csv').open('w', newline='') as stream:
        writer = csv.writer(stream)
        writer.writerow(['block', 'start_index', 'sample_index', 'time_ns', 'step',
                         'memory_source_index'] +
                        [f'{kind}_{v}' for kind in ('truth', 'prediction') for v in CONTROL_NAMES])
        for episode, indices in enumerate(raw['indices']):
            for step, idx in enumerate(indices):
                writer.writerow([int(block_ids[episode]) + 1, int(indices[0]), int(idx),
                                 int(raw['time_ns'][episode, step]), step + 1,
                                 int(raw['memory_source_index'][episode, step]),
                                 *raw['truth'][episode, step].tolist(),
                                 *raw['prediction'][episode, step].tolist()])


def run_horizon_validation(data, stats, twins, config, outdir):
    """Validate multi/sensor/evaluation fits on shared 50-step held-out chains.

    Returns and saves ``validation_results.json``. ``validation`` config owns
    ``rollout_starts`` (50), ``max_horizon`` (50), ``horizons`` ([1,5,10,20,50]),
    ``time_blocks`` (3) and inference ``batch_size`` (512). No setting is selected
    from a test error. The evaluation twin is another fit of the same model class
    and data, not independent physical or interventional ground truth.
    """
    if set(twins) != {'multi', 'sensor', 'eval'}:
        raise ValueError('Horizon validation requires multi, sensor and eval twins')
    splits = _validate_splits(data)
    cfg = config.get('validation', {})
    count = int(cfg.get('rollout_starts', 50))
    maximum = int(cfg.get('max_horizon', 50))
    blocks_count = int(cfg.get('time_blocks', 3))
    horizons = tuple(int(x) for x in cfg.get('horizons', DEFAULT_HORIZONS))
    if not horizons or len(set(horizons)) != len(horizons) or tuple(sorted(horizons)) != horizons or horizons[0] < 1 or horizons[-1] > maximum:
        raise ValueError('Endpoint horizons must be sorted unique positive values within max_horizon')
    batch_size = int(cfg.get('batch_size', 512))
    if batch_size <= 0:
        raise ValueError('Inference batch size must be positive')
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(int(config.get('training', {}).get('threads', 4)))
    chains, block_ids, blocks, block_descriptions = select_validation_chains(
        data, count, maximum, blocks_count)
    test = np.concatenate(blocks)
    result = {
        'schema': 1, 'control_names': list(CONTROL_NAMES),
        'test_samples': len(test), 'horizons': list(horizons),
        'max_horizon': maximum, 'rollout_starts': chains[:, 0].tolist(),
        'chronological_blocks': block_descriptions, 'models': {},
        'qualification': 'Logged-MV prediction validation; no causal plant-control claim',
    }
    memory_cfg = config.get('retrieval', {})
    for name, twin in twins.items():
        expected_mode = 'sensor' if name == 'sensor' else 'multi'
        if getattr(twin, 'mode', expected_mode) != expected_mode:
            raise ValueError(f'{name} twin has the wrong modality configuration')
        print(f'horizon validation: {name}', flush=True)
        twin.eval()
        predicted_cv = predict_twin(twin, data, test, batch_size)
        truth, predicted = _write_one_step(out, name, data, test, predicted_cv)
        one_step = {**_metrics(truth, predicted), 'n': len(test), 'blocks': []}
        for block, indices in enumerate(blocks):
            take = np.isin(test, indices)
            one_step['blocks'].append({'block': block + 1, 'n': int(take.sum()),
                                      **_metrics(truth[take], predicted[take])})
        memory = VisualMemory(twin, data, data['train_idx'],
                              max_items=int(memory_cfg.get('max_items', 512)),
                              k=int(memory_cfg.get('k', 3)))
        memory.save(out / f'{name}_memory')
        raw = _recursive_rollouts(twin, memory, data, chains)
        _write_rollout(out, name, raw, block_ids)
        result['models'][name] = {'model_sha256': encoder_fingerprint(twin),
                                  'onestep': one_step,
                                  'rollout': _rollout_summary(raw, block_ids, horizons)}

    # Persistence is anchored before the first prediction, never to future CVs.
    pred_cv = np.asarray(data['z_prev'])[test].copy()
    truth, prediction = _write_one_step(out, 'persistence', data, test, pred_cv)
    one_step = {**_metrics(truth, prediction), 'n': len(test), 'blocks': []}
    for block, indices in enumerate(blocks):
        take = np.isin(test, indices)
        one_step['blocks'].append({'block': block + 1, 'n': int(take.sum()),
                                  **_metrics(truth[take], prediction[take])})
    truth_cv = np.asarray(data['z_target'])[chains].copy()
    prediction_cv = np.repeat(np.asarray(data['z_prev'])[chains[:, 0], None, :], maximum, axis=1)
    raw = {'indices': chains, 'time_ns': np.asarray(data['time_ns'])[chains],
           'truth_cv': truth_cv, 'prediction_cv': prediction_cv,
           'truth': control_values(truth_cv), 'prediction': control_values(prediction_cv),
           'logged_mv': np.asarray(data['u_current'])[chains],
           'memory_source_index': np.full(chains.shape, -1, dtype=np.int64)}
    _write_rollout(out, 'persistence', raw, block_ids)
    result['models']['persistence'] = {'onestep': one_step,
                                      'rollout': _rollout_summary(raw, block_ids, horizons)}
    manifest = {
        'schema': 1, 'config': cfg,
        'models': {name: value['model_sha256'] for name, value in result['models'].items() if 'model_sha256' in value},
        'selection': 'Three chronological equal-count test blocks; complete within-block disjoint chains; uniform selection per block',
        'block_chain_allocation': [int((block_ids == b).sum()) for b in range(blocks_count)],
        'one_step_visual': 'Observed historical feature from prepared causal sample',
        'recursive_visual': 'Training-only retrieval at every step, including first',
        'recursive_cv': 'Observed initial history and z_prev; then own predictions only',
        'recursive_mv': 'Fixed future logged MV, identical across models',
        'persistence': 'Observed z_prev for one-step; fixed anchor z_prev at every recursive horizon',
        'comparison_limits': 'Different one-step versus recursive image inputs and sample counts; same fitted-data model class is not independent physical validation',
        'test_selection_used_for_tuning': False,
        'previously_inspected_test_period': True,
        'analysis_status': 'Fixed post-development re-evaluation; not a fresh blind confirmatory test',
        'source_sha256': {
            Path(p).name: hashlib.sha256(Path(p).read_bytes()).hexdigest()
            for p in (__file__, Path(__file__).with_name('analysis.py'),
                      Path(__file__).with_name('models.py'), Path(__file__).with_name('retrieval.py'))
        },
    }
    for name, value in [('validation_results.json', result), ('validation_manifest.json', manifest)]:
        (out / name).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    return result
