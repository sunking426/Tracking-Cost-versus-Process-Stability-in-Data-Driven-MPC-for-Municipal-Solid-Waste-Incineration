"""Ridge policy-state, exact execution and historical-context interfaces.

Predictor/reward/projection remain owned by their canonical modules. The new
policy tensor is not an old GRU state: current physical MV is explicit.
"""
from __future__ import annotations

import numpy as np
import torch
from scipy.spatial import cKDTree
from sklearn.preprocessing import StandardScaler

from .control import project_normalized_actions, reward_and_violation
from .data import MINUTE_NS
from .ridge_response import decision_rollout
from .ridge_response_study import joint_features, support_query

ACTIVE = np.array([0, 3])
INACTIVE = np.array([1, 2, 4, 5, 6, 7])


def policy_numeric(u, z_previous, current):
    u, z_previous, current = (np.asarray(a, dtype=np.float64) for a in (u, z_previous, current))
    n = len(u)
    if u.shape != (n, 11, 8) or z_previous.shape != (n, 10, 9) or current.shape != (n, 9):
        raise ValueError('policy histories must be (11,8),(10,9),current9')
    result = np.concatenate((u.reshape(n, 88),
                             np.concatenate((z_previous[:, 1:], current[:, None]), axis=1).reshape(n, 90)), axis=1)
    if not np.isfinite(result).all():
        raise FloatingPointError('nonfinite policy history')
    return result


class ExactSupport:
    """Exact Euclidean tree lookup; canonical support_query is the audit oracle.

No approximate-neighbor tolerance. Expand k until the first time-eligible
neighbor is present. Numerical equivalence is checked before experimental use.
"""
    def __init__(self, values):
        self.values = values
        self.bank = np.asarray(values['bank_standardized'], dtype=np.float64)
        self.tree = cKDTree(self.bank)
        self.times = np.asarray(values['bank_time_ns'])
        self.radius_time = int(values['exclusion_minutes']) * MINUTE_NS

    def query(self, u, z, delta, times):
        v = self.values
        x = (joint_features(u, z, delta) - v['x_mean']) / v['x_scale']
        times = np.asarray(times, dtype=np.int64)
        if times.shape != (len(x),) or not np.isfinite(x).all():
            raise ValueError('finite aligned support input required')
        distance = np.empty(len(x)); selected = np.empty(len(x), dtype=np.int64)
        pending = np.arange(len(x)); k = min(4, len(self.bank))
        while len(pending):
            d, idx = self.tree.query(x[pending], k=k, eps=0, workers=1)
            if k == 1:
                d, idx = d[:, None], idx[:, None]
            allowed = np.abs(times[pending, None] - self.times[idx]) > self.radius_time
            any_ok = allowed.any(axis=1); first = np.argmax(allowed, axis=1)
            take = np.flatnonzero(any_ok)
            distance[pending[take]] = d[take, first[take]]
            selected[pending[take]] = idx[take, first[take]]
            pending = pending[~any_ok]
            if len(pending) and k == len(self.bank):
                raise ValueError('no time-disjoint support donor')
            k = min(2*k, len(self.bank))
        return distance, distance <= float(v['threshold']), selected

    def audit(self, u, z, delta, times):
        old = support_query(self.values, u, z, delta, times)
        new = self.query(u, z, delta, times)
        err = float(np.max(np.abs(old[0] - new[0])))
        if err > 1e-10 or not np.array_equal(old[1], new[1]):
            raise AssertionError('exact support backend differs from canonical rule')
        return {'max_distance_difference': err, 'decisions_equal': True, 'rows': len(u)}


class Execution:
    def __init__(self, stats, support):
        self.stats = stats
        self.support = ExactSupport(support)
        self.scale = np.asarray(stats['action_scale'], dtype=np.float64)
        self.bound = np.asarray(stats['action_bound'], dtype=np.float64)
        self.m = .1 * self.bound[ACTIVE] / self.scale[ACTIVE]
        if np.any(self.m <= 0):
            raise ValueError('two positive active budgets required')

    def request(self, b):
        b = np.asarray(b, dtype=np.float64)
        if b.ndim != 2 or b.shape[1] != 2 or not np.isfinite(b).all():
            raise ValueError('finite actor request (N,2) required')
        a = np.zeros((len(b), 8)); a[:, ACTIVE] = np.clip(b, -1, 1) * self.m
        return a

    def screen(self, request, u, z, times):
        a, u = (np.asarray(v, dtype=np.float64) for v in (request, u))
        if a.shape != u.shape or a.shape[1] != 8 or not np.isfinite(a).all():
            raise ValueError('aligned finite eight-channel request required')
        if np.any(a[:, INACTIVE] != 0) or np.any(np.abs(a[:, ACTIVE]) > self.m + 1e-12):
            raise ValueError('restricted actor budget exceeded')
        executed, delta, next_u = project_normalized_actions(torch.from_numpy(a.copy()), torch.from_numpy(u.copy()), self.stats)
        executed, delta, next_u = (x.numpy() for x in (executed, delta, next_u))
        complete = np.all(np.abs(delta - a*self.scale) <= 1e-10, axis=1)
        dist, supported, _ = self.support.query(u, z, delta, times)
        nonzero = np.any(a != 0, axis=1)
        admitted = (complete & supported) | ~nonzero
        return {'executed':executed, 'physical':delta, 'next_u':next_u,
                'distance':dist, 'supported':supported, 'complete':complete,
                'nonzero':nonzero, 'admitted':admitted}

    def apply(self, request, u, z, times):
        proposal = self.screen(request, u, z, times)
        blocked = ~proposal['admitted']
        if blocked.any():
            applied = np.asarray(request).copy(); applied[blocked] = 0
            actual = self.screen(applied, u, z, times)
        else:
            actual = proposal
        if np.any(actual['physical'][:, INACTIVE] != 0):
            raise AssertionError('inactive MV corrected: reset outside declared scope')
        return actual, proposal, blocked

    def tensor(self, b, u, z, times):
        """Differentiable projection, detached exact support acceptance."""
        request = b.to(torch.float64).clamp(-1,1) @ b.new_tensor(
            [[self.m[0],0,0,0,0,0,0,0], [0,0,0,self.m[1],0,0,0,0]], dtype=torch.float64)
        physical_u = torch.as_tensor(u, dtype=torch.float64)
        executed, _, _ = project_normalized_actions(request, physical_u, self.stats)
        with torch.no_grad():
            screen = self.screen(request.detach().numpy(), np.asarray(u), z, times)
        mask = torch.as_tensor(screen['admitted'], dtype=torch.float64)[:,None]
        return (executed * mask).to(b.dtype)


class PolicyContext:
    def __init__(self, values, stats):
        self.v = values
        self.v_mean = np.asarray(stats['v_mean']); self.v_scale = np.asarray(stats['v_scale'])

    @classmethod
    def fit(cls, data, stats):
        train = np.asarray(data['train_idx']); x = policy_numeric(data['u_hist'], data['z_hist'], data['z_current'])
        scaler = StandardScaler().fit(x[train])
        positions = np.linspace(0,len(train)-1,512).round().astype(np.int64)
        anchors = train[np.unique(positions)]
        keys = (x[anchors]-scaler.mean_)/scaler.scale_
        keys /= np.maximum(np.linalg.norm(keys,axis=1,keepdims=True),1e-12)
        values = {'mean':scaler.mean_, 'scale':scaler.scale_, 'indices':anchors,
                  'keys':keys, 'visual':np.asarray(data['visual'][anchors],dtype=np.float64),
                  'source_start':data['source_start_ns'][anchors], 'source_end':data['source_end_ns'][anchors],
                  'capture':data['visual_time_ns'][anchors]}
        return cls(values,stats)

    def query(self, numeric, exclusion=None):
        x = (np.asarray(numeric,dtype=np.float64)-self.v['mean'])/self.v['scale']
        key = x/np.maximum(np.linalg.norm(x,axis=1,keepdims=True),1e-12)
        result = []; donors=[]
        for start in range(0,len(x),512):
            end=min(start+512,len(x)); sim=key[start:end]@self.v['keys'].T
            if exclusion is not None:
                lo,hi,cap=exclusion
                mask=(self.v['source_start'][None]<=hi[start:end,None]) & (self.v['source_end'][None]>=lo[start:end,None])
                caps=np.asarray(cap[start:end]);caps=caps[:,None] if caps.ndim==1 else caps
                mask |= np.any(self.v['capture'][None,None,:]==caps[:,:,None],axis=1)
                if mask.all(axis=1).any():raise ValueError('no eligible training visual donor')
                sim[mask]=-np.inf
            best=np.argmax(sim,axis=1);result.append(self.v['visual'][best]);donors.append(self.v['indices'][best])
        return np.concatenate(result), np.concatenate(donors)

    def features(self, numeric, visual, mode='full'):
        n=(np.asarray(numeric)-self.v['mean'])/self.v['scale']
        v=(np.asarray(visual)-self.v_mean)/self.v_scale
        if mode=='sensor':v=np.zeros_like(v)
        state=np.concatenate((n,v),axis=1).astype(np.float32)
        if state.shape[1]!=230 or not np.isfinite(state).all():raise ValueError('invalid230 policy state')
        return state


class RidgePolicyEnv:
    """Vector environment with Gym-style reset and five-value step contract.

Physical metadata is explicit; no dependency on GRU state layout. Sampling
truncation is never a physical terminal and does not mask TD bootstrap.
"""
    def __init__(self, dynamics, execution, context=None, horizon=10, visual_mode='full'):
        self.model=dynamics;self.execution=execution;self.context=context
        self.horizon=int(horizon);self.visual_mode=visual_mode

    def reset(self, *, options):
        row=options['inputs']
        self.u=np.asarray(row['u_hist'],dtype=np.float64).copy()
        self.z=np.asarray(row['z_hist'],dtype=np.float64).copy()
        self.current=np.asarray(row['z_current'],dtype=np.float64).copy()
        self.times=np.asarray(row['time_ns'],dtype=np.int64).copy()
        self.indices=np.asarray(row['indices'],dtype=np.int64).copy()
        self.exclusion=options.get('exclusion');self.elapsed=0
        stats=self.execution.stats
        if np.any(self.u[:,-1]<np.asarray(stats['u_low'])) or np.any(self.u[:,-1]>np.asarray(stats['u_high'])):
            raise ValueError('reset MV outside scope')
        self.initial_visual=None
        obs=self.observation()
        return obs,{'indices':self.indices.copy()}

    def observation(self):
        numeric=policy_numeric(self.u,self.z,self.current)
        if self.context is None:return numeric
        if self.visual_mode=='hold' and self.initial_visual is not None:
            visual=self.initial_visual;donors=self.initial_donors
        else:
            visual,donors=self.context.query(numeric,self.exclusion)
            if self.initial_visual is None:
                self.initial_visual=visual.copy();self.initial_donors=donors.copy()
        self.last_visual=visual;self.last_donors=donors
        return self.context.features(numeric,visual,self.visual_mode)

    def step(self,b):
        return self.step_request(self.execution.request(b))

    def step_request(self,request):
        actual,proposal,blocked=self.execution.apply(request,self.u[:,-1],self.current,self.times)
        next_z=decision_rollout(self.model,self.u,self.z,self.current,actual['next_u'][:,None])[:,0]
        reward,violation,costs=reward_and_violation(next_z,actual['executed'],self.execution.stats)
        info={'pred_cv':next_z.copy(),'u_path':actual['next_u'].copy(),'requested_action':np.asarray(request).copy(),
              'executed_action':actual['executed'],'physical_executed_action':actual['physical'],
              'proposal_support_distance':proposal['distance'],'proposal_supported':proposal['supported'],
              'proposal_full_execution':proposal['complete'],'action_support_distance':actual['distance'],
              'action_supported':actual['supported'],'blocked_nonzero':blocked,
              'zero_action_unsupported':~actual['nonzero']&~actual['supported'],
              'reward':reward,'violation':violation,**costs}
        self.z=np.concatenate((self.z[:,1:],self.current[:,None]),axis=1)
        self.u=np.concatenate((self.u[:,1:],actual['next_u'][:,None]),axis=1)
        self.current=next_z;self.times=self.times+MINUTE_NS;self.elapsed+=1
        obs=self.observation()
        if self.context is not None:info['next_visual_donor']=self.last_donors.copy()
        return obs,reward,np.zeros(len(reward),dtype=bool),np.full(len(reward),self.elapsed>=self.horizon),info
