"""Frozen representative-controller evaluation; no fitting or configuration search.

Transition adapters implement predict_next only. The existing environment owns
history alignment, action admission, reward calculation, and feedback.
"""
from __future__ import annotations
import argparse
import datetime
import json
import shutil
import time
from pathlib import Path
import numpy as np
import torch
from threadpoolctl import threadpool_limits
from .frozen_mpc import ROOT, C_CONFIG, C_SHA256, load_frozen_mpc, file_sha256
from .ridge_dynamics import RidgeDynamics
from .ridge_policy import RidgePolicyEnv
from .ridge_policy_study import REF, OUT as POLICY, SEEDS, read_npz, write_json, shared
from .ridge_policy_evaluation import DecisionPolicy, actor_path
from .mpc_stability import StabilityCEM
from .training import load_twin

DESIGN=ROOT/'experiment_protocols/s8_cross_evaluation_20261108'
OUT=ROOT/'experiment_runs/s8_cross_evaluation_20261108'
NUMERIC=ROOT/'experiment_runs/numeric_baselines_20261104'
DATA=ROOT/'experiment_runs/corrected_vision/data'
RESPONSE=ROOT/'experiment_runs/ridge_response_20261106'
OLD=ROOT/'experiment_runs/mpc_stability_v2_20261108'
MODELS=('early','middle','late','pooled_matched')
METHODS=(('hold',0),*[('bc',s) for s in SEEDS],('C0',0),('S8',0))
GRU=NUMERIC/'models/gru/seed_23/twin.pt'


class GRUFeedback:
    def __init__(self,path=GRU):
        self.model=load_twin(path)
        if self.model.mode!='sensor':raise ValueError('numeric GRU required')

    @torch.no_grad()
    def predict_next(self,u,z):
        u=torch.as_tensor(np.asarray(u),dtype=torch.float32)
        z=torch.as_tensor(np.asarray(z),dtype=torch.float32)
        visual=torch.zeros((len(u),self.model.v_dim),dtype=torch.float32)
        # Match the archived canonical float32 increment-to-level addition.
        return (z[:,-1]+self.model(u,z,visual)).numpy().astype(np.float64)


class ResidualFeedback:
    def __init__(self,model,residual):
        self.model=model
        self.residual=np.asarray(residual,dtype=np.float64)
        if self.residual.ndim!=3 or self.residual.shape[-1]!=9 or not np.isfinite(self.residual).all():
            raise ValueError('finite episode/time/nine-channel residuals required')
        self.step=0

    def predict_next(self,u,z):
        if len(u)!=len(self.residual) or self.step>=self.residual.shape[1]:raise ValueError('residual alignment')
        p=self.model.predict_next(u,z)+self.residual[:,self.step]
        self.step+=1
        return p


def seal():
    parent=load_frozen_mpc()
    if (DESIGN/'seal.json').exists():return verify()
    if (OUT/'trajectories').exists():raise RuntimeError('freeze must precede new control outcomes')
    selection=json.loads((NUMERIC/'selection.json').read_text())['models']
    candidates=[v for v in selection if v['method']=='gru']
    best=min(candidates,key=lambda x:x['val_normalized_mse'])
    if best['seed']!=23:raise AssertionError('validation-only environment selection changed')
    files=[C_CONFIG,Path(__file__),ROOT/'mswi_experiments/mpc_stability.py',
        ROOT/'mswi_experiments/ridge_policy_study.py',ROOT/'mswi_experiments/ridge_policy_evaluation.py',
        ROOT/'mswi_experiments/ridge_policy_training.py',ROOT/'mswi_experiments/training.py',ROOT/'mswi_experiments/models.py',
        POLICY/'policy_context.npz',NUMERIC/'selection.json',GRU,
        NUMERIC/'predictions/gru_seed_23/val.npz',DATA/'dataset.npz',DATA/'stats.json',RESPONSE/'rows.npz',
        ROOT/'experiment_runs/factory_feedback_reassessment_v2_20261108/metrics.py',
        OLD/'trajectories/S8/early.npz',ROOT/'experiment_runs/mpc_temperature_20261107/trajectories/C/early.npz']
    files += [ROOT/p for p in parent['dependencies']]
    files += [REF/f'evaluation_models/{m}.npz' for m in MODELS]
    files += [actor_path('bc',s) for s in SEEDS]
    dependencies={str(p.relative_to(ROOT)):file_sha256(p) for p in sorted(set(files))}
    config={'schema_version':1,'status':'representative_configuration_frozen_not_all_research_screens_passed',
        'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'parent_C0':{'path':str(C_CONFIG.relative_to(ROOT)),'sha256':C_SHA256},
        'stability_weight':8,'stability_formula':'sum_t(abs(F_next-F_current)/5 + abs(O_next-O_current)/0.5)',
        'planning_score':'original_return - 3*temperature_cost - 8*stability_cost',
        'inherited_unchanged':['actions','support','cem','randomness','planner','reward'],
        'parent_contract':{k:parent[k] for k in ('actions','support','cem','objective','planner')},
        'evaluation':{'partition':'val','starts':256,'horizon':50,'primary_horizon':10,
            'methods':METHODS,'gru_seed':23,'gru_selection':best,
            'gru_other_seeds':'omitted before execution to limit computation',
            'td3bc':'optional comparator omitted before execution to limit computation',
            'ridge_models':MODELS,'residual_replicates':5,'residual_block_minutes':10,
            'pooled_residual_scope':'pending user clarification; separate sealed C addendum required',
            'no_test_selection_or_evaluation':True,'no_paper_update':True},
        'statistics':{'bootstrap_repetitions':10000,'seed':20261108,'unit':'paired original starting point',
            'BC':'calculate metrics per seed/trajectory, then mean all five seeds within start',
            'noise':'calculate metrics per trajectory, then mean five residual sequences within start',
            'interval':'percentile 95%, exploratory, no multiplicity correction',
            'detrended_sd':'OLS intercept and linear trend removed separately within each trajectory; residual sample SD ddof1',
            'ratios':'ratio of across-start mean SDs; paired bootstrap ratio',
            'temperature':'six-sensor mean for SD; any of six sensors for >1050; trailing five-minute mean includes four observed prefix values',
            'low_temperature':'single-sensor time-point counts and five-minute six-mean proxy; not statutory compliance certification'},
        'positioning':{'C_vs_BC':'H10 S8 detrendedSD <= BC in >=10/12 cells, no variable worse in >=2 models',
            'B_vs_BC':'H10 >=2/3 variables S8<=BC; any remaining positive difference CI includes zero',
            'C_vs_C0':'each of three H10 detrendedSDs: equal-weight mean over four evaluators is strictly lower for S8',
            'decision':'controller framing only if all three; otherwise framework representative; no controller reselection',
            'safety':'high temperature and long low oxygen reported regardless of positioning'},
        'residual_fidelity':{'draw_seed':20261108,'draw_rule':'SeedSequence([20261108,model_index,original_start_index,replicate]); five uniform eligible blocks with replacement',
            'allowed_blocks':'10 consecutive one-minute rows, all on one calendar date, all in approved training residual pool',
            'no_rescaling_or_recentering':True,
            'sd_check':'per-channel sampled marginal SD compared with eligible-block-population SD using 2000 Monte Carlo block samples of the same number of blocks; simultaneous Bonferroni 99% envelope across 36 model/channel checks',
            'sd_check_action':'report pass/fail; never redraw or rescale; distinguish eligible-block pool from all fit-row residual SD'},
        'dependencies':dependencies}
    DESIGN.mkdir(parents=True,exist_ok=True);OUT.mkdir(parents=True,exist_ok=True)
    write_json(DESIGN/'config.json',config)
    write_json(DESIGN/'seal.json',{'config_sha256':file_sha256(DESIGN/'config.json'),'dependencies':dependencies})
    for p in set(files):
        if p.suffix=='.py':
            dest=OUT/'code_snapshot'/p.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
    for name in ('config.json','seal.json'):shutil.copy2(DESIGN/name,OUT/name)
    print('SEALED',file_sha256(DESIGN/'config.json'),flush=True)
    return config


def verify():
    binding=json.loads((DESIGN/'seal.json').read_text())
    if file_sha256(DESIGN/'config.json')!=binding['config_sha256']:raise AssertionError('S8 config changed')
    for name,digest in binding['dependencies'].items():
        if file_sha256(ROOT/name)!=digest:raise AssertionError('bound dependency changed: '+name)
    load_frozen_mpc()
    return json.loads((DESIGN/'config.json').read_text())


def rollout(layer,mid,method,seed=0,rep=0,zero=False):
    path=OUT/f'trajectories/{layer}/{mid}/{method}/seed{seed}_rep{rep}.npz'
    if path.exists():
        if file_sha256(path)!=json.loads(path.with_suffix('.json').read_text())['sha256']:raise AssertionError('saved result changed')
        return path
    cfg=json.loads((DESIGN/'config.json').read_text())
    stats,execution,context,full=shared();parent=load_frozen_mpc()
    inputs={k:v for k,v in read_npz(REF/'inputs/val.npz').items() if k in ('u_hist','z_hist','z_current','time_ns','indices')}
    planner=StabilityCEM(full,execution,8 if method=='S8' else 0,parent) if method in ('C0','S8') else None
    policy=DecisionPolicy(method,seed,full,execution,context) if planner is None else None
    residual=None
    if layer=='B':model=GRUFeedback()
    else:
        model=RidgeDynamics.load(REF/f'evaluation_models/{mid}.npz')
        if zero:residual=np.zeros((256,50,9))
        elif layer=='C':
            noise=read_npz(OUT/f'residuals/{mid}_sequences.npz')
            np.testing.assert_array_equal(noise['start_indices'],inputs['indices'])
            residual=noise['residual'][:,rep]
        if residual is not None:model=ResidualFeedback(model,residual)
    env=RidgePolicyEnv(model,execution,context if method=='bc' else None,horizon=50)
    state,_=env.reset(options={'inputs':inputs});buf={};begin=time.perf_counter()
    for step in range(50):
        if planner is None:request,diag=policy.decide(env,state,step)
        else:request,diag=planner.plan(env.u,env.z,env.current,env.times,env.indices,step)
        state,reward,done,cut,info=env.step_request(request)
        if done.any() or cut.all()!=(step==49):raise AssertionError('termination semantics')
        info.update(diag)
        if residual is not None:info['injected_residual']=residual[:,step]
        for k,v in info.items():buf.setdefault(k,[]).append(v)
        if planner is not None and (step+1)%10==0:
            print(layer,mid,method,'rep',rep,'step',step+1,'seconds',round(time.perf_counter()-begin,1),flush=True)
    arrays={k:np.stack(v,axis=1) for k,v in buf.items()}
    arrays.update(indices=inputs['indices'],time_ns=inputs['time_ns'],initial_u=inputs['u_hist'][:,-1],initial_z_current=inputs['z_current'])
    for k,v in arrays.items():
        if np.issubdtype(v.dtype,np.number) and not np.isfinite(v).all():raise FloatingPointError(k)
    path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix('.partial.npz');np.savez_compressed(tmp,**arrays);tmp.replace(path)
    write_json(path.with_suffix('.json'),{'layer':layer,'model':mid,'method':method,'seed':seed,'replicate':rep,
        'split':'val','episodes':256,'horizon':50,'elapsed_seconds':time.perf_counter()-begin,
        'config_sha256':file_sha256(DESIGN/'config.json'),'sha256':file_sha256(path)})
    print('COMPLETE',layer,mid,method,seed,rep,flush=True)
    return path


def interface_checks():
    verify()
    with np.load(DATA/'dataset.npz') as a:
        ix=a['val_idx'];u=a['u_hist'][ix];z=a['z_hist'][ix];y=a['z_target'][ix]
    old=read_npz(NUMERIC/'predictions/gru_seed_23/val.npz')
    np.testing.assert_array_equal(ix,old['indices'])
    model=GRUFeedback();pred=np.concatenate([model.predict_next(u[i:i+512],z[i:i+512]) for i in range(0,len(u),512)])
    max_error=float(np.max(np.abs(pred-old['pred'])))
    scale=np.asarray(json.loads((DATA/'stats.json').read_text())['delta_scale'])
    nmse=float(np.mean(((pred-y)/scale)**2));old_nmse=float(np.mean(((old['pred'].astype(float)-y)/scale)**2))
    if max_error>2e-4 or abs(nmse-old_nmse)>1e-6:raise AssertionError('GRU single-step compatibility')
    cfg=json.loads((DESIGN/'config.json').read_text())
    if abs(nmse-cfg['evaluation']['gru_selection']['val_normalized_mse'])>1e-6:raise AssertionError('validation NMSE')
    write_json(OUT/'gru_interface_acceptance.json',{'status':'passed','rows':len(ix),'partition':'val','seed':23,
        'NMSE':nmse,'archived_NMSE':old_nmse,'prediction_max_absolute_difference':max_error,
        'tolerances':{'prediction_absolute':2e-4,'NMSE_absolute':1e-6},
        'bitwise_predictions_equal':bool(np.array_equal(pred,old['pred']))})
    print('GRU INTERFACE PASSED',nmse,max_error,flush=True)


def reproduction():
    verify();checks=[]
    for method in ('S8','C0','hold','bc'):
        seed=11 if method=='bc' else 0
        p=rollout('acceptance','early',method,seed,zero=True)
        old=(OLD/'trajectories/S8/early.npz' if method=='S8' else
             ROOT/'experiment_runs/mpc_temperature_20261107/trajectories/C/early.npz' if method=='C0' else
             POLICY/f'trajectories/val/early/{method}/seed{seed}.npz')
        a,b=read_npz(p),read_npz(old);keys=sorted(set(a)&set(b))
        for k in keys:np.testing.assert_array_equal(a[k],b[k],err_msg=method+':'+k)
        checks.append({'method':method,'seed':seed,'model':'early','episodes':256,'horizon':50,
            'bitwise_equal_fields':keys,'source_sha256':file_sha256(old),'result_sha256':file_sha256(p)})
        print('BITWISE REPRODUCTION PASSED',method,len(keys),flush=True)
    write_json(OUT/'reproduction_acceptance.json',{'status':'passed','zero_residual_feedback':True,'checks':checks})


def run(layer,shard,shards):
    verify()
    for name in ('reproduction_acceptance.json','gru_interface_acceptance.json'):
        if json.loads((OUT/name).read_text())['status']!='passed':raise AssertionError('acceptance required')
    if layer=='B':jobs=[('gru23',m,s,0) for m,s in METHODS]
    else:
        addendum=json.loads((DESIGN/'C_addendum.json').read_text())
        if file_sha256(DESIGN/'C_addendum.json')!=(DESIGN/'C_addendum.sha256').read_text().strip():raise AssertionError('C addendum changed')
        for mid in MODELS:
            p=OUT/f'residuals/{mid}_sequences.npz'
            if file_sha256(p)!=json.loads(p.with_suffix('.json').read_text())['sha256']:raise AssertionError('noise changed')
        jobs=[(mid,m,s,r) for mid in MODELS for r in range(5) for m,s in METHODS]
    for mid,m,s,r in jobs[shard::shards]:rollout(layer,mid,m,s,r)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('stage',choices=('seal','interface','reproduce','B','C'))
    ap.add_argument('--shard',type=int,default=0);ap.add_argument('--shards',type=int,default=1);args=ap.parse_args()
    torch.set_num_threads(2)
    with threadpool_limits(2):
        if args.stage=='seal':seal()
        elif args.stage=='interface':interface_checks()
        elif args.stage=='reproduce':reproduction()
        else:run(args.stage,args.shard,args.shards)

if __name__=='__main__':main()
