"""Temperature-objective CEM study over the frozen execution/physics owner.

The prior CEM implementation is an immutable experiment dependency. This module
owns the new candidate ranking, hard-temperature eligibility and CRN evidence;
the inherited score method still owns ALL candidate dynamics/support execution.
"""
from __future__ import annotations
import hashlib
import numpy as np
from .control import reward_and_violation
from .ridge_policy_planning import CEMPlanner


def rank_candidates(scores,feasible,elite_count=16):
    scores=np.asarray(scores,dtype=float);feasible=np.asarray(feasible,dtype=bool)
    if scores.shape!=feasible.shape or scores.ndim!=2 or not np.isfinite(scores).all():
        raise ValueError('finite aligned candidate scores and eligibility required')
    counts=feasible.sum(1)
    if np.any(counts==0):raise AssertionError('hold must provide a feasible candidate')
    order=np.argsort(-np.where(feasible,scores,-np.inf),axis=1,kind='stable')
    elite=np.empty((len(scores),elite_count),dtype=order.dtype)
    enough=counts>=elite_count
    if np.any(enough):elite[enough]=order[enough,:elite_count]
    for row in np.flatnonzero(counts<elite_count):
        elite[row]=np.resize(order[row,:counts[row]],elite_count)
    return order[:,0],elite,counts


class TemperatureCEM(CEMPlanner):
    def __init__(self,model,execution,temperature_weight=1,temperature_constraint=False):
        super().__init__(model,execution)
        if temperature_weight not in (1,2,4,8):raise ValueError('unregistered temperature weight')
        if temperature_constraint and temperature_weight!=1:raise ValueError('E keeps original cost')
        self.weight=temperature_weight;self.constraint=bool(temperature_constraint)

    def candidate_metrics(self,plans,u,z,current,times):
        original,trace=super().score(plans,u,z,current,times,return_trace=True)
        rewards,_,components=reward_and_violation(trace['prediction'],trace['executed'],self.execution.stats)
        if not np.array_equal(rewards,trace['reward']):raise AssertionError('canonical candidate reward changed')
        jt=components['tracking_cost'][...,0].astype(float).sum(axis=2)
        score=original-(self.weight-1)*jt
        feasible=(jt<=jt[:,:1]) if self.constraint else np.ones_like(jt,dtype=bool)
        if not feasible[:,0].all():raise AssertionError('zero plan is infeasible')
        return score,original,jt,feasible

    def plan(self,u,z,current,times,indices,decision_step):
        n=len(u)
        warm=np.zeros((n,10,2)) if self.warm is None else np.concatenate((self.warm[:,1:],np.zeros((n,1,2))),axis=1)
        mean=warm.copy();std=np.full_like(mean,.35);incumbent=np.zeros_like(mean)
        best_score=np.full(n,-np.inf);best=np.zeros_like(mean)
        best_original=np.zeros(n);best_jt=np.zeros(n);feasible_counts=[];iteration_scores=[]
        # Configuration and evaluator identity intentionally never enter RNG.
        rngs=[np.random.default_rng(np.random.SeedSequence([2026,int(i),int(decision_step)])) for i in indices]
        hashes=[hashlib.sha256() for _ in indices]
        for iteration in range(4):
            noise=np.stack([rng.normal(size=(117,10,2)) for rng in rngs])
            for h,values in zip(hashes,noise):h.update(values.tobytes(order='C'))
            random=np.clip(mean[:,None]+std[:,None]*noise,-1,1)
            plans=np.concatenate((np.broadcast_to(self.fixed,(n,9,10,2)),warm[:,None],incumbent[:,None],random),axis=1)
            score,original,jt,feasible=self.candidate_metrics(plans,u,z,current,times)
            winner,elite_indices,counts=rank_candidates(score,feasible)
            incumbent=plans[np.arange(n),winner].copy();iteration_score=score[np.arange(n),winner]
            better=iteration_score>best_score
            best[better]=incumbent[better];best_score[better]=iteration_score[better]
            best_original[better]=original[np.arange(n),winner][better];best_jt[better]=jt[np.arange(n),winner][better]
            zero_tie=score[:,0]==best_score;best[zero_tie]=0
            best_original[zero_tie]=original[zero_tie,0];best_jt[zero_tie]=jt[zero_tie,0]
            elite=plans[np.arange(n)[:,None],elite_indices]
            mean=elite.mean(1);std=np.maximum(elite.std(1,ddof=0),.05)
            feasible_counts.append(counts);iteration_scores.append(iteration_score)
        hold_jt=jt[:,0]
        if self.constraint and np.any(best_jt>hold_jt):raise AssertionError('E selected a temperature-violating plan')
        self.warm=best.copy()
        return self.execution.request(best[:,0]),{
            'best_requested_plan_b':best,'selected_planning_score':best_score,'selected_original_return':best_original,
            'selected_temperature_cost':best_jt,'hold_temperature_cost':hold_jt,'planned_temperature_margin':hold_jt-best_jt,
            'iteration_best_score':np.stack(iteration_scores,axis=1),'feasible_candidate_counts':np.stack(feasible_counts,axis=1),
            'noise_sha256':np.asarray([h.hexdigest() for h in hashes],dtype='S64')}


def acceptance_tier(reference,candidate,relative_margin):
    """Per-model means: original return gain>0; five losses bounded separately."""
    reference=np.asarray(reference,dtype=float);candidate=np.asarray(candidate,dtype=float)
    if reference.shape!=(4,6) or candidate.shape!=reference.shape or not np.isfinite(reference).all() or not np.isfinite(candidate).all():
        raise ValueError('four non-planner model means and six endpoints required')
    if relative_margin not in (0,.01):raise ValueError('only registered0 and1% tiers')
    if np.any(reference[:,1:]<0):raise ValueError('guardrail costs must be nonnegative')
    margin=relative_margin*reference[:,1:]
    gain=candidate[:,0]-reference[:,0];degradation=candidate[:,1:]-reference[:,1:]
    limit=reference[:,1:] if relative_margin==0 else 1.01*reference[:,1:]
    guards=candidate[:,1:]<=limit
    return {'pass':bool(np.all(gain>0)&np.all(guards)),'cost_gain':gain.tolist(),
            'worst_cost_gain':float(gain.min()),'guard_degradation':degradation.tolist(),
            'allowed_degradation':margin.tolist(),'guard_limit':limit.tolist(),'guard_pass':guards.tolist(),'cost_pass':(gain>0).tolist()}


def select_configuration(reference,candidates):
    assessed={}
    for name in ('A','B','C','D','E'):
        strict=acceptance_tier(reference,candidates[name],0);secondary=acceptance_tier(reference,candidates[name],.01)
        tier='strict_pass' if strict['pass'] else 'relative_1pct_pass' if secondary['pass'] else 'not_passed'
        assessed[name]={'tier':tier,'strict':strict,'secondary':secondary}
    selected=None;selected_tier=None
    for tier in ('strict_pass','relative_1pct_pass'):
        eligible=[k for k,v in assessed.items() if v['tier']==tier]
        if eligible:
            selected=max(eligible,key=lambda k:assessed[k]['strict']['worst_cost_gain']);selected_tier=tier;break
    return {'selected':selected,'selected_tier':selected_tier,'configurations':assessed}
