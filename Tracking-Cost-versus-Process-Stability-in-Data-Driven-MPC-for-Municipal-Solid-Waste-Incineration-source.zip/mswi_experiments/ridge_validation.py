"""Frozen Ridge recursive validation and objectively selected operation changes.

The recorded-MV branch conditions on the actual future input sequence. It is
not an online forecast or an identified intervention. Only initial CV history
is observed in recursive branches; teacher forcing is a separately labelled
single-step diagnostic. No model is trained or selected here.
"""
from __future__ import annotations

import argparse
import csv
import importlib.metadata
import json
from pathlib import Path
import platform
import sys
import time

import numpy as np
from threadpoolctl import threadpool_limits

from .data import MINUTE_NS, control_values, load_data
from .numeric_baselines import sha256, write_json
from .ridge_dynamics import (RidgeDynamics, continuous_chains,
                             persistence_rollout, recursive_rollout)


BRANCHES = {
    'ridge_logged': 'Recursive CV feedback conditional on the recorded MV path; future actual operations are known inputs.',
    'ridge_hold_mv': 'Recursive CV feedback with MV held at initial u_t from step 2; a fixed-input scenario, not cancellation of the initial operation or causal counterfactual truth.',
    'persistence': 'All CV forecasts equal initial z_prev; stored MV path is ignored by this reference.',
    'ridge_teacher_forced': 'Each step uses its actual recorded CV/MV history; repeated one-step diagnostic, not recursive multi-step forecasting.',
}


def current_operation_changes(data):
    u = np.asarray(data['u_hist'], dtype=np.float64)
    if u.ndim != 3 or u.shape[1:] != (11, 8) or not np.isfinite(u).all():
        raise ValueError('operation changes require finite (N,11,8) MV histories')
    return u[:, -1] - u[:, -2]


def training_event_thresholds(data, stats, *, quantile=.9, tolerance=1e-6,
                              direction_floor=1e-6):
    if not 0 < quantile <= 1 or tolerance <= 0 or direction_floor <= 0:
        raise ValueError('invalid event quantile or tolerance')
    idx = np.asarray(data['train_idx'], dtype=np.int64)
    delta = current_operation_changes(data)[idx]
    magnitudes = np.abs(delta)
    thresholds, counts = [], []
    for channel in range(8):
        active = magnitudes[:, channel][magnitudes[:, channel] > tolerance]
        counts.append(len(active))
        thresholds.append(float(np.quantile(active, quantile)) if len(active) else None)
    physical_change = control_values(np.asarray(data['z_target'], dtype=np.float64)[idx]) - control_values(np.asarray(data['z_prev'], dtype=np.float64)[idx])
    if not np.isfinite(physical_change).all():
        raise ValueError('nonfinite training physical change')
    medians = np.median(np.abs(physical_change), axis=0)
    deadband = np.maximum(medians, direction_floor)
    return {
        'training_samples': len(idx), 'quantile': float(quantile),
        'nonzero_tolerance': float(tolerance), 'trigger_rule': 'abs(delta)>tolerance and abs(delta)>=training nonzero quantile',
        'operation_delta': 'u_hist[t,-1]-u_hist[t,-2]; not next-minute data.action',
        'mv_names': stats['mv_names'], 'mv_thresholds': thresholds,
        'mv_nonzero_training_counts': counts,
        'physical_names': ['temperature', 'pressure', 'steam', 'oxygen'],
        'direction_training_median_abs_change': medians.tolist(),
        'direction_deadband_floor': float(direction_floor),
        'direction_deadbands': deadband.tolist(),
        'direction_training_nonzero_counts': (np.abs(physical_change) > tolerance).sum(axis=0).tolist(),
        'direction_rule': '-1 below -deadband; +1 above +deadband; 0 otherwise',
    }


def select_operation_events(data, chains, thresholds, *, minimum_separation=10,
                            example_count=4):
    chains = np.asarray(chains, dtype=np.int64)
    if chains.ndim != 2 or not len(chains) or chains.shape[1] < 1:
        raise ValueError('event selection needs complete nonempty chains')
    if minimum_separation < chains.shape[1] or example_count < 0:
        raise ValueError('event windows must not overlap and example count must be nonnegative')
    starts = chains[:, 0]
    times = np.asarray(data['time_ns'], dtype=np.int64)[starts]
    if np.any(np.diff(times) <= 0):
        raise ValueError('event starts must be in chronological order')
    current = current_operation_changes(data)
    delta = current[starts]
    tol = float(thresholds['nonzero_tolerance'])
    trigger = np.zeros(delta.shape, dtype=bool)
    for j, threshold in enumerate(thresholds['mv_thresholds']):
        if threshold is not None:
            trigger[:, j] = (np.abs(delta[:, j]) > tol) & (np.abs(delta[:, j]) >= threshold)
    candidates = np.flatnonzero(trigger.any(axis=1))
    selected, previous = [], None
    for position in candidates:
        stamp = int(times[position])
        if previous is None or stamp - previous >= minimum_separation * MINUTE_NS:
            selected.append(int(position)); previous = stamp
    selected = np.asarray(selected, dtype=np.int64)
    if len(selected) and example_count:
        examples = selected[np.linspace(0, len(selected)-1, min(example_count, len(selected)), dtype=np.int64)]
    else:
        examples = np.empty(0, dtype=np.int64)
    future = np.abs(current[chains[:, 1:]]) > tol
    return {
        'chain_start_indices': starts, 'chain_start_time_ns': times,
        'candidate_positions': candidates, 'candidate_indices': starts[candidates],
        'selected_positions': selected, 'selected_indices': starts[selected],
        'selected_time_ns': times[selected], 'example_positions': examples,
        'example_indices': starts[examples], 'current_delta': delta,
        'trigger_mask': trigger, 'current_nonzero_mask': np.abs(delta) > tol,
        'current_sign': np.where(np.abs(delta) > tol, np.sign(delta), 0).astype(np.int8),
        'current_nonzero_channels': (np.abs(delta) > tol).sum(axis=1),
        'future_change_mask': future,
        'future_change_steps': future.any(axis=2).sum(axis=1),
        'future_change_cells': future.sum(axis=(1, 2)),
        'future_changed_channels': future.any(axis=1).sum(axis=1),
    }


def resolve_predictor(project, predictor_file):
    project = Path(project).resolve()
    path = (project / predictor_file).resolve()
    selected = json.loads(path.read_text())
    if selected.get('kind') != 'ridge' or selected.get('model_id') != 'ridge':
        raise ValueError('current predictor must identify the direct Ridge model')
    study = (project / selected['selected_study']).resolve()
    selection_path = study / 'selection.json'
    frozen_path = study / 'selection_frozen.json'
    frozen = json.loads(frozen_path.read_text())
    if frozen.get('status') != 'complete' or sha256(selection_path) != frozen['files']['selection.json']:
        raise ValueError('source model selection is not frozen or has changed')
    if selected['selection_sha256'] != sha256(selection_path):
        raise ValueError('current predictor selection identity changed')
    source_selection = json.loads(selection_path.read_text())
    if source_selection.get('status') != 'complete':
        raise ValueError('source model selection is incomplete')
    rows = [r for r in source_selection['models'] if r['id'] == 'ridge']
    if len(rows) != 1 or rows[0]['method'] != 'ridge' or rows[0]['base_model_path'] is not None:
        raise ValueError('source selection does not identify one direct Ridge')
    row = rows[0]
    checkpoint = (project / selected['checkpoint']).resolve()
    if checkpoint != (study / row['model_path']).resolve():
        raise ValueError('current predictor checkpoint is not the selected direct Ridge path')
    digest = sha256(checkpoint)
    if digest != selected['checkpoint_sha256'] or digest != frozen['files'][row['model_path']]:
        raise ValueError('current predictor checkpoint hash differs from frozen selection')
    model = RidgeDynamics.load(checkpoint)
    if float(model.weights['alpha']) != row['selected_alpha']:
        raise ValueError('saved alpha differs from selected Ridge alpha')
    return selected, checkpoint, study, model


def _paths(config_file):
    path = Path(config_file).resolve()
    cfg = json.loads(path.read_text())
    return cfg, path.parent, path.parent / cfg['source_run'], path.parent / cfg['output_dir']


def _validate_config(cfg):
    if cfg['horizon'] != 10 or cfg['endpoints'] != [1, 5, 10]:
        raise ValueError('this frozen study requires horizon10 and endpoints1/5/10')
    if cfg['event_minimum_separation_minutes'] < cfg['horizon'] or cfg['threads'] < 1:
        raise ValueError('invalid event separation or thread count')


def _event_csv(path, arrays, mv_names):
    fields = ['chain_position', 'sample_index', 'time_ns', 'trigger_channels',
              'current_nonzero_channels', 'future_change_steps', 'future_change_cells',
              'future_changed_channels'] + [f'delta_{name}' for name in mv_names]
    with Path(path).open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields); writer.writeheader()
        for p in arrays['selected_positions']:
            row = {'chain_position': int(p), 'sample_index': int(arrays['chain_start_indices'][p]),
                   'time_ns': int(arrays['chain_start_time_ns'][p]),
                   'trigger_channels': '|'.join(mv_names[j] for j in np.flatnonzero(arrays['trigger_mask'][p]))}
            for name in ('current_nonzero_channels', 'future_change_steps', 'future_change_cells', 'future_changed_channels'):
                row[name] = int(arrays[name][p])
            row.update({f'delta_{name}': float(arrays['current_delta'][p, j]) for j, name in enumerate(mv_names)})
            writer.writerow(row)


def prepare(config_file):
    cfg, project, source, out = _paths(config_file)
    _validate_config(cfg)
    out.mkdir(parents=True, exist_ok=True)
    if (out/'prepare_frozen.json').exists():
        _load_prepared(config_file)
        return out
    if (out/'config.json').exists():
        raise ValueError('incomplete existing preparation; preserve it and use a new output directory')
    selected, checkpoint, study, model = resolve_predictor(project, cfg['current_predictor'])
    data, stats, source_manifest = load_data(source/'data')
    if not np.array_equal(np.asarray(stats['delta_scale']), model.weights['delta_scale']):
        raise ValueError('dynamics target scales differ from the prepared training statistics')
    if json.loads((study/'stats.json').read_text()) != stats:
        raise ValueError('source model and current data statistics differ')
    thresholds = training_event_thresholds(data, stats, quantile=cfg['event_quantile'],
        tolerance=cfg['event_nonzero_tolerance'], direction_floor=cfg['direction_deadband_floor'])
    chains = {s: continuous_chains(data, s, cfg['horizon']) for s in ('train', 'val', 'test')}
    if any(len(c) == 0 for c in chains.values()):
        raise ValueError('a partition has no complete common forecast chains')
    np.savez_compressed(out/'chains.npz', **{s+'_chains': c for s, c in chains.items()})
    (out/'events').mkdir(exist_ok=True)
    event_summary = {}
    for split, chain in chains.items():
        events = select_operation_events(data, chain, thresholds,
            minimum_separation=cfg['event_minimum_separation_minutes'], example_count=cfg['example_count'])
        np.savez_compressed(out/f'events/{split}.npz', **events)
        _event_csv(out/f'events/{split}.csv', events, stats['mv_names'])
        event_summary[split] = {'chains': len(chain), 'candidate_count': len(events['candidate_positions']),
            'selected_count': len(events['selected_positions']), 'example_indices': events['example_indices'].tolist(),
            'selected_trigger_counts_per_mv': events['trigger_mask'][events['selected_positions']].sum(axis=0).tolist(),
            'selected_with_further_mv_changes': int(np.sum(events['future_change_steps'][events['selected_positions']] > 0))}
    input_paths = [source/'data'/name for name in ('dataset.npz', 'stats.json', 'manifest.json')]
    input_paths += [project/cfg['current_predictor'], checkpoint, study/'selection.json', study/'selection_frozen.json', study/'stats.json', study/'predictions_manifest.json']
    prior_manifest = json.loads((study/'predictions_manifest.json').read_text())
    if prior_manifest.get('status') != 'complete' or prior_manifest['selection_sha256'] != sha256(study/'selection.json'):
        raise ValueError('prior Ridge prediction manifest does not reference the completed selection')
    for split in chains:
        p = study/f'predictions/ridge/{split}.npz'
        row = [r for r in prior_manifest['files'] if r['model_id'] == 'ridge' and r['split'] == split]
        if len(row) != 1 or row[0]['sha256'] != sha256(p):
            raise ValueError('prior Ridge prediction archive identity differs from manifest')
        input_paths.append(p)
    hashes = {str(p.resolve()): sha256(p) for p in input_paths}
    protocol = {
        'schema_version': 1, 'model': 'frozen direct numerical Ridge, alpha selected in the preceding single-step study',
        'current_predictor': selected, 'branches': BRANCHES, 'horizon': cfg['horizon'], 'endpoints': cfg['endpoints'],
        'forecast_alignment': 'first target z_t; step h target z_(t+h-1); initial CV history ends t-1 and first known MV is u_t',
        'recursive_cv_sources': 'initial recorded CV history only, then each predicted CV is appended; no future observed CV input',
        'chain_selection': 'all complete 10-step chains in each preserved partition; identical starts at all endpoints; no target/error-based selection',
        'primary_endpoint': 'step10 nine-channel squared error divided by canonical training delta_scale squared, averaged over channels and starts',
        'secondary': 'endpoints1/5; all step1..10 curves; four physical MAE/RMSE; operation-change segments and direction agreement',
        'direction_definition': 'physical prediction and observed change relative to initial z_prev; ternary training-derived deadbands',
        'event_selection': 'any current MV jump >= its training nonzero90th percentile and >tolerance; chronological first eligible candidate then >=10-minute separation',
        'event_scope': 'observed mixed-operation segments, not isolated step interventions; future operation changes are retained and counted',
        'examples': 'up to four selected test events at equally spaced positions in chronological order, independent of predictions and outcomes',
        'overlap': 'rolling forecast starts overlap; paired uncertainty must resample whole start-date blocks; event target windows do not overlap',
        'limits': 'Previously inspected historical evaluation period; no causal effect, physical response lag, online forecasting or closed-loop control claim. No GRU/BC/RL checkpoint is treated as compatible with Ridge.',
        'nonfinite_policy': 'no clipping and no dropped trajectories; nonfinite forecast raises and writes run_failure.json',
        'source_manifest': source_manifest,
    }
    write_json(out/'config.json', cfg); write_json(out/'current_predictor.json', selected)
    write_json(out/'stats.json', stats); write_json(out/'input_hashes.json', hashes)
    write_json(out/'event_thresholds.json', thresholds); write_json(out/'event_summary.json', event_summary)
    write_json(out/'protocol.json', protocol)
    write_json(out/'environment.json', {'python': sys.version, 'platform': platform.platform(),
        'packages': {name: importlib.metadata.version(name) for name in ('numpy', 'scipy', 'scikit-learn', 'threadpoolctl')},
        'threads': cfg['threads'], 'inference_dtype': 'float64', 'model_fit_in_this_study': False})
    frozen_names = ['config.json', 'current_predictor.json', 'stats.json', 'input_hashes.json', 'event_thresholds.json', 'event_summary.json', 'protocol.json', 'chains.npz']
    frozen_names += [f'events/{split}.{ext}' for split in chains for ext in ('npz', 'csv')]
    write_json(out/'prepare_frozen.json', {'status': 'complete', 'files': {n: sha256(out/n) for n in frozen_names}})
    return out


def _load_prepared(config_file):
    cfg, project, source, out = _paths(config_file)
    if not (out/'prepare_frozen.json').exists() or json.loads((out/'config.json').read_text()) != cfg:
        raise ValueError('prepare this exact configuration before running')
    frozen = json.loads((out/'prepare_frozen.json').read_text())
    if frozen['status'] != 'complete':
        raise ValueError('preparation is incomplete')
    for name, digest in frozen['files'].items():
        if sha256(out/name) != digest:
            raise ValueError(f'frozen prepared artifact changed: {name}')
    for name, digest in json.loads((out/'input_hashes.json').read_text()).items():
        if sha256(name) != digest:
            raise ValueError(f'frozen input changed: {name}')
    _, checkpoint, study, model = resolve_predictor(project, cfg['current_predictor'])
    data, stats, _ = load_data(source/'data')
    return cfg, out, study, model, data, stats


def _prediction_comparison(actual, reference, label, tolerance=1e-10):
    actual, reference = np.asarray(actual), np.asarray(reference)
    if actual.shape != reference.shape or not np.isfinite(actual).all() or not np.isfinite(reference).all():
        raise ValueError(f'invalid prediction comparison: {label}')
    error = float(np.max(np.abs(actual-reference)))
    if error > tolerance:
        raise AssertionError(f'{label} differs from saved prediction by {error}')
    return {'label': label, 'shape': list(actual.shape), 'exact_equal': bool(np.array_equal(actual, reference)),
            'max_absolute_difference': error, 'absolute_tolerance': tolerance}


def run(config_file):
    cfg, out, study, model, data, stats = _load_prepared(config_file)
    if (out/'rollouts').exists() or (out/'run_manifest.json').exists():
        raise ValueError('run outputs already exist; preserve the record and use a new output directory')
    (out/'rollouts').mkdir()
    started = time.monotonic(); records, replays = [], []
    try:
        with np.load(out/'chains.npz', allow_pickle=False) as f:
            chains = {split: f[split+'_chains'] for split in ('train', 'val', 'test')}
        with threadpool_limits(limits=cfg['threads']):
            for split, chain in chains.items():
                indices = np.asarray(data[split+'_idx'], dtype=np.int64)
                one = model.predict_next(data['u_hist'][indices], data['z_hist'][indices])
                with np.load(study/f'predictions/ridge/{split}.npz', allow_pickle=False) as prior:
                    if not np.array_equal(prior['indices'], indices) or not np.array_equal(prior['y'], data['z_target'][indices]):
                        raise ValueError('prior Ridge prediction observations are not aligned')
                    replays.append(_prediction_comparison(one, prior['pred'], split+'_full_single_step_replay'))
                lookup = np.full(len(data['time_ns']), -1, dtype=np.int64); lookup[indices] = np.arange(len(indices))
                if (lookup[chain] < 0).any():
                    raise AssertionError('forecast chain escaped partition')
                teacher = one[lookup[chain]]
                starts = chain[:, 0]
                u, z = data['u_hist'][starts], data['z_hist'][starts]
                path = np.asarray(data['u_hist'], dtype=np.float64)[chain, -1]
                held = np.repeat(np.asarray(u[:, -1], dtype=np.float64)[:, None], cfg['horizon'], axis=1)
                truth = np.asarray(data['z_target'], dtype=np.float64)[chain]
                for branch in BRANCHES:
                    mv_path = held if branch == 'ridge_hold_mv' else path
                    if branch in ('ridge_logged', 'ridge_hold_mv'):
                        pred = recursive_rollout(model, u, z, mv_path)
                    elif branch == 'persistence':
                        pred = persistence_rollout(z, cfg['horizon'])
                    else:
                        pred = teacher.copy()
                    if pred.shape != truth.shape or not np.isfinite(pred).all():
                        raise FloatingPointError(f'invalid {split}/{branch} rollout')
                    if branch in ('ridge_logged', 'ridge_hold_mv', 'ridge_teacher_forced'):
                        replays.append(_prediction_comparison(pred[:, 0], teacher[:, 0], split+'_'+branch+'_first_step'))
                    folder = out/'rollouts'/split; folder.mkdir(exist_ok=True)
                    destination = folder/f'{branch}.npz'
                    np.savez_compressed(destination, indices=chain,
                        start_time_ns=np.asarray(data['time_ns'])[starts], time_ns=np.asarray(data['time_ns'])[chain],
                        truth_cv=truth, pred_cv=pred, initial_zprev=np.asarray(z[:, -1], dtype=np.float64), mv_path=mv_path)
                    records.append({'split': split, 'branch': branch, 'path': str(destination.relative_to(out)),
                                    'sha256': sha256(destination), 'starts': len(chain), 'horizon': cfg['horizon'],
                                    'shape': list(pred.shape), 'interpretation': BRANCHES[branch]})
                    print(f'{split}/{branch}: {len(chain)} starts x {cfg["horizon"]} steps saved', flush=True)
        write_json(out/'single_step_replay.json', {'status': 'passed', 'comparisons': replays,
            'note': 'Full-partition inference is compared to saved one-step predictions; submatrix BLAS can differ at floating-point roundoff, recorded explicitly.'})
        manifest = {'status': 'complete', 'model_kind': 'ridge', 'model_checkpoint': str(model.source_path),
            'model_sha256': sha256(model.source_path), 'files': records, 'elapsed_seconds': time.monotonic()-started,
            'prepare_frozen_sha256': sha256(out/'prepare_frozen.json'), 'trajectories_dropped': 0,
            'predictions_clipped': False, 'model_retrained': False}
        write_json(out/'run_manifest.json', manifest)
        return manifest
    except Exception as error:
        write_json(out/'run_failure.json', {'status': 'failed', 'error_type': type(error).__name__,
            'message': str(error), 'completed_output_files': records, 'elapsed_seconds': time.monotonic()-started,
            'trajectories_dropped': 0, 'fallback_used': False})
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', required=True)
    parser.add_argument('--stage', choices=('prepare', 'run'), required=True)
    args = parser.parse_args()
    result = prepare(args.config) if args.stage == 'prepare' else run(args.config)
    print(f'{args.stage} completed: {result if isinstance(result, Path) else len(result["files"])}', flush=True)


if __name__ == '__main__':
    main()
