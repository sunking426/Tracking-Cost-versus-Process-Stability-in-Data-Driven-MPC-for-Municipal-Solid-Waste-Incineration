"""Frozen representation probes and leakage-free prediction diagnostics.

All target quantities are physical units. Observed historical images are used for
the one-step/probe tests; recursive forecasts use training-only visual memory at
every step and feed predicted CV values back into the recurrent history.
"""
from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
import torch

from .data import MINUTE_NS, control_values
from .retrieval import VisualMemory, encoder_fingerprint
from .training import predict_twin


CONTROL_NAMES = ("temperature", "pressure", "steam", "oxygen")
HORIZONS = (1, 5, 10, 20)


def _write_json(path: Path, value) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def _metrics(truth: np.ndarray, prediction: np.ndarray) -> dict:
    truth = np.asarray(truth, dtype=np.float64)
    prediction = np.asarray(prediction, dtype=np.float64)
    if truth.shape != prediction.shape or truth.ndim != 2 or len(truth) == 0:
        raise ValueError("metric inputs must be matching nonempty (sample, channel) arrays")
    error = prediction - truth
    if not np.isfinite(error).all():
        raise FloatingPointError("nonfinite prediction error")
    return {"mae": np.abs(error).mean(axis=0).tolist(),
            "rmse": np.sqrt(np.square(error).mean(axis=0)).tolist()}


def _device(twin) -> torch.device:
    parameter = next(twin.parameters(), None)
    if parameter is not None:
        return parameter.device
    buffer = next(twin.buffers(), None)
    return torch.device("cpu") if buffer is None else buffer.device


def _validate_splits(data: dict) -> dict[str, np.ndarray]:
    n = len(data["time_ns"])
    splits = {}
    seen = set()
    for name in ("train", "val", "test"):
        idx = np.asarray(data[name + "_idx"], dtype=np.int64)
        if idx.ndim != 1 or len(idx) == 0 or idx.min() < 0 or idx.max() >= n:
            raise ValueError(f"invalid or empty {name} indices")
        members = set(idx.tolist())
        if len(members) != len(idx) or seen.intersection(members):
            raise ValueError("prediction analysis requires unique, disjoint partitions")
        seen.update(members)
        splits[name] = idx
    if np.asarray(data["z_target"]).shape != (n, 9):
        raise ValueError("prediction analysis requires nine physical CV channels")
    return splits


@torch.no_grad()
def _encode_latents(twin, data: dict, indices: np.ndarray, batch_size: int = 512) -> np.ndarray:
    """Return only the frozen encoder output; never append observed current CV."""
    if batch_size <= 0:
        raise ValueError("encoder batch size must be positive")
    twin.eval()
    device = _device(twin)
    outputs = []
    for begin in range(0, len(indices), batch_size):
        idx = indices[begin:begin + batch_size]
        u, z, v = (torch.as_tensor(np.asarray(data[name])[idx], dtype=torch.float32, device=device)
                   for name in ("u_hist", "z_hist", "visual"))
        latent = twin.encode(u, z, v).detach().cpu().numpy()
        if latent.ndim != 2 or len(latent) != len(idx) or not np.isfinite(latent).all():
            raise ValueError("encoder produced an invalid latent matrix")
        outputs.append(latent)
    return np.concatenate(outputs, axis=0)


def _fit_linear_probe(train_x, val_x, test_x, train_y, val_y, test_y):
    """Select regularization on validation normalized MSE, then score test once.

    Both input and target scaling are fitted on training observations only.
    Training targets are absolute next-step mean temperature and pressure.
    The selected Ridge remains fitted on training rows, without a test refit.
    """
    from sklearn.linear_model import Ridge
    from sklearn.preprocessing import StandardScaler

    x_scaler = StandardScaler().fit(train_x)
    y_scaler = StandardScaler().fit(train_y)
    x_train, x_val, x_test = (x_scaler.transform(x) for x in (train_x, val_x, test_x))
    y_train, y_val = (y_scaler.transform(y) for y in (train_y, val_y))
    candidates = []
    for alpha in (.1, 1., 10.):
        model = Ridge(alpha=alpha, solver="cholesky").fit(x_train, y_train)
        score = float(np.square(model.predict(x_val) - y_val).mean())
        if not np.isfinite(score):
            raise FloatingPointError("nonfinite validation score for representation probe")
        candidates.append((score, alpha, model))
    score, alpha, model = min(candidates, key=lambda item: (item[0], item[1]))
    prediction = y_scaler.inverse_transform(model.predict(x_test))
    metrics = {**_metrics(test_y, prediction), "alpha": alpha}
    fitted = {"x_mean": x_scaler.mean_, "x_scale": x_scaler.scale_,
              "y_mean": y_scaler.mean_, "y_scale": y_scaler.scale_,
              "coef": model.coef_, "intercept": model.intercept_,
              "alphas": np.asarray([row[1] for row in candidates]),
              "val_normalized_mse": np.asarray([row[0] for row in candidates])}
    return metrics, prediction, fitted


def _select_rollout_chains(data: dict, count: int = 50, horizon: int = 20) -> np.ndarray:
    """Uniformly select distinct, nonoverlapping complete test trajectories."""
    if count <= 0 or horizon <= 0:
        raise ValueError("rollout count and horizon must be positive")
    test_idx = np.asarray(data["test_idx"], dtype=np.int64)
    allowed = set(test_idx.tolist())
    times = np.asarray(data["time_ns"], dtype=np.int64)
    next_idx = np.asarray(data["next_idx"], dtype=np.int64)
    used = set()
    candidates = []
    for start in test_idx[np.argsort(times[test_idx], kind="stable")]:
        current = int(start)
        chain = []
        for step in range(horizon):
            if current not in allowed or current in used:
                break
            chain.append(current)
            if step + 1 == horizon:
                break
            following = int(next_idx[current])
            if following not in allowed or times[following] - times[current] != MINUTE_NS:
                break
            current = following
        if len(chain) == horizon:
            candidates.append(chain)
            used.update(chain)
    if len(candidates) < count:
        raise ValueError(f"need {count} complete disjoint {horizon}-step test trajectories; "
                         f"found {len(candidates)}")
    positions = np.linspace(0, len(candidates) - 1, count).round().astype(np.int64)
    return np.asarray(candidates, dtype=np.int64)[positions]


@torch.no_grad()
def _recursive_rollouts(twin, memory, data: dict, chains: np.ndarray) -> dict:
    """Predict with logged future MV; update CV history exclusively with forecasts."""
    chains = np.asarray(chains, dtype=np.int64)
    if chains.ndim != 2 or chains.shape[0] == 0 or chains.shape[1] == 0:
        raise ValueError("rollout chains must be a nonempty (episode, step) matrix")
    device = _device(twin)
    twin.eval()
    first = chains[:, 0]
    u_hist = torch.as_tensor(np.asarray(data["u_hist"])[first], dtype=torch.float32, device=device).clone()
    z_hist = torch.as_tensor(np.asarray(data["z_hist"])[first], dtype=torch.float32, device=device).clone()
    previous = torch.as_tensor(np.asarray(data["z_prev"])[first], dtype=torch.float32, device=device).clone()
    train_idx = np.asarray(data["train_idx"], dtype=np.int64)
    predictions, source_indices = [], []
    for step in range(chains.shape[1]):
        visual, sources = memory.query(u_hist, z_hist)
        sources = np.asarray(sources, dtype=np.int64)
        if sources.shape != (len(first),) or not np.isin(sources, train_idx).all():
            raise ValueError("recursive visual memory returned a non-training source")
        predicted = previous + twin(u_hist, z_hist, visual)
        if predicted.shape != previous.shape or not torch.isfinite(predicted).all():
            raise FloatingPointError(f"invalid recursive CV prediction at step {step + 1}")
        predictions.append(predicted.detach().cpu().numpy())
        source_indices.append(sources)
        if step + 1 < chains.shape[1]:
            next_u = torch.as_tensor(np.asarray(data["u_current"])[chains[:, step + 1]],
                                     dtype=torch.float32, device=device)
            u_hist = torch.cat((u_hist[:, 1:], next_u[:, None, :]), dim=1)
            z_hist = torch.cat((z_hist[:, 1:], predicted[:, None, :]), dim=1)
            previous = predicted
    # Future CVs enter only the error calculation after all forecasts are finished.
    truth = np.asarray(data["z_target"])[chains].copy()
    prediction = np.stack(predictions, axis=1)
    return {"indices": chains, "time_ns": np.asarray(data["time_ns"])[chains],
            "truth_cv": truth, "prediction_cv": prediction,
            "truth": control_values(truth), "prediction": control_values(prediction),
            "logged_mv": np.asarray(data["u_current"])[chains],
            "memory_source_index": np.stack(source_indices, axis=1)}


def _endpoint_metrics(truth: np.ndarray, prediction: np.ndarray,
                      horizons=HORIZONS) -> dict:
    if truth.shape != prediction.shape or truth.ndim != 3:
        raise ValueError("rollout metric inputs must have matching (episode, step, channel) shapes")
    rows = [_metrics(truth[:, h - 1], prediction[:, h - 1]) for h in horizons]
    return {"horizons": list(horizons), "mae": [row["mae"] for row in rows],
            "rmse": [row["rmse"] for row in rows]}


def _write_prediction_csv(path, indices, time_ns, truth, prediction, names) -> None:
    with Path(path).open("w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["sample_index", "time_ns"] + [f"truth_{name}" for name in names] +
                        [f"prediction_{name}" for name in names] + [f"error_{name}" for name in names])
        for idx, ts, y, pred in zip(indices, time_ns, truth, prediction):
            writer.writerow([int(idx), int(ts), *y.tolist(), *pred.tolist(), *(pred - y).tolist()])


def _write_rollout_csv(path: Path, raw: dict) -> None:
    names = CONTROL_NAMES
    with path.open("w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["start_index", "sample_index", "time_ns", "step", "memory_source_index"] +
                        [f"logged_mv_{i}" for i in range(raw["logged_mv"].shape[-1])] +
                        [f"truth_{name}" for name in names] + [f"prediction_{name}" for name in names] +
                        [f"error_{name}" for name in names])
        for episode, indices in enumerate(raw["indices"]):
            for step, idx in enumerate(indices):
                y, pred = raw["truth"][episode, step], raw["prediction"][episode, step]
                writer.writerow([int(indices[0]), int(idx), int(raw["time_ns"][episode, step]), step + 1,
                                 int(raw["memory_source_index"][episode, step]),
                                 *raw["logged_mv"][episode, step].tolist(), *y.tolist(), *pred.tolist(),
                                 *(pred - y).tolist()])


def _save_tsne(latents: dict, test_idx, data, config, path: Path) -> dict:
    from sklearn.manifold import TSNE

    cfg = config.get("analysis", {})
    maximum = int(cfg.get("tsne_max_samples", 1500))
    if maximum < 3 or maximum > 1500:
        raise ValueError("tsne_max_samples must be between 3 and 1500")
    count = min(len(test_idx), maximum)
    if count < 3:
        raise ValueError("t-SNE requires at least three held-out observations")
    positions = np.linspace(0, len(test_idx) - 1, count).round().astype(np.int64)
    indices = np.asarray(test_idx)[positions]
    seed = int(cfg.get("seed", config.get("evaluation", {}).get("seed", 2026)))
    perplexity = min(30., (count - 1) / 3.)
    iterations = int(cfg.get("tsne_iterations", 1000))
    if iterations < 250:
        raise ValueError("t-SNE iterations must be at least 250")
    saved = {"indices": indices, "time_ns": np.asarray(data["time_ns"])[indices],
             "steam": control_values(np.asarray(data["z_target"])[indices])[:, 2],
             "random_state": np.asarray(seed), "perplexity": np.asarray(perplexity)}
    for mode in ("sensor", "multi"):
        latent = np.asarray(latents[mode])[positions]
        saved[mode + "_latent"] = latent
        saved[mode] = TSNE(n_components=2, perplexity=perplexity, init="pca",
                           learning_rate="auto", max_iter=iterations, random_state=seed,
                           n_jobs=int(config.get("training", {}).get("threads", 4))).fit_transform(latent)
    np.savez_compressed(path, **saved)
    return {"n": count, "random_state": seed, "perplexity": perplexity,
            "max_iter": iterations, "color": "observed steam flow (physical units)",
            "selection": "identical uniformly spaced test indices for both modes",
            "coordinates": "separate t-SNE fits; axes do not represent physical or shared latent coordinates"}


def run_prediction_analysis(data, stats, twins, config, outdir) -> dict:
    """Write real raw predictions and return the manuscript-facing result contract."""
    from threadpoolctl import threadpool_limits

    if set(twins) != {"multi", "sensor", "image"}:
        raise ValueError("twins must supply exactly multi, sensor and image models")
    splits = _validate_splits(data)
    for mode, twin in twins.items():
        if getattr(twin, "mode", mode) != mode:
            raise ValueError(f"twin mode does not match {mode}")
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    cfg = config.get("analysis", {})
    batch_size = int(cfg.get("batch_size", 512))
    threads = int(config.get("training", {}).get("threads", 4))
    if threads <= 0:
        raise ValueError("analysis threads must be positive")
    torch.set_num_threads(threads)
    fingerprints = {mode: encoder_fingerprint(twin) for mode, twin in twins.items()}
    controls = control_values(np.asarray(data["z_target"]))
    all_idx = np.concatenate([splits[name] for name in ("train", "val", "test")])
    train_end = len(splits["train"])
    val_end = train_end + len(splits["val"])
    probes, latent_test, validation_scores = {}, {}, {}
    test_idx = splits["test"]
    test_time = np.asarray(data["time_ns"])[test_idx]

    with threadpool_limits(limits=threads):
        for mode in ("multi", "sensor", "image"):
            print(f"prediction analysis: frozen {mode} probe", flush=True)
            latent = _encode_latents(twins[mode], data, all_idx, batch_size)
            x_train, x_val, x_test = np.split(latent, [train_end, val_end])
            metrics, prediction, fitted = _fit_linear_probe(
                x_train, x_val, x_test, controls[splits["train"], :2],
                controls[splits["val"], :2], controls[test_idx, :2])
            probes[mode] = metrics
            validation_scores[mode] = {str(alpha): float(score) for alpha, score in
                                       zip(fitted["alphas"], fitted["val_normalized_mse"])}
            np.savez_compressed(out / f"probe_{mode}.npz", indices=test_idx, time_ns=test_time,
                                truth=controls[test_idx, :2], prediction=prediction,
                                error=prediction - controls[test_idx, :2], **fitted)
            _write_prediction_csv(out / f"probe_{mode}.csv", test_idx, test_time,
                                  controls[test_idx, :2], prediction, CONTROL_NAMES[:2])
            if mode in ("multi", "sensor"):
                latent_test[mode] = x_test.copy()

        print("prediction analysis: full test one-step predictions", flush=True)
        cv_prediction = predict_twin(twins["multi"], data, test_idx, batch_size)
        one_prediction = control_values(cv_prediction)
        one_truth = controls[test_idx]
        onestep = {**_metrics(one_truth, one_prediction), "n": len(test_idx)}
        np.savez_compressed(out / "onestep.npz", indices=test_idx, time_ns=test_time,
                            truth=one_truth, prediction=one_prediction, error=one_prediction - one_truth,
                            truth_cv=np.asarray(data["z_target"])[test_idx], prediction_cv=cv_prediction)
        _write_prediction_csv(out / "onestep.csv", test_idx, test_time,
                              one_truth, one_prediction, CONTROL_NAMES)

        print("prediction analysis: recursive forecasts with training-only visual memory", flush=True)
        count = int(cfg.get("rollout_starts", config.get("evaluation", {}).get("episodes", 50)))
        chains = _select_rollout_chains(data, count, max(HORIZONS))
        retrieval = config.get("retrieval", {})
        memory = VisualMemory(twins["multi"], data, splits["train"],
                              max_items=int(retrieval.get("max_items", 512)),
                              k=int(retrieval.get("k", 3)))
        memory.save(out / "rollout_memory")
        raw = _recursive_rollouts(twins["multi"], memory, data, chains)
        raw["error"] = raw["prediction"] - raw["truth"]
        raw["error_cv"] = raw["prediction_cv"] - raw["truth_cv"]
        np.savez_compressed(out / "rollout.npz", **raw)
        _write_rollout_csv(out / "rollout.csv", raw)
        rollout = _endpoint_metrics(raw["truth"], raw["prediction"])
        endpoint_temperature = np.abs(raw["error"][:, -1, 0])
        example_position = np.argsort(endpoint_temperature, kind="stable")[len(chains) // 2]
        rollout.update({"starts": chains[:, 0].tolist(),
                        "example": {"steps": list(range(1, max(HORIZONS) + 1)),
                                    "truth": raw["truth"][example_position].tolist(),
                                    "prediction": raw["prediction"][example_position].tolist(),
                                    "start_index": int(chains[example_position, 0])}})

        print("prediction analysis: paired test t-SNE", flush=True)
        tsne_path = out / "tsne.npz"
        tsne_manifest = _save_tsne(latent_test, test_idx, data, config, tsne_path)

    if any(encoder_fingerprint(twins[mode]) != value for mode, value in fingerprints.items()):
        raise RuntimeError("prediction analysis mutated trained model weights")
    result = {"probe": probes, "onestep": onestep, "rollout": rollout,
              "tsne_file": str(tsne_path.resolve())}
    manifest = {"schema": 1, "control_names": list(CONTROL_NAMES),
                "model_sha256": fingerprints, "seed": int(config.get("training", {}).get("seed", 11)),
                "partitions": {name: len(idx) for name, idx in splits.items()},
                "probe": {"representation": "frozen twin.encode latent only; no appended observed CV",
                          "target": "absolute next-step mean temperature and pressure",
                          "selection": "training-only StandardScaler and Ridge; alpha chosen by validation normalized MSE",
                          "validation_scores": validation_scores,
                          "uncertainty": "one trained encoder seed; point estimates only"},
                "one_step": {"visual": "observed historical image at/before t-1, same prepared test rows",
                             "target": "all four physical control quantities at prediction time t"},
                "recursive": {"episodes": len(chains), "steps": max(HORIZONS),
                              "starts": "uniformly spaced among complete disjoint test trajectories",
                              "mv": "fixed future logged MV; initial history observed",
                              "cv": "predictions fed back after first step; future true CV used only for errors",
                              "visual": "training-only VisualMemory.query at every step, including step 1",
                              "metric": "MAE/RMSE across trajectories at each horizon endpoint",
                              "example": "upper median absolute 20-step temperature error, with stable tie order",
                              "comparison": "recursive h=1 and full-test one-step have different visual conditions and sample counts"},
                "tsne": tsne_manifest, "config": config,
                "stats_source": "prepared training partition statistics supplied by caller"}
    _write_json(out / "analysis_manifest.json", manifest)
    _write_json(out / "analysis_results.json", result)
    return result
