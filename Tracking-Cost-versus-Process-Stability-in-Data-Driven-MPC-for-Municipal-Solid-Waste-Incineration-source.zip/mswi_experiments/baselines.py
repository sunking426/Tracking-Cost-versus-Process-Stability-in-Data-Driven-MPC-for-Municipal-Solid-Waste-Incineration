"""Finite-budget, receding-horizon CEM planning in the training surrogate only."""
from __future__ import annotations

import time

import numpy as np
import torch

from .control import TwinEnv
from .models import make_state


class CEMMPCPolicy:
    """Plan blocked incremental actions, execute one, and replan at the next state.

    This controller owns a training twin and training-only visual memory. Its
    interface accepts current observations, never an evaluation dynamics object,
    future observations or logged future actions. Candidate forward simulation
    reuses TwinEnv, including its history/retrieval/executed-action semantics.
    """

    def __init__(self, twin, memory, stats, prior_actor, *, horizon=10,
                 block_steps=5, population=32, elite=4, iterations=2,
                 initial_std=0.35, minimum_std=0.05, gamma=0.99, seed=2026):
        integer_values = (horizon, block_steps, population, elite, iterations)
        if any(int(x) != x or x <= 0 for x in integer_values):
            raise ValueError("CEM-MPC budgets must be positive integers")
        if horizon % block_steps or elite > population or population < 3:
            raise ValueError("CEM-MPC requires complete action blocks, elite <= population and population >= 3")
        if not (0 < minimum_std <= initial_std) or not 0 < gamma <= 1:
            raise ValueError("Invalid CEM-MPC search scale or discount")
        self.twin, self.memory = twin.eval(), memory
        self.stats, self.prior_actor = stats, prior_actor.eval()
        self.horizon, self.block_steps = int(horizon), int(block_steps)
        self.blocks = self.horizon // self.block_steps
        self.population, self.elite, self.iterations = int(population), int(elite), int(iterations)
        self.initial_std, self.minimum_std = float(initial_std), float(minimum_std)
        self.gamma, self.seed = float(gamma), int(seed)
        self.action_dim = len(stats["action_scale"])
        self.plan = None
        self.reset_count = 0
        self.calls = 0
        self.forward_transitions = 0
        self.elapsed_seconds = 0.0
        self.call_history = []

    def reset(self, observation):
        self.rng = np.random.default_rng(self.seed)
        self.plan = None
        self.batch_size = len(observation["u_current"])
        self.reset_count += 1
        self.calls = 0
        self.forward_transitions = 0
        self.elapsed_seconds = 0.0
        self.call_history = []

    def _score(self, observation, candidates):
        batch, population, blocks, channels = candidates.shape
        if (population, blocks, channels) != (self.population, self.blocks, self.action_dim):
            raise ValueError("Candidate plan shape does not match CEM-MPC budget")
        # Each current observed history becomes an independent initial history
        # for every candidate. There is no lookup of a future test observation.
        candidate_data = {
            name: np.repeat(value.detach().cpu().numpy(), population, axis=0)
            for name, value in observation.items()
        }
        env = TwinEnv(self.twin, self.memory, self.stats, candidate_data, {})
        env.reset(np.arange(batch * population, dtype=np.int64))
        score = np.zeros(batch * population, dtype=np.float64)
        flat = candidates.reshape(batch * population, blocks, channels)
        for step in range(self.horizon):
            _, reward, _ = env.step(flat[:, step // self.block_steps])
            score += self.gamma ** step * reward
        self.forward_transitions += batch * population * self.horizon
        return score.reshape(batch, population)

    @torch.no_grad()
    def __call__(self, observation):
        begin = time.perf_counter()
        batch = len(observation["u_current"])
        if self.plan is None:
            if not hasattr(self, "rng"):
                raise RuntimeError("CEM-MPC policy must be reset before planning")
        elif len(self.plan) != batch:
            raise ValueError("CEM-MPC batch changed without reset")
        prior = self.prior_actor(make_state(self.twin, **observation)).cpu().numpy()
        if prior.shape != (batch, self.action_dim) or not np.isfinite(prior).all():
            raise ValueError("Invalid BC prior for CEM-MPC")
        prior = np.repeat(prior[:, None, :], self.blocks, axis=1)
        if self.plan is None:
            warm = prior.copy()
        else:
            # Shift the previous full plan by one control step, then re-block.
            expanded = np.repeat(self.plan, self.block_steps, axis=1)
            shifted = np.concatenate((expanded[:, 1:], expanded[:, -1:]), axis=1)
            warm = shifted.reshape(batch, self.blocks, self.block_steps, self.action_dim).mean(axis=2)
        mean = warm.copy()
        std = np.full_like(mean, self.initial_std)
        best_score = np.full(batch, -np.inf)
        best_plan = np.zeros_like(mean)
        batch_idx = np.arange(batch)
        for _ in range(self.iterations):
            candidates = self.rng.normal(mean[:, None], std[:, None],
                size=(batch, self.population, self.blocks, self.action_dim)).astype(np.float32)
            candidates = np.clip(candidates, -1., 1.)
            # Fixed reference candidates prevent losing a useful current plan
            # simply because random proposals all have worse predicted cost.
            candidates[:, 0] = 0.
            candidates[:, 1] = prior
            candidates[:, 2] = best_plan if np.isfinite(best_score).all() else warm
            scores = self._score(observation, candidates)
            if not np.isfinite(scores).all():
                raise FloatingPointError("Nonfinite CEM-MPC predicted return")
            winner = scores.argmax(axis=1)
            current_score = scores[batch_idx, winner]
            improving = current_score > best_score
            best_plan[improving] = candidates[batch_idx[improving], winner[improving]]
            best_score[improving] = current_score[improving]
            elite_idx = np.argsort(scores, axis=1, kind="stable")[:, -self.elite:]
            elites = candidates[batch_idx[:, None], elite_idx]
            mean = elites.mean(axis=1)
            std = np.maximum(elites.std(axis=1), self.minimum_std)
        self.plan = best_plan
        elapsed = time.perf_counter() - begin
        self.calls += 1
        self.elapsed_seconds += elapsed
        self.call_history.append({"step": self.calls, "batch": batch,
            "predicted_mean_discounted_return": float(best_score.mean()),
            "planning_seconds": elapsed,
            "forward_transitions": batch * self.population * self.iterations * self.horizon})
        return best_plan[:, 0].copy()

    def metrics(self):
        return {"controller": "CEM-MPC in training surrogate with per-step replanning",
            "seed": self.seed, "horizon": self.horizon, "block_steps": self.block_steps,
            "blocks": self.blocks, "population": self.population, "elite": self.elite,
            "iterations": self.iterations, "initial_std": self.initial_std,
            "minimum_std": self.minimum_std, "gamma": self.gamma,
            "reference_candidates": ["zero action", "BC prior", "shifted previous/best plan"],
            "reset_count": self.reset_count, "planning_calls": self.calls,
            "forward_transitions": self.forward_transitions,
            "planning_elapsed_seconds": self.elapsed_seconds,
            "planning_seconds_per_control_decision": self.elapsed_seconds / (self.calls * self.batch_size)
                if self.calls else None,
            "dynamics_source": "training twin and training-only visual memory; no evaluation-model planning",
            "call_history": self.call_history}
