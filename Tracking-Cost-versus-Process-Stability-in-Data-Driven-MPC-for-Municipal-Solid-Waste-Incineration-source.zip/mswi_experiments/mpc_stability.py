"""Stability-only objective extension over immutable C execution and CEM owners.

The inherited temperature planner owns candidate generation, CRN, warm starts
and ranking. The canonical CEM scorer owns dynamics, projection and support.
Only executed-state variation and its contribution to the score are new.
"""
from __future__ import annotations
import numpy as np
from .control import reward_and_violation
from .ridge_policy_planning import CEMPlanner
from .mpc_temperature import TemperatureCEM,acceptance_tier


def stability_components(prediction,current):
    p=np.asarray(prediction,dtype=np.float64);c=np.asarray(current,dtype=np.float64)
    if p.ndim!=4 or p.shape[-1]!=9 or c.shape!=(len(p),9) or not np.isfinite(p).all() or not np.isfinite(c).all():
        raise ValueError('finite(N,candidates,H,9) predictions and(N,9) current required')
    start=np.broadcast_to(c[:,None,None,7:9],(len(p),p.shape[1],1,2))
    delta=np.abs(np.diff(np.concatenate((start,p[...,7:9]),axis=2),axis=2))
    parts=(delta/np.array([5.,.5])).sum(axis=2)
    return parts[...,0],parts[...,1]


class StabilityCEM(TemperatureCEM):
    def __init__(self,model,execution,stability_weight,parent):
        if stability_weight not in (0,1,2,4,8):raise ValueError('unregistered lambda')
        # These immutable CEM owners implement this exact parent contract.
        expected={'population':128,'elite':16,'iterations':4,'planning_horizon':10,
                  'initial_std':.35,'minimum_std':.05,'std_ddof':0,'gamma':1.}
        if any(parent['cem'][k]!=v for k,v in expected.items()):raise ValueError('parent CEM contract changed')
        if parent['actions']['active_indices']!=[0,3] or parent['actions']['fraction']!=.1:raise ValueError('parent action contract changed')
        if parent['objective']['temperature_weight']!=4 or parent['objective']['hard_temperature_constraint']:raise ValueError('parent temperature contract changed')
        if float(execution.support.values['threshold'])!=parent['support']['threshold']:raise ValueError('parent support changed')
        super().__init__(model,execution,parent['objective']['temperature_weight'],False)
        self.stability_weight=stability_weight

    def objective_components(self,plans,u,z,current,times):
        original,trace=CEMPlanner.score(self,plans,u,z,current,times,return_trace=True)
        rewards,_,parts=reward_and_violation(trace['prediction'],trace['executed'],self.execution.stats)
        if not np.array_equal(rewards,trace['reward']):raise AssertionError('canonical reward changed')
        jt=parts['tracking_cost'][...,0].astype(float).sum(axis=2)
        jf,jo=stability_components(trace['prediction'],current)
        score=original-(self.weight-1)*jt-self.stability_weight*(jf+jo)
        return score,original,jt,jf,jo

    def candidate_metrics(self,plans,u,z,current,times):
        score,original,jt,_,_=self.objective_components(plans,u,z,current,times)
        return score,original,jt,np.ones_like(score,dtype=bool)

    def plan(self,u,z,current,times,indices,decision_step):
        request,meta=super().plan(u,z,current,times,indices,decision_step)
        score,original,jt,jf,jo=self.objective_components(meta['best_requested_plan_b'][:,None],u,z,current,times)
        for key,values in [('selected_planning_score',score),('selected_original_return',original),('selected_temperature_cost',jt)]:
            np.testing.assert_array_equal(values[:,0],meta[key])
        meta.update(selected_steam_variation_cost=jf[:,0],selected_oxygen_variation_cost=jo[:,0],
                    selected_stability_cost=(jf+jo)[:,0])
        return request,meta


def choose_stability(reference_original,bc_variation,candidates):
    """Candidates map lambda -> (4x6 original means,4x2 variation means)."""
    bc=np.asarray(bc_variation,dtype=float)
    if bc.shape!=(4,2) or not np.isfinite(bc).all() or np.any(bc<0):raise ValueError('four model BC fluctuation means required')
    assessed={}
    for weight in sorted(candidates):
        original,var=candidates[weight];var=np.asarray(var,dtype=float)
        if var.shape!=bc.shape or not np.isfinite(var).all() or np.any(var<0):raise ValueError('variation means')
        guards=acceptance_tier(reference_original,original,.01)
        stable=var<=bc
        assessed[str(weight)]=dict(original=guards,stability_pass=bool(stable.all()),stability_per_model_metric=stable.tolist(),
            stability_difference=(var-bc).tolist(),BC_means=bc.tolist(),candidate_variation=var.tolist(),
            eligible=bool(guards['pass'] and stable.all()))
    eligible=[w for w in sorted(candidates) if assessed[str(w)]['eligible']]
    selected=max(eligible,key=lambda w:assessed[str(w)]['original']['worst_cost_gain']) if eligible else None
    return dict(eligible_lambda=eligible,recommended_lambda=selected,retained_reference_lambda=0 if selected is None else None,
                configurations=assessed,main_configuration_refrozen=False)
