"""Independent saved-trajectory integrity checks for the finished evaluation."""
from __future__ import annotations
import json,argparse
import numpy as np
import torch
from threadpoolctl import threadpool_limits
from .s8_cross_evaluation import ROOT,OUT,DESIGN,REF,MODELS,METHODS,GRUFeedback,verify
from .ridge_policy_study import read_npz,write_json
from .ridge_dynamics import RidgeDynamics
from .ridge_response import decision_rollout
from .control import reward_and_violation
from .frozen_mpc import file_sha256


def main(selected_models=None):
    verify();inputs=read_npz(REF/'inputs/val.npz');stats=json.loads((REF/'stats.json').read_text())
    lo,hi=np.array(stats['u_low']),np.array(stats['u_high']);rows=[]
    for layer,mids in (('B',('gru23',)),('C',MODELS)):
        for mid in mids:
            if layer=='C' and selected_models is not None and mid not in selected_models:continue
            if layer=='C':
                noise=read_npz(OUT/f'residuals/{mid}_sequences.npz')
                bank=read_npz(OUT/f'residuals/{mid}_bank.npz')
                t=noise['residual_source_time_ns'].reshape(256,5,5,10)
                assert (np.diff(t,axis=-1)==60000000000).all()
                assert (t[...,0]//86400000000000==t[...,-1]//86400000000000).all()
                expected=bank['residual'][bank['block_positions'][noise['chosen_block_positions']]].reshape(256,5,50,9)
                np.testing.assert_array_equal(expected,noise['residual'])
                with np.load(ROOT/'experiment_runs/corrected_vision/data/dataset.npz') as raw:
                    assert np.isin(noise['residual_source_indices'],raw['train_idx']).all()
                model=RidgeDynamics.load(REF/f'evaluation_models/{mid}.npz')
            else:model=GRUFeedback()
            for method,seed in METHODS:
                for rep in range(5) if layer=='C' else (0,):
                    p=OUT/f'trajectories/{layer}/{mid}/{method}/seed{seed}_rep{rep}.npz';a=read_npz(p)
                    assert file_sha256(p)==json.loads(p.with_suffix('.json').read_text())['sha256']
                    np.testing.assert_array_equal(a['indices'],inputs['indices'])
                    assert a['pred_cv'].shape==(256,50,9)
                    r,v,cost=reward_and_violation(a['pred_cv'],a['executed_action'],stats)
                    np.testing.assert_array_equal(r,a['reward']);np.testing.assert_array_equal(v,a['violation'])
                    for name,value in cost.items():np.testing.assert_array_equal(value,a[name])
                    np.testing.assert_array_equal(a['physical_executed_action'][:,:,[1,2,4,5,6,7]],0)
                    assert ((a['u_path']>=lo-1e-10)&(a['u_path']<=hi+1e-10)).all()
                    assert (np.abs(a['physical_executed_action'])<=.1*np.asarray(stats['action_bound'])+1e-10).all()
                    if layer=='C':np.testing.assert_array_equal(a['injected_residual'],noise['residual'][:,rep])
                    # Rebuild every input history from stored feedback, not runner state.
                    u=inputs['u_hist'].astype(float).copy();z=inputs['z_hist'].astype(float).copy();current=inputs['z_current'].astype(float).copy()
                    max_error=0.
                    for step in range(50):
                        if step in (0,9,49):
                            pred=decision_rollout(model,u,z,current,a['u_path'][:,step,None])[:,0]
                            if layer=='C':pred=pred+noise['residual'][:,rep,step]
                            error=float(np.max(abs(pred-a['pred_cv'][:,step])));max_error=max(max_error,error)
                            np.testing.assert_array_equal(pred,a['pred_cv'][:,step])
                        z=np.concatenate((z[:,1:],current[:,None]),axis=1)
                        u=np.concatenate((u[:,1:],a['u_path'][:,step,None]),axis=1);current=a['pred_cv'][:,step]
                    rows.append({'layer':layer,'model':mid,'method':method,'seed':seed,'replicate':rep,
                        'episodes':256,'steps':50,'reward_and_costs_bitwise_recomputed':True,
                        'feedback_recomputed_steps':[1,10,50],'feedback_max_absolute_difference':max_error,
                        'common_noise_exact':layer=='C','inactive_actions_zero':True,'MV_bounds_pass':True,
                        'active_action_budget_pass':True,
                        'zero_action_unsupported_steps':int(a['zero_action_unsupported'].sum())})
    verify()
    filename='final_integrity_audit.json' if selected_models is None else 'partial_integrity_audit.json'
    write_json(OUT/filename,{'status':'passed','scope':'full' if selected_models is None else selected_models,'trajectory_files':len(rows),
        'episodes':len(rows)*256,'transition_steps':len(rows)*256*50,'test_evaluations':0,
        'all_controller_bound_dependencies_unchanged':True,'details':rows})
    print('INTEGRITY PASSED',len(rows),'files',len(rows)*256*50,'steps',flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--models',nargs='+',choices=MODELS);args=parser.parse_args()
    torch.set_num_threads(2)
    with threadpool_limits(2):main(args.models)
