"""Statistics and source-bound figures for frozen Ridge recursive validation.

Recorded future operations are conditioning inputs, not known online forecasts.
Teacher forcing is retained only as a repeated one-step diagnostic. Event
segments describe observed, often mixed operations rather than interventions.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import json
from pathlib import Path

import numpy as np

from .data import MINUTE_NS, control_values
from .numeric_baselines_report import metric_summary
from .visual_diagnostics_statistics import DAY_NS, paired_block_interval


BRANCHES = ("ridge_logged", "ridge_hold_mv", "persistence", "ridge_teacher_forced")
RECURSIVE = BRANCHES[:3]
ENDPOINTS = (1, 5, 10)
QUANTITIES = ("temperature", "pressure", "steam", "oxygen")
UNITS = ("°C", "Pa", "t/h", "vol%")
TITLES = ("炉膛平均温度", "炉膛负压", "主蒸汽流量", "烟气氧浓度")
LABELS = {"ridge_logged": "Ridge：记录操作路径", "ridge_hold_mv": "Ridge：保持起点操作",
          "persistence": "持续性预测", "ridge_teacher_forced": "真实CV更新（诊断）"}
COLORS = {"ridge_logged": "#1f77b4", "ridge_hold_mv": "#ff7f0e", "persistence": "#2ca02c",
          "ridge_teacher_forced": "#777777"}
PRIMARY = "nine_channel_normalized_mse"
ENDPOINT_NAMES = (PRIMARY, *[q+"_mae" for q in QUANTITIES])


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2,
                                    allow_nan=False)+"\n", encoding="utf-8")


def _csv(path, rows):
    if not rows:
        raise ValueError("report tables must retain defined rows, including empty event groups")
    with Path(path).open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)


def direction_labels(changes, deadbands):
    changes = np.asarray(changes, dtype=np.float64)
    bands = np.asarray(deadbands, dtype=np.float64)
    if (changes.ndim < 2 or changes.shape[-1] != 4 or bands.shape != (4,)
            or not np.isfinite(changes).all() or not np.isfinite(bands).all() or np.any(bands <= 0)):
        raise ValueError("finite four-quantity changes and positive training deadbands required")
    return np.where(changes > bands, 1, np.where(changes < -bands, -1, 0)).astype(np.int8)


def response_directions(truth_cv, prediction_cv, initial_cv, deadbands):
    """Report ternary observed-versus-predicted directions and all denominators."""
    truth = np.asarray(truth_cv, dtype=np.float64)
    pred = np.asarray(prediction_cv, dtype=np.float64)
    initial = np.asarray(initial_cv, dtype=np.float64)
    if truth.ndim != 2 or truth.shape[1] != 9 or pred.shape != truth.shape or initial.shape != truth.shape:
        raise ValueError("aligned event endpoint and initial nine-CV arrays required")
    if not all(np.isfinite(a).all() for a in (truth, pred, initial)):
        raise ValueError("nonfinite event response")
    baseline = control_values(initial)
    observed = direction_labels(control_values(truth)-baseline, deadbands)
    predicted = direction_labels(control_values(pred)-baseline, deadbands)
    result = []
    for j, quantity in enumerate(QUANTITIES):
        confusion = np.zeros((3, 3), dtype=np.int64)
        np.add.at(confusion, (observed[:, j]+1, predicted[:, j]+1), 1)
        active = observed[:, j] != 0; neutral = ~active
        correct = observed[:, j] == predicted[:, j]
        n, na, nn = len(truth), int(active.sum()), int(neutral.sum())
        result.append({"quantity": quantity, "samples": n, "deadband": float(deadbands[j]),
            "labels": [-1, 0, 1], "confusion_rows": "observed", "confusion_columns": "predicted",
            "confusion": confusion.tolist(), "correct_count": int(correct.sum()),
            "overall_accuracy": float(correct.mean()) if n else None,
            "observed_active_count": na, "active_correct_count": int(correct[active].sum()),
            "active_accuracy": float(correct[active].mean()) if na else None,
            "observed_neutral_count": nn, "neutral_correct_count": int(correct[neutral].sum()),
            "neutral_accuracy": float(correct[neutral].mean()) if nn else None})
    return result


def _empty_metric():
    return {"samples": 0, "normalized_mse": None, "channel_mae": [None]*9,
            "channel_rmse": [None]*9, "physical_mae": [None]*4, "physical_rmse": [None]*4}


def endpoint_metrics(truth_cv, prediction_cv, delta_scale):
    truth, pred = np.asarray(truth_cv), np.asarray(prediction_cv)
    if truth.shape != pred.shape or truth.ndim != 2 or truth.shape[1] != 9:
        raise ValueError("endpoint metrics require aligned (sample, 9) arrays")
    return metric_summary(pred[None], truth, delta_scale) if len(truth) else _empty_metric()


def trajectory_metrics(truth_cv, prediction_cv, delta_scale):
    truth, pred = np.asarray(truth_cv), np.asarray(prediction_cv)
    if truth.shape != pred.shape or truth.ndim != 3 or truth.shape[-1] != 9 or truth.shape[1] == 0:
        raise ValueError("trajectory metrics require aligned (event, step, 9) arrays")
    metric = endpoint_metrics(truth.reshape(-1, 9), pred.reshape(-1, 9), delta_scale)
    metric.update(segments=len(truth), steps=truth.shape[1], denominator="all segment-step pairs, equally weighted")
    return metric


def endpoint_differences(reference, candidate, truth, delta_scale):
    ref, cand, y = [np.asarray(a, dtype=np.float64) for a in (reference, candidate, truth)]
    scale = np.asarray(delta_scale, dtype=np.float64)
    if (ref.shape != cand.shape or ref.shape != y.shape or ref.ndim != 2 or ref.shape[1] != 9
            or scale.shape != (9,) or np.any(scale <= 0)
            or not all(np.isfinite(a).all() for a in (ref, cand, y, scale))):
        raise ValueError("paired finite nine-channel endpoints and positive scales required")
    mse = (np.square((ref-y)/scale)-np.square((cand-y)/scale)).mean(1)
    physical = abs(control_values(ref)-control_values(y))-abs(control_values(cand)-control_values(y))
    return np.column_stack((mse, physical))[None]


def load_completed_validation(study_dir):
    root = Path(study_dir).resolve()
    names = ("config.json", "stats.json", "protocol.json", "run_manifest.json",
             "event_thresholds.json", "prepare_frozen.json", "event_summary.json")
    config, stats, protocol, run, thresholds, frozen, event_summary = [json.loads((root/n).read_text()) for n in names]
    if (run["status"] != "complete" or frozen["status"] != "complete"
            or run["prepare_frozen_sha256"] != _sha(root/"prepare_frozen.json")
            or run["trajectories_dropped"] != 0 or run["predictions_clipped"] or run["model_retrained"]
            or config["horizon"] != 10 or config["endpoints"] != list(ENDPOINTS)):
        raise ValueError("completed frozen ten-step validation required")
    sources = {n: _sha(root/n) for n in names}
    for name, digest in frozen["files"].items():
        if _sha(root/name) != digest: raise ValueError("frozen prepared artifact changed: "+name)
        sources[name] = digest
    indexed = {(r["split"], r["branch"]): r for r in run["files"]}
    expected = set(itertools.product(("train", "val", "test"), BRANCHES))
    if set(indexed) != expected or len(run["files"]) != len(expected):
        raise ValueError("all twelve unique split-by-branch rollouts required")
    with np.load(root/"chains.npz", allow_pickle=False) as raw:
        chains = {s: raw[s+"_chains"].copy() for s in ("train", "val", "test")}
    arrays = {}; events = {}; checks = []
    for split in ("train", "val", "test"):
        arrays[split] = {}; shared = None
        for branch in BRANCHES:
            item = indexed[(split, branch)]; name=f"rollouts/{split}/{branch}.npz"
            if item["path"] != name or _sha(root/name) != item["sha256"]:
                raise ValueError("rollout identity or hash mismatch")
            with np.load(root/name, allow_pickle=False) as saved:
                row = {k: saved[k].copy() for k in ("indices", "start_time_ns", "time_ns", "truth_cv",
                        "pred_cv", "initial_zprev", "mv_path")}
            n, h = item["starts"], item["horizon"]
            if (n <= 0 or h != 10 or item["shape"] != [n, h, 9]
                    or row["indices"].shape != (n,h) or row["time_ns"].shape != (n,h)
                    or row["start_time_ns"].shape != (n,) or row["initial_zprev"].shape != (n,9)
                    or row["truth_cv"].shape != (n,h,9) or row["pred_cv"].shape != (n,h,9)
                    or row["mv_path"].shape != (n,h,8)
                    or not all(np.isfinite(row[k]).all() for k in row)
                    or not np.array_equal(row["indices"], chains[split])
                    or not np.array_equal(row["time_ns"], row["start_time_ns"][:,None]+np.arange(h)*MINUTE_NS)
                    or np.any(np.diff(row["start_time_ns"]) <= 0)):
                raise ValueError("invalid common rollout arrays or minute alignment")
            identity = ("indices", "start_time_ns", "time_ns", "truth_cv", "initial_zprev")
            if shared is None: shared = row
            elif any(not np.array_equal(row[k], shared[k]) for k in identity):
                raise ValueError("branches do not share starting observations and targets")
            arrays[split][branch] = row; sources[name] = item["sha256"]
            checks.append({"split": split, "branch": branch, "starts": n, "horizon": h,
                           "hash_shape_alignment_verified": True})
        base = arrays[split]["ridge_logged"]
        held = arrays[split]["ridge_hold_mv"]
        if not np.array_equal(held["mv_path"], np.repeat(base["mv_path"][:, :1], 10, axis=1)):
            raise ValueError("held-operation path differs from the starting operation")
        for branch in ("persistence", "ridge_teacher_forced"):
            if not np.array_equal(arrays[split][branch]["mv_path"], base["mv_path"]):
                raise ValueError("recorded-operation diagnostics have inconsistent MV paths")
        for branch in ("ridge_hold_mv", "ridge_teacher_forced"):
            if not np.allclose(arrays[split][branch]["pred_cv"][:,0], base["pred_cv"][:,0], rtol=0, atol=1e-10):
                raise ValueError("Ridge first steps must agree")
        if not np.array_equal(arrays[split]["persistence"]["pred_cv"], np.repeat(base["initial_zprev"][:,None],10,axis=1)):
            raise ValueError("persistence must retain initial pre-target CV")
        with np.load(root/f"events/{split}.npz", allow_pickle=False) as saved:
            event={k:saved[k].copy() for k in saved.files}
        n=len(base["indices"])
        for key in ("candidate_positions", "selected_positions", "example_positions"):
            pos=event[key]
            if (pos.ndim!=1 or (len(pos) and (pos.min()<0 or pos.max()>=n or np.any(np.diff(pos)<=0)))):
                raise ValueError("event positions must be unique increasing rollout rows")
        selected, candidates, examples = (event[k] for k in ("selected_positions","candidate_positions","example_positions"))
        if (not np.isin(selected,candidates).all() or not np.isin(examples,selected).all()
                or not np.array_equal(event["chain_start_indices"],base["indices"][:,0])
                or not np.array_equal(event["chain_start_time_ns"],base["start_time_ns"])
                or not np.array_equal(event["selected_indices"],base["indices"][selected,0])
                or not np.array_equal(event["selected_time_ns"],base["start_time_ns"][selected])
                or not np.array_equal(event["candidate_indices"],base["indices"][candidates,0])
                or not np.array_equal(event["example_indices"],base["indices"][examples,0])
                or (len(selected)>1 and np.any(np.diff(event["selected_time_ns"])<config["event_minimum_separation_minutes"]*MINUTE_NS))):
            raise ValueError("event identity or separation mismatch")
        expected_examples=selected[np.linspace(0,len(selected)-1,min(config["example_count"],len(selected)),dtype=np.int64)] if len(selected) else np.empty(0,dtype=np.int64)
        if not np.array_equal(examples,expected_examples): raise ValueError("examples must be chosen by chronological position, never by error")
        for name in ("current_delta","trigger_mask","current_nonzero_mask","current_sign"):
            if event[name].shape != (n,8): raise ValueError("event MV fields must cover all rollout starts")
        for name in ("current_nonzero_channels","future_change_steps","future_change_cells","future_changed_channels"):
            if event[name].shape != (n,): raise ValueError("event counts must cover all rollout starts")
        future=event["future_change_mask"]
        if (future.shape!=(n,9,8) or not np.array_equal(event["current_nonzero_channels"],event["current_nonzero_mask"].sum(1))
                or not np.array_equal(event["future_change_steps"],future.any(2).sum(1))
                or not np.array_equal(event["future_change_cells"],future.sum((1,2)))
                or not np.array_equal(event["future_changed_channels"],future.any(1).sum(1))
                or not np.array_equal(candidates,np.flatnonzero(event["trigger_mask"].any(1)))):
            raise ValueError("event masks and counts disagree")
        expected_counts=event_summary[split]
        if (expected_counts["chains"]!=n or expected_counts["candidate_count"]!=len(candidates)
                or expected_counts["selected_count"]!=len(selected)
                or expected_counts["example_indices"]!=event["example_indices"].tolist()):
            raise ValueError("event summary disagrees with saved identities")
        events[split]=event
    for a,b in itertools.combinations(arrays,2):
        if np.intersect1d(chains[a].ravel(),chains[b].ravel()).size: raise ValueError("outer split rollout targets overlap")
    return root,config,stats,protocol,thresholds,arrays,events,sources,checks


def _metric_row(metric):
    row={"sample_pairs":metric["samples"],"normalized_mse":metric["normalized_mse"]}
    for j,q in enumerate(QUANTITIES):
        row[q+"_mae"]=metric["physical_mae"][j];row[q+"_rmse"]=metric["physical_rmse"][j]
    return row


def event_context(events):
    selected=events["selected_positions"]; n=len(selected)
    multi=int((events["current_nonzero_channels"][selected]>1).sum())
    continued=int((events["future_change_steps"][selected]>0).sum())
    trigger_multi=int((events["trigger_mask"][selected].sum(1)>1).sum())
    return {"candidate_count":len(events["candidate_positions"]),"selected_count":n,
            "examples":len(events["example_positions"]),"multiple_current_mv_count":multi,
            "multiple_current_mv_fraction":multi/n if n else None,
            "multiple_trigger_mv_count":trigger_multi,"multiple_trigger_mv_fraction":trigger_multi/n if n else None,
            "further_operation_change_count":continued,"further_operation_change_fraction":continued/n if n else None,
            "trigger_counts_per_mv":events["trigger_mask"][selected].sum(0).tolist(),
            "scope":"Observed operation-change segments; mixed and continuing operations retained; not isolated interventions"}


def summarize_validation(study_dir):
    root,cfg,stats,protocol,thresholds,arrays,events,sources,checks=load_completed_validation(study_dir)
    out=root/"statistics";out.mkdir(exist_ok=True)
    scale=np.asarray(stats["delta_scale"],dtype=float);bands=np.asarray(thresholds["direction_deadbands"],dtype=float)
    metrics={};event_metrics={};contexts={};comparisons={}
    curve_rows=[];endpoint_rows=[];channel_rows=[];daily_rows=[];event_rows=[];direction_rows=[];confusion_rows=[]
    for split in ("train","val","test"):
        metrics[split]={};event_metrics[split]={};contexts[split]=event_context(events[split])
        selected=events[split]["selected_positions"]
        for branch in BRANCHES:
            r=arrays[split][branch];truth=r["truth_cv"];pred=r["pred_cv"]
            metrics[split][branch]={};event_metrics[split][branch]={}
            days=r["start_time_ns"]//DAY_NS
            for h in range(1,11):
                metric=endpoint_metrics(truth[:,h-1],pred[:,h-1],scale)
                metrics[split][branch][str(h)]=metric
                row={"split":split,"branch":branch,"role":"diagnostic" if branch==BRANCHES[-1] else "recursive",
                     "step":h,"minutes_after_start":h-1,"starts":len(truth),**_metric_row(metric)}
                curve_rows.append(row)
                if h in ENDPOINTS:
                    endpoint_rows.append(row)
                    for j,name in enumerate(stats["cv_names"]):
                        channel_rows.append({"split":split,"branch":branch,"step":h,"channel":name,
                            "unit":"°C" if j<6 else UNITS[j-5],"starts":len(truth),
                            "mae":metric["channel_mae"][j],"rmse":metric["channel_rmse"][j]})
                    for day in np.unique(days):
                        mask=days==day;dm=endpoint_metrics(truth[mask,h-1],pred[mask,h-1],scale)
                        daily_rows.append({"split":split,"branch":branch,"step":h,
                            "start_date":str(np.datetime64(int(day),"D")),**_metric_row(dm)})
                    endpoint=endpoint_metrics(truth[selected,h-1],pred[selected,h-1],scale)
                    trajectory=trajectory_metrics(truth[selected,:h],pred[selected,:h],scale)
                    directions=response_directions(truth[selected,h-1],pred[selected,h-1],r["initial_zprev"][selected],bands)
                    event_metrics[split][branch][str(h)]={"endpoint":endpoint,"trajectory":trajectory,"directions":directions}
                    for metric_type,em in (("endpoint",endpoint),("trajectory_through_step",trajectory)):
                        event_rows.append({"split":split,"branch":branch,"step":h,"metric_type":metric_type,
                                           "segments":len(selected),**_metric_row(em)})
                    for d in directions:
                        direction_rows.append({"split":split,"branch":branch,"step":h,
                            **{k:v for k,v in d.items() if k not in ("labels","confusion","confusion_rows","confusion_columns")}})
                        for observed in (-1,0,1):
                            for predicted in (-1,0,1):
                                confusion_rows.append({"split":split,"branch":branch,"step":h,"quantity":d["quantity"],
                                    "observed_direction":observed,"predicted_direction":predicted,
                                    "count":d["confusion"][observed+1][predicted+1],"samples":d["samples"]})
    comparison_rows=[];truth=arrays["test"]["ridge_logged"]["truth_cv"]
    days=arrays["test"]["ridge_logged"]["start_time_ns"]//DAY_NS
    pairs=(("persistence","ridge_logged"),("persistence","ridge_hold_mv"),("ridge_hold_mv","ridge_logged"))
    for reference,candidate in pairs:
        name=candidate+"_vs_"+reference;comparisons[name]={}
        for h in ENDPOINTS:
            difference=endpoint_differences(arrays["test"][reference]["pred_cv"][:,h-1],
                arrays["test"][candidate]["pred_cv"][:,h-1],truth[:,h-1],scale)
            interval=paired_block_interval(difference,days,draws=cfg["bootstrap_draws"],
                seed=cfg["bootstrap_seed"],confidence_level=cfg["confidence_level"])
            interval.update(reference=reference,candidate=candidate,step=h,endpoints=list(ENDPOINT_NAMES),
                fitted_models=1,training_seed_resampling=False,
                dependence="Overlapping rolling starts grouped by whole origin calendar date; one deterministic fitted model")
            comparisons[name][str(h)]=interval
            for j,endpoint in enumerate(ENDPOINT_NAMES):
                comparison_rows.append({"comparison":name,"reference":reference,"candidate":candidate,"step":h,
                    "endpoint":endpoint,"difference":interval["difference"][j],"ci_lower":interval["ci_lower"][j],
                    "ci_upper":interval["ci_upper"][j],"starts":interval["samples"],"calendar_blocks":interval["time_blocks"],
                    "confidence_level":interval["confidence_level"],"positive_means":"candidate lower error",
                    "exploratory":True,"multiple_comparison_adjustment":"none"})
    test_start=arrays["test"]["ridge_logged"]["start_time_ns"]
    result={"metrics":metrics,"event_metrics":event_metrics,"event_context":contexts,"comparisons":comparisons,
            "branches":list(BRANCHES),"test_period":{"start":str(np.datetime64(int(test_start.min()),"ns")),
                "end":str(np.datetime64(int(test_start.max()),"ns")),"starts":len(test_start),
                "calendar_blocks":len(np.unique(days)),"horizon":10},
            "delta_scale":scale.tolist(),"direction_deadbands":bands.tolist(),"source_hashes":sources,"rollout_checks":checks,
            "primary_endpoint":"step10 nine-channel normalized MSE",
            "teacher_forced_scope":"Repeated one-step prediction using actual CV histories; not a recursive forecasting competitor",
            "recorded_operation_scope":"Conditional replay given actual future operations; not an online forecast or causal action effect",
            "hold_operation_scope":"MV kept at observed u_t after step1; fixed-input scenario, not a no-intervention causal counterfactual",
            "event_scope":"Observed mixed-operation segments; no causal effect or physical delay estimated",
            "response_amplitude_note":"Error of predicted change from common initial CV equals endpoint error algebraically; not separate evidence",
            "test_scope":"Previously inspected historical period; exploratory development evaluation",
            "uncertainty":"Whole origin-calendar-day blocks; overlapping starts; one deterministic model; no seed-replication uncertainty; unadjusted percentile intervals"}
    tables={"step_curves.csv":curve_rows,"endpoints.csv":endpoint_rows,"channels.csv":channel_rows,
            "per_day.csv":daily_rows,"comparisons.csv":comparison_rows,"event_metrics.csv":event_rows,
            "event_directions.csv":direction_rows,"event_confusion.csv":confusion_rows,
            "event_context.csv":[{"split":s,**{k:v for k,v in c.items() if k not in ("trigger_counts_per_mv","scope")}}
                                  for s,c in contexts.items()]}
    for name,rows in tables.items():_csv(out/name,rows)
    _json(out/"summary.json",result)
    return result


def render_validation_figures(study_dir,summary=None):
    from .visual_diagnostics_report import _pyplot,_save_figure,_style_axis
    root=Path(study_dir).resolve();result=summary if summary is not None else json.loads((root/"statistics/summary.json").read_text())
    _,cfg,stats,protocol,thresholds,arrays,events,sources,_=load_completed_validation(root)
    folder=root/"figures";folder.mkdir(exist_ok=True);plt,font_path=_pyplot();paths=[];data_files=[]
    period=result["test_period"];dates=period["start"][:10]+"—"+period["end"][:10]
    curve_data=[];effect_data=[];example_data=[]
    fig,axes=plt.subplots(2,2,figsize=(12.6,8.4))
    for j,ax in enumerate(axes.flat):
        for branch in BRANCHES:
            points=[result["metrics"]["test"][branch][str(h)]["physical_mae"][j] for h in range(1,11)]
            ax.plot(range(1,11),points,color=COLORS[branch],linestyle="--" if branch==BRANCHES[-1] else "-",
                    marker=None if branch==BRANCHES[-1] else {"ridge_logged":"o","ridge_hold_mv":"s","persistence":"^"}[branch],
                    markersize=4,linewidth=1.5,label=LABELS[branch])
            for h,point in enumerate(points,1):curve_data.append({"branch":branch,"quantity":QUANTITIES[j],
                "unit":UNITS[j],"step":h,"minutes_after_start":h-1,"mae":point,"starts":period["starts"]})
        ax.set_xticks(range(1,11));ax.set_xlim(.8,10.2);ax.set_ylim(bottom=0)
        ax.set_xlabel("预测步 h（h=1 对应 t；h=10 对应 t+9）");ax.set_ylabel(f"MAE ({UNITS[j]})")
        ax.set_title(TITLES[j]);_style_axis(ax,grid_axis="both")
    handles,labels=axes[0,0].get_legend_handles_labels();fig.legend(handles,labels,loc="upper center",ncol=2,bbox_to_anchor=(.5,.94),frameon=False)
    fig.suptitle("固定 Ridge 的递归预测误差",y=.985)
    fig.text(.5,.025,f"{dates}；{period['starts']:,} 个共同起点，滚动窗口有重叠。灰虚线每步使用真实 CV，仅作诊断。\n"
             "记录操作路径包含未来实际操作；结果是条件回放。既有测试时段已用于开发，当前比较为探索性。",ha="center",fontsize=10)
    fig.subplots_adjust(left=.09,right=.98,bottom=.15,top=.80,wspace=.27,hspace=.48)
    paths+=_save_figure(fig,folder,"ridge_recursive_physical_mae");plt.close(fig)
    _json(folder/"recursive_mae_plot_data.json",curve_data);_csv(folder/"recursive_mae_plot_data.csv",curve_data)
    data_files += [folder/"recursive_mae_plot_data.json",folder/"recursive_mae_plot_data.csv"]
    fig,ax=plt.subplots(figsize=(11.2,5.2));bounds=[0.];positions=[];ticklabels=[]
    for i,h in enumerate(ENDPOINTS):
        for j,branch in enumerate(RECURSIVE[:2]):
            c=result["comparisons"][branch+"_vs_persistence"][str(h)]
            value,lo,hi=[c[k][0] for k in ("difference","ci_lower","ci_upper")];pos=i*3+j
            ax.hlines(pos,lo,hi,color=COLORS[branch],linewidth=1.6);ax.vlines([lo,hi],pos-.08,pos+.08,color=COLORS[branch])
            ax.plot(value,pos,"o" if j==0 else "s",color=COLORS[branch],markersize=6)
            positions.append(pos);ticklabels.append(f"h={h}：{LABELS[branch]}");bounds += [value,lo,hi]
            effect_data.append({"branch":branch,"reference":"persistence","step":h,"endpoint":PRIMARY,
                "difference":value,"ci_lower":lo,"ci_upper":hi,"starts":period["starts"]})
    pad=max((max(bounds)-min(bounds))*.12,1e-5);ax.set_xlim(min(bounds)-pad,max(bounds)+pad)
    ax.set_ylim(max(positions)+.6,-.6);ax.set_yticks(positions,ticklabels);ax.axvline(0,color="black",linestyle="--",linewidth=.9)
    ax.set_xlabel("持续性预测 MSE − Ridge MSE（九通道按训练增量尺度归一化；正值更好）")
    ax.set_title("递归预测相对持续性预测的误差改善");_style_axis(ax)
    fig.text(.5,.025,f"{dates}；{period['calendar_blocks']} 个起点日历块。探索性配对日块 95% 区间，未做多重比较校正。\n"
             "同一个固定模型；没有随机种子重复拟合。滚动起点重叠；记录操作分支使用未来实际操作。",ha="center",fontsize=10)
    fig.subplots_adjust(left=.27,right=.98,top=.9,bottom=.23)
    paths+=_save_figure(fig,folder,"ridge_recursive_primary_effects");plt.close(fig)
    _json(folder/"primary_effects_plot_data.json",effect_data);_csv(folder/"primary_effects_plot_data.csv",effect_data)
    data_files += [folder/"primary_effects_plot_data.json",folder/"primary_effects_plot_data.csv"]
    base=arrays["test"]["ridge_logged"];ev=events["test"]
    for example_number,p in enumerate(ev["example_positions"],1):
        p=int(p);initial=control_values(base["initial_zprev"][p]);observed=control_values(base["truth_cv"][p])
        timestamp=str(np.datetime64(int(base["start_time_ns"][p]),"ns"))[:16].replace("T"," ")
        x=np.arange(-1,10);fig,axes=plt.subplots(2,2,figsize=(12.6,8.5))
        for j,ax in enumerate(axes.flat):
            true_line=np.r_[initial[j],observed[:,j]]
            ax.plot(x,true_line,color="black",linewidth=1.8,marker=".",markersize=5,label="实测轨迹")
            for step,value in zip(x,true_line):example_data.append({"example":example_number,"chain_position":p,
                "start_time":timestamp,"quantity":QUANTITIES[j],"unit":UNITS[j],"series":"observed",
                "minutes_after_start":int(step),"prediction_step":int(step+1),"value":float(value)})
            for branch in RECURSIVE:
                pred=control_values(arrays["test"][branch]["pred_cv"][p]);line=np.r_[initial[j],pred[:,j]]
                ax.plot(x,line,color=COLORS[branch],linestyle="--" if branch=="persistence" else "-",
                    marker={"ridge_logged":"o","ridge_hold_mv":"s","persistence":"^"}[branch],
                    markersize=3.5,linewidth=1.25,label=LABELS[branch])
                for step,value in zip(x,line):example_data.append({"example":example_number,"chain_position":p,
                    "start_time":timestamp,"quantity":QUANTITIES[j],"unit":UNITS[j],"series":branch,
                    "minutes_after_start":int(step),"prediction_step":int(step+1),"value":float(value)})
            ax.axvline(0,color="#777777",linestyle=":",linewidth=.9)
            ax.set_xticks([-1,0,2,4,6,8,9]);ax.set_xlim(-1.25,9.25)
            ax.set_xlabel("相对操作起点的分钟（−1 为实测基准；0 为第1步）")
            ax.set_ylabel(f"{TITLES[j]} ({UNITS[j]})");_style_axis(ax,grid_axis="both")
        handles,labels=axes[0,0].get_legend_handles_labels();fig.legend(handles,labels,loc="upper center",ncol=2,bbox_to_anchor=(.5,.94),frameon=False)
        fig.suptitle(f"操作变化片段 {example_number}：{timestamp}",y=.985)
        mult=int(ev["current_nonzero_channels"][p]);continued=int(ev["future_change_steps"][p])
        fig.text(.5,.025,f"示例按选中片段的时间顺序等距确定；当前 {mult} 个 MV 有变化，后续 9 分钟内 {continued} 步仍有操作变化。\n"
            "记录操作分支以未来实际操作为条件；保持操作分支为固定输入情景。观测片段不代表孤立干预或因果响应。",ha="center",fontsize=10)
        fig.subplots_adjust(left=.10,right=.98,bottom=.15,top=.80,wspace=.30,hspace=.44)
        paths+=_save_figure(fig,folder,f"ridge_operation_example_{example_number:02d}");plt.close(fig)
    _json(folder/"operation_examples_plot_data.json",example_data)
    data_files.append(folder/"operation_examples_plot_data.json")
    if example_data:
        _csv(folder/"operation_examples_plot_data.csv",example_data);data_files.append(folder/"operation_examples_plot_data.csv")
    _json(folder/"operation_examples_selection.json",{"positions":ev["example_positions"].tolist(),
        "indices":ev["example_indices"].tolist(),"selection":"equally spaced positions among chronological selected events, independent of outcomes",
        "selected_event_count":len(ev["selected_positions"]),"example_count":len(ev["example_positions"]),
        "empty_policy":"No example figures if no selected event; no simulated replacement"})
    data_files.append(folder/"operation_examples_selection.json")
    manifest={"renderer":str(Path(__file__).resolve()),"renderer_sha256":_sha(__file__),"font":str(font_path),
        "palette":COLORS,"curve_point_count":len(curve_data),"effect_point_count":len(effect_data),
        "effect_interval_count":len(effect_data),"event_trajectory_point_count":len(example_data),
        "event_example_count":len(ev["example_positions"]),"visual_inspection":"pending",
        "inputs":{str(p.relative_to(root)):_sha(p) for p in [root/"statistics/summary.json",*data_files]},
        "outputs":{str(p.relative_to(root)):_sha(p) for p in paths},"rollout_source_hashes":sources}
    _json(folder/"figure_manifest.json",manifest)
    return manifest


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument("--study-dir",required=True)
    parser.add_argument("--skip-figures",action="store_true");args=parser.parse_args()
    result=summarize_validation(args.study_dir)
    if not args.skip_figures:render_validation_figures(args.study_dir,result)
    print(json.dumps({"rollouts":len(result["rollout_checks"]),"comparisons":len(result["comparisons"]),
                      "test_events":result["event_context"]["test"]["selected_count"]},ensure_ascii=False))


if __name__=="__main__":main()
