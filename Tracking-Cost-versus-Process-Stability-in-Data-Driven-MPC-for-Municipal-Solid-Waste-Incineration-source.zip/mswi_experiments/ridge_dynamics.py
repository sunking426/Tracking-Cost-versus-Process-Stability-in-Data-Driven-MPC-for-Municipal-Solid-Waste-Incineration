"""Frozen numerical Ridge dynamics with explicit recursive input contracts.

The forecast at t consumes MV t-10..t and observed CV t-10..t-1. Recursive
forecasts accept an explicit MV path and feed back predicted CV only. Supplying
recorded future MV makes this a conditional replay, not an autonomous forecast
or an identified causal response to intervention.
"""
from __future__ import annotations

from pathlib import Path
from types import MappingProxyType

import numpy as np

from .data import MINUTE_NS
from .numeric_baselines import linear_increment, numeric_features


def _history_arrays(u_hist, z_hist):
    u = np.asarray(u_hist, dtype=np.float64)
    z = np.asarray(z_hist, dtype=np.float64)
    # Use the same numerical design contract as the fitted baseline.
    numeric_features({'u_hist': u, 'z_hist': z})
    if len(u) == 0:
        raise ValueError('a dynamics call requires at least one history')
    return u, z


def _horizon(value):
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, np.integer)) or value < 1:
        raise ValueError('horizon must be a positive integer')
    return int(value)


class RidgeDynamics:
    """A saved direct Ridge increment predictor; no latent-state/actor adapter.

    Parameters follow the nine-output model archive written by
    ``numeric_baselines``. Its input/target scaling operation remains owned by
    ``linear_increment``. Only a direct increment model should be supplied;
    a residual corrector has different semantics despite similar array shapes.
    """

    def __init__(self, weights):
        shapes = {'x_mean': (178,), 'x_scale': (178,), 'coef': (9, 178),
                  'intercept': (9,), 'delta_scale': (9,)}
        values = {}
        for name, shape in shapes.items():
            value = np.array(weights[name], dtype=np.float64, copy=True)
            if value.shape != shape or not np.isfinite(value).all():
                raise ValueError(f'{name} must be finite with shape {shape}')
            if name.endswith('scale') and np.any(value <= 0):
                raise ValueError(f'{name} must be strictly positive')
            value.flags.writeable = False
            values[name] = value
        kind, alpha = np.asarray(weights['kind']), np.asarray(weights['alpha'])
        if kind.shape != () or str(kind.item()) != 'ridge':
            raise ValueError('RidgeDynamics requires a selected Ridge model')
        if alpha.shape != () or not np.isfinite(float(alpha)) or float(alpha) <= 0:
            raise ValueError('saved Ridge alpha must be finite and positive')
        values['kind'] = 'ridge'
        values['alpha'] = float(alpha)
        self.weights = MappingProxyType(values)
        self.source_path = None

    @classmethod
    def load(cls, path):
        path = Path(path).resolve()
        with np.load(path, allow_pickle=False) as archive:
            required = ('x_mean', 'x_scale', 'coef', 'intercept', 'delta_scale', 'kind', 'alpha')
            if not set(required).issubset(archive.files):
                raise ValueError('incomplete numerical Ridge model archive')
            model = cls({name: archive[name] for name in required})
        model.source_path = path
        return model

    def predict_delta(self, u_hist, z_hist):
        u, z = _history_arrays(u_hist, z_hist)
        x = numeric_features({'u_hist': u, 'z_hist': z})
        with np.errstate(over='raise', invalid='raise', divide='raise'):
            prediction = linear_increment(self.weights, x)
        if prediction.shape != (len(u), 9) or not np.isfinite(prediction).all():
            raise FloatingPointError('Ridge produced nonfinite or invalid increments')
        return prediction

    def predict_next(self, u_hist, z_hist):
        u, z = _history_arrays(u_hist, z_hist)
        with np.errstate(over='raise', invalid='raise'):
            prediction = z[:, -1] + self.predict_delta(u, z)
        if not np.isfinite(prediction).all():
            raise FloatingPointError('Ridge produced nonfinite process forecasts')
        return prediction


def recursive_rollout(model, u_hist, z_hist, mv_path):
    """Return physical CV forecasts (N,H,9) with predicted-only CV feedback.

    ``mv_path[:, 0]`` is the known current u_t and must equal u_hist[:, -1].
    Remaining entries supply u_(t+1), ..., u_(t+H-1). These may be planned values
    or a recorded path for conditional validation. No future CV argument exists.
    Input arrays are not mutated. No clipping or silent fallback is performed.
    """
    u, z = _history_arrays(u_hist, z_hist)
    path = np.asarray(mv_path, dtype=np.float64)
    if path.ndim != 3 or path.shape[0] != len(u) or path.shape[2] != 8 or path.shape[1] < 1:
        raise ValueError('MV path must have shape (N, positive horizon, 8)')
    if not np.isfinite(path).all():
        raise ValueError('MV path must be finite')
    if not np.array_equal(path[:, 0], u[:, -1]):
        raise ValueError('first MV path entry must equal the known current MV')
    u, z = u.copy(), z.copy()
    predictions = np.empty((len(u), path.shape[1], 9), dtype=np.float64)
    for step in range(path.shape[1]):
        prediction = np.asarray(model.predict_next(u, z), dtype=np.float64)
        if prediction.shape != (len(u), 9) or not np.isfinite(prediction).all():
            raise FloatingPointError(f'invalid recursive prediction at step {step + 1}')
        predictions[:, step] = prediction
        if step + 1 < path.shape[1]:
            z = np.concatenate((z[:, 1:], prediction[:, None]), axis=1)
            u = np.concatenate((u[:, 1:], path[:, step + 1, None]), axis=1)
    return predictions


def persistence_rollout(z_hist, horizon):
    """Hold the final initially observed CV fixed over every forecast step."""
    z = np.asarray(z_hist, dtype=np.float64)
    if z.ndim != 3 or z.shape[1:] != (10, 9) or len(z) == 0 or not np.isfinite(z).all():
        raise ValueError('persistence requires finite CV histories (N,10,9)')
    return np.repeat(z[:, -1, None], _horizon(horizon), axis=1)


def _integer_vector(data, name, length=None):
    value = np.asarray(data[name])
    if value.ndim != 1 or not np.issubdtype(value.dtype, np.integer) or (length is not None and len(value) != length):
        raise ValueError(f'{name} must be a one-dimensional integer array of the expected length')
    return value.astype(np.int64, copy=False)


def continuous_chains(data, split='test', horizon=10):
    """Return every complete consecutive chain inside an existing partition.

    The original prepared source-based partition memberships are retained, and
    their source ranges must not overlap. Missing links, temporal gaps, and
    links outside the selected partition stop a chain. Starts overlap by design;
    callers must use time-blocked uncertainty, not treat all windows as iid.
    No CV labels, operating values or forecast errors influence selection.
    An empty (0,H) result honestly represents no eligible complete chain.
    """
    horizon = _horizon(horizon)
    if split not in ('train', 'val', 'test'):
        raise ValueError('split must be train, val or test')
    times = _integer_vector(data, 'time_ns')
    n = len(times)
    if n == 0 or np.any(np.diff(times) <= 0):
        raise ValueError('source times must be nonempty and strictly increasing')
    following = _integer_vector(data, 'next_idx', n)
    if np.any(following < -1) or np.any(following >= n):
        raise ValueError('next_idx contains an invalid source index')
    source_start = _integer_vector(data, 'source_start_ns', n)
    source_end = _integer_vector(data, 'source_end_ns', n)
    if np.any(source_start > times) or np.any(source_end < times):
        raise ValueError('recorded sources must enclose each prepared sample time')
    partitions, assigned = {}, np.zeros(n, dtype=bool)
    last_source_end = None
    for name in ('train', 'val', 'test'):
        idx = _integer_vector(data, name + '_idx')
        if len(idx) == 0 or np.any(idx < 0) or np.any(idx >= n) or np.any(np.diff(idx) <= 0):
            raise ValueError('partition indices must be nonempty, valid, unique and ordered')
        if assigned[idx].any():
            raise ValueError('prepared partitions overlap')
        assigned[idx] = True
        if last_source_end is not None and source_start[idx].min() <= last_source_end:
            raise ValueError('prepared partition source ranges overlap or are not chronological')
        last_source_end = int(source_end[idx].max())
        partitions[name] = idx
    indices = partitions[split]
    allowed = np.zeros(n, dtype=bool)
    allowed[indices] = True
    chains = np.full((len(indices), horizon), -1, dtype=np.int64)
    chains[:, 0] = indices
    alive = np.ones(len(indices), dtype=bool)
    for step in range(1, horizon):
        previous = np.where(alive, chains[:, step - 1], 0)
        child = following[previous]
        safe_child = np.maximum(child, 0)
        keep = alive & (child >= 0) & allowed[safe_child]
        keep &= times[safe_child] - times[previous] == MINUTE_NS
        chains[:, step] = np.where(keep, child, -1)
        alive = keep
    return chains[alive].copy()
