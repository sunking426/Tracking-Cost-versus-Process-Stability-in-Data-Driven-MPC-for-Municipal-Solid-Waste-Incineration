"""Paired direct forecasts using frozen raw-image representations.

The encoder is an external, frozen input. This module owns training-only PCA,
conditional Ridge probes, their protocol, and complete paired predictions.
It never changes the previous descriptor study or any manuscript.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import time

import numpy as np

from .data import MINUTE_NS, control_values
from .visual_diagnostics import load_study
from .visual_diagnostics_horizons import (
    ALPHAS, CONTROL_NAMES, apply_direct_ridge, direct_interval, eligible_pairs,
    fit_direct_ridge,
)
from .visual_diagnostics_statistics import DAY_NS


HORIZONS = (1, 5, 10)
METHODS = ("sensor", "timing", "old52", "quality", "rgb32", "gray32", "null_rgb32")
PARTITIONS = ("train", "val", "test")


def _sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _json(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
    temporary.replace(path)


def _archive(path):
    with np.load(path, allow_pickle=False) as saved:
        return {key: saved[key] for key in saved.files}


def validate_encoder_artifact(manifest_path, embeddings_path):
    """Require a completed encoder run tied to the exact embedding archive."""
    manifest = json.loads(Path(manifest_path).read_text())
    if manifest.get("status") != "completed":
        raise ValueError("encoder manifest must report a completed run")
    expected = manifest.get("embeddings_sha256")
    if not isinstance(expected, str) or expected != _sha(embeddings_path):
        raise ValueError("embedding archive does not match the completed encoder manifest")
    return manifest


def validate_capture_inputs(data, embeddings, quality):
    """Align quality by exact capture identity and reject future/missing inputs."""
    times = np.asarray(embeddings["capture_time_ns"])
    mapping = np.asarray(embeddings["sample_capture_index"])
    n = len(data["time_ns"])
    if (times.ndim != 1 or not len(times) or not np.issubdtype(times.dtype, np.integer)
            or np.any(np.diff(times) <= 0)):
        raise ValueError("embedding capture timestamps must be unique and increasing")
    if (mapping.shape != (n,) or not np.issubdtype(mapping.dtype, np.integer)
            or mapping.min() < 0 or mapping.max() >= len(times)):
        raise ValueError("invalid sample-to-capture mapping")
    if not np.array_equal(times[mapping], data["visual_time_ns"]):
        raise ValueError("embedding captures do not match the frozen selected images")
    if np.any(times[mapping] > np.asarray(data["time_ns"]) - MINUTE_NS):
        raise ValueError("positive image input exceeds the origin input cutoff")
    for view in ("rgb", "gray"):
        matrix = np.asarray(embeddings[view])
        if matrix.shape != (len(times), 512) or not np.isfinite(matrix).all():
            raise ValueError("encoder views must contain finite 512-dimensional rows")
    qt = np.asarray(quality["capture_time_ns"])
    qv, columns = np.asarray(quality["quality"]), np.asarray(quality["columns"])
    if (qt.ndim != 1 or not len(qt) or not np.issubdtype(qt.dtype, np.integer)
            or np.any(np.diff(qt) <= 0) or qv.ndim != 2 or len(qv) != len(qt)
            or columns.shape != (qv.shape[1],) or not len(columns)
            or len(np.unique(columns)) != len(columns) or not np.isfinite(qv).all()):
        raise ValueError("invalid image-quality capture matrix or column names")
    positions = np.searchsorted(qt, times)
    if np.any(positions >= len(qt)) or not np.array_equal(qt[positions], times):
        raise ValueError("image quality is missing an encoded capture")
    if "sample_capture_index" in quality:
        qm = np.asarray(quality["sample_capture_index"])
        if (qm.shape != (n,) or not np.issubdtype(qm.dtype, np.integer)
                or qm.min() < 0 or qm.max() >= len(qt)
                or not np.array_equal(qt[qm], data["visual_time_ns"])):
            raise ValueError("image-quality sample capture identities disagree")
    partitions = {name: np.unique(mapping[data[name + "_idx"]]) for name in PARTITIONS}
    for i, left in enumerate(PARTITIONS):
        for right in PARTITIONS[i + 1:]:
            if np.intersect1d(partitions[left], partitions[right]).size:
                raise ValueError("a selected capture occurs in multiple outer partitions")
    return qv[positions].astype(np.float64), columns.astype(str), partitions


def fit_capture_pca(features, sample_capture_index, train_rows, components=32):
    """Fit unweighted PCA on unique selected training captures only."""
    from sklearn.decomposition import PCA

    values = np.asarray(features, dtype=np.float64)
    mapping, rows = np.asarray(sample_capture_index), np.asarray(train_rows)
    if values.ndim != 2 or not np.isfinite(values).all():
        raise ValueError("PCA embeddings must be a finite matrix")
    if (mapping.ndim != 1 or rows.ndim != 1 or not len(rows)
            or not np.issubdtype(mapping.dtype, np.integer)
            or not np.issubdtype(rows.dtype, np.integer)
            or rows.min() < 0 or rows.max() >= len(mapping)
            or mapping.min() < 0 or mapping.max() >= len(values)):
        raise ValueError("invalid PCA capture or training row indices")
    unique_train = np.unique(mapping[rows])
    if not isinstance(components, int) or not 1 <= components <= min(len(unique_train), values.shape[1]):
        raise ValueError("PCA dimension exceeds unique training capture support")
    model = PCA(n_components=components, svd_solver="full", whiten=False).fit(values[unique_train])
    fitted = {"mean": model.mean_, "components": model.components_,
              "explained_variance": model.explained_variance_,
              "explained_variance_ratio": model.explained_variance_ratio_,
              "singular_values": model.singular_values_, "train_capture_indices": unique_train}
    # Use exactly the saved-weight formula both here and in replay.
    scores = (values - fitted["mean"]) @ fitted["components"].T
    return fitted, scores


def validate_null_donors(data, mapping, donors):
    """Check inherited block permutation; it is deliberately noncausal."""
    mapping, donors = np.asarray(mapping), np.asarray(donors)
    if donors.shape != mapping.shape or not np.issubdtype(donors.dtype, np.integer):
        raise ValueError("invalid inherited null donor mapping")
    safe = np.arange(len(donors), dtype=np.int64)
    metadata = {}
    for name in PARTITIONS:
        rows = np.asarray(data[name + "_idx"])
        source = donors[rows]
        if not np.isin(source, rows).all():
            raise ValueError("null donors must remain within the same outer partition")
        captures, first, inverse = np.unique(mapping[rows], return_index=True, return_inverse=True)
        donor_captures = mapping[source]
        if not np.array_equal(donor_captures, donor_captures[first][inverse]):
            raise ValueError("rows sharing a capture must share null donor content")
        safe[rows] = source
        metadata[name] = {
            "samples": len(rows), "unique_captures": len(captures),
            "future_donor_fraction": float(np.mean(data["visual_time_ns"][source] > data["visual_time_ns"][rows])),
            "unchanged_capture_fraction": float(np.mean(donor_captures == mapping[rows])),
            "donors_within_partition": True,
        }
    return safe, metadata


def origin_design(data, variants, features, method, origins):
    """Build only origin-known covariates; no destination input is accepted."""
    if method not in METHODS:
        raise ValueError("unknown representation probe method")
    rows = np.asarray(origins, dtype=np.int64)
    numeric = np.concatenate([data[key][rows].reshape(len(rows), -1)
                              for key in ("u_hist", "z_hist")], axis=1)
    if numeric.shape[1] != 178:
        raise ValueError("representation probe expects 11x8 MV and 10x9 CV history")
    chunks = [numeric]
    if method != "sensor":
        chunks.append(variants["timing4"][rows])
    if method == "old52":
        chunks.append(variants["original52"][rows])
    if method in ("quality", "rgb32", "gray32", "null_rgb32"):
        chunks.append(features["quality"][rows])
    if method in ("rgb32", "gray32", "null_rgb32"):
        chunks.append(features[method][rows])
    design = np.concatenate(chunks, axis=1).astype(np.float64)
    if not len(design) or not np.isfinite(design).all():
        raise ValueError("invalid or nonfinite origin design")
    return design


def freeze_protocol(path, specification):
    """Create the protocol before fitting, or reject an incompatible rerun."""
    path = Path(path)
    current = dict(specification)
    if path.exists():
        previous = json.loads(path.read_text())
        if {k: v for k, v in previous.items() if k != "frozen_before_fitting_unix"} != current:
            raise ValueError("representation probe differs from its frozen protocol")
        return previous
    current["frozen_before_fitting_unix"] = time.time()
    _json(path, current)
    return current


def _comparison_priority(horizon, candidate, reference):
    primary = horizon == 5 and candidate == "rgb32" and reference in ("quality", "null_rgb32")
    return {name: ("prespecified_this_round_exploratory_primary" if primary and name in ("steam", "oxygen")
                   else "exploratory_secondary") for name in CONTROL_NAMES}


def run_representation_probe(config_file):
    """Freeze inputs, fit PCA and all probes, then score every saved split."""
    from threadpoolctl import threadpool_limits

    config_path = Path(config_file).resolve()
    config = json.loads(config_path.read_text())
    root = config_path.parent
    base_path = (root / config["base_config"]).resolve()
    base, data, _, variants, metadata, old_study = load_study(base_path)
    output = (root / config["output_dir"]).resolve() / "probe"
    output.mkdir(parents=True, exist_ok=True)
    if (output / "completed.json").exists():
        raise FileExistsError("completed probe is immutable; use a new output directory for a refit")
    paths = {key: (root / config[key]).resolve() for key in
             ("embeddings_file", "quality_file", "encoder_manifest")}
    validate_encoder_artifact(paths["encoder_manifest"], paths["embeddings_file"])
    embeddings, quality = _archive(paths["embeddings_file"]), _archive(paths["quality_file"])
    quality_matrix, quality_columns, capture_partitions = validate_capture_inputs(data, embeddings, quality)
    mapping = embeddings["sample_capture_index"]
    donors, donor_info = validate_null_donors(data, mapping, metadata["null_donor_sample_index"])
    pairs = {h: {name: eligible_pairs(data, name, h) for name in PARTITIONS} for h in HORIZONS}
    if any(len(pair[0]) < 2 for parts in pairs.values() for pair in parts.values()):
        raise ValueError("not enough eligible origins for every horizon and partition")
    components = int(config.get("pca_components", 32))
    if components != 32:
        raise ValueError("the declared rgb32/gray32 probe requires exactly 32 PCA components")
    options = dict(base["diagnostics"])
    options.update({key: config[key] for key in ("bootstrap_draws", "bootstrap_seed", "confidence_level") if key in config})
    old_protocol = json.loads((old_study / "protocol.json").read_text())
    for path, digest in old_protocol["input_hashes"].items():
        if _sha(path) != digest:
            raise ValueError("a frozen source input or manuscript changed before representation probing")
    if _sha(old_study / "feature_variants.npz") != old_protocol["feature_archive_sha256"]:
        raise ValueError("previous descriptor feature archive changed")
    frozen_files = [config_path, base_path, *paths.values(), old_study / "protocol.json",
                    old_study / "feature_variants.npz", old_study / "feature_metadata.npz"]
    input_hashes = {str(path): _sha(path) for path in frozen_files}
    input_hashes.update(old_protocol["input_hashes"])
    code_files = [Path(__file__).resolve().with_name(name) for name in
                  ("visual_representation_probe.py", "visual_diagnostics_horizons.py",
                   "visual_diagnostics_statistics.py", "visual_diagnostics.py", "data.py")]
    protocol = freeze_protocol(output / "protocol.json", {
        "scope": "frozen image representation predictive diagnostics; no policy or plant intervention",
        "config": config, "methods": list(METHODS), "horizons_minutes": list(HORIZONS),
        "primary_endpoints": "5-minute steam MAE and oxygen MAE, rgb32 versus quality and null_rgb32; exploratory on an historically inspected test period",
        "target_names": list(CONTROL_NAMES), "units": ["degC", "Pa", "t/h", "vol%"],
        "target_definition": "destination control_values(z_target) minus origin control_values(z_prev); h-1 continuous minute links, same outer partition",
        "numeric_inputs": "178 origin-known entries from 11x8 MV and 10x9 CV; no future MV/CV inputs",
        "input_composition": {
            "sensor": "numeric", "timing": "numeric + timing4", "old52": "numeric + timing4 + original52",
            "quality": "numeric + timing4 + ROI quality/appearance", "rgb32": "quality design + RGB PCA32",
            "gray32": "quality design + grayscale PCA32", "null_rgb32": "quality design + misaligned RGB PCA32"},
        "quality_columns": quality_columns.tolist(), "capture_counts": {k: len(v) for k, v in capture_partitions.items()},
        "pca": {"components": components, "solver": "full", "whiten": False,
                "fitting_rows": "unique capture indices selected by outer training rows; no duplicated-minute weighting",
                "centering": "training capture mean only; no pre-PCA feature scaling",
                "test_use": "transform only; encoder frozen and no PCA/feature selection using test outcomes"},
        "regression": {"alphas": list(ALPHAS), "solver": "cholesky Ridge", "scaling": "eligible training X and four target changes only",
                       "selection": "mean 4-output standardized validation MSE; all 21 fits selected before test scoring"},
        "negative_control": {"source": "previous frozen six-capture block donor mapping",
                             "only_permuted_inputs": "RGB PCA coordinates; quality and timing remain aligned",
                             "scope": "may use future capture donors within an outer partition; intentionally noncausal broken-correspondence diagnostic",
                             "partitions": donor_info},
        "intervals": {"difference": "reference absolute error minus candidate absolute error; positive favors candidate",
                      "resampling": "paired origin-calendar-day bootstrap; deterministic fits, no neural seed axis",
                      "draws": int(options["bootstrap_draws"]), "seed": int(options["bootstrap_seed"]),
                      "confidence_level": float(options["confidence_level"]), "multiple_comparison_adjustment": "none"},
        "eligible_counts": {str(h): {k: len(pair[0]) for k, pair in parts.items()} for h, parts in pairs.items()},
        "test_scope": "historically inspected existing test period; this protocol is frozen only before this round's fits",
        "source_input_hashes": input_hashes, "code_hashes": {str(p): _sha(p) for p in code_files},
    })
    _json(output / "config.json", config)
    result = {"status": "running", "protocol": protocol, "horizons": {}}
    features = {"quality": quality_matrix[mapping]}
    artifacts = []
    with threadpool_limits(limits=1):
        for view in ("rgb", "gray"):
            fitted_pca, scores = fit_capture_pca(embeddings[view], mapping, data["train_idx"], components)
            path = output / f"pca_{view}.npz"
            np.savez_compressed(path, **fitted_pca, capture_time_ns=embeddings["capture_time_ns"])
            artifacts.append(path)
            features[view + "32"] = scores[mapping]
        features["null_rgb32"] = features["rgb32"][donors]
        feature_path = output / "prepared_features.npz"
        np.savez_compressed(feature_path, **features, sample_capture_index=mapping,
                            null_donor_sample_index=donors, quality_columns=quality_columns)
        artifacts.append(feature_path)
        # Complete every model and validation selection before any test scoring.
        for horizon, parts in pairs.items():
            horizon_dir = output / f"horizon_{horizon:02d}"
            horizon_dir.mkdir(exist_ok=True)
            pair_path = horizon_dir / "eligible_pairs.npz"
            np.savez_compressed(pair_path, **{name + suffix: pair[i] for name, pair in parts.items()
                                             for suffix, i in (("_origin_indices", 0), ("_destination_indices", 1))})
            artifacts.append(pair_path)
            train_origin, train_destination = parts["train"]
            val_origin, val_destination = parts["val"]
            train_previous = control_values(data["z_prev"][train_origin]).astype(np.float64)
            val_previous = control_values(data["z_prev"][val_origin]).astype(np.float64)
            train_change = control_values(data["z_target"][train_destination]).astype(np.float64) - train_previous
            val_change = control_values(data["z_target"][val_destination]).astype(np.float64) - val_previous
            result["horizons"][str(horizon)] = {"eligible_counts": protocol["eligible_counts"][str(horizon)],
                                                  "methods": {}, "comparisons": {}}
            for method in METHODS:
                method_dir = horizon_dir / method
                method_dir.mkdir(exist_ok=True)
                tx = origin_design(data, variants, features, method, train_origin)
                vx = origin_design(data, variants, features, method, val_origin)
                fitted = fit_direct_ridge(tx, train_change, vx, val_change)
                path = method_dir / "ridge_weights.npz"
                np.savez_compressed(path, **fitted)
                artifacts.append(path)
                selection = {"alpha": float(fitted["alpha"]), "alphas": fitted["alphas"].tolist(),
                             "val_normalized_mse": fitted["val_normalized_mse"].tolist(),
                             "input_dimension": tx.shape[1], "weights_sha256": _sha(path)}
                _json(method_dir / "selection.json", selection)
                result["horizons"][str(horizon)]["methods"][method] = selection
            print(f"representation fitting completed: horizon={horizon}, methods={len(METHODS)}", flush=True)
        _json(output / "fitting_completed.json", {"completed_unix": time.time(), "fits": len(HORIZONS) * len(METHODS),
                                                   "test_predictions_written": False, "protocol_sha256": _sha(output / "protocol.json")})
        for horizon, parts in pairs.items():
            horizon_dir = output / f"horizon_{horizon:02d}"
            horizon_result = result["horizons"][str(horizon)]
            errors = {}
            for method in METHODS:
                method_dir = horizon_dir / method
                fitted = _archive(method_dir / "ridge_weights.npz")
                split_results = {}
                for name, (origins, destinations) in parts.items():
                    truth = control_values(data["z_target"][destinations]).astype(np.float64)
                    previous = control_values(data["z_prev"][origins]).astype(np.float64)
                    pred = apply_direct_ridge(fitted, origin_design(data, variants, features, method, origins), previous)
                    error = pred - truth
                    if not np.isfinite(error).all():
                        raise FloatingPointError("nonfinite representation probe prediction")
                    path = method_dir / f"{name}_predictions.npz"
                    np.savez_compressed(path, indices=origins, destination_indices=destinations,
                                        time_ns=data["time_ns"][origins], destination_time_ns=data["time_ns"][destinations],
                                        truth=truth, origin_previous=previous, pred=pred, error=error)
                    artifacts.append(path)
                    split_results[name] = {"mae": np.abs(error).mean(axis=0).tolist(),
                                           "rmse": np.sqrt(np.square(error).mean(axis=0)).tolist(),
                                           "samples": len(origins), "predictions_sha256": _sha(path)}
                    if name == "test":
                        errors[method] = error
                horizon_result["methods"][method].update(split_results["test"])
                horizon_result["methods"][method]["split_metrics"] = split_results
            comparisons = {(method, reference) for reference in ("sensor", "timing", "quality")
                           for method in METHODS if method != reference}
            comparisons.update({("rgb32", "null_rgb32"), ("rgb32", "gray32"), ("rgb32", "old52")})
            days = data["time_ns"][parts["test"][0]] // DAY_NS
            for method, reference in sorted(comparisons):
                row = direct_interval(np.abs(errors[reference]) - np.abs(errors[method]), days, options)
                row.update({"candidate": method, "reference": reference,
                            "endpoint_priorities": _comparison_priority(horizon, method, reference)})
                horizon_result["comparisons"][method + "_vs_" + reference] = row
            _json(output / "results.json", result)
            print(f"representation scoring completed: horizon={horizon}", flush=True)
    for path, digest in input_hashes.items():
        if _sha(path) != digest:
            raise AssertionError("a frozen source changed during probing")
    for path, digest in protocol["code_hashes"].items():
        if _sha(path) != digest:
            raise AssertionError("probe code changed during fitting")
    result["status"] = "completed"
    _json(output / "results.json", result)
    _json(output / "artifact_hashes.json", {str(p.relative_to(output)): _sha(p) for p in artifacts})
    _json(output / "completed.json", {"status": "completed", "fits": len(HORIZONS) * len(METHODS),
                                       "all_source_inputs_unchanged": True, "all_probe_code_unchanged": True,
                                       "results_sha256": _sha(output / "results.json"),
                                       "protocol_sha256": _sha(output / "protocol.json"),
                                       "artifact_hashes_sha256": _sha(output / "artifact_hashes.json")})
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    run_representation_probe(args.config)


if __name__ == "__main__":
    main()
