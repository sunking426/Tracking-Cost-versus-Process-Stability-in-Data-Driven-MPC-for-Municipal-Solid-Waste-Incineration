"""Audit and summarize the frozen four-geometry observed-outcome study.

No model fitting or test-based selection occurs here. All methods remain visible;
the primary comparison uses the geometry already selected on validation log loss.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from .numeric_baselines import sha256, write_json
from .numeric_baselines_report import metric_summary
from .rgb_control_diagnostic_models import binary_metrics, paired_day_bootstrap
from .rgb_control_diagnostic_report import archive, csv_write, validate_probability_archive
from .rgb_geometry_study import GEOMETRIES, METHODS, TASKS, paths, select_geometry
from .ridge_validation_report import endpoint_differences
from .visual_diagnostics_statistics import DAY_NS, paired_block_interval


CLASS_METHODS = (*METHODS, 'selected_stale')
PHYSICAL = ('temperature', 'pressure', 'steam', 'oxygen')
UNITS = ('degC', 'Pa', 't/h', 'vol%')
REG_ENDPOINTS = ('normalized_mse', *[name+'_mae' for name in PHYSICAL])
LABELS = {'numeric':'Numerical', 'quality':'Image statistics',
          'A':'A: squash/global', 'B':'B: letterbox/global',
          'C':'C: squash/spatial', 'D':'D: letterbox/spatial',
          'selected_stale':'Matched older RGB'}
COLORS = {'numeric':'#777777', 'quality':'#aaaaaa', 'A':'#1f77b4',
          'B':'#ff7f0e', 'C':'#2ca02c', 'D':'#9467bd'}
TITLES = {'thermal_change':'Future temperature movement',
          'action_change':'Next-minute MV change'}


def declared_contrasts(selected):
    """Keep declared contrast names even when two compare the same pair."""
    if selected not in GEOMETRIES:
        raise ValueError('unknown validation-selected geometry')
    return [('selected_vs_quality','quality',selected),
            ('selected_vs_numeric','numeric',selected),
            ('selected_vs_A','A',selected),
            ('selected_vs_stale','selected_stale',selected),
            ('B_vs_A','A','B'), ('D_vs_C','C','D'),
            ('C_vs_A','A','C'), ('D_vs_B','B','D'), ('D_vs_A','A','D')]


def validate_regression_archive(row):
    if not {'indices','time_ns','truth_cv','pred_cv'}.issubset(row):
        raise ValueError('missing regression archive arrays')
    n = len(row['indices'])
    for name in ('indices','time_ns'):
        values = row[name]
        if (values.shape != (n,) or not np.issubdtype(values.dtype,np.integer)
                or np.any(np.diff(values) <= 0)):
            raise ValueError('invalid regression chronological identity: '+name)
    for name in ('truth_cv','pred_cv'):
        if n == 0 or row[name].shape != (n,9) or not np.isfinite(row[name]).all():
            raise ValueError('invalid regression nine-CV array: '+name)


def load_study(study_dir):
    root = Path(study_dir).resolve()
    cfg = json.loads((root/'config.json').read_text())
    selection = json.loads((root/'selection.json').read_text())
    frozen = json.loads((root/'selection_frozen.json').read_text())
    manifest = json.loads((root/'predictions_manifest.json').read_text())
    if (selection.get('status') != 'complete' or frozen.get('status') != 'complete'
            or manifest.get('status') != 'complete'
            or manifest['selection_sha256'] != sha256(root/'selection.json')
            or manifest['selection_frozen_sha256'] != sha256(root/'selection_frozen.json')):
        raise ValueError('completed frozen validation selection required')
    selected_class = {(r['task'],r['method']):r for r in selection['classification']}
    selected_reg = {r['method']:r for r in selection['regression']}
    if (set(selected_class) != {(t,m) for t in TASKS for m in CLASS_METHODS}
            or len(selection['classification']) != 14 or set(selected_reg) != set(METHODS)
            or len(selection['regression']) != 6):
        raise ValueError('all 14 classifiers and 6 regressors must be frozen')
    required = {'config.json','selection.json','stats.json','protocol.json','preparation.json',
                'classification_prepared.npz','regression_prepared.npz'}
    required.update(r['model_path'] for r in [*selected_class.values(),*selected_reg.values()])
    if not required.issubset(frozen['files']) or not frozen['source_code_hashes']:
        raise ValueError('frozen source/model inventory incomplete')
    for name,digest in frozen['files'].items():
        if sha256(root/name) != digest:
            raise ValueError('frozen artifact changed: '+name)
    for name,digest in frozen['source_code_hashes'].items():
        if sha256(Path(name)) != digest:
            raise ValueError('frozen source changed: '+name)
    for task in TASKS:
        winner = select_geometry([r for r in selection['classification'] if r['task']==task], 'val_log_loss')
        if selection['selected_geometry'][task] != winner:
            raise ValueError('geometry differs from validation selection')
        if selected_class[(task,'selected_stale')]['geometry'] != winner:
            raise ValueError('older-image geometry differs from selected geometry')
    if selection['selected_regression_geometry'] != select_geometry(selection['regression'],'val_normalized_mse'):
        raise ValueError('regression geometry differs from validation selection')
    cls = archive(root/'classification_prepared.npz')
    reg = archive(root/'regression_prepared.npz')
    scale = np.asarray(json.loads((root/'stats.json').read_text())['delta_scale'])
    if (scale.shape != (9,) or not np.isfinite(scale).all() or np.any(scale <= 0)
            or not np.array_equal(scale,reg['delta_scale'])):
        raise ValueError('canonical nine-CV normalization scales differ')
    expected = {('classification',s,t,m) for s in ('val','test') for t in TASKS for m in CLASS_METHODS}
    expected.update(('regression',s,'',m) for s in ('val','test') for m in METHODS)
    rows,checks = {},[]
    for item in manifest['files']:
        kind,split,task,method = item['kind'],item['split'],item.get('task',''),item['method']
        key = kind,split,task,method
        name = f'classification/{split}/{task}_{method}.npz' if kind=='classification' else f'regression/{split}/{method}.npz'
        if (key not in expected or key in rows or item['path'] != name
                or sha256(root/name) != item['sha256']):
            raise ValueError('prediction inventory/hash mismatch')
        row = archive(root/name)
        if kind == 'classification':
            validate_probability_archive(row)
            for field in ('indices','time_ns'):
                if not np.array_equal(row[field],cls[split+'_'+field]):
                    raise ValueError('classification differs from prepared identity')
            if not np.array_equal(row['y'],cls[split+'_'+task]):
                raise ValueError('classification differs from prepared observed label')
            if float(row['threshold']) != selected_class[(task,method)]['alarm_threshold']:
                raise ValueError('alarm threshold differs from frozen validation selection')
        else:
            validate_regression_archive(row)
            indices = reg[split+'_indices']
            if (not np.array_equal(row['indices'],indices)
                    or not np.array_equal(row['time_ns'],reg['time_ns'][indices])):
                raise ValueError('regression differs from prepared identity')
            if not np.array_equal(row['truth_cv'],reg['z_target'][indices]):
                raise ValueError('regression differs from prepared observed target')
        rows[key] = row
        checks.append({'kind':kind,'split':split,'task':task,'method':method,
                       'samples':len(row['indices']),'sha256':item['sha256']})
    if set(rows) != expected:
        raise ValueError('all 40 unique prediction archives required')
    # Verify validation records and alarms without consulting test rankings.
    for (task,method),selected in selected_class.items():
        row = rows[('classification','val',task,method)]
        loss = binary_metrics(row['y'],row['probability'],float(row['threshold']))['log_loss']
        if not np.isclose(loss,selected['selected']['val_log_loss'],rtol=1e-10,atol=1e-12):
            raise ValueError('validation log loss differs from selection record')
        threshold = np.quantile(row['probability'],cfg['alarm_quantile'],method='linear')
        if not np.isclose(float(row['threshold']),threshold,rtol=1e-12,atol=1e-14):
            raise ValueError('alarm threshold is not the frozen validation quantile')
    for method,selected in selected_reg.items():
        row = rows[('regression','val','',method)]
        score = metric_summary(row['pred_cv'][None],row['truth_cv'],scale)['normalized_mse']
        if not np.isclose(score,selected['selected']['val_normalized_mse'],rtol=1e-10,atol=1e-12):
            raise ValueError('validation NMSE differs from selection record')
    return root,cfg,selection,rows,scale,checks


def summarize(study_dir):
    root,cfg,selection,rows,scale,checks = load_study(study_dir)
    classification = {s:{t:{} for t in TASKS} for s in ('val','test')}
    regression = {s:{} for s in ('val','test')}
    class_table,reg_table,channel_table = [],[],[]
    for (kind,split,task,method),row in rows.items():
        if kind == 'classification':
            result = binary_metrics(row['y'],row['probability'],float(row['threshold']))
            classification[split][task][method] = result
            class_table.append({'split':split,'task':task,'method':method,
                **{k:v for k,v in result.items() if v is None or isinstance(v,(int,float,str,bool))}})
        else:
            result = metric_summary(row['pred_cv'][None],row['truth_cv'],scale)
            regression[split][method] = result
            reg_table.append({'split':split,'method':method,'samples':result['samples'],
                'normalized_mse':result['normalized_mse'],
                **{name+'_mae':result['physical_mae'][i] for i,name in enumerate(PHYSICAL)},
                **{name+'_rmse':result['physical_rmse'][i] for i,name in enumerate(PHYSICAL)}})
            channel_table.extend({'split':split,'method':method,'channel':j,
                'mae':result['channel_mae'][j],'rmse':result['channel_rmse'][j]} for j in range(9))
    settings = {k:cfg[k] for k in ('confidence_level',)}
    settings.update(draws=cfg['bootstrap_draws'],seed=cfg['bootstrap_seed'])
    comparisons,class_comparison_table = {},[]
    for task in TASKS:
        comparisons[task] = {}
        for name,reference,candidate in declared_contrasts(selection['selected_geometry'][task]):
            ref,cand = [rows[('classification','test',task,m)] for m in (reference,candidate)]
            result = paired_day_bootstrap(cand['y'],ref['probability'],cand['probability'],cand['time_ns'],**settings)
            result.update(reference=reference,candidate=candidate)
            comparisons[task][name] = result
            for j,endpoint in enumerate(result['endpoint_names']):
                class_comparison_table.append({'task':task,'contrast':name,'reference':reference,
                    'candidate':candidate,'metric':endpoint,'difference':result['difference'][j],
                    'ci_lower':result['ci_lower'][j],'ci_upper':result['ci_upper'][j],
                    'valid_draws':result['valid_draws'][j],'undefined_draws':result['undefined_draws'][j]})
    reg_comparisons,reg_comparison_table = {},[]
    for candidate in GEOMETRIES:
        for reference in ('quality','numeric'):
            ref,cand = [rows[('regression','test','',m)] for m in (reference,candidate)]
            delta = endpoint_differences(ref['pred_cv'],cand['pred_cv'],cand['truth_cv'],scale)
            result = paired_block_interval(delta,cand['time_ns']//DAY_NS,**settings)
            result.update(reference=reference,candidate=candidate,endpoint_names=list(REG_ENDPOINTS),
                          direction='positive favors candidate: reference minus candidate error')
            name = candidate+'_vs_'+reference;reg_comparisons[name] = result
            for j,endpoint in enumerate(REG_ENDPOINTS):
                reg_comparison_table.append({'contrast':name,'reference':reference,'candidate':candidate,
                    'metric':endpoint,'difference':result['difference'][j],
                    'ci_lower':result['ci_lower'][j],'ci_upper':result['ci_upper'][j]})
    primary = comparisons[cfg['primary_task']]['selected_vs_quality']
    result = {'status':'complete','primary_task':cfg['primary_task'],'primary_metric':cfg['primary_metric'],
        'primary_contrast':'selected_vs_quality','primary_result':primary,
        'selected_geometry':selection['selected_geometry'],
        'selected_regression_geometry':selection['selected_regression_geometry'],
        'selection_rule':'Classification: validation log loss; regression: validation nine-CV NMSE. No test selection.',
        'classification':classification,'classification_comparisons':comparisons,
        'regression':regression,'regression_comparisons':reg_comparisons,
        'pca':json.loads((root/'preparation.json').read_text())['pca'],
        'prediction_checks':checks,
        'comparison_inventory':{'classification_named_contrasts':18,'classification_endpoint_rows':54,
            'classification_unique_pairs':{t:len({(r,c) for _,r,c in declared_contrasts(selection['selected_geometry'][t])}) for t in TASKS},
            'regression_contrasts':8,'regression_endpoint_rows':40,
            'duplicates':'Named declared contrasts retained even when pairs coincide; no extra independent evidence.'},
        'limits':json.loads((root/'protocol.json').read_text())['limits'],
        'source_prediction_manifest_sha256':sha256(root/'predictions_manifest.json'),
        'source_selection_sha256':sha256(root/'selection.json'),
        'source_selection_frozen_sha256':sha256(root/'selection_frozen.json')}
    stats = root/'statistics';stats.mkdir(exist_ok=True)
    write_json(stats/'summary.json',result)
    for name,table in [('classification_metrics',class_table),('classification_comparisons',class_comparison_table),
                       ('regression_metrics',reg_table),('regression_channels',channel_table),
                       ('regression_comparisons',reg_comparison_table)]:
        csv_write(stats/(name+'.csv'),table)
    return result


def render_figures(root,result):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    dest = Path(root)/'figures';dest.mkdir(exist_ok=True)

    def save(fig,name,table):
        fig.tight_layout()
        for extension in ('png','svg'):
            fig.savefig(dest/(name+'.'+extension),dpi=180,bbox_inches='tight')
        plt.close(fig);csv_write(dest/(name+'_data.csv'),table)

    fig,axes = plt.subplots(1,2,figsize=(12,4.5));table = []
    for ax,task in zip(axes,TASKS):
        values = [result['classification']['test'][task][m]['average_precision'] for m in METHODS]
        ax.bar(range(6),[np.nan if v is None else v for v in values],color=[COLORS[m] for m in METHODS])
        winner = result['selected_geometry'][task]
        ax.set_xticks(range(6),[LABELS[m]+(' *' if m==winner else '') for m in METHODS],rotation=25,ha='right')
        ax.set_title(TITLES[task]);ax.set_ylabel('Test average precision');ax.grid(axis='y',alpha=.2)
        ax.margins(y=.15)
        for x,(method,value) in enumerate(zip(METHODS,values)):
            if value is not None:
                ax.annotate(f'{value:.4f}',(x,value),xytext=(0,4),textcoords='offset points',ha='center',fontsize=8)
            table.append({'task':task,'method':method,'average_precision':value,'validation_selected':method==winner})
    fig.suptitle('* Geometry selected by validation log loss; all four image groups shown')
    save(fig,'classification_ap',table)

    fig,axes = plt.subplots(1,2,figsize=(13,6.5));table = []
    for ax,task in zip(axes,TASKS):
        labels = []
        for i,(name,reference,candidate) in enumerate(declared_contrasts(result['selected_geometry'][task])):
            r = result['classification_comparisons'][task][name]
            mean,low,high = r['difference'][0],r['ci_lower'][0],r['ci_upper'][0]
            color = COLORS[candidate]
            if all(v is not None for v in (mean,low,high)):
                ax.plot([low,high],[i,i],color=color,lw=2);ax.scatter([mean],[i],color=color,s=30,zorder=3)
            else:
                ax.text(0,i,'Not estimable',ha='center')
            labels.append(f'{name.replace("_", " ")} ({candidate} - {reference})')
            table.append({'task':task,'contrast':name,'reference':reference,'candidate':candidate,
                          'difference':mean,'ci_lower':low,'ci_upper':high})
        ax.axvline(0,color='black',linestyle='--',lw=.8);ax.set_yticks(range(9),labels,fontsize=8)
        ax.invert_yaxis();ax.set_title(TITLES[task]);ax.grid(axis='x',alpha=.2)
        ax.set_xlabel('AP increase (positive favors candidate)')
    confidence = 100*result['primary_result']['confidence_level']
    fig.suptitle(f'Paired calendar-day exploratory {confidence:g}% intervals; declared contrasts retained')
    save(fig,'classification_ap_comparisons',table)

    fig,axes = plt.subplots(2,2,figsize=(12,8));table = []
    for i,ax in enumerate(axes.flat):
        values = [result['regression']['test'][m]['physical_mae'][i] for m in METHODS]
        ax.bar(range(6),values,color=[COLORS[m] for m in METHODS])
        ax.set_xticks(range(6),[LABELS[m] for m in METHODS],rotation=25,ha='right')
        ax.set_title(PHYSICAL[i].capitalize());ax.set_ylabel(f'MAE ({UNITS[i]}; lower is better)')
        ax.grid(axis='y',alpha=.2);ax.margins(y=.15)
        for x,(method,value) in enumerate(zip(METHODS,values)):
            ax.annotate(f'{value:.4g}',(x,value),xytext=(0,4),textcoords='offset points',ha='center',fontsize=8)
            table.append({'quantity':PHYSICAL[i],'unit':UNITS[i],'method':method,'mae':value})
    fig.suptitle('Auxiliary one-step prediction with observed current images')
    save(fig,'regression_physical_mae',table)


def write_readout(root,result):
    def number(value):
        return 'NA' if value is None else f'{value:.9g}'
    lines = ['Four-geometry RGB representation study','',
        'Primary endpoint: validation-selected geometry versus image statistics, future-temperature-movement AP.',
        result['selection_rule'],
        'A=squash/global; B=letterbox/global; C=squash/2x2 spatial; D=letterbox/2x2 spatial.',
        'Every group uses the same frozen encoder and 32 PCA coordinates fitted on unique outer-training captures.','']
    for task in TASKS:
        lines += [TITLES[task]+': validation-selected '+result['selected_geometry'][task],
                  'method | validation log loss | test AP | test ROC AUC | test Brier | test log loss']
        for method in CLASS_METHODS:
            val,test = [result['classification'][s][task][method] for s in ('val','test')]
            values = [val['log_loss'],*[test[k] for k in ('average_precision','roc_auc','brier','log_loss')]]
            lines.append(method+' | '+' | '.join(map(number,values)))
        for name,r in result['classification_comparisons'][task].items():
            lines.append(f'{name} ({r["candidate"]} versus {r["reference"]}): AP increase '+
                number(r['difference'][0])+'; interval ['+number(r['ci_lower'][0])+', '+number(r['ci_upper'][0])+']')
        lines.append('')
    lines += ['Auxiliary one-step nine-CV regression: validation-selected geometry '+result['selected_regression_geometry'],
              'method | validation NMSE | test NMSE | temperature MAE | pressure MAE | steam MAE | oxygen MAE']
    for method in METHODS:
        val,test = [result['regression'][s][method] for s in ('val','test')]
        lines.append(method+' | '+' | '.join(map(number,[val['normalized_mse'],test['normalized_mse'],*test['physical_mae']])))
    lines += ['', 'Interpretation constraints:',
        '- B-A and D-C describe geometry changes at fixed pooling; C-A and D-B describe pooling changes at fixed geometry. No factorial-interaction claim is made.',
        '- Pooling effects include subsequent PCA compression: 512 or 2048 coordinates are reduced to the same 32 dimensions; retained variance differs.',
        '- The matched older-image head uses the selected geometry with older deep features and current simple image statistics.',
        '- Labels are recorded temperature movement and MV changes, not safety violations or optimal actions.',
        '- Alarm thresholds are fixed validation quantiles; test alarm fractions are unconstrained.',
        '- All intervals are exploratory, conditional on the fitted models, with no multiplicity correction. Duplicate declared contrasts are not independent replications.',
        '- These observed-outcome tasks establish no counterfactual plant-control benefit; no simulator reward or RL policy is evaluated.',
        *['- '+line for line in result['limits']]]
    (Path(root)/'RESULTS.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')


def build_report(study_dir):
    root = Path(study_dir).resolve();result = summarize(root)
    render_figures(root,result);write_readout(root,result)
    outputs = [*sorted((root/'statistics').glob('*')),*sorted((root/'figures').glob('*')),root/'RESULTS.txt']
    write_json(root/'report_manifest.json',{'status':'complete',
        'source_prediction_manifest_sha256':sha256(root/'predictions_manifest.json'),
        'source_selection_frozen_sha256':sha256(root/'selection_frozen.json'),
        'files':{str(p.relative_to(root)):sha256(p) for p in outputs if p.is_file()}})
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('study_dir',nargs='?');parser.add_argument('--config')
    args = parser.parse_args()
    if (args.study_dir is None) == (args.config is None):
        parser.error('provide either study_dir or --config')
    root = paths(args.config)[2] if args.config else Path(args.study_dir)
    result = build_report(root)
    print(json.dumps({'status':result['status'],'prediction_archives':len(result['prediction_checks']),
                      'selected_geometry':result['selected_geometry']}))


if __name__ == '__main__':
    main()
