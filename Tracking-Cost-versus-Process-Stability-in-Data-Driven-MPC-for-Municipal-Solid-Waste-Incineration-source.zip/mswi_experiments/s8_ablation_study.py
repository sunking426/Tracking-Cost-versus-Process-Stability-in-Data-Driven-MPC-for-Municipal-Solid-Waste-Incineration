"""Frozen validation-only S8 ablations; no policy fitting or test evaluation."""
import argparse,datetime,json,shutil,time
from pathlib import Path
import numpy as np
import torch
from threadpoolctl import threadpool_limits
from .frozen_mpc import ROOT,load_frozen_mpc,file_sha256
from .ridge_policy_study import read_npz,write_json
from .ridge_policy import Execution,RidgePolicyEnv
from .ridge_dynamics import RidgeDynamics
from .mpc_stability import StabilityCEM
from .mpc_ablation import AblationExecution,AblationCEM
from .s8_cross_evaluation import verify as verify_parent,OUT as CROSS,OLD,REF,MODELS,ResidualFeedback

DESIGN=ROOT/'experiment_protocols/s8_ablation_20261108'
OUT=ROOT/'experiment_runs/s8_ablation_20261108'
SAMPLE_KEYS=('u_hist','z_hist','z_current','time_ns','indices')


def seal():
    verify_parent();load_frozen_mpc()
    if (DESIGN/'seal.json').exists():return verify()
    if (OUT/'trajectories').exists():raise AssertionError('seal precedes outcomes')
    files=list((ROOT/'mswi_experiments').glob('*.py'))+[ROOT/'tests/test_mpc_ablation.py',DESIGN/'protocol.json',DESIGN/'PRESET_zh.txt']
    files += [CROSS/'config.json',CROSS/'seal.json',CROSS/'FINAL_MANIFEST.json',CROSS/'COMPLETE.json']
    files += [REF/'stats.json',REF/'support.npz',REF/'inputs/val.npz']
    files += [REF/f'evaluation_models/{m}.npz' for m in ('full',)+MODELS]
    files += [CROSS/f'residuals/{m}_sequences.npz' for m in MODELS]
    hashes={str(p.relative_to(ROOT)):file_sha256(p) for p in files}
    data=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),hashes=hashes)
    write_json(DESIGN/'seal.json',data);shutil.copy2(DESIGN/'seal.json',OUT/'seal.json')
    for p in files:
        if p.suffix=='.py':
            dest=OUT/'code_snapshot'/p.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
    print('SEALED',file_sha256(DESIGN/'protocol.json'),flush=True)


def verify():
    binding=json.loads((DESIGN/'seal.json').read_text())
    for p,h in binding['hashes'].items():
        if file_sha256(ROOT/p)!=h:raise AssertionError('sealed source changed: '+p)
    verify_parent()
    return json.loads((DESIGN/'protocol.json').read_text())


def d2_mode():
    p=DESIGN/'D2_choice.json'
    if not p.exists():raise RuntimeError('D2 clarification remains pending; do not infer consent')
    data=json.loads(p.read_text());h=p.with_suffix('.sha256').read_text().split()[0]
    if file_sha256(p)!=h:raise AssertionError('D2 choice changed')
    return data['admission']


def run_case(layer,mid,method,rep=0):
    path=OUT/f'trajectories/{layer}/{mid}/{method}/rep{rep}.npz'
    if path.exists():
        if file_sha256(path)!=json.loads(path.with_suffix('.json').read_text())['sha256']:raise AssertionError('trajectory changed')
        return path
    parent=load_frozen_mpc();stats=json.loads((REF/'stats.json').read_text());sup=read_npz(REF/'support.npz')
    inputs={k:v for k,v in read_npz(REF/'inputs/val.npz').items() if k in SAMPLE_KEYS}
    full=RidgeDynamics.load(REF/'evaluation_models/full.npz')
    horizon=10 if layer=='P' else 50
    if method=='S8':
        ex=Execution(stats,sup);planner=StabilityCEM(full,ex,8,parent)
    else:
        ex=AblationExecution(stats,sup,8 if method.startswith('D1') else 2,
            d2_mode() if method=='D2' else 'supported',zero_extra=method=='D1_zero')
        planner=AblationCEM(full,ex,512 if method=='D1_512' else 128)
    model=RidgeDynamics.load(REF/f'evaluation_models/{mid}.npz');residual=None
    if layer=='C':
        noise=read_npz(CROSS/f'residuals/{mid}_sequences.npz')
        np.testing.assert_array_equal(noise['start_indices'],inputs['indices'])
        residual=noise['residual'][:,rep];model=ResidualFeedback(model,residual)
    env=RidgePolicyEnv(model,ex,horizon=horizon);env.reset(options={'inputs':inputs})
    buf={};begin=time.perf_counter()
    for step in range(horizon):
        request,diag=planner.plan(env.u,env.z,env.current,env.times,env.indices,step)
        _,_,done,cut,info=env.step_request(request)
        if done.any() or cut.all()!=(step==horizon-1):raise AssertionError('termination')
        info.update(diag)
        if residual is not None:info['injected_residual']=residual[:,step]
        for k,v in info.items():buf.setdefault(k,[]).append(v)
        if (step+1)%10==0:print(layer,mid,method,rep,step+1,'seconds',round(time.perf_counter()-begin,1),flush=True)
    a={k:np.stack(v,axis=1) for k,v in buf.items()}
    a.update(indices=inputs['indices'],time_ns=inputs['time_ns'],initial_u=inputs['u_hist'][:,-1],initial_z_current=inputs['z_current'])
    for k,v in a.items():
        if np.issubdtype(v.dtype,np.number) and not np.isfinite(v).all():raise FloatingPointError(k)
    if layer in ('C','D'):
        old=read_npz(CROSS/f'trajectories/C/{mid}/S8/seed0_rep{rep}.npz') if layer=='C' else read_npz(OLD/f'trajectories/S8/{mid}.npz')
        np.testing.assert_array_equal(a['noise_sha256'],old['noise_sha256'])
        if layer=='C':np.testing.assert_array_equal(a['injected_residual'],old['injected_residual'])
    path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix('.partial.npz');np.savez_compressed(tmp,**a);tmp.replace(path)
    meta=dict(layer=layer,model=mid,method=method,replicate=rep,partition='val',starts=256,horizon=horizon,
        protocol_sha256=file_sha256(DESIGN/'protocol.json'),elapsed_seconds=time.perf_counter()-begin,sha256=file_sha256(path),
        shared_old_channel_noise_verified=layer in ('C','D'),shared_residuals_verified=layer=='C')
    if method=='D2':meta['D2_choice_sha256']=file_sha256(DESIGN/'D2_choice.json')
    write_json(path.with_suffix('.json'),meta);print('COMPLETE',layer,mid,method,rep,flush=True)
    return path


def acceptance():
    checks=[]
    old=read_npz(OLD/'trajectories/S8/early.npz')
    for method in ('S8','D1_zero'):
        a=read_npz(run_case('acceptance','early',method));keys=sorted(set(a)&set(old))
        for k in keys:
            value=a[k][...,:2] if k=='best_requested_plan_b' and method=='D1_zero' else a[k]
            np.testing.assert_array_equal(value,old[k],err_msg=method+':'+k)
        if method=='D1_zero':assert np.all(a['best_requested_plan_b'][...,2:]==0)
        checks.append(dict(method=method,starts=256,steps=50,bitwise_fields=keys,status='passed'))
    write_json(OUT/'acceptance.json',dict(status='passed',checks=checks))
    print('ACCEPTANCE PASSED',flush=True)


def planning():
    if json.loads((OUT/'acceptance.json').read_text())['status']!='passed':raise AssertionError('acceptance first')
    main=read_npz(run_case('P','full','S8'));d1=read_npz(run_case('P','full','D1'))
    a=main['reward'].astype(float).sum(1);b=d1['reward'].astype(float).sum(1)
    trigger=bool(b.mean()<a.mean())
    result=dict(main_original_return=float(a.mean()),D1_original_return=float(b.mean()),difference=float((b-a).mean()),
        trigger_D1_512=trigger,rule='strictly lower mean original H10 return in full planning Ridge',
        evaluated_after_protocol_freeze=True)
    p=OUT/'budget_trigger.json'
    if p.exists() and json.loads(p.read_text())!=result:raise AssertionError('trigger changed')
    write_json(p,result);print('BUDGET TRIGGER',json.dumps(result),flush=True)
    if trigger:run_case('P','full','D1_512')


def worker(method,worker,workers):
    if not (OUT/'acceptance.json').exists():raise AssertionError('acceptance first')
    if method=='D1_512' and not json.loads((OUT/'budget_trigger.json').read_text())['trigger_D1_512']:raise AssertionError('not triggered')
    cases=[('D',mid,0) for mid in MODELS]+[('C',mid,r) for r in range(5) for mid in MODELS]
    for i,(layer,mid,r) in enumerate(cases):
        if i%workers==worker:run_case(layer,mid,method,r)


def main():
    p=argparse.ArgumentParser();p.add_argument('operation',choices=['seal','acceptance','planning','case','worker'])
    p.add_argument('--layer',default='P');p.add_argument('--model',default='full');p.add_argument('--method',default='D1')
    p.add_argument('--rep',type=int,default=0);p.add_argument('--worker',type=int,default=0);p.add_argument('--workers',type=int,default=1)
    a=p.parse_args();torch.set_num_threads(2)
    with threadpool_limits(limits=2):
        if a.operation=='seal':seal();return
        verify()
        if a.operation=='acceptance':acceptance()
        elif a.operation=='planning':planning()
        elif a.operation=='case':run_case(a.layer,a.model,a.method,a.rep)
        else:worker(a.method,a.worker,a.workers)
if __name__=='__main__':main()
