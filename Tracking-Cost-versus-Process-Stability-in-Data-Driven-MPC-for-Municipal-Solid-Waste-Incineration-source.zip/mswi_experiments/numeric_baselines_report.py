"""Read-only statistical comparison of saved nine-channel numerical forecasts.

The four methods share observations and target scales. Model selection remains
in ``numeric_baselines``; this module never fits or chooses a predictor.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import json
from pathlib import Path

import numpy as np

from .data import control_values
from .visual_diagnostics_statistics import DAY_NS, paired_block_interval


METHODS = ("persistence", "ridge", "gru", "gru_residual")
QUANTITIES = ("temperature", "pressure", "steam", "oxygen")
UNITS = ("°C", "Pa", "t/h", "vol%")
LABELS = {"persistence": "持续性预测", "ridge": "Ridge", "gru": "GRU",
          "gru_residual": "GRU＋数值残差"}
COLORS = {"persistence": "#1f77b4", "ridge": "#ff7f0e", "gru": "#2ca02c",
          "gru_residual": "#6f5b89"}


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2,
                                    allow_nan=False) + "\n", encoding="utf-8")


def _csv(path, rows):
    if not rows:
        raise ValueError("cannot export empty result table")
    with Path(path).open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)


def error_components(predictions, truth, delta_scale):
    """Return squared normalized nine-CV errors and four physical errors.

    Temperature is aggregated before its error is calculated. The prediction
    seed axis is retained; averaging predictions would describe an untested
    ensemble and is not used for the main results.
    """
    pred = np.asarray(predictions, dtype=np.float64)
    y = np.asarray(truth, dtype=np.float64)
    scale = np.asarray(delta_scale, dtype=np.float64)
    if (pred.ndim != 3 or min(pred.shape) == 0 or pred.shape[-1] != 9
            or y.shape != pred.shape[1:] or scale.shape != (9,)
            or not np.isfinite(pred).all() or not np.isfinite(y).all()
            or not np.isfinite(scale).all() or np.any(scale <= 0)):
        raise ValueError("expected finite (fit, sample, 9), (sample, 9), positive nine-CV scale")
    errors = pred - y[None]
    squared = np.square(errors / scale)
    physical = control_values(pred) - control_values(y)[None]
    return squared, physical, errors


def metric_summary(predictions, truth, delta_scale):
    squared, physical, errors = error_components(predictions, truth, delta_scale)
    channel_mae = np.abs(errors).mean(axis=1)
    channel_rmse = np.sqrt(np.square(errors).mean(axis=1))
    physical_mae = np.abs(physical).mean(axis=1)
    physical_rmse = np.sqrt(np.square(physical).mean(axis=1))
    return {
        "fits": len(predictions), "samples": len(truth),
        "normalized_mse": float(squared.mean()),
        "per_fit_normalized_mse": squared.mean(axis=(1, 2)).tolist(),
        "channel_mae": channel_mae.mean(axis=0).tolist(),
        "channel_rmse": channel_rmse.mean(axis=0).tolist(),
        "channel_pooled_rmse": np.sqrt(np.square(errors).mean(axis=(0, 1))).tolist(),
        "physical_mae": physical_mae.mean(axis=0).tolist(),
        "physical_rmse": physical_rmse.mean(axis=0).tolist(),
        "physical_pooled_rmse": np.sqrt(np.square(physical).mean(axis=(0, 1))).tolist(),
        "per_fit_physical_mae": physical_mae.tolist(),
        "per_fit_physical_rmse": physical_rmse.tolist(),
        "rmse_definition": "arithmetic mean of individual-fit RMSE; pooled RMSE also retained",
    }


def paired_endpoints(reference, candidate, truth, delta_scale):
    """Pair stochastic seeds, broadcasting a deterministic fit without counting it twice."""
    ref_sq, ref_phys, _ = error_components(reference, truth, delta_scale)
    cand_sq, cand_phys, _ = error_components(candidate, truth, delta_scale)
    nr, nc = len(reference), len(candidate)
    if nr != nc and min(nr, nc) != 1:
        raise ValueError("stochastic candidates must share matched seed counts")
    primary = (ref_sq.mean(axis=2) - cand_sq.mean(axis=2))[..., None]
    physical = np.abs(ref_phys) - np.abs(cand_phys)
    return np.concatenate((primary, physical), axis=2)


def load_completed_study(study_dir):
    root = Path(study_dir).resolve()
    names = ("config.json", "stats.json", "protocol.json", "selection.json", "predictions_manifest.json")
    config, stats, protocol, selection, manifest = [json.loads((root/n).read_text()) for n in names]
    if manifest["status"] != "complete" or manifest["selection_sha256"] != _sha(root/"selection.json"):
        raise ValueError("prediction stage incomplete or selection hash changed")
    seeds = [int(s) for s in config["diagnostics"]["seeds"]]
    if not seeds or len(set(seeds)) != len(seeds):
        raise ValueError("expected distinct fitted seeds")
    models = selection["models"]
    expected = {"persistence": ("persistence", None), "ridge": ("ridge", None)}
    for m in ("gru", "gru_residual"):
        expected.update({f"{m}_seed_{s}": (m, s) for s in seeds})
    if (len(models) != len(expected) or
            {m["id"]: (m["method"], m["seed"]) for m in models} != expected):
        raise ValueError("model inventory does not match deterministic and stochastic fits")
    indexed = {(row["model_id"], row["split"]): row for row in manifest["files"]}
    if len(indexed) != len(expected)*3 or len(manifest["files"]) != len(indexed):
        raise ValueError("prediction manifest is not the complete unique model-by-split set")
    sources = {name: _sha(root/name) for name in names}
    arrays = {}; shared = {}; checks = []
    for split in ("train", "val", "test"):
        arrays[split] = {}
        for model in models:
            model_id = model["id"]; record = indexed[(model_id, split)]
            expected_path = f"predictions/{model_id}/{split}.npz"
            path = root/expected_path
            if (record["path"] != expected_path or record["method"] != model["method"]
                    or record["seed"] != model["seed"] or record["sha256"] != _sha(path)):
                raise ValueError("prediction identity or hash mismatch")
            with np.load(path, allow_pickle=False) as raw:
                row = {k: raw[k].copy() for k in ("indices", "time_ns", "y", "pred", "error")}
            n = len(row["indices"])
            if (n == 0 or row["indices"].shape != (n,) or row["time_ns"].shape != (n,)
                    or row["y"].shape != (n, 9) or row["pred"].shape != (n, 9)
                    or not np.isfinite(row["y"]).all() or not np.isfinite(row["pred"]).all()
                    or not np.array_equal(row["error"], row["pred"]-row["y"])
                    or record["n"] != n or record["shape"] != [n, 9]
                    or len(np.unique(row["indices"])) != n or np.any(np.diff(row["time_ns"]) <= 0)):
                raise ValueError("invalid numerical prediction record")
            if split not in shared:
                shared[split] = {k: row[k] for k in ("indices", "time_ns", "y")}
            elif any(not np.array_equal(row[k], shared[split][k]) for k in shared[split]):
                raise ValueError("methods do not share identical observations and targets")
            arrays[split][model_id] = row["pred"]
            sources[expected_path] = record["sha256"]
            checks.append({"model_id": model_id, "split": split, "samples": n,
                           "hash_identity_shape_error_verified": True})
    for a, b in itertools.combinations(shared, 2):
        if np.intersect1d(shared[a]["indices"], shared[b]["indices"]).size:
            raise ValueError("split sample identities overlap")
    if not (shared["train"]["time_ns"].max() < shared["val"]["time_ns"].min()
            and shared["val"]["time_ns"].max() < shared["test"]["time_ns"].min()):
        raise ValueError("outer partitions must be chronological")
    return root, config, stats, protocol, models, arrays, shared, sources, checks


def _metric_row(metric):
    row = {"samples": metric["samples"], "normalized_mse": metric["normalized_mse"]}
    for j, q in enumerate(QUANTITIES):
        row[q+"_mae"] = metric["physical_mae"][j]
        row[q+"_rmse"] = metric["physical_rmse"][j]
        row[q+"_pooled_rmse"] = metric["physical_pooled_rmse"][j]
    return row


def summarize_study(study_dir):
    root, config, stats, protocol, models, arrays, shared, sources, checks = load_completed_study(study_dir)
    out = root/"statistics"; out.mkdir(exist_ok=True)
    options = config["diagnostics"]
    scale = np.asarray(stats["delta_scale"], dtype=np.float64)
    by_method = {m: sorted([r for r in models if r["method"] == m],
                          key=lambda r: -1 if r["seed"] is None else r["seed"]) for m in METHODS}
    normalized = {}; overall = []; individual = []; channels = []; daily = []
    stacked = {}
    for split in ("train", "val", "test"):
        normalized[split] = {}; stacked[split] = {}; truth = shared[split]["y"]
        for method in METHODS:
            runs = np.stack([arrays[split][r["id"]] for r in by_method[method]])
            stacked[split][method] = runs
            summary = metric_summary(runs, truth, scale); normalized[split][method] = summary
            overall.append({"split": split, "method": method, "fits": len(runs), **_metric_row(summary)})
            entries = [("method_average", method, None, summary)]
            for row in by_method[method]:
                metric = metric_summary(arrays[split][row["id"]][None], truth, scale)
                individual.append({"split": split, "model_id": row["id"], "method": method,
                                   "seed": row["seed"], **_metric_row(metric)})
                entries.append(("individual_fit", row["id"], row["seed"], metric))
            for kind, identity, seed, entry in entries:
                for j, name in enumerate(stats["cv_names"]):
                    channels.append({"split": split, "row_kind": kind, "identity": identity,
                                     "method": method, "seed": seed, "channel": name,
                                     "unit": "°C" if j < 6 else UNITS[j-5],
                                     "samples": len(truth), "mae": entry["channel_mae"][j],
                                     "mean_fit_rmse": entry["channel_rmse"][j],
                                     "pooled_rmse": entry["channel_pooled_rmse"][j]})
            if split == "test":
                days = shared[split]["time_ns"]//DAY_NS
                for day in np.unique(days):
                    mask = days == day
                    for kind, identity, seed, _ in entries:
                        day_runs = runs[:, mask] if kind == "method_average" else arrays[split][identity][None, mask]
                        metric = metric_summary(day_runs, truth[mask], scale)
                        daily.append({"date": str(np.datetime64(int(day), "D")), "row_kind": kind,
                                      "identity": identity, "method": method, "seed": seed,
                                      "fits": len(day_runs), **_metric_row(metric)})
    comparisons = {}; contrast_rows = []
    endpoint_names = ("nine_channel_normalized_mse", *[q+"_mae" for q in QUANTITIES])
    day_ids = shared["test"]["time_ns"]//DAY_NS
    for reference, candidate in itertools.combinations(METHODS, 2):
        difference = paired_endpoints(stacked["test"][reference], stacked["test"][candidate],
                                      shared["test"]["y"], scale)
        interval = paired_block_interval(difference, day_ids,
            draws=int(options["bootstrap_draws"]), seed=int(options["bootstrap_seed"]),
            confidence_level=float(options["confidence_level"]))
        interval.update(reference=reference, candidate=candidate, endpoints=list(endpoint_names),
            reference_fits=len(by_method[reference]), candidate_fits=len(by_method[candidate]),
            deterministic_broadcast="one saved deterministic prediction is paired with each stochastic seed; no extra fit")
        name = candidate+"_vs_"+reference; comparisons[name] = interval
        for j, endpoint in enumerate(endpoint_names):
            contrast_rows.append({"comparison": name, "reference": reference, "candidate": candidate,
                "endpoint": endpoint, "difference": interval["difference"][j],
                "ci_lower": interval["ci_lower"][j], "ci_upper": interval["ci_upper"][j],
                "reference_fits": interval["reference_fits"], "candidate_fits": interval["candidate_fits"],
                "paired_seed_axis": interval["training_seeds"], "samples": interval["samples"],
                "calendar_blocks": interval["time_blocks"], "confidence_level": interval["confidence_level"],
                "positive_means": "candidate lower error", "exploratory": True,
                "multiple_comparison_adjustment": "none"})
    result = {"metrics": normalized, "comparisons": comparisons, "methods": list(METHODS),
        "test_period": {"start": str(np.datetime64(int(shared["test"]["time_ns"].min()), "ns")),
                        "end": str(np.datetime64(int(shared["test"]["time_ns"].max()), "ns")),
                        "samples": len(day_ids), "calendar_blocks": len(np.unique(day_ids))},
        "delta_scale": scale.tolist(), "source_hashes": sources, "prediction_checks": checks,
        "scope": "Existing image-eligible retained samples; same previously inspected test period; exploratory development comparison",
        "primary_metric": "sample-and-fit mean of nine-channel squared errors divided by canonical training delta_scale squared",
        "residual_definition": "Frozen GRU plus Ridge fitted to in-sample training residuals; not OOF or independent calibration",
        "fit_aggregation": "Metrics averaged over fits, not metrics of averaged predictions",
        "multiple_comparison_adjustment": "none"}
    tables = {"overall.csv": overall, "individual_fits.csv": individual, "channels.csv": channels,
              "per_day.csv": daily, "comparisons.csv": contrast_rows}
    for filename, rows in tables.items(): _csv(out/filename, rows)
    _json(out/"summary.json", result)
    return result


def render_figures(study_dir, summary=None):
    from .visual_diagnostics_report import _pyplot, _save_figure, _style_axis
    root = Path(study_dir).resolve()
    result = summary if summary is not None else json.loads((root/"statistics/summary.json").read_text())
    folder = root/"figures"; folder.mkdir(exist_ok=True)
    plt, font_path = _pyplot(); paths = []; physical_data = []; effect_data = []
    period = result["test_period"]
    dates = period["start"][:10]+"—"+period["end"][:10]
    fig, axes = plt.subplots(2, 2, figsize=(12.4, 8.1))
    titles = ("炉膛平均温度", "炉膛负压", "主蒸汽流量", "烟气氧浓度")
    for q, ax in enumerate(axes.flat):
        largest = 0.
        for pos, method in enumerate(METHODS):
            metric = result["metrics"]["test"][method]
            mean = metric["physical_mae"][q]
            fitted = [row[q] for row in metric["per_fit_physical_mae"]]
            ax.barh(pos, mean, color=COLORS[method], alpha=.72, height=.56, edgecolor="black", linewidth=.6)
            offsets = np.linspace(-.12, .12, len(fitted)) if len(fitted)>1 else np.zeros(1)
            ax.plot(fitted, pos+offsets, linestyle="none", marker="o", markersize=4,
                    markerfacecolor="white", markeredgecolor="black", markeredgewidth=.7)
            largest = max(largest, mean, *fitted)
            physical_data.append({"method": method, "quantity": QUANTITIES[q], "unit": UNITS[q],
                                  "mean_mae": mean, "individual_fit_mae": fitted,
                                  "fits": metric["fits"], "samples": metric["samples"]})
        xmax = largest*1.22 if largest else 1.
        for pos, method in enumerate(METHODS):
            mean = result["metrics"]["test"][method]["physical_mae"][q]
            ax.text(mean+xmax*.015, pos, f"{mean:.4f}", va="center", fontsize=10)
        ax.set_xlim(0, xmax); ax.set_ylim(3.6, -.6)
        ax.set_yticks(range(4), [LABELS[m] for m in METHODS]); ax.set_title(titles[q])
        ax.set_xlabel(f"MAE ({UNITS[q]})，越小越好"); _style_axis(ax)
    fig.suptitle("相同九通道训练目标下的数值预测基线", y=.985)
    fig.text(.5, .025, f"{dates}；{period['samples']:,} 个共同样本。柱：各拟合指标均值；白点：单次拟合；不表示置信区间。\n"
             "既有测试时段已用于开发；当前结果为探索性比较。", ha="center", fontsize=10)
    fig.subplots_adjust(left=.15, right=.98, top=.91, bottom=.15, wspace=.52, hspace=.46)
    paths += _save_figure(fig, folder, "numeric_baseline_physical_mae"); plt.close(fig)
    fig, ax = plt.subplots(figsize=(11.2, 4.9))
    bounds = [0.]
    for pos, method in enumerate(METHODS[1:]):
        c = result["comparisons"][method+"_vs_persistence"]
        point, low, high = [c[k][0] for k in ("difference", "ci_lower", "ci_upper")]
        ax.hlines(pos, low, high, color=COLORS[method], linewidth=1.7)
        ax.vlines([low, high], pos-.075, pos+.075, color=COLORS[method], linewidth=1.)
        ax.plot(point, pos, "o", color=COLORS[method], markersize=7)
        bounds += [point, low, high]
        effect_data.append({"method": method, "reference": "persistence",
                            "difference": point, "ci_lower": low, "ci_upper": high,
                            "endpoint": "nine_channel_normalized_mse",
                            "reference_fits": c["reference_fits"], "candidate_fits": c["candidate_fits"]})
    span = max(bounds)-min(bounds); padding=max(.13*span, 1e-5)
    ax.set_xlim(min(bounds)-padding, max(bounds)+padding); ax.set_ylim(2.5, -.5)
    ax.axvline(0, color="black", linestyle="--", linewidth=.9)
    ax.set_yticks(range(3), [LABELS[m] for m in METHODS[1:]])
    ax.set_xlabel("持续性预测 MSE − 候选模型 MSE（九通道按训练增量尺度归一化；正值更好）")
    ax.set_title("相对持续性预测的主要指标改善"); _style_axis(ax)
    fig.text(.5, .035, f"{dates}；{period['samples']:,} 个共同样本，{period['calendar_blocks']} 个日历块。\n"
             "探索性配对日块＋训练种子 95% 区间；未做多重比较校正；既有测试时段已用于开发。",
             ha="center", fontsize=10)
    fig.subplots_adjust(left=.19, right=.98, top=.88, bottom=.25)
    paths += _save_figure(fig, folder, "numeric_baseline_primary_effects"); plt.close(fig)
    _json(folder/"physical_mae_plot_data.json", physical_data)
    _json(folder/"primary_effects_plot_data.json", effect_data)
    _csv(folder/"primary_effects_plot_data.csv", effect_data)
    flat = [{**{k:v for k,v in row.items() if k != "individual_fit_mae"},
             "individual_fit_mae": json.dumps(row["individual_fit_mae"])} for row in physical_data]
    _csv(folder/"physical_mae_plot_data.csv", flat)
    inputs = [root/"statistics/summary.json", folder/"physical_mae_plot_data.json",
              folder/"primary_effects_plot_data.json", folder/"physical_mae_plot_data.csv",
              folder/"primary_effects_plot_data.csv"]
    manifest = {"renderer": str(Path(__file__).resolve()), "renderer_sha256": _sha(__file__),
                "font": str(font_path), "palette": COLORS, "point_count": len(physical_data)+len(effect_data),
                "interval_count": len(effect_data), "physical_means": len(physical_data),
                "inputs": {str(p.relative_to(root)): _sha(p) for p in inputs},
                "outputs": {str(p.relative_to(root)): _sha(p) for p in paths},
                "visual_inspection": "pending; numeric manifest does not certify visual inspection"}
    _json(folder/"figure_manifest.json", manifest)
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--study-dir", required=True)
    parser.add_argument("--skip-figures", action="store_true")
    args = parser.parse_args()
    result = summarize_study(args.study_dir)
    if not args.skip_figures: render_figures(args.study_dir, result)
    print(json.dumps({"statistics": str(Path(args.study_dir)/"statistics"),
                      "models": len(result["prediction_checks"])//3,
                      "comparisons": len(result["comparisons"])}, ensure_ascii=False))


if __name__ == "__main__":
    main()
