"""Exact source-image mapping and target-free image-quality measurements.

This diagnostic reads sample/capture times and split indices, not process targets.
Original images and train/validation/test assignments are never modified.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
import csv
import hashlib
import io
import json
from pathlib import Path

import numpy as np
from PIL import Image

from .visual_features import gray_from_rgb


CROP_XYXY = (.21, .25, .79, .88)
QUALITY_COLUMNS = (
    "gray_mean", "gray_sd", "black_fraction", "white_clipped_fraction",
    "any_channel_clipped_fraction", "hsv_saturation_mean",
    "red_mean", "green_mean", "blue_mean", "red_sd", "green_sd", "blue_sd",
)
PARTITIONS = ("train", "val", "test")


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def crop_bounds(width, height, fractions=CROP_XYXY):
    if len(fractions) != 4 or not np.isfinite(fractions).all():
        raise ValueError("Crop must contain four finite fractions")
    x0, y0, x1, y1 = fractions
    if not (0 <= x0 < x1 <= 1 and 0 <= y0 < y1 <= 1):
        raise ValueError("Invalid normalized crop")
    bounds = int(width*x0), int(height*y0), int(width*x1), int(height*y1)
    if not (0 <= bounds[0] < bounds[2] <= width and 0 <= bounds[1] < bounds[3] <= height):
        raise ValueError("Empty or invalid pixel crop")
    return bounds


def load_capture_index(dataset_path, manifest_path, image_dir=None):
    """Return chronological unique captures and an index for every dataset row.

    records[i] maps sample_capture_index == i to one exact recorded JPG. Captures
    used only by purged rows remain with split='unassigned'. A capture shared by
    assigned partitions is explicitly labeled 'multiple', never silently split.
    """
    manifest = json.loads(Path(manifest_path).read_text())
    image_dir = Path(image_dir or manifest["image_dir"]).resolve()
    sources = {}
    for source in manifest["sources"]:
        time = np.datetime64(source["time"], "ns")
        name = source["img_name"]
        if np.isnat(time) or Path(name).name != name:
            raise ValueError("Invalid source timestamp or image filename")
        if np.datetime64(Path(name).stem, "ns") != time:
            raise ValueError("Source filename and timestamp disagree")
        stamp = int(time.astype(np.int64))
        if stamp in sources:
            raise ValueError("Duplicate source capture timestamp")
        sources[stamp] = source
    with np.load(dataset_path, allow_pickle=False) as saved:
        times = saved["time_ns"].astype(np.int64)
        selected = saved["visual_time_ns"].astype(np.int64)
        split_indices = {s: saved[s+"_idx"].astype(np.int64) for s in PARTITIONS}
    if times.shape != selected.shape or times.ndim != 1:
        raise ValueError("Sample and selected capture times must be paired vectors")
    if np.any(selected > times - 60_000_000_000):
        raise ValueError("Selected capture is later than the causal input cutoff")
    assignment = np.full(len(times), "unassigned", dtype="U10")
    assigned = np.zeros(len(times), dtype=bool)
    for split, rows in split_indices.items():
        if np.any(rows < 0) or np.any(rows >= len(times)) or len(np.unique(rows)) != len(rows):
            raise ValueError("Invalid or repeated split sample index")
        if np.any(assigned[rows]):
            raise ValueError("Sample indices overlap across splits")
        assigned[rows] = True
        assignment[rows] = split
    captures, inverse = np.unique(selected, return_inverse=True)
    records = []
    for i, stamp in enumerate(captures):
        if int(stamp) not in sources:
            raise ValueError(f"Selected capture absent from source manifest: {stamp}")
        source = sources[int(stamp)]
        counts = Counter(assignment[inverse == i].tolist())
        active = [s for s in PARTITIONS if counts.get(s, 0)]
        split = active[0] if len(active) == 1 else "multiple" if active else "unassigned"
        records.append({"capture_index": i, "time_ns": int(stamp),
                        "timestamp": source["time"], "img_name": source["img_name"],
                        "path": str(image_dir/source["img_name"]), "split": split,
                        "split_counts": {s: int(counts.get(s, 0)) for s in (*PARTITIONS, "unassigned")},
                        "source_sha256": source["sha256"],
                        "source_width": int(source["width"]), "source_height": int(source["height"])})
    return records, inverse.astype(np.int64)


def _pixel_hash(rgb):
    digest = hashlib.sha256()
    digest.update(np.asarray(rgb.shape, dtype="<i8").tobytes())
    digest.update(rgb.tobytes(order="C"))
    return digest.hexdigest()


def measure_rgb(rgb):
    """Quality measured in original, unresized ROI-union pixels."""
    if rgb.dtype != np.uint8 or rgb.ndim != 3 or rgb.shape[2] != 3:
        raise ValueError("Expected a uint8 RGB image")
    height, width = rgb.shape[:2]
    x0, y0, x1, y1 = crop_bounds(width, height)
    crop = rgb[y0:y1, x0:x1]
    gray = gray_from_rgb(crop)
    maximum = crop.max(axis=2).astype(np.float32)
    minimum = crop.min(axis=2).astype(np.float32)
    saturation = np.divide(maximum-minimum, maximum, out=np.zeros_like(maximum), where=maximum>0)
    colors = {}
    for channel, name in enumerate(("red", "green", "blue")):
        colors[name+"_mean"] = float(crop[...,channel].mean(dtype=np.float64))
        colors[name+"_sd"] = float(crop[...,channel].std(dtype=np.float64))
    return {"width": width, "height": height, "crop_width": x1-x0, "crop_height": y1-y0,
            "rgb_pixel_sha256": _pixel_hash(rgb), "crop_pixel_sha256": _pixel_hash(crop),
            "gray_mean": float(gray.mean()), "gray_sd": float(gray.std(dtype=np.float64)),
            "gray_p01": float(np.percentile(gray, 1)), "gray_p50": float(np.percentile(gray, 50)),
            "gray_p99": float(np.percentile(gray, 99)),
            "black_fraction": float((maximum <= 5).mean()),
            "white_clipped_fraction": float((minimum >= 250).mean()),
            "any_channel_clipped_fraction": float((maximum >= 250).mean()),
            "hsv_saturation_mean": float(saturation.mean(dtype=np.float64)), **colors}


def audit_capture(record):
    raw = Path(record["path"]).read_bytes()
    file_hash = hashlib.sha256(raw).hexdigest()
    if file_hash != record["source_sha256"]:
        raise ValueError(f"Image bytes disagree with original manifest: {record['img_name']}")
    with Image.open(io.BytesIO(raw)) as image:
        rgb = np.asarray(image.convert("RGB"))
    measured = measure_rgb(rgb)
    if (measured["width"], measured["height"]) != (record["source_width"], record["source_height"]):
        raise ValueError("Image dimensions disagree with original manifest")
    return {**record, **measured, "bytes": len(raw), "file_sha256": file_hash,
            "source_hash_matches": True}


def duplicate_groups(records, key):
    groups = defaultdict(list)
    for record in records:
        groups[record[key]].append(record)
    output = []
    for digest, group in groups.items():
        if len(group) < 2:
            continue
        splits = sorted({s for r in group for s in PARTITIONS if r["split_counts"].get(s, 0)})
        output.append({"hash": digest, "capture_indices": [r["capture_index"] for r in group],
                       "filenames": [r["img_name"] for r in group], "splits": splits,
                       "cross_partition": len(splits)>1})
    return output


def _json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+"\n")


def make_contact_sheet(records, out):
    """Display unchanged source photographs and prescribed crop copies for QA."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    choices = []
    for split in PARTITIONS:
        group = [r for r in records if r["split_counts"][split]]
        if group:
            choices.extend(group[j] for j in np.unique(np.linspace(0, len(group)-1, 4).round().astype(int)))
    if not choices:
        return []
    fig, axes = plt.subplots(len(choices), 2, figsize=(10, 2.1*len(choices)), squeeze=False)
    for row, record in enumerate(choices):
        with Image.open(record["path"]) as image:
            rgb = np.asarray(image.convert("RGB"))
        h,w = rgb.shape[:2];x0,y0,x1,y1 = crop_bounds(w,h)
        axes[row,0].imshow(rgb); axes[row,0].set_title(f"{record['split']} | {record['timestamp']}", fontsize=10)
        axes[row,1].imshow(rgb[y0:y1,x0:x1]); axes[row,1].set_title("ROI union: x=.21-.79; y=.25-.88",fontsize=10)
        for ax in axes[row]: ax.set_axis_off()
    fig.suptitle("Recorded flame images: chronological quartiles in each partition", fontsize=12)
    fig.tight_layout(rect=(0,0,1,.985));fig.savefig(out,dpi=130);plt.close(fig)
    return [{"capture_index":r["capture_index"],"timestamp":r["timestamp"],"split":r["split"],
             "file_sha256":r["file_sha256"]} for r in choices]


def run_audit(dataset_path, manifest_path, output_dir, workers=2, image_dir=None):
    if workers < 1:
        raise ValueError("Workers must be positive")
    output_dir = Path(output_dir).resolve();output_dir.mkdir(parents=True, exist_ok=True)
    records, mapping = load_capture_index(dataset_path, manifest_path, image_dir)
    _json(output_dir/"capture_index.json", records)
    np.save(output_dir/"sample_capture_index.npy", mapping, allow_pickle=False)
    measured=[]
    with ThreadPoolExecutor(max_workers=workers) as pool:
        for i, record in enumerate(pool.map(audit_capture, records)):
            measured.append(record)
            if (i+1)%500 == 0: print(f"image quality {i+1}/{len(records)}", flush=True)
    _json(output_dir/"capture_quality.json", measured)
    columns = ["capture_index","time_ns","timestamp","img_name","path","split","width","height",
               "crop_width","crop_height",*QUALITY_COLUMNS,"gray_p01","gray_p50","gray_p99",
               "bytes","file_sha256","rgb_pixel_sha256","crop_pixel_sha256"]
    with (output_dir/"capture_quality.csv").open("w",newline="") as stream:
        writer=csv.DictWriter(stream,fieldnames=columns,extrasaction="ignore");writer.writeheader();writer.writerows(measured)
    features=np.asarray([[r[k] for k in QUALITY_COLUMNS] for r in measured],dtype=np.float32)
    np.savez_compressed(output_dir/"quality_features.npz", capture_time_ns=np.asarray([r['time_ns'] for r in measured]),
                        quality=features, columns=np.asarray(QUALITY_COLUMNS), sample_capture_index=mapping)
    duplicates={key:duplicate_groups(measured,key) for key in ("file_sha256","rgb_pixel_sha256","crop_pixel_sha256")}
    _json(output_dir/"duplicate_groups.json",duplicates)
    by_split={}
    for split in (*PARTITIONS,"unassigned"):
        subset=[r for r in measured if r["split_counts"][split]]
        by_split[split]={"unique_captures":len(subset),"sample_rows":sum(r["split_counts"][split] for r in subset),
                         "dimensions":dict(Counter(f"{r['width']}x{r['height']}" for r in subset)),
                         "quality_quantiles_0_25_50_75_100":{k:np.percentile([r[k] for r in subset],[0,25,50,75,100]).tolist() if subset else [] for k in QUALITY_COLUMNS}}
    contact=make_contact_sheet(measured,output_dir/"image_contact_sheet.png")
    summary={"status":"completed","dataset_sha256":sha256(dataset_path),"source_manifest_sha256":sha256(manifest_path),
             "code_sha256":sha256(Path(__file__)),"selected_unique_captures":len(records),"dataset_rows":len(mapping),
             "all_selected_source_file_hashes_match":all(r['source_hash_matches'] for r in measured),
             "causal_cutoff":"selected_capture <= sample_time - 1 minute", "process_targets_accessed":False,
             "split_assignments_modified":False,"crop_normalized_xyxy":CROP_XYXY,"quality_columns":QUALITY_COLUMNS,
             "quality_definitions":{"gray_mean":"mean BT.601 integer grayscale (0-255)","gray_sd":"population grayscale SD",
                  "black_fraction":"fraction of crop pixels with every RGB channel <=5",
                  "white_clipped_fraction":"fraction with every RGB channel >=250",
                  "any_channel_clipped_fraction":"fraction with any RGB channel >=250",
                  "hsv_saturation_mean":"mean (max(R,G,B)-min(R,G,B))/max; zero for black pixels",
                  "red/green/blue_mean":"mean of each original RGB channel over the crop (0-255)",
                  "red/green/blue_sd":"population SD of each original RGB channel over the crop"},
             "measurement_resolution":"original unresized crop pixels", "split_summaries":by_split,
             "captures_shared_across_assigned_partitions":[r['capture_index'] for r in records if r['split']=='multiple'],
             "duplicate_group_counts":{k:{"all":len(v),"cross_partition":sum(g['cross_partition'] for g in v)} for k,v in duplicates.items()},
             "contact_sheet_selection":"four equally spaced unique captures per chronological split; no target/quality selection",
             "contact_sheet_sources":contact,
             "limits":"Exact pixels only: nonidentical near-duplicates and physical camera calibration are not verified. Quality thresholds are diagnostics, not defect labels or exclusion rules."}
    _json(output_dir/"image_quality_summary.json",summary)
    return summary


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset",required=True);parser.add_argument("--manifest",required=True)
    parser.add_argument("--output",required=True);parser.add_argument("--image-dir")
    parser.add_argument("--workers",type=int,default=2);args=parser.parse_args()
    result=run_audit(args.dataset,args.manifest,args.output,args.workers,args.image_dir)
    print(json.dumps({"status":result['status'],"selected_unique_captures":result['selected_unique_captures'],
                      "duplicate_group_counts":result['duplicate_group_counts']}),flush=True)


if __name__ == "__main__":
    main()
