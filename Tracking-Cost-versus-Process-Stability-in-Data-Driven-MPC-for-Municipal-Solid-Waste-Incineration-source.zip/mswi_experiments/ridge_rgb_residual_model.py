"""Small nonlinear corrections to frozen, nine-channel Ridge predictions.

Training consumes only prepared out-of-fold training residuals and the outer
validation partition. Test arrays are loaded only by the separate prediction
stage, after all selections and checkpoint hashes have been frozen. The same
226-input network is used in each ablation; unavailable columns are masked
after a shared training-only standardization.
"""
from __future__ import annotations

import copy
import csv
import json
from pathlib import Path
import time

import numpy as np
from sklearn.preprocessing import StandardScaler
import torch
from torch import nn
from threadpoolctl import threadpool_limits

from .numeric_baselines import normalized_mse, sha256, write_json
from .training import seed_everything


METHODS = ("numeric", "quality", "rgb", "null_rgb")
SPLITS = ("train", "val", "test")
INPUT_DIM = 226
TIE_TOLERANCE = 1e-12


def feature_mask(method):
    if method not in METHODS:
        raise ValueError(f"unknown residual method: {method}")
    stop = {"numeric": 178, "quality": 194, "rgb": 226, "null_rgb": 226}[method]
    mask = np.zeros(INPUT_DIM, dtype=np.float32)
    mask[:stop] = 1
    return mask


class ResidualHead(nn.Module):
    """Normalized residual, with identical architecture in every ablation."""

    def __init__(self, method):
        super().__init__()
        self.method = method
        self.register_buffer("mask", torch.from_numpy(feature_mask(method)))
        self.network = nn.Sequential(nn.Linear(INPUT_DIM, 64), nn.ReLU(),
                                     nn.Linear(64, 32), nn.ReLU(), nn.Linear(32, 9))
        nn.init.zeros_(self.network[-1].weight)
        nn.init.zeros_(self.network[-1].bias)

    def forward(self, standardized):
        if standardized.ndim != 2 or standardized.shape[1] != INPUT_DIM:
            raise ValueError("residual head requires a (N,226) matrix")
        return self.network(standardized * self.mask)


def _settings(config):
    seeds = config.get("seeds", [11, 23, 37])
    if (not isinstance(seeds, list) or not seeds or len(set(seeds)) != len(seeds)
            or any(isinstance(s, bool) or not isinstance(s, int) or s < 0 for s in seeds)):
        raise ValueError("seeds must be distinct nonnegative integers")
    settings = {"epochs": 30, "patience": 5, "batch_size": 256, "lr": 0.001,
                "weight_decay": 0.0001, "grad_clip": 1.0, "threads": 2,
                "min_delta": 1e-5}
    settings.update(config.get("training", {}))
    for key in ("epochs", "patience", "batch_size", "threads"):
        value = settings[key]
        if isinstance(value, bool) or not isinstance(value, int) or value < 1:
            raise ValueError(f"{key} must be a positive integer")
    for key in ("lr", "grad_clip"):
        if not np.isfinite(settings[key]) or settings[key] <= 0:
            raise ValueError(f"{key} must be finite and positive")
    for key in ("weight_decay", "min_delta"):
        if not np.isfinite(settings[key]) or settings[key] < 0:
            raise ValueError(f"{key} must be finite and nonnegative")
    return seeds, settings


def _read_split(archive, split):
    result = {}
    # np.load is lazy: this accesses exactly the named split, not every array.
    for field in ("indices", "x", "null_x", "base", "truth", "time_ns", "capture_index"):
        result[field] = np.asarray(archive[f"{split}_{field}"]).copy()
    n = len(result["indices"])
    if n == 0:
        raise ValueError(f"empty residual split: {split}")
    for field in ("indices", "time_ns", "capture_index"):
        a = result[field]
        if a.shape != (n,) or not np.issubdtype(a.dtype, np.integer):
            raise ValueError(f"{split}_{field} must be an aligned integer vector")
    if np.any(np.diff(result["indices"]) <= 0) or np.any(np.diff(result["time_ns"]) <= 0):
        raise ValueError(f"{split} samples must be unique and chronological")
    for field, width in (("x", INPUT_DIM), ("null_x", INPUT_DIM), ("base", 9), ("truth", 9)):
        a = np.asarray(result[field], dtype=np.float64)
        if a.shape != (n, width) or not np.isfinite(a).all():
            raise ValueError(f"invalid {split}_{field} matrix")
        result[field] = a
    if not np.array_equal(result["x"][:, :194], result["null_x"][:, :194]):
        raise ValueError("negative control must preserve all non-embedding inputs")
    return result


def _read_scale(archive):
    scale = np.asarray(archive["delta_scale"], dtype=np.float64).copy()
    if scale.shape != (9,) or not np.isfinite(scale).all() or np.any(scale <= 0):
        raise ValueError("delta_scale must contain nine finite positive values")
    return scale


def _standardize(x, mean, scale):
    x = np.asarray(x, dtype=np.float64)
    mean, scale = np.asarray(mean, dtype=np.float64), np.asarray(scale, dtype=np.float64)
    if (x.ndim != 2 or x.shape[1] != INPUT_DIM or mean.shape != (INPUT_DIM,)
            or scale.shape != (INPUT_DIM,) or not np.isfinite(x).all()
            or not np.isfinite(mean).all() or not np.isfinite(scale).all()
            or np.any(scale <= 0)):
        raise ValueError("invalid features or shared input standardization")
    value = ((x - mean) / scale).astype(np.float32)
    if not np.isfinite(value).all():
        raise FloatingPointError("nonfinite standardized residual features")
    return torch.from_numpy(value)


@torch.no_grad()
def _network_prediction(model, standardized, batch_size):
    model.eval()
    chunks = [model(standardized[start:start + batch_size]).cpu().numpy()
              for start in range(0, len(standardized), batch_size)]
    if not chunks:
        raise ValueError("cannot predict an empty residual batch")
    result = np.concatenate(chunks).astype(np.float64)
    if result.shape != (len(standardized), 9) or not np.isfinite(result).all():
        raise FloatingPointError("nonfinite or incorrectly shaped residual prediction")
    return result


def _score(model, x, part, delta_scale, batch_size):
    residual = _network_prediction(model, x, batch_size)
    return normalized_mse(part["truth"], part["base"] + residual * delta_scale, delta_scale)


def _cpu_state(model):
    return {name: value.detach().cpu().clone() for name, value in model.state_dict().items()}


def _fit_one(train, val, delta_scale, mean, scale, method, seed, settings, folder):
    seed_everything(seed, settings["threads"])
    model = ResidualHead(method)
    initial_state = _cpu_state(model)
    field = "null_x" if method == "null_rgb" else "x"
    x_train = _standardize(train[field], mean, scale)
    x_val = _standardize(val[field], mean, scale)
    target = torch.from_numpy(((train["truth"] - train["base"]) / delta_scale).astype(np.float32))
    if not torch.isfinite(target).all():
        raise FloatingPointError("nonfinite normalized training residual")
    optimizer = torch.optim.AdamW(model.parameters(), lr=settings["lr"],
                                  weight_decay=settings["weight_decay"])
    batch_size = settings["batch_size"]
    baseline_train = normalized_mse(train["truth"], train["base"], delta_scale)
    baseline_val = normalized_mse(val["truth"], val["base"], delta_scale)
    history = [{"epoch": 0, "train_normalized_mse": baseline_train,
                "val_normalized_mse": baseline_val, "optimizer_steps": 0,
                "elapsed_seconds": 0.0}]
    selected_state, selected_loss, selected_epoch = initial_state, baseline_val, 0
    trained_state, trained_loss, trained_epoch, trained_optimizer = None, float("inf"), None, None
    selected_optimizer = copy.deepcopy(optimizer.state_dict())
    patience_loss, no_improvement, steps = baseline_val, 0, 0
    rng = np.random.default_rng(seed)
    started = time.perf_counter()
    for epoch in range(1, settings["epochs"] + 1):
        model.train()
        permutation = rng.permutation(len(x_train))
        for start in range(0, len(permutation), batch_size):
            idx = torch.from_numpy(permutation[start:start + batch_size].copy())
            optimizer.zero_grad(set_to_none=True)
            loss = torch.square(model(x_train[idx]) - target[idx]).mean()
            if not torch.isfinite(loss):
                raise FloatingPointError("nonfinite residual training loss")
            loss.backward()
            norm = torch.nn.utils.clip_grad_norm_(model.parameters(), settings["grad_clip"],
                                                 error_if_nonfinite=True)
            if not torch.isfinite(norm):
                raise FloatingPointError("nonfinite residual training gradient")
            optimizer.step()
            steps += 1
        train_loss = _score(model, x_train, train, delta_scale, batch_size)
        val_loss = _score(model, x_val, val, delta_scale, batch_size)
        history.append({"epoch": epoch, "train_normalized_mse": train_loss,
                        "val_normalized_mse": val_loss, "optimizer_steps": steps,
                        "elapsed_seconds": time.perf_counter() - started})
        if val_loss < trained_loss - TIE_TOLERANCE:
            trained_state, trained_loss, trained_epoch = _cpu_state(model), val_loss, epoch
            trained_optimizer = copy.deepcopy(optimizer.state_dict())
        if val_loss < selected_loss - TIE_TOLERANCE:
            selected_state, selected_loss, selected_epoch = _cpu_state(model), val_loss, epoch
            selected_optimizer = copy.deepcopy(optimizer.state_dict())
        # Early stopping and exact validation minimization are separate rules.
        if val_loss < patience_loss - settings["min_delta"]:
            patience_loss, no_improvement = val_loss, 0
        else:
            no_improvement += 1
        if no_improvement >= settings["patience"]:
            break
    record = {"method": method, "seed": seed, "selected_epoch": selected_epoch,
              "selected_kind": "zero" if selected_epoch == 0 else "trained",
              "val_normalized_mse": selected_loss, "zero_val_normalized_mse": baseline_val,
              "trained_epoch": trained_epoch, "trained_val_normalized_mse": trained_loss,
              "epochs_run": len(history) - 1, "optimizer_steps": steps,
              "training_samples": len(train["indices"]), "validation_samples": len(val["indices"]),
              "parameters": sum(p.numel() for p in model.parameters()),
              "active_input_columns": int(feature_mask(method).sum()),
              "elapsed_seconds": time.perf_counter() - started, "test_evaluated": False,
              "tie_rule": "within 1e-12 prefer zero, then earlier epoch",
              "min_delta_scope": "early stopping only; does not discard smaller selection improvements"}
    folder.mkdir(parents=True)
    checkpoint = {"kind": "ridge_rgb_residual_head", "schema_version": 1,
                  "method": method, "seed": seed, "architecture": [INPUT_DIM, 64, 32, 9],
                  "activation": "relu", "selected_state_dict": selected_state,
                  "trained_state_dict": trained_state,
                  "selected_optimizer_state_dict": selected_optimizer,
                  "trained_optimizer_state_dict": trained_optimizer,
                  "x_mean": torch.from_numpy(mean.copy()), "x_scale": torch.from_numpy(scale.copy()),
                  "delta_scale": torch.from_numpy(delta_scale.copy()),
                  "selection": record, "training_settings": settings}
    torch.save(checkpoint, folder / "checkpoint.pt")
    with (folder / "history.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(history[0]))
        writer.writeheader()
        writer.writerows(history)
    write_json(folder / "training.json", record)
    return record


def fit_all(prepared_path, config, outdir):
    """Fit all four ablations using training/validation arrays only.

    ``config`` has root ``seeds`` and a ``training`` dictionary. ``outdir`` is
    the study directory. The prepared artifact may contain test arrays, but no
    test key is accessed here. A subsequent predict_all call requires the saved
    selection, checkpoints and scaler to match the frozen hashes.
    """
    prepared_path, out = Path(prepared_path).resolve(), Path(outdir).resolve()
    seeds, settings = _settings(config)
    out.mkdir(parents=True, exist_ok=True)
    if (out / "model_selection.json").exists() or (out / "models").exists():
        raise ValueError("residual training output already exists; use a new study directory")
    with np.load(prepared_path, allow_pickle=False) as archive:
        train, val, delta_scale = _read_split(archive, "train"), _read_split(archive, "val"), _read_scale(archive)
    if len(np.intersect1d(train["indices"], val["indices"])) or train["time_ns"][-1] >= val["time_ns"][0]:
        raise ValueError("residual training must precede disjoint validation samples")
    scaler = StandardScaler().fit(train["x"])
    mean, scale = scaler.mean_.astype(np.float64), scaler.scale_.astype(np.float64)
    np.savez_compressed(out / "residual_scaler.npz", x_mean=mean, x_scale=scale,
                        delta_scale=delta_scale, fit_indices=train["indices"])
    records = []
    with threadpool_limits(limits=settings["threads"]):
        for method in METHODS:
            for seed in seeds:
                print(f"residual fit: method={method} seed={seed}", flush=True)
                folder = out / "models" / method / f"seed_{seed}"
                record = _fit_one(train, val, delta_scale, mean, scale, method, seed, settings, folder)
                record["checkpoint"] = str((folder / "checkpoint.pt").relative_to(out))
                records.append(record)
                print(f"  selected epoch={record['selected_epoch']} val={record['val_normalized_mse']:.9f}; "
                      f"best trained epoch={record['trained_epoch']} val={record['trained_val_normalized_mse']:.9f}", flush=True)
    manifest = {"status": "complete", "prepared_sha256": sha256(prepared_path),
                "methods": list(METHODS), "seeds": seeds, "training_settings": settings,
                "models": records, "input_scaling": "positive OOF-training design only, shared across ablations",
                "training_reference": "time-forward out-of-fold Ridge predictions supplied by prepared artifact",
                "evaluation_reference": "same frozen full-training Ridge for validation and test",
                "test_evaluated": False, "diagnostic_trained_candidate": "best epoch >=1, even if zero correction selected"}
    write_json(out / "model_selection.json", manifest)
    paths = [out / "model_selection.json", out / "residual_scaler.npz"]
    paths.extend(out / record["checkpoint"] for record in records)
    paths.extend((out / record["checkpoint"]).parent / name
                 for record in records for name in ("history.csv", "training.json"))
    write_json(out / "model_selection_frozen.json", {
        "prepared_sha256": sha256(prepared_path),
        "artifacts": {str(p.relative_to(out)): sha256(p) for p in paths}})
    return manifest


def load_head(checkpoint_path, *, trained=False):
    """Load one selected (or explicitly diagnostic trained) residual model."""
    checkpoint = torch.load(Path(checkpoint_path), map_location="cpu", weights_only=True)
    if (checkpoint.get("kind") != "ridge_rgb_residual_head" or checkpoint.get("schema_version") != 1
            or checkpoint.get("architecture") != [INPUT_DIM, 64, 32, 9]
            or checkpoint.get("activation") != "relu"):
        raise ValueError("checkpoint is not the fixed residual-head architecture")
    method = checkpoint["method"]
    model = ResidualHead(method)
    state = checkpoint["trained_state_dict" if trained else "selected_state_dict"]
    if not np.array_equal(state["mask"].cpu().numpy(), feature_mask(method)):
        raise ValueError("checkpoint mask disagrees with the named ablation")
    if any(not torch.isfinite(value).all() for value in state.values()):
        raise ValueError("checkpoint contains nonfinite model parameters")
    model.load_state_dict(state, strict=True)
    model.eval()
    mean = checkpoint["x_mean"].cpu().numpy()
    scale = checkpoint["x_scale"].cpu().numpy()
    delta_scale = checkpoint["delta_scale"].cpu().numpy()
    _standardize(np.zeros((1, INPUT_DIM)), mean, scale)
    if delta_scale.shape != (9,) or np.any(delta_scale <= 0) or not np.isfinite(delta_scale).all():
        raise ValueError("invalid saved target scale")
    return model, mean, scale, delta_scale


def predict_checkpoint(checkpoint_path, x, base, *, trained=False, batch_size=256):
    """Return physical prediction and correction for externally supplied inputs."""
    if isinstance(batch_size, bool) or not isinstance(batch_size, int) or batch_size < 1:
        raise ValueError("prediction batch size must be a positive integer")
    model, mean, scale, delta_scale = load_head(checkpoint_path, trained=trained)
    standardized = _standardize(x, mean, scale)
    base = np.asarray(base, dtype=np.float64)
    if base.shape != (len(standardized), 9) or not np.isfinite(base).all():
        raise ValueError("base predictions must be finite nine-channel arrays")
    correction = _network_prediction(model, standardized, batch_size) * delta_scale
    prediction = base + correction
    if not np.isfinite(prediction).all():
        raise FloatingPointError("nonfinite corrected physical prediction")
    return prediction, correction


def predict_all(prepared_path, config, outdir):
    """Replay all saved selections after every fit has completed and been frozen."""
    prepared_path, out = Path(prepared_path).resolve(), Path(outdir).resolve()
    seeds, settings = _settings(config)
    frozen_path = out / "model_selection_frozen.json"
    if not frozen_path.exists():
        raise ValueError("all residual fits must be frozen before prediction")
    frozen = json.loads(frozen_path.read_text())
    if sha256(prepared_path) != frozen["prepared_sha256"]:
        raise ValueError("prepared residual data changed after model selection")
    for name, expected in frozen["artifacts"].items():
        if sha256(out / name) != expected:
            raise ValueError(f"frozen residual selection changed: {name}")
    manifest = json.loads((out / "model_selection.json").read_text())
    if manifest["seeds"] != seeds or manifest["training_settings"] != settings:
        raise ValueError("prediction config differs from frozen training settings")
    expected_pairs = {(method, seed) for method in METHODS for seed in seeds}
    actual_pairs = [(record["method"], record["seed"]) for record in manifest["models"]]
    if set(actual_pairs) != expected_pairs or len(actual_pairs) != len(expected_pairs):
        raise ValueError("incomplete or duplicate residual model selections")
    with np.load(prepared_path, allow_pickle=False) as archive:
        data = {split: _read_split(archive, split) for split in SPLITS}
        delta_scale = _read_scale(archive)
    files = []
    with threadpool_limits(limits=settings["threads"]):
        torch.set_num_threads(settings["threads"])
        for split, part in data.items():
            baseline_path = out / "predictions" / "ridge" / f"{split}.npz"
            baseline_path.parent.mkdir(parents=True, exist_ok=True)
            raw = {name: part[name] for name in ("indices", "time_ns", "capture_index", "truth")}
            np.savez_compressed(baseline_path, **raw, prediction=part["base"], base_prediction=part["base"],
                                correction=np.zeros_like(part["base"]), trained_prediction=part["base"],
                                delta_scale=delta_scale)
            files.append({"method": "ridge", "seed": None, "split": split,
                          "path": str(baseline_path.relative_to(out)), "sha256": sha256(baseline_path),
                          "samples": len(part["indices"]), "normalized_mse": normalized_mse(part["truth"], part["base"], delta_scale)})
        for record in manifest["models"]:
            for split, part in data.items():
                field = "null_x" if record["method"] == "null_rgb" else "x"
                path = out / "predictions" / record["method"] / f"seed_{record['seed']}" / f"{split}.npz"
                checkpoint_path = out / record["checkpoint"]
                prediction, correction = predict_checkpoint(checkpoint_path, part[field], part["base"],
                                                              batch_size=settings["batch_size"])
                trained_prediction, trained_correction = predict_checkpoint(
                    checkpoint_path, part[field], part["base"], trained=True, batch_size=settings["batch_size"])
                path.parent.mkdir(parents=True, exist_ok=True)
                raw = {name: part[name] for name in ("indices", "time_ns", "capture_index", "truth")}
                np.savez_compressed(path, **raw, prediction=prediction, correction=correction,
                                    base_prediction=part["base"], trained_prediction=trained_prediction,
                                    trained_correction=trained_correction, delta_scale=delta_scale)
                files.append({"method": record["method"], "seed": record["seed"], "split": split,
                              "path": str(path.relative_to(out)), "sha256": sha256(path),
                              "samples": len(part["indices"]), "selected_epoch": record["selected_epoch"],
                              "normalized_mse": normalized_mse(part["truth"], prediction, delta_scale),
                              "trained_normalized_mse": normalized_mse(part["truth"], trained_prediction, delta_scale)})
    result = {"status": "complete", "files": files, "model_selection_frozen_sha256": sha256(frozen_path),
              "prepared_sha256": sha256(prepared_path), "test_evaluated": True,
              "train_scope": "out-of-fold Ridge reference on residual training rows; not full-training in-sample performance",
              "trained_prediction_scope": "validation-best epoch >=1 diagnostic, not replacement for selected zero correction"}
    write_json(out / "predictions_manifest.json", result)
    return result
