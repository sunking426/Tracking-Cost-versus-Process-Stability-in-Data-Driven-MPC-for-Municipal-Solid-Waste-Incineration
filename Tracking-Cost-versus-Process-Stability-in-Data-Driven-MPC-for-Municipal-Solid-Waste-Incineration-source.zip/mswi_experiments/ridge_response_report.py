"""Source-bound reporting of model-implied Ridge operation responses.

Admission is a prespecified heuristic on training-model responses and validation
coverage. It is not a causal-effect, physical actuator or plant-safety test.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np

from .data import control_values
from .numeric_baselines import sha256, write_json
from .ridge_validation_report import endpoint_metrics


MODEL_IDS = ('full', 'early', 'middle', 'late', 'pooled_matched')
PHYSICAL = ('temperature', 'pressure', 'steam', 'oxygen')
UNITS = ('degC', 'Pa', 't/h', 'vol%')
MV_SHORT = ('Primary fan', 'Air-temp valve', 'Secondary fan', 'Induced fan',
            'Feeder stop', 'Drying stop', 'Combustion stop', 'Burnout stop')


def archive(path):
    with np.load(path, allow_pickle=False) as raw:
        return {key: raw[key].copy() for key in raw.files}


def physical_responses(response, amplitude):
    """Convert M,H,9,8 unit-input kernels to M,H,4,8 for a fixed positive step."""
    values, amp = np.asarray(response, dtype=np.float64), np.asarray(amplitude, dtype=np.float64)
    if (values.ndim != 4 or values.shape[2:] != (9,8) or amp.shape != (8,)
            or np.any(amp <= 0) or not np.isfinite(values).all() or not np.isfinite(amp).all()):
        raise ValueError('finite model/horizon/nine-CV/eight-MV responses and positive amplitudes required')
    return np.swapaxes(control_values(np.swapaxes(values,2,3)),2,3)*amp[None,None,None,:]


def response_screen(step_physical, physical_scale, cfg):
    """Prespecified same-size model screening; no validation/test outcome input.

    A consistent inverse response across horizons is allowed. Material sign
    disagreement means different fitted models disagree at the SAME horizon.
    The larger full-training reference is not a same-size training replicate.
    """
    response, scale = np.asarray(step_physical,dtype=np.float64), np.asarray(physical_scale,dtype=np.float64)
    if (response.shape != (5,10,4,8) or scale.shape != (4,) or np.any(scale<=0)
            or not np.isfinite(response).all() or not np.isfinite(scale).all()):
        raise ValueError('five models, ten steps, four outputs and eight inputs required')
    normalized=response/scale[None,None,:,None]
    block=normalized[1:]
    dead=float(cfg['response_deadband_sigma'])
    endpoints=np.asarray(cfg['gate_endpoints'],dtype=np.int64)-1
    if not np.array_equal(endpoints,[0,4,9]) or not 0<dead<1:
        raise ValueError('fixed response endpoints/deadband required')
    selected=block[:,endpoints]
    flips=(selected.max(0)>dead)&(selected.min(0)<-dead)
    last=block[:,9]
    common_positive=(last>dead).all(0); common_negative=(last < -dead).all(0)
    same_sign=common_positive|common_negative
    absolute=np.abs(last)
    ratio=np.divide(absolute.max(0),absolute.min(0),out=np.full((4,8),np.inf),where=absolute.min(0)>0)
    reference=normalized[0,9]
    reference_opposes=(common_positive&(reference < -dead))|(common_negative&(reference>dead))
    stable=same_sign&(ratio<=float(cfg['max_response_amplitude_ratio']))&~reference_opposes
    return {'normalized':normalized,'material_flips':flips,'stable_pairs':stable,
            'same_sign':same_sign,'amplitude_ratio':ratio,'reference_opposes':reference_opposes,
            'response_eligible':stable.any(0)&~flips.any(axis=(0,1))}


def coverage_summary(inputs):
    full=np.asarray(inputs['full_request_executed'],dtype=bool)
    support=np.asarray(inputs['supported'],dtype=bool)
    if full.ndim!=2 or full.shape[1]!=16 or len(full)==0 or full.shape!=support.shape:
        raise ValueError('aligned nonempty sixteen-case execution/support masks required')
    realized=np.asarray(inputs['executed_delta'],dtype=np.float64)
    requested=np.asarray(inputs['requested_delta'],dtype=np.float64)
    if realized.shape!=(len(full),16,8) or requested.shape!=(16,8):
        raise ValueError('physical execution/request arrays do not align')
    columns=np.repeat(np.arange(8),2)
    denominator=np.abs(requested[np.arange(16),columns])
    if np.any(denominator<=0): raise ValueError('nonzero trial amplitudes required')
    fraction=np.abs(realized[:,np.arange(16),columns])/denominator[None]
    return {'samples':len(full),'full_request_fraction':full.mean(0).reshape(8,2).tolist(),
        'requested_support_fraction':support.mean(0).reshape(8,2).tolist(),
        'joint_fraction':(full&support).mean(0).reshape(8,2).tolist(),
        'mean_amplitude_fraction':fraction.mean(0).reshape(8,2).tolist(),
        'baseline_support_fraction':float(np.mean(inputs['baseline_supported'])),
        'logged_support_fraction':float(np.mean(inputs['logged_supported']))}


def admission(screen, validation_coverage, cfg):
    """Never accept test coverage or test rewards as a selection input."""
    joint=np.asarray(validation_coverage['joint_fraction'],dtype=np.float64)
    if joint.shape!=(8,2) or not np.isfinite(joint).all() or np.any((joint<0)|(joint>1)):
        raise ValueError('validation coverage must be eight channels by two signs')
    supported=(joint>=float(cfg['minimum_supported_executable_fraction'])).all(1)
    eligible=np.asarray(screen['response_eligible'])&supported
    return {'response_eligible':np.asarray(screen['response_eligible']).tolist(),
            'coverage_eligible':supported.tolist(),'eligible_channels':np.flatnonzero(eligible).tolist(),
            'status':'limited_control_candidate' if eligible.any() else 'stop_before_control',
            'basis':'Training-model response screening and validation input coverage only; no test outcomes.',
            'interpretation':'Heuristic eligibility for a separate bounded model-control experiment; not causal, physical-execution or safety validation.'}


def csv_write(path, rows):
    with Path(path).open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)


def load_study(study_dir):
    from .ridge_response_study import verify
    root=Path(study_dir).resolve()
    cfg=json.loads((root/'config.json').read_text()); stats=json.loads((root/'stats.json').read_text())
    frozen=json.loads((root/'selection_frozen.json').read_text())
    verify(frozen['files'],root); verify(frozen['source_code_hashes'])
    verify(json.loads((root/'input_hashes.json').read_text()))
    selection=json.loads((root/'selection.json').read_text())
    if tuple(r['model_id'] for r in selection['models'])!=MODEL_IDS:
        raise ValueError('five prespecified models required in fixed order')
    run=json.loads((root/'run_manifest.json').read_text())
    if (run['status']!='complete' or run['source_selection_sha256']!=sha256(root/'selection.json')
            or run['source_selection_frozen_sha256']!=sha256(root/'selection_frozen.json')
            or run['response_checks_sha256']!=sha256(root/'response_checks.json')
            or run['trajectories_dropped']!=0 or run['predictions_clipped'] or run['policy_optimized']):
        raise ValueError('completed unchanged diagnostic run required')
    for row in run['files']:
        if sha256(root/row['path'])!=row['sha256']: raise ValueError('changed run artifact')
    responses=archive(root/'responses.npz')
    if tuple(responses['model_ids'].tolist())!=MODEL_IDS:
        raise ValueError('response identity mismatch')
    inputs={s:archive(root/f'inputs/{s}.npz') for s in ('val','test')}
    rollouts={}
    for split in inputs:
        for model in MODEL_IDS:
            row=archive(root/f'rollouts/{split}/{model}.npz'); origin=inputs[split]
            for key in ('indices','time_ns','truth_cv'):
                if not np.array_equal(row[key],origin[key]): raise ValueError('rollout alignment differs: '+key)
            n=len(origin['indices'])
            for key,shape in [('baseline_pred',(n,10,9)),('logged_pred',(n,10,9)),('trial_pred',(n,2,16,10,9))]:
                if row[key].shape!=shape or not np.isfinite(row[key]).all(): raise ValueError('invalid rollout '+key)
            rollouts[split,model]=row
    expected={(s,m) for s in ('val','test') for m in MODEL_IDS}
    listed={(r['split'],r['model_id']) for r in run['files'] if r.get('kind')=='rollout'}
    if listed!=expected or len(run['files'])!=11: raise ValueError('ten complete model/split rollouts required')
    return root,cfg,stats,selection,responses,inputs,rollouts


def summarize(study_dir):
    root,cfg,stats,selection,responses,inputs,rollouts=load_study(study_dir)
    physical={pattern:physical_responses(responses[pattern],responses['amp']) for pattern in ('pulse','step')}
    screen=response_screen(physical['step'],responses['phys_scale'],cfg)
    coverage={s:coverage_summary(v) for s,v in inputs.items()}
    gate=admission(screen,coverage['val'],cfg)
    response_rows=[]
    for pattern,values in physical.items():
        for m,model in enumerate(MODEL_IDS):
            for h in range(10):
                for q,quantity in enumerate(PHYSICAL):
                    for j,mv in enumerate(stats['mv_names']):
                        response_rows.append({'pattern':pattern,'model':model,'horizon':h+1,'quantity':quantity,
                            'mv':mv,'amplitude':float(responses['amp'][j]),'response':float(values[m,h,q,j]),
                            'response_sigma':float(values[m,h,q,j]/responses['phys_scale'][q])})
    pair_rows=[]
    for q,quantity in enumerate(PHYSICAL):
        for j,mv in enumerate(stats['mv_names']):
            ratio=float(screen['amplitude_ratio'][q,j])
            pair_rows.append({'quantity':quantity,'mv':mv,'same_sign':bool(screen['same_sign'][q,j]),
                'amplitude_ratio':ratio if np.isfinite(ratio) else None,
                'reference_opposes':bool(screen['reference_opposes'][q,j]),
                'stable_h10_pair':bool(screen['stable_pairs'][q,j]),
                'material_flip_h1':bool(screen['material_flips'][0,q,j]),
                'material_flip_h5':bool(screen['material_flips'][1,q,j]),
                'material_flip_h10':bool(screen['material_flips'][2,q,j])})
    metric_rows=[]
    trial_rows=[]
    for (split,model),row in rollouts.items():
        # The hypothetical held path is not the plant's observed input path;
        # its error against actual outcomes is a sensitivity diagnostic only.
        for branch in ('logged','baseline'):
            for h in (1,5,10):
                metrics=endpoint_metrics(row['truth_cv'][:,h-1],row[branch+'_pred'][:,h-1],stats['delta_scale'])
                metric_rows.append({'split':split,'model':model,'branch':branch,'horizon':h,
                    'samples':metrics['samples'],'normalized_mse':metrics['normalized_mse'],
                    **{q+'_mae':metrics['physical_mae'][k] for k,q in enumerate(PHYSICAL)}})
        for pattern,k in (('pulse',0),('step',1)):
            for case in range(16):
                gain=row['trial_reward'][:,k,case].sum(1)-row['baseline_reward'].sum(1)
                trial_rows.append({'split':split,'model':model,'pattern':pattern,'mv':stats['mv_names'][case//2],
                    'sign':-1 if case%2==0 else 1,'samples':len(gain),'mean_return_difference':float(gain.mean()),
                    'positive_fraction':float(np.mean(gain>0)),
                    'trial_violation_fraction':float(row['trial_violation'][:,k,case].mean()),
                    'baseline_violation_fraction':float(row['baseline_violation'].mean())})
    result={'status':'complete','model_ids':list(MODEL_IDS),'models':selection['models'],
        'gate':gate,'coverage':coverage,'stable_pairs':screen['stable_pairs'].tolist(),
        'material_flips':screen['material_flips'].tolist(),'physical_scale':responses['phys_scale'].tolist(),
        'amplitudes':responses['amp'].tolist(),'spectral_radius':responses['spectral_radius'].tolist(),
        'pairs':pair_rows,'forecast_metrics':metric_rows,'trial_costs':trial_rows,
        'source_run_manifest_sha256':sha256(root/'run_manifest.json'),
        'source_selection_frozen_sha256':sha256(root/'selection_frozen.json'),
        'limits':['All responses are properties of observationally fitted linear models, not identified plant effects.',
                  'Response directions are state independent before projection. Repeated histories are implementation checks, not independent interventions.',
                  'Block models have equal sample counts and alpha, but separately fitted input scalers; this tests stability of the complete training procedure.',
                  'Pooled shares training rows with the blocks; full uses more rows. Neither is an independent replicate.',
                  'Support uses initial MV/CV/action only, not full history or future trajectory support; percentile thresholds are heuristic.',
                  'Test period was previously inspected. No new blind holdout, physical actuator execution, or causal/control validation is claimed.',
                  'Fixed pulse/step return changes are diagnostics of the fitted reward/model, not an optimized policy comparison.',
                  'The admission rule is fixed before results. Failure is a reason to pause this route, not proof that the plant is uncontrollable.']}
    folder=root/'statistics';folder.mkdir(exist_ok=True)
    for name,rows in [('responses',response_rows),('stability_pairs',pair_rows),('forecast_metrics',metric_rows),('trial_costs',trial_rows)]:
        csv_write(folder/(name+'.csv'),rows)
    write_json(folder/'summary.json',result)
    return result,physical


def render(root,result,physical):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    folder=root/'figures';folder.mkdir(exist_ok=True)
    colors=['#555555','#1f77b4','#ff7f0e','#2ca02c','#000000']
    fig,axes=plt.subplots(2,2,figsize=(13,8),constrained_layout=True)
    for q,ax in enumerate(axes.flat):
        for m,model in enumerate(MODEL_IDS):
            ax.plot(np.arange(8),physical['step'][m,9,q],marker='o',markersize=4,
                    color=colors[m],ls='--' if m==0 else '-',label=model)
        ax.axhline(0,color='gray',lw=.8);ax.set_xticks(np.arange(8),MV_SHORT,rotation=30,ha='right')
        ax.set_title(PHYSICAL[q]);ax.set_ylabel('Predicted change ('+UNITS[q]+')');ax.grid(alpha=.2)
    handles,labels=axes.flat[0].get_legend_handles_labels();fig.legend(handles,labels,loc='outside upper center',ncol=5)
    fig.suptitle('Ten-step model response to +10% action-bound level step',y=1.07)
    for suffix in ('png','svg'):fig.savefig(folder/('step_endpoints.'+suffix),dpi=160,bbox_inches='tight')
    plt.close(fig)
    # Channels fixed before any model fitting; not selected by effect size.
    choices=(0,3,4);fig,axes=plt.subplots(3,4,figsize=(14,9),constrained_layout=True)
    for row,j in enumerate(choices):
        for q in range(4):
            ax=axes[row,q]
            for m,model in enumerate(MODEL_IDS):
                ax.plot(np.arange(1,11),physical['step'][m,:,q,j],color=colors[m],
                        ls='--' if m==0 else '-',label=model)
            ax.axhline(0,color='gray',lw=.6);ax.grid(alpha=.2)
            ax.set_title(MV_SHORT[j]+' / '+PHYSICAL[q],fontsize=9)
            ax.set_xlabel('Minutes after action');ax.set_ylabel(UNITS[q])
    handles,labels=axes[0,0].get_legend_handles_labels();fig.legend(handles,labels,loc='outside upper center',ncol=5)
    fig.suptitle('Prespecified operation examples: model-implied step responses',y=1.05)
    for suffix in ('png','svg'):fig.savefig(folder/('response_curves.'+suffix),dpi=160,bbox_inches='tight')
    plt.close(fig)
    fig,axes=plt.subplots(2,1,figsize=(12,7),constrained_layout=True)
    stable=np.asarray(result['stable_pairs']);flips=np.asarray(result['material_flips']).any(0)
    state=np.where(flips,-1,np.where(stable,1,0))
    from matplotlib.colors import ListedColormap,BoundaryNorm
    axes[0].imshow(state,aspect='auto',cmap=ListedColormap(['#d95f5f','#dddddd','#70b780']),
                   norm=BoundaryNorm([-1.5,-.5,.5,1.5],3))
    axes[0].set_yticks(np.arange(4),PHYSICAL);axes[0].set_xticks(np.arange(8),MV_SHORT)
    axes[0].set_title('Red: material model sign conflict; green: stable h10 pair; gray: unresolved')
    for q in range(4):
        for j in range(8):axes[0].text(j,q,str(state[q,j]),ha='center',va='center',fontsize=10)
    for split,color in [('val','#1f77b4'),('test','#ff7f0e')]:
        values=np.asarray(result['coverage'][split]['joint_fraction'])
        for sign,marker in [(0,'v'),(1,'^')]:
            axes[1].plot(np.arange(8),values[:,sign],color=color,marker=marker,
                         ls='--' if sign==0 else '-',label=split+(' minus' if sign==0 else ' plus'))
    axes[1].axhline(.8,color='black',ls=':',label='Validation admission threshold')
    axes[1].set_xticks(np.arange(8),MV_SHORT,rotation=20,ha='right');axes[1].set_ylim(-.03,1.03)
    axes[1].set_ylabel('Full request AND supported fraction');axes[1].grid(alpha=.2)
    axes[1].legend(loc='lower left',fontsize=8,ncol=3)
    for suffix in ('png','svg'):fig.savefig(folder/('stability_and_coverage.'+suffix),dpi=160,bbox_inches='tight')
    plt.close(fig)


def readout(root,result):
    stats=json.loads((root/'stats.json').read_text());cfg=json.loads((root/'config.json').read_text())
    lines=['Ridge operation-response and temporal-stability study','',
        'Admission: '+result['gate']['status'],
        'Eligible channels: '+str([stats['mv_names'][j] for j in result['gate']['eligible_channels']]),
        'Admission uses training-model response agreement and validation coverage only.','',
        'Fixed +10% action-bound step: nine CVs aggregated to four physical quantities.',
        'Stable h10 pairs: '+str(int(np.asarray(result['stable_pairs']).sum()))+' of32.',
        'Material sign-conflict pairs (any h1/5/10): '+str(int(np.asarray(result['material_flips']).any(0).sum()))+' of32.',
        'Thresholds are heuristic: deadband='+str(cfg['response_deadband_sigma'])+' innovation SD; amplitude ratio<='+str(cfg['max_response_amplitude_ratio'])+'; each-sign validation executable/support fraction>='+str(cfg['minimum_supported_executable_fraction']),
        '','Model | training rows | alpha | homogeneous CV spectral radius']
    for r,radius in zip(result['models'],result['spectral_radius']):
        lines.append(f"{r['model_id']} | {r['training_samples']} | {r['alpha']} | {radius:.12g}")
    for split,c in result['coverage'].items():
        lines+=['',split+': '+str(c['samples'])+' anchors',
                'Logged-action support='+str(c['logged_support_fraction'])+'; zero-action support='+str(c['baseline_support_fraction'])]
        for j,mv in enumerate(stats['mv_names']):lines.append(mv+' minus/plus jointly executable/supported='+str(c['joint_fraction'][j]))
    lines+=['','All prediction and fixed-action reward summaries are saved in statistics/.',
            'No MPC, BC or reinforcement-learning policy comparison is contained in this diagnostic report.','',*result['limits']]
    (root/'RESULTS.txt').write_text('\n'.join(lines)+'\n')


def build_report(study_dir):
    root=Path(study_dir).resolve();result,physical=summarize(root)
    render(root,result,physical);readout(root,result)
    files=[*sorted((root/'statistics').glob('*')),*sorted((root/'figures').glob('*')),root/'RESULTS.txt']
    write_json(root/'report_manifest.json',{'status':'complete','files':{str(p.relative_to(root)):sha256(p) for p in files if p.is_file()},
        'source_run_manifest_sha256':sha256(root/'run_manifest.json')})
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('study_dir')
    args=parser.parse_args();result=build_report(args.study_dir)
    print(json.dumps(result['gate']))


if __name__=='__main__':main()
