"""Source-bound readout of selected RGB residual heads and separate diagnostics.

No fitting, model selection or recursive evaluation occurs here. The frozen
validation selection is the main result; a trained nonzero head never replaces
a selected zero correction because of its test performance.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np

from .data import CV_NAMES
from .numeric_baselines import sha256
from .numeric_baselines_report import metric_summary, paired_endpoints
from .visual_diagnostics_statistics import DAY_NS, paired_block_interval


METHODS = ("ridge", "numeric", "quality", "rgb", "null_rgb")
CORRECTORS = METHODS[1:]
COMPARISONS = (("numeric", "ridge"), ("quality", "numeric"), ("rgb", "numeric"),
               ("rgb", "ridge"), ("rgb", "quality"), ("rgb", "null_rgb"))
GATE_CONTROLS = ("ridge", "numeric", "quality", "null_rgb")
PRIMARY_COMPARISONS = ("rgb_vs_quality", "rgb_vs_null_rgb")
QUANTITIES = ("temperature", "pressure", "steam", "oxygen")
UNITS = ("°C", "Pa", "t/h", "vol%")
ENDPOINTS = ("nine_channel_normalized_mse", *[q+"_mae" for q in QUANTITIES])
LABELS = {"ridge": "固定 Ridge", "numeric": "数值残差", "quality": "简单外观残差",
          "rgb": "RGB 残差", "null_rgb": "错配 RGB 残差"}
COLORS = {"ridge": "#666666", "numeric": "#1f77b4", "quality": "#ff7f0e",
          "rgb": "#2ca02c", "null_rgb": "#a0a0a0"}
TITLES = ("炉膛平均温度", "炉膛负压", "主蒸汽流量", "烟气氧浓度")


def _json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+"\n", encoding="utf-8")


def _csv(path, rows):
    if not rows: raise ValueError("cannot export empty comparison table")
    with Path(path).open("w", newline="", encoding="utf-8") as handle:
        writer=csv.DictWriter(handle, fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)


def _metric_row(metric):
    row={"samples": metric["samples"], "normalized_mse": metric["normalized_mse"]}
    for j,q in enumerate(QUANTITIES):
        row[q+"_mae"]=metric["physical_mae"][j]
        row[q+"_rmse"]=metric["physical_rmse"][j]
        row[q+"_pooled_rmse"]=metric["physical_pooled_rmse"][j]
    return row


def recursive_gate(selected_test_metrics, comparisons, rule):
    """Evaluate only the predeclared development gate; never select a test-best head."""
    details=[]
    rgb_mae=np.asarray(selected_test_metrics["rgb"]["physical_mae"], dtype=float)
    if rgb_mae.shape!=(4,) or not np.isfinite(rgb_mae).all(): raise ValueError("invalid selected RGB MAEs")
    for control in GATE_CONTROLS:
        contrast=comparisons["rgb_vs_"+control]
        if contrast["candidate"]!="rgb" or contrast["reference"]!=control:
            raise ValueError("gate contrasts must compare selected RGB with the named control")
        low=float(contrast["ci_lower"][0]);high=float(contrast["ci_upper"][0])
        reference=np.asarray(selected_test_metrics[control]["physical_mae"], dtype=float)
        if not np.isfinite([low, high]).all() or reference.shape!=(4,) or not np.isfinite(reference).all():
            raise ValueError("gate requires finite paired intervals and four physical means")
        individual=(rgb_mae <= reference).tolist()
        details.append({"control":control,"nmse_difference":float(contrast["difference"][0]),
            "nmse_ci_lower":low,"nmse_ci_upper":high,"nmse_lower_strictly_positive":bool(low>0),
            "rgb_physical_mae":rgb_mae.tolist(),"control_physical_mae":reference.tolist(),
            "physical_mae_no_worse":individual,"all_physical_mae_no_worse":bool(all(individual))})
    passed=all(d["nmse_lower_strictly_positive"] and d["all_physical_mae_no_worse"] for d in details)
    return {"passed":passed,"decision":"eligible_for_predeclared_recursive_followup" if passed else "stop_after_one_step",
            "rule_from_config":rule,"metric_version":"validation_selected",
            "controls":list(GATE_CONTROLS),"details":details,
            "nmse_constraints_passed":sum(d["nmse_lower_strictly_positive"] for d in details),
            "physical_constraints_passed":sum(sum(d["physical_mae_no_worse"]) for d in details),
            "total_nmse_constraints":4,"total_physical_constraints":16,
            "scope":"Predeclared exploratory development gate; not a confirmatory significance or journal standard",
            "test_based_model_reselection":False,"recursive_evaluation_run_by_report":False}


def load_completed_study(study_dir):
    root=Path(study_dir).resolve()
    json_names=("config.json","preparation.json","model_selection.json","model_selection_frozen.json","predictions_manifest.json")
    cfg,preparation,selection,frozen,manifest=[json.loads((root/n).read_text()) for n in json_names]
    if (preparation["status"]!="complete" or selection["status"]!="complete" or manifest["status"]!="complete"
            or selection["test_evaluated"] or not manifest["test_evaluated"]
            or manifest["model_selection_frozen_sha256"]!=sha256(root/"model_selection_frozen.json")):
        raise ValueError("complete, frozen validation selections must precede prediction")
    prepared_sha=sha256(root/"prepared.npz")
    if any(r["prepared_sha256"]!=prepared_sha for r in (preparation,selection,frozen,manifest)):
        raise ValueError("prepared residual data changed after model selection")
    seeds=[int(s) for s in cfg["seeds"]]
    if (not seeds or len(seeds)!=len(set(seeds)) or selection["seeds"]!=seeds
            or selection["methods"]!=list(CORRECTORS)
            or cfg["statistics"]["primary_comparisons"]!=list(PRIMARY_COMPARISONS)):
        raise ValueError("unexpected frozen methods, seeds or primary comparisons")
    sources={n:sha256(root/n) for n in json_names};sources["prepared.npz"]=prepared_sha
    sources["PROTOCOL.txt"]=sha256(root/"PROTOCOL.txt")
    for name,digest in frozen["artifacts"].items():
        if sha256(root/name)!=digest:raise ValueError("frozen residual artifact changed: "+name)
        sources[name]=digest
    models={(r["method"],r["seed"]):r for r in selection["models"]}
    if len(selection["models"])!=len(CORRECTORS)*len(seeds) or set(models)!={(m,s) for m in CORRECTORS for s in seeds}:
        raise ValueError("missing or repeated selected residual models")
    indexed={(r["method"],r["seed"],r["split"]):r for r in manifest["files"]}
    expected={(m,s,split) for m in METHODS for s in ([None] if m=="ridge" else seeds) for split in ("train","val","test")}
    if set(indexed)!=expected or len(manifest["files"])!=len(expected):raise ValueError("incomplete unique prediction inventory")
    with np.load(root/"prepared.npz",allow_pickle=False) as raw:
        scale=raw["delta_scale"].astype(float)
        shared={s:{k:raw[s+"_"+k].copy() for k in ("indices","time_ns","capture_index","truth","base")}
                for s in ("train","val","test")}
    if scale.shape!=(9,) or not np.isfinite(scale).all() or np.any(scale<=0):raise ValueError("invalid canonical delta scale")
    arrays={split:{m:[] for m in METHODS} for split in shared};checks=[]
    for split,identity in shared.items():
        n=len(identity["indices"])
        if n!=preparation["partition_counts"][split] or n==0 or np.any(np.diff(identity["time_ns"])<=0):
            raise ValueError("prepared split count or chronological order invalid")
        for method in METHODS:
            for seed in ([None] if method=="ridge" else seeds):
                item=indexed[(method,seed,split)]
                name=f"predictions/ridge/{split}.npz" if method=="ridge" else f"predictions/{method}/seed_{seed}/{split}.npz"
                path=root/name
                if item["path"]!=name or item["samples"]!=n or item["sha256"]!=sha256(path):
                    raise ValueError("prediction path, size or hash differs from manifest")
                with np.load(path,allow_pickle=False) as raw:row={k:raw[k].copy() for k in raw.files}
                for key in ("indices","time_ns","capture_index","truth"):
                    if not np.array_equal(row[key],identity[key]):raise ValueError("predictions do not share fixed identities and targets")
                if not np.array_equal(row["base_prediction"],identity["base"]) or not np.array_equal(row["delta_scale"],scale):
                    raise ValueError("baseline or target scales differ across corrections")
                for key in ("truth","prediction","base_prediction","correction","trained_prediction"):
                    if row[key].shape!=(n,9) or not np.isfinite(row[key]).all():raise ValueError("invalid nine-channel prediction field")
                if not np.array_equal(row["prediction"],row["base_prediction"]+row["correction"]):
                    raise ValueError("selected prediction does not equal base plus saved correction")
                selected_metric=metric_summary(row["prediction"][None],row["truth"],scale)["normalized_mse"]
                if not np.isclose(selected_metric,item["normalized_mse"],rtol=0,atol=1e-10):
                    raise ValueError("selected NMSE differs from saved prediction")
                if method=="ridge":
                    if not np.array_equal(row["prediction"],row["base_prediction"]) or not np.array_equal(row["trained_prediction"],row["base_prediction"]):
                        raise ValueError("Ridge reference must have zero correction")
                else:
                    record=models[(method,seed)]
                    if record["selected_kind"]!=("zero" if record["selected_epoch"]==0 else "trained"):
                        raise ValueError("selection kind and epoch disagree")
                    if item["selected_epoch"]!=record["selected_epoch"] or record["trained_epoch"]<1:
                        raise ValueError("invalid trained-versus-selected epoch identity")
                    if record["selected_kind"]=="zero" and not np.array_equal(row["prediction"],row["base_prediction"]):
                        raise ValueError("selected zero was replaced by nonzero diagnostic")
                    if record["selected_kind"]=="trained" and (record["selected_epoch"]!=record["trained_epoch"]
                            or not np.array_equal(row["prediction"],row["trained_prediction"])):
                        raise ValueError("selected nonzero checkpoint differs from the validation-best trained head")
                    if (row["trained_correction"].shape!=(n,9) or
                            not np.array_equal(row["trained_prediction"],row["base_prediction"]+row["trained_correction"])):
                        raise ValueError("trained diagnostic and correction disagree")
                    trained_metric=metric_summary(row["trained_prediction"][None],row["truth"],scale)["normalized_mse"]
                    if not np.isclose(trained_metric,item["trained_normalized_mse"],rtol=0,atol=1e-10):
                        raise ValueError("diagnostic NMSE differs from saved predictions")
                    if split=="val" and (not np.isclose(selected_metric,record["val_normalized_mse"],rtol=0,atol=1e-9)
                            or not np.isclose(trained_metric,record["trained_val_normalized_mse"],rtol=0,atol=1e-9)):
                        raise ValueError("validation predictions differ from frozen model selection")
                    if split=="val":
                        zero_score=metric_summary(row["base_prediction"][None],row["truth"],scale)["normalized_mse"]
                        if not np.isclose(zero_score,record["zero_val_normalized_mse"],rtol=0,atol=1e-9):
                            raise ValueError("zero-correction validation score differs from common Ridge")
                arrays[split][method].append(row)
                sources[name]=item["sha256"]
                checks.append({"method":method,"seed":seed,"split":split,"samples":n,
                    "unique_captures":len(np.unique(row["capture_index"])),"selected_and_trained_integrity_verified":True})
    for previous,next_split in (("train","val"),("val","test")):
        if shared[previous]["time_ns"].max()>=shared[next_split]["time_ns"].min():raise ValueError("chronological partitions overlap")
        if np.intersect1d(shared[previous]["indices"],shared[next_split]["indices"]).size:raise ValueError("sample identities overlap")
    return root,cfg,preparation,selection,models,arrays,shared,scale,sources,checks


def summarize_study(study_dir):
    root,cfg,prep,selection,models,arrays,shared,scale,sources,checks=load_completed_study(study_dir)
    folder=root/"statistics";folder.mkdir(exist_ok=True);seeds=cfg["seeds"]
    versions={"selected":"prediction","trained_diagnostic":"trained_prediction"};metrics={};stacked={}
    for version,field in versions.items():
        metrics[version]={};stacked[version]={};overall=[];by_seed=[];by_day=[];channels=[]
        for split,identity in shared.items():
            metrics[version][split]={};stacked[version][split]={};truth=identity["truth"]
            captures=len(np.unique(identity["capture_index"]));days=identity["time_ns"]//DAY_NS
            for method in METHODS:
                model_seeds=[None] if method=="ridge" else seeds
                pred=np.stack([r[field] for r in arrays[split][method]]);stacked[version][split][method]=pred
                summary=metric_summary(pred,truth,scale);metrics[version][split][method]=summary
                overall.append({"metric_version":version,"split":split,"method":method,"fits":len(pred),
                    "unique_captures":captures,**_metric_row(summary)})
                entries=[("method_average",method,None,pred,summary)]
                for i,seed in enumerate(model_seeds):
                    met=metric_summary(pred[i:i+1],truth,scale)
                    identity_name=method if seed is None else f"{method}_seed_{seed}"
                    by_seed.append({"metric_version":version,"split":split,"method":method,"seed":seed,
                                    "unique_captures":captures,**_metric_row(met)})
                    entries.append(("individual_fit",identity_name,seed,pred[i:i+1],met))
                for kind,identity_name,seed,prediction,met in entries:
                    for j,channel in enumerate(CV_NAMES):
                        channels.append({"metric_version":version,"split":split,"row_kind":kind,"identity":identity_name,
                            "method":method,"seed":seed,"channel":channel,"unit":"°C" if j<6 else UNITS[j-5],
                            "samples":len(truth),"mae":met["channel_mae"][j],"mean_fit_rmse":met["channel_rmse"][j],
                            "pooled_rmse":met["channel_pooled_rmse"][j]})
                    for day in np.unique(days):
                        mask=days==day;daily=metric_summary(prediction[:,mask],truth[mask],scale)
                        by_day.append({"metric_version":version,"split":split,"date":str(np.datetime64(int(day),"D")),
                            "row_kind":kind,"identity":identity_name,"method":method,"seed":seed,"fits":len(prediction),
                            "unique_captures":len(np.unique(shared[split]["capture_index"][mask])),**_metric_row(daily)})
        prefix="" if version=="selected" else "trained_diagnostic_"
        for name,rows in (("overall",overall),("by_seed",by_seed),("by_day",by_day),("channels",channels)):
            _csv(folder/(prefix+name+".csv"),rows)
    comparisons={};comparison_rows=[];day_ids=shared["test"]["time_ns"]//DAY_NS;options=cfg["statistics"]
    for candidate,reference in COMPARISONS:
        differences=paired_endpoints(stacked["selected"]["test"][reference],stacked["selected"]["test"][candidate],
                                     shared["test"]["truth"],scale)
        interval=paired_block_interval(differences,day_ids,draws=options["bootstrap_draws"],
            seed=options["bootstrap_seed"],confidence_level=options["confidence_level"])
        name=candidate+"_vs_"+reference
        interval.update(reference=reference,candidate=candidate,endpoints=list(ENDPOINTS),metric_version="selected",
            reference_fits=1 if reference=="ridge" else len(seeds),candidate_fits=len(seeds),
            comparison_role="primary" if name in PRIMARY_COMPARISONS else "secondary_or_guard",
            repeated_zero_scope="Identical selected zero predictions remain identical; duplicated seeds add no independent information")
        comparisons[name]=interval
        for j,endpoint in enumerate(ENDPOINTS):
            comparison_rows.append({"comparison":name,"reference":reference,"candidate":candidate,
                "comparison_role":interval["comparison_role"],"metric_version":"selected","endpoint":endpoint,
                "difference":interval["difference"][j],"ci_lower":interval["ci_lower"][j],"ci_upper":interval["ci_upper"][j],
                "reference_fits":interval["reference_fits"],"candidate_fits":interval["candidate_fits"],
                "samples":interval["samples"],"calendar_blocks":interval["time_blocks"],
                "positive_means":"candidate lower error","exploratory":True,"multiple_comparison_adjustment":"none"})
    _csv(folder/"comparisons.csv",comparison_rows)
    zero_counts={m:sum(models[(m,s)]["selected_kind"]=="zero" for s in seeds) for m in CORRECTORS}
    selection_rows=[]
    for method in CORRECTORS:
        for seed in seeds:
            r=models[(method,seed)]
            selection_rows.append({k:r[k] for k in ("method","seed","selected_kind","selected_epoch","val_normalized_mse",
                "zero_val_normalized_mse","trained_epoch","trained_val_normalized_mse","epochs_run","optimizer_steps")})
    _csv(folder/"selections.csv",selection_rows)
    gate=recursive_gate(metrics["selected"]["test"],comparisons,options["recursive_gate"])
    _json(folder/"recursive_gate.json",gate)
    period={"start":str(np.datetime64(int(shared["test"]["time_ns"].min()),"ns")),
            "end":str(np.datetime64(int(shared["test"]["time_ns"].max()),"ns")),
            "samples":len(day_ids),"calendar_blocks":len(np.unique(day_ids)),
            "unique_captures":len(np.unique(shared["test"]["capture_index"]))}
    result={"metrics":metrics["selected"],"trained_diagnostic_metrics":metrics["trained_diagnostic"],
        "comparisons":comparisons,"recursive_gate":gate,"selected_zero_counts":zero_counts,
        "seeds":seeds,"methods":list(METHODS),"test_period":period,"delta_scale":scale.tolist(),
        "partition_counts":prep["partition_counts"],"original_partition_counts":prep["original_partition_counts"],
        "selections":selection_rows,"source_hashes":sources,"prediction_checks":checks,
        "scope":{"train":"Forward-fold Ridge references on later residual-training rows; not full-training Ridge in-sample performance",
                 "validation_test":"The same frozen full-training Ridge is the baseline for every correction",
                 "distribution_shift":"Residual training uses smaller earlier Ridge fits; final validation/test uses the full-training baseline",
                 "selected":"Validation-selected epoch including zero; these predictions control the comparisons and recursion gate",
                 "trained_diagnostic":"Validation-best epoch >=1; descriptive diagnostic only and never substituted using test results",
                 "null_rgb":"Mismatched embeddings can come from later captures within the same outer partition; diagnostic, not causal input",
                 "sample_units":"Repeated minute windows share image captures; capture counts are not independent-sample inference",
                 "test":"Previously inspected historical period, exploratory development comparison",
                 "fit_aggregation":"Mean of individual-fit metrics, not metrics of averaged seed predictions",
                 "intervals":"Crossed seed and whole calendar-date blocks; exploratory unadjusted percentile intervals"}}
    _json(folder/"summary.json",result)
    return result


def render_figures(study_dir,summary=None):
    from .visual_diagnostics_report import _pyplot,_save_figure,_style_axis
    root=Path(study_dir).resolve();result=summary if summary is not None else json.loads((root/"statistics/summary.json").read_text())
    folder=root/"figures";folder.mkdir(exist_ok=True);plt,font=_pyplot();paths=[];datafiles=[]
    period=result["test_period"];dates=period["start"][:10]+"—"+period["end"][:10]
    physical_data=[];effect_data=[];diagnostic_data=[]
    fig,axes=plt.subplots(2,2,figsize=(12.8,8.8))
    for j,ax in enumerate(axes.flat):
        largest=0.
        for position,method in enumerate(METHODS):
            met=result["metrics"]["test"][method];mean=met["physical_mae"][j];individual=[a[j] for a in met["per_fit_physical_mae"]]
            ax.barh(position,mean,color=COLORS[method],height=.55,edgecolor="black",linewidth=.55,
                    alpha=.75,hatch="//" if method=="null_rgb" else None)
            offsets=np.linspace(-.11,.11,len(individual)) if len(individual)>1 else np.zeros(1)
            ax.plot(individual,position+offsets,linestyle="none",marker="o",markersize=3.7,
                    markerfacecolor="white",markeredgecolor="black",markeredgewidth=.7)
            largest=max(largest,mean,*individual)
            physical_data.append({"metric_version":"selected","method":method,"quantity":QUANTITIES[j],"unit":UNITS[j],
                "mean_mae":mean,"individual_fit_mae":individual,"selected_zero_count":result["selected_zero_counts"].get(method),
                "fits":met["fits"],"samples":met["samples"]})
        xmax=max(1e-6,largest*1.25)
        for position,method in enumerate(METHODS):
            met=result["metrics"]["test"][method];mean=met["physical_mae"][j]
            rightmost=max(mean,*[value[j] for value in met["per_fit_physical_mae"]])
            ax.text(rightmost+.013*xmax,position,f"{mean:.4f}",va="center",fontsize=10)
        ax.set_xlim(0,xmax);ax.set_ylim(4.6,-.6);ax.set_yticks(range(5),[LABELS[m] for m in METHODS])
        ax.set_title(TITLES[j]);ax.set_xlabel(f"MAE ({UNITS[j]})，越小越好");_style_axis(ax)
    fig.suptitle("验证集选定的 Ridge 残差校正：物理指标",y=.985)
    zeros="；".join(f"{LABELS[m]} {result['selected_zero_counts'][m]}/{len(result['seeds'])}" for m in CORRECTORS)
    fig.text(.5,.025,f"{dates}；{period['samples']:,} 个窗口，{period['unique_captures']} 张不同图像。柱为拟合指标均值，白点为单次拟合。\n"
        f"选择零校正的次数：{zeros}。\n既有测试时段已用于开发；这些点不表示置信区间。",ha="center",fontsize=9.5)
    fig.subplots_adjust(left=.16,right=.98,top=.91,bottom=.19,wspace=.54,hspace=.45)
    paths+=_save_figure(fig,folder,"rgb_residual_selected_physical_mae");plt.close(fig)
    fig,axes=plt.subplots(2,3,figsize=(15,8.6))
    endpoint_titles=("九通道归一化 MSE",*[TITLES[j]+f" MAE ({UNITS[j]})" for j in range(4)])
    ref_order=("ridge","numeric","quality","null_rgb")
    for q,ax in enumerate(axes.flat):
        if q==5:ax.axis("off");continue
        bounds=[0.]
        for pos,reference in enumerate(ref_order):
            c=result["comparisons"]["rgb_vs_"+reference];value,lo,hi=[c[k][q] for k in ("difference","ci_lower","ci_upper")]
            ax.hlines(pos,lo,hi,color=COLORS[reference],linewidth=1.6)
            ax.vlines([lo,hi],pos-.08,pos+.08,color=COLORS[reference],linewidth=1.)
            ax.plot(value,pos,"s" if reference=="null_rgb" else "o",color=COLORS[reference],markersize=6)
            bounds += [value,lo,hi]
            effect_data.append({"metric_version":"selected","candidate":"rgb","reference":reference,"endpoint":ENDPOINTS[q],
                "difference":value,"ci_lower":lo,"ci_upper":hi,"comparison_role":c["comparison_role"]})
        pad=max((max(bounds)-min(bounds))*.15,1e-5);ax.set_xlim(min(bounds)-pad,max(bounds)+pad)
        ax.axvline(0,color="black",linestyle="--",linewidth=.9);ax.set_ylim(3.5,-.5)
        ax.set_yticks(range(4),[LABELS[r] for r in ref_order]);ax.set_title(endpoint_titles[q]);ax.set_xlabel("对照误差 − RGB 误差（正值更好）")
        ax.ticklabel_format(axis="x",style="plain",useOffset=False);_style_axis(ax)
    fig.suptitle("验证选定 RGB 校正与各对照的配对差值",y=.985)
    fig.text(.5,.025,f"{dates}；{period['calendar_blocks']} 个日历块，{len(result['seeds'])} 个训练种子。探索性配对日块＋种子 95% 区间；未做多重比较校正。\n"
             "主比较：RGB 对简单外观、错配 RGB。零校正与基准相同时差值和区间可均为零。",ha="center",fontsize=10)
    fig.subplots_adjust(left=.10,right=.98,top=.90,bottom=.15,wspace=.65,hspace=.5)
    paths+=_save_figure(fig,folder,"rgb_residual_selected_effects");plt.close(fig)
    fig,axes=plt.subplots(1,3,figsize=(15,5.8));all_bounds=[0.]
    for ax,split,title in zip(axes,("train","val","test"),("残差训练行（前序 Ridge）","验证（全训练 Ridge）","测试（全训练 Ridge）")):
        baseline=result["trained_diagnostic_metrics"][split]["ridge"]["normalized_mse"]
        for position,method in enumerate(CORRECTORS):
            met=result["trained_diagnostic_metrics"][split][method]
            values=baseline-np.array(met["per_fit_normalized_mse"]);value=float(values.mean())
            ax.plot(values,position+np.linspace(-.12,.12,len(values)),linestyle="none",marker="o",markersize=4,
                    markerfacecolor="white",markeredgecolor=COLORS[method])
            ax.plot(value,position,"D",color=COLORS[method],markersize=6)
            all_bounds += values.tolist()+[value]
            diagnostic_data.append({"metric_version":"trained_diagnostic","split":split,"method":method,
                "reference":"ridge","difference":value,"individual_fit_differences":values.tolist(),
                "reference_nmse":baseline,"samples":met["samples"],"zero_selected_count":result["selected_zero_counts"][method]})
        ax.set_yticks(range(4),[LABELS[m] for m in CORRECTORS]);ax.set_ylim(3.5,-.5);ax.set_title(title)
        ax.axvline(0,color="black",linestyle="--",linewidth=.9);ax.set_xlabel("Ridge NMSE − 训练后候选 NMSE");_style_axis(ax)
    pad=max((max(all_bounds)-min(all_bounds))*.12,1e-5)
    for ax in axes:ax.set_xlim(min(all_bounds)-pad,max(all_bounds)+pad)
    fig.suptitle("训练后最佳候选：独立诊断，不替代验证选择",y=.98)
    fig.text(.5,.035,"每组保留验证集最好的非零轮次；若零校正胜出，这些预测仅用于诊断。菱形为种子均值，空心点为各种子；无置信区间。\n"
             "训练行使用较少历史拟合的前序 Ridge；验证与测试使用全训练 Ridge，两个基准分布不同。测试结果不能用于重选模型。",ha="center",fontsize=10)
    fig.subplots_adjust(left=.09,right=.98,top=.82,bottom=.24,wspace=.6)
    paths+=_save_figure(fig,folder,"rgb_residual_trained_diagnostic");plt.close(fig)
    for name,values in (("selected_physical_mae",physical_data),("selected_effects",effect_data),("trained_diagnostic",diagnostic_data)):
        jp=folder/(name+"_plot_data.json");cp=folder/(name+"_plot_data.csv")
        _json(jp,values);_csv(cp,[{k:json.dumps(v) if isinstance(v,list) else v for k,v in r.items()} for r in values]);datafiles += [jp,cp]
    figure_manifest={"renderer":str(Path(__file__).resolve()),"renderer_sha256":sha256(__file__),"font":str(font),
        "palette":COLORS,"selected_physical_mean_count":len(physical_data),"selected_effect_point_count":len(effect_data),
        "selected_effect_interval_count":len(effect_data),"trained_diagnostic_mean_count":len(diagnostic_data),
        "inputs":{str(p.relative_to(root)):sha256(p) for p in [root/"statistics/summary.json",*datafiles]},
        "outputs":{str(p.relative_to(root)):sha256(p) for p in paths},"visual_inspection":"pending"}
    _json(folder/"figure_manifest.json",figure_manifest)
    return figure_manifest


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument("--study-dir",required=True)
    parser.add_argument("--skip-figures",action="store_true");args=parser.parse_args()
    result=summarize_study(args.study_dir)
    if not args.skip_figures:render_figures(args.study_dir,result)
    print(json.dumps({"prediction_files":len(result["prediction_checks"]),"comparisons":len(result["comparisons"]),
                      "recursive_gate_passed":result["recursive_gate"]["passed"]},ensure_ascii=False))


if __name__=="__main__":main()
