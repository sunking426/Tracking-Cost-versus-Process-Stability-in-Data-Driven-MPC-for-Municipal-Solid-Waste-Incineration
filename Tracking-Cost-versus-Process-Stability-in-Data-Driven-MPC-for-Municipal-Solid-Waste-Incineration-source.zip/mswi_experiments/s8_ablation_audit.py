"""Independent artifact, alignment, admission, and reward audit."""
import argparse,json,datetime,shutil
import numpy as np
from .s8_ablation_study import ROOT,OUT,DESIGN,REF,CROSS,OLD,MODELS,verify,d2_mode
from .ridge_policy_study import read_npz,write_json
from .frozen_mpc import file_sha256
from .control import reward_and_violation
from .ridge_dynamics import RidgeDynamics


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--method',choices=['D1','D2','D1_512']);ap.add_argument('--existing-only',action='store_true');args=ap.parse_args()
    if args.existing_only and not args.method:ap.error('--existing-only requires --method')
    verify();trigger=json.loads((OUT/'budget_trigger.json').read_text());methods=['D1','D2']+(['D1_512'] if trigger['trigger_D1_512'] else [])
    if args.method:
        if args.method not in methods:raise AssertionError('method not triggered')
        methods=[args.method]
    inp=read_npz(REF/'inputs/val.npz');stats=json.loads((REF/'stats.json').read_text())
    scale=np.asarray(stats['action_scale']);parent=json.loads((CROSS/'config.json').read_text())['parent_contract']
    lo=np.asarray(parent['actions']['absolute_mv_lower']);hi=np.asarray(parent['actions']['absolute_mv_upper']);B=np.asarray(stats['action_bound'])
    paths=[OUT/'trajectories/P/full/S8/rep0.npz']
    for method in methods:
        paths.append(OUT/f'trajectories/P/full/{method}/rep0.npz')
        paths += [OUT/f'trajectories/D/{m}/{method}/rep0.npz' for m in MODELS]
        paths += [OUT/f'trajectories/C/{m}/{method}/rep{r}.npz' for m in MODELS for r in range(5)]
    expected_paths=len(paths)
    if args.existing_only:paths=[p for p in paths if p.exists() and p.with_suffix('.json').exists()]
    records=[]
    for p in paths:
        a=read_npz(p);meta=json.loads(p.with_suffix('.json').read_text());h=a['reward'].shape[1];method=meta['method'];layer=meta['layer'];mid=meta['model'];rep=meta['replicate']
        if file_sha256(p)!=meta['sha256']:raise AssertionError('artifact hash')
        np.testing.assert_array_equal(a['indices'],inp['indices']);np.testing.assert_array_equal(a['time_ns'],inp['time_ns'])
        np.testing.assert_array_equal(a['initial_u'],inp['u_hist'][:,-1]);np.testing.assert_array_equal(a['initial_z_current'],inp['z_current'])
        if a['reward'].shape!=(256,h):raise AssertionError('trajectory shape')
        for k,v in a.items():
            if np.issubdtype(v.dtype,np.number) and not np.isfinite(v).all():raise AssertionError('nonfinite '+k)
        np.testing.assert_allclose(np.diff(np.concatenate((a['initial_u'][:,None],a['u_path']),axis=1),axis=1),a['physical_executed_action'],rtol=0,atol=1e-10)
        np.testing.assert_allclose(a['physical_executed_action'],a['executed_action']*scale,rtol=0,atol=1e-10)
        if (a['u_path']<lo-1e-10).any() or (a['u_path']>hi+1e-10).any():raise AssertionError('MV boundaries')
        if (abs(a['requested_action']*scale)>.1*B+1e-10).any():raise AssertionError('requested action budgets')
        if method in ('S8','D2') and np.any(a['physical_executed_action'][...,[1,2,4,5,6,7]]!=0):raise AssertionError('inactive MV')
        req=np.any(a['requested_action']!=0,axis=2);mode=d2_mode() if method=='D2' else 'supported'
        blocked=(req&(~a['proposal_full_execution']|~a['proposal_supported'])) if mode=='supported' else req&~a['proposal_full_execution'] if mode=='complete' else np.zeros_like(req)
        np.testing.assert_array_equal(a['blocked_nonzero'],blocked)
        if np.any(a['physical_executed_action'][blocked]!=0):raise AssertionError('rejected requests must hold')
        reward,violation,parts=reward_and_violation(a['pred_cv'],a['executed_action'],stats)
        np.testing.assert_array_equal(reward,a['reward']);np.testing.assert_array_equal(violation,a['violation'])
        for k,v in parts.items():np.testing.assert_array_equal(v,a[k])
        if layer=='P' and method!='S8':
            main_plan=read_npz(OUT/'trajectories/P/full/S8/rep0.npz')
            np.testing.assert_array_equal(a['noise_sha256'],main_plan['noise_sha256'])
        if layer in ('C','D'):
            # Before the first feedback, every environment has identical observed
            # history, planning model, candidate streams, and zero warm start.
            initial_plan=read_npz(OUT/f'trajectories/P/full/{method}/rep0.npz')
            for key in ('requested_action','best_requested_plan_b','selected_planning_score',
                        'selected_original_return','selected_temperature_cost','iteration_best_score'):
                np.testing.assert_array_equal(a[key][:,0],initial_plan[key][:,0],
                    err_msg='same initial planning context: '+key)
            ref=read_npz(CROSS/f'trajectories/C/{mid}/S8/seed0_rep{rep}.npz') if layer=='C' else read_npz(OLD/f'trajectories/S8/{mid}.npz')
            np.testing.assert_array_equal(a['noise_sha256'],ref['noise_sha256'])
            if layer=='C':
                noise=read_npz(CROSS/f'residuals/{mid}_sequences.npz')
                np.testing.assert_array_equal(a['injected_residual'],noise['residual'][:,rep])
                np.testing.assert_array_equal(a['injected_residual'],ref['injected_residual'])
        model=RidgeDynamics.load(REF/f'evaluation_models/{mid}.npz')
        u=inp['u_hist'].copy();z=inp['z_hist'].copy();current=inp['z_current'].copy()
        for step in range(h):
            u=np.concatenate((u[:,1:],a['u_path'][:,step,None]),axis=1)
            z=np.concatenate((z[:,1:],current[:,None]),axis=1)
            prediction=model.predict_next(u,z)
            if layer=='C':prediction=prediction+a['injected_residual'][:,step]
            np.testing.assert_array_equal(prediction,a['pred_cv'][:,step])
            current=prediction
        if method=='D1_512' and layer in ('C','D'):
            ordinary=read_npz(OUT/f'trajectories/{layer}/{mid}/D1/rep{rep}.npz')
            np.testing.assert_array_equal(a['extra_noise_sha256'],ordinary['extra_noise_sha256'])
        records.append(dict(path=str(p.relative_to(ROOT)),method=method,layer=layer,model=mid,replicate=rep,starts=256,horizon=h,sha256=file_sha256(p),status='passed'))
    if not args.method:
        binding=json.loads((OUT/'report/source_bindings.json').read_text())
        for p,h in binding.items():
            if file_sha256(ROOT/p)!=h:raise AssertionError('report input changed')
    report=dict(status='partial_passed' if args.method else 'passed',methods=methods,expected_trajectory_files=expected_paths,existing_only=args.existing_only,new_trajectory_files=len(records),new_episodes=256*len(records),new_transition_steps=sum(r['starts']*r['horizon'] for r in records),checks=records)
    suffix='_existing' if args.existing_only else ''
    write_json(OUT/(f'partial_integrity_{args.method}{suffix}.json' if args.method else 'integrity_audit.json'),report)
    if not args.method:
        for name in ('s8_ablation_report.py','s8_ablation_audit.py'):
            shutil.copy2(ROOT/'mswi_experiments'/name,OUT/'code_snapshot/mswi_experiments'/name)
    print(json.dumps({k:v for k,v in report.items() if k!='checks'}),flush=True)
if __name__=='__main__':main()
