"""Direct short-horizon ridge probes for incremental descriptor information.

These are deterministic prediction diagnostics on logged transitions. They do
not optimize or assess a control policy. Input histories and visual features
always belong to the origin; no future MV/CV input is supplied to the probe.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import time

import numpy as np

from .data import MINUTE_NS, control_values
from .visual_diagnostics import load_study
from .visual_diagnostics_statistics import DAY_NS, paired_block_interval


HORIZONS = (1, 5, 10)
METHODS = ("sensor", "timing4", "original52", "static40", "fixed10", "fixed60", "null_fixed10")
ALPHAS = (0.1, 1.0, 10.0, 100.0, 1000.0)
CONTROL_NAMES = ("temperature", "pressure", "steam", "oxygen")


def _write_json(path, value):
    destination = Path(path)
    temporary = destination.with_suffix(destination.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
    temporary.replace(destination)


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def eligible_pairs(data: dict, partition: str, horizon: int) -> tuple[np.ndarray, np.ndarray]:
    """Keep origin/destination pairs linked continuously inside one partition.

    horizon=1 predicts z_target at the origin. A horizon h follows h-1 links,
    rejecting a gap even if a malformed next_idx points across that gap.
    """
    if not isinstance(horizon, (int, np.integer)) or horizon < 1:
        raise ValueError("horizon must be a positive integer")
    time_ns = np.asarray(data["time_ns"])
    following = np.asarray(data["next_idx"])
    rows = np.asarray(data[partition + "_idx"])
    if time_ns.ndim != 1 or following.shape != time_ns.shape or rows.ndim != 1:
        raise ValueError("invalid prepared time or partition arrays")
    n = len(time_ns)
    if not np.issubdtype(rows.dtype, np.integer) or not np.issubdtype(following.dtype, np.integer):
        raise ValueError("partition and next indices must be integers")
    if len(rows) and (rows.min() < 0 or rows.max() >= n or len(np.unique(rows)) != len(rows)):
        raise ValueError("invalid partition indices")
    membership = np.zeros(n, dtype=bool)
    membership[rows] = True
    origins = rows.copy()
    destinations = rows.copy()
    valid = np.ones(len(rows), dtype=bool)
    for _ in range(horizon - 1):
        active = np.flatnonzero(valid)
        next_rows = following[destinations[active]]
        in_range = (next_rows >= 0) & (next_rows < n)
        safe_next = np.clip(next_rows, 0, max(n - 1, 0))
        continuous = in_range & membership[safe_next] & (
            time_ns[safe_next] - time_ns[destinations[active]] == MINUTE_NS)
        valid[active[~continuous]] = False
        destinations[active[continuous]] = next_rows[continuous]
    origins, destinations = origins[valid], destinations[valid]
    if len(origins) and not np.array_equal(time_ns[destinations] - time_ns[origins],
                                          np.full(len(origins), (horizon - 1) * MINUTE_NS)):
        raise AssertionError("direct-horizon links do not match their declared time span")
    return origins.astype(np.int64), destinations.astype(np.int64)


def origin_design(data: dict, variants: dict, method: str, origins: np.ndarray) -> np.ndarray:
    """Read only origin covariates; target/destination indices are not accepted."""
    if method not in METHODS:
        raise ValueError("unknown direct-horizon method")
    rows = np.asarray(origins, dtype=np.int64)
    numeric = np.concatenate([np.asarray(data[name])[rows].reshape(len(rows), -1)
                              for name in ("u_hist", "z_hist")], axis=1)
    if numeric.shape[1] != 178:
        raise ValueError("direct probe requires the frozen 11x8 MV and 10x9 CV histories")
    matrix = numeric if method == "sensor" else np.concatenate(
        (numeric, np.asarray(variants[method])[rows]), axis=1)
    if not len(matrix) or not np.isfinite(matrix).all():
        raise ValueError("direct-horizon origin features must be finite and nonempty")
    return matrix


def fit_direct_ridge(train_x, train_change, val_x, val_change) -> dict:
    """Fit scalers/ridges on training only and select alpha on validation only."""
    from sklearn.linear_model import Ridge
    from sklearn.preprocessing import StandardScaler

    x, change = np.asarray(train_x, dtype=np.float64), np.asarray(train_change, dtype=np.float64)
    vx, vc = np.asarray(val_x, dtype=np.float64), np.asarray(val_change, dtype=np.float64)
    if (x.ndim != 2 or len(x) < 2 or change.shape != (len(x), 4)
            or vx.ndim != 2 or not len(vx) or vx.shape[1] != x.shape[1]
            or vc.shape != (len(vx), 4)):
        raise ValueError("invalid direct ridge train/validation matrices")
    if any(not np.isfinite(array).all() for array in (x, change, vx, vc)):
        raise ValueError("direct ridge matrices must be finite")
    x_scaler, y_scaler = StandardScaler().fit(x), StandardScaler().fit(change)
    sx, sy = x_scaler.transform(x), y_scaler.transform(change)
    svx, svy = x_scaler.transform(vx), y_scaler.transform(vc)
    candidates = []
    for alpha in ALPHAS:
        model = Ridge(alpha=alpha, solver="cholesky").fit(sx, sy)
        score = float(np.square(model.predict(svx) - svy).mean())
        if not np.isfinite(score):
            raise FloatingPointError("nonfinite direct ridge validation score")
        candidates.append((score, alpha, model))
    _, alpha, model = min(candidates, key=lambda item: (item[0], item[1]))
    return {"x_mean": x_scaler.mean_, "x_scale": x_scaler.scale_,
            "y_mean": y_scaler.mean_, "y_scale": y_scaler.scale_,
            "coef": model.coef_, "intercept": model.intercept_,
            "alpha": np.asarray(alpha), "alphas": np.asarray(ALPHAS),
            "val_normalized_mse": np.asarray([item[0] for item in candidates])}


def apply_direct_ridge(fitted: dict, features: np.ndarray, origin_previous_cv: np.ndarray) -> np.ndarray:
    """Restore a direct absolute prediction from origin-relative target changes."""
    x = np.asarray(features, dtype=np.float64)
    previous = np.asarray(origin_previous_cv, dtype=np.float64)
    if x.ndim != 2 or x.shape[1] != len(fitted["x_mean"]) or previous.shape != (len(x), 4):
        raise ValueError("invalid direct prediction inputs")
    scaled = (x - fitted["x_mean"]) / fitted["x_scale"]
    change = (scaled @ fitted["coef"].T + fitted["intercept"]) * fitted["y_scale"] + fitted["y_mean"]
    return previous + change


def direct_interval(differences, block_ids, options):
    """Reuse paired resampling with one deterministic fit, no NN seed axis."""
    interval = paired_block_interval(np.asarray(differences)[None, :, :], block_ids,
        draws=int(options.get("bootstrap_draws", 10000)),
        seed=int(options.get("bootstrap_seed", 20261104)),
        confidence_level=float(options.get("confidence_level", .95)))
    interval.pop("training_seeds")
    interval["deterministic_fits"] = 1
    interval["estimand"] = "mean paired per-origin absolute-error reduction for a single deterministic ridge fit"
    interval["resampling"] = "whole origin-calendar-day percentile bootstrap; no neural-training-seed axis"
    interval["warnings"] = [warning for warning in interval["warnings"] if warning != "one_training_seed: interval contains no between-fit variation"]
    interval["warnings"].append("single_deterministic_fit: intervals describe time-block variation only")
    return interval


def run_horizon_probe(config_file) -> dict:
    """Freeze this supplementary probe's protocol, then fit and score all methods."""
    from threadpoolctl import threadpool_limits

    cfg, data, _, variants, _, study = load_study(config_file)
    out = study / "horizon_probe"
    out.mkdir(parents=True, exist_ok=True)
    root_protocol = json.loads((study / "protocol.json").read_text())
    for path, digest in root_protocol["input_hashes"].items():
        if _sha(path) != digest:
            raise ValueError("frozen base input changed before supplementary horizon probe")
    if _sha(study / "feature_variants.npz") != root_protocol["feature_archive_sha256"]:
        raise ValueError("frozen feature variants changed before supplementary horizon probe")
    prepared_pairs = {h: {name: eligible_pairs(data, name, h) for name in ("train", "val", "test")}
                      for h in HORIZONS}
    if any(len(origin) < 2 for parts in prepared_pairs.values() for origin, _ in parts.values()):
        raise ValueError("insufficient continuous within-partition chains for the prespecified horizons")
    options = cfg["diagnostics"]
    implementation = Path(__file__).resolve()
    protocol = {
        "scope": "prespecified supplementary exploratory direct prediction, not a policy or control comparison",
        "frozen_before_fitting_unix": time.time(), "horizons_minutes": list(HORIZONS),
        "methods": list(METHODS), "alphas": list(ALPHAS), "solver": "deterministic cholesky Ridge",
        "targets": list(CONTROL_NAMES), "target_definition": "control_values(z_target at destination), where destination follows h-1 next_idx links from origin",
        "fitted_target": "destination absolute controls minus control_values(z_prev at origin); restore this origin baseline after prediction",
        "inputs": "origin 11x8 MV and 10x9 CV histories flattened to 178 numeric features, plus specified origin visual variant; no future MV/CV inputs",
        "eligible_pairs": "same partition, every next_idx link exactly one minute, no gap crossing; identical origins/destinations for all methods within each horizon",
        "scaling": "X and four target-change scalers fit only eligible outer-train rows",
        "selection": "choose alpha by mean four-channel training-standardized MSE on eligible outer-validation rows; no test selection",
        "comparison_references": ["sensor", "timing4"],
        "intervals": {"metric": "reference absolute error minus candidate absolute error; positive favors candidate",
                      "unit": "origin calendar day", "deterministic_fits": 1,
                      "no_neural_training_seed_axis": True,
                      "bootstrap_draws": int(options.get("bootstrap_draws", 10000)),
                      "bootstrap_seed": int(options.get("bootstrap_seed", 20261104)),
                      "confidence_level": float(options.get("confidence_level", .95)),
                      "exploratory_unadjusted": True},
        "null_scope": "null_fixed10 deliberately permutes content within outer partitions, can use future donors and is only a broken-correspondence diagnostic, not causal prediction evidence",
        "interpretation": "These linear direct-horizon probes test descriptor information conditional on numerical history. Do not compare their absolute precision as a matched alternative to the main GRU, or infer policy/plant effects.",
        "test_scope": "same previously inspected test period; this supplementary protocol is fixed before its own fits/test metrics, not before all historical development",
        "eligible_counts": {str(h): {name: len(pair[0]) for name, pair in parts.items()} for h, parts in prepared_pairs.items()},
        "main_neural_protocol_unchanged": True,
        "input_hashes": {str(study / name): _sha(study / name) for name in
                         ("config.json", "protocol.json", "feature_variants.npz", "feature_metadata.npz")},
        "code_hashes": {str(implementation): _sha(implementation),
                        str(implementation.with_name("visual_diagnostics_statistics.py")): _sha(implementation.with_name("visual_diagnostics_statistics.py"))}}
    protocol_path = out / "protocol.json"
    if protocol_path.exists():
        previous = json.loads(protocol_path.read_text())
        current = dict(protocol)
        current["frozen_before_fitting_unix"] = previous["frozen_before_fitting_unix"]
        if current != previous:
            raise ValueError("supplementary probe differs from its frozen protocol")
        protocol = previous
    else:
        _write_json(protocol_path, protocol)
    # All fitting and all test-error calculation occur strictly after this file.
    result = {"status": "running", "protocol": protocol, "horizons": {}}
    with threadpool_limits(limits=1):
        for horizon, pairs in prepared_pairs.items():
            horizon_out = out / f"horizon_{horizon:02d}"
            horizon_out.mkdir(exist_ok=True)
            np.savez_compressed(horizon_out / "eligible_pairs.npz", **{
                name + suffix: pair[position] for name, pair in pairs.items()
                for suffix, position in (("_origin_indices", 0), ("_destination_indices", 1))})
            train_origin, train_destination = pairs["train"]
            val_origin, val_destination = pairs["val"]
            train_previous = control_values(data["z_prev"][train_origin]).astype(np.float64)
            val_previous = control_values(data["z_prev"][val_origin]).astype(np.float64)
            train_change = control_values(data["z_target"][train_destination]).astype(np.float64) - train_previous
            val_change = control_values(data["z_target"][val_destination]).astype(np.float64) - val_previous
            selected_fits = {}
            horizon_result = {"eligible_counts": protocol["eligible_counts"][str(horizon)], "methods": {}, "comparisons": {}}
            for method in METHODS:
                design_train = origin_design(data, variants, method, train_origin)
                design_val = origin_design(data, variants, method, val_origin)
                fitted = fit_direct_ridge(design_train, train_change, design_val, val_change)
                method_out = horizon_out / method
                method_out.mkdir(exist_ok=True)
                np.savez_compressed(method_out / "ridge_weights.npz", **fitted)
                selection = {"alpha": float(fitted["alpha"]), "alphas": fitted["alphas"].tolist(),
                             "val_normalized_mse": fitted["val_normalized_mse"].tolist(),
                             "input_dimension": int(design_train.shape[1])}
                _write_json(method_out / "selection.json", selection)
                selected_fits[method] = fitted
                horizon_result["methods"][method] = selection
            # Select every comparator before constructing any test design/errors.
            test_origin, test_destination = pairs["test"]
            truth = control_values(data["z_target"][test_destination]).astype(np.float64)
            previous = control_values(data["z_prev"][test_origin]).astype(np.float64)
            errors = {}
            for method, fitted in selected_fits.items():
                prediction = apply_direct_ridge(fitted, origin_design(data, variants, method, test_origin), previous)
                error = prediction - truth
                if not np.isfinite(error).all():
                    raise FloatingPointError("nonfinite short-horizon probe predictions")
                path = horizon_out / method / "test_predictions.npz"
                np.savez_compressed(path, indices=test_origin, destination_indices=test_destination,
                    time_ns=data["time_ns"][test_origin], destination_time_ns=data["time_ns"][test_destination],
                    truth=truth, origin_previous=previous, pred=prediction, error=error)
                errors[method] = error
                horizon_result["methods"][method].update({
                    "mae": np.abs(error).mean(axis=0).tolist(),
                    "rmse": np.sqrt(np.square(error).mean(axis=0)).tolist(),
                    "test_predictions_sha256": _sha(path)})
            days = data["time_ns"][test_origin] // DAY_NS
            for reference in ("sensor", "timing4"):
                for method in METHODS:
                    if method == reference:
                        continue
                    difference = np.abs(errors[reference]) - np.abs(errors[method])
                    horizon_result["comparisons"][f"{method}_vs_{reference}"] = direct_interval(difference, days, options)
            result["horizons"][str(horizon)] = horizon_result
            _write_json(out / "results.json", result)
            print(json.dumps({"horizon_probe_completed_minutes": horizon,
                              "methods": len(METHODS), "eligible_counts": horizon_result["eligible_counts"]}), flush=True)
    result["status"] = "completed"
    _write_json(out / "results.json", result)
    _write_json(out / "completed.json", {"status": "completed", "horizons": list(HORIZONS),
        "deterministic_fits": len(HORIZONS) * len(METHODS), "protocol_sha256": _sha(protocol_path),
        "results_sha256": _sha(out / "results.json"),
        "main_neural_protocol_unchanged": _sha(study / "protocol.json") == protocol["input_hashes"][str(study / "protocol.json")]})
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    run_horizon_probe(args.config)


if __name__ == "__main__":
    main()
