"""Frozen, paired experiments for incremental information in flame descriptors.

Run with ``python -m mswi_experiments.visual_diagnostics --config FILE``.
The original prepared samples and released model/results are read-only inputs.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from contextlib import redirect_stdout, redirect_stderr
import copy
import hashlib
import json
from pathlib import Path
import platform
import sys
import time

import numpy as np

from .data import load_data, _mean_scale


def _write_json(path: Path, value) -> None:
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
    temporary.replace(path)


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def capture_block_null(values, data, *, seed=20261104, block_captures=6):
    """Misalign content by capture blocks within partitions; retain timing fields.

    This is a deliberately broken-correspondence negative control, not a causal
    forecasting input. No labels are consulted. Every minute matched to a capture
    receives the same donor content. The final four timing fields stay aligned.
    """
    values = np.asarray(values)
    if values.ndim != 2 or values.shape[1] != 52 or len(values) != len(data['time_ns']):
        raise ValueError('fixed10 negative control requires an aligned 52-column matrix')
    if block_captures < 1:
        raise ValueError('block_captures must be positive')
    result = values.copy()
    donor_sample = np.full(len(values), -1, dtype=np.int64)
    records = {}
    rng = np.random.default_rng(seed)
    for name in ('train', 'val', 'test'):
        idx = np.asarray(data[name + '_idx'])
        captures, first, inverse = np.unique(data['visual_time_ns'][idx], return_index=True, return_inverse=True)
        groups = [np.arange(start, min(start + block_captures, len(captures)))
                  for start in range(0, len(captures), block_captures)]
        order = rng.permutation(len(groups))
        donors = np.concatenate([groups[j] for j in order])
        source_rows = idx[first[donors[inverse]]]
        result[idx, :48] = values[source_rows, :48]
        donor_sample[idx] = source_rows
        records[name] = {
            'unique_captures': len(captures), 'blocks': len(groups),
            'same_capture_fraction': float(np.mean(captures[donors] == captures)),
            'future_donor_fraction': float(np.mean(data['visual_time_ns'][source_rows] > data['visual_time_ns'][idx])),
            'donors_within_partition': bool(np.isin(source_rows, idx).all())}
    if not np.array_equal(result[:, 48:], values[:, 48:]):
        raise AssertionError('negative control changed timing information')
    return result, donor_sample, {
        'seed': seed, 'block_captures': block_captures,
        'content_columns_permuted': 48, 'timing_columns_preserved': 4,
        'scope': 'diagnostic negative control; intentionally misaligned within each partition, not a deployable causal input',
        'partitions': records}


def null_feature_provenance(data, metadata, donors, positive_manifest, null_manifest):
    """Describe actual donor sources rather than inheriting positive provenance."""
    assigned = donors >= 0
    safe_donors = np.where(assigned, donors, np.arange(len(donors)))
    donor_start = metadata['variant_source_start_ns_fixed10'][safe_donors]
    donor_end = metadata['variant_source_end_ns_fixed10'][safe_donors]
    timing_start = metadata['variant_source_start_ns_timing4']
    timing_end = metadata['variant_source_end_ns_timing4']
    begin, end = np.minimum(donor_start, timing_start), np.maximum(donor_end, timing_end)
    partitions = {}
    for name in ('train', 'val', 'test'):
        idx = data[name + '_idx']
        partitions[name] = {
            'samples': len(idx),
            'actual_source_begin_ns_min': int(begin[idx].min()),
            'actual_source_end_ns_max': int(end[idx].max()),
            'future_content_samples': int((donor_end[idx] > data['visual_time_ns'][idx]).sum()),
            'donors_in_same_outer_partition': bool(np.isin(donors[idx], idx).all())}
    return {'columns': positive_manifest['columns'], 'shape': positive_manifest['shape'],
            'description': null_manifest['scope'], 'partitions': partitions,
            'source_definition': 'union of permuted donor content and original timing fields',
            'causal_forecasting_variant': False,
            'residual_subpartition_note': 'donors stay within outer partitions but may cross early-fit/internal-validation/calibration subpartitions; only a negative control'}


def _paths(config_file):
    path = Path(config_file).resolve()
    cfg = json.loads(path.read_text())
    root = path.parent
    return cfg, root / cfg['source_run'], root / cfg['feature_file'], root / cfg['output_dir']


def prepare(config_file):
    from .visual_diagnostics_features import build_visual_variants
    cfg, source, feature_file, out = _paths(config_file)
    out.mkdir(parents=True, exist_ok=True)
    frozen = out / 'config.json'
    if frozen.exists() and json.loads(frozen.read_text()) != cfg:
        raise ValueError('existing study has a different frozen configuration; use a new output directory')
    _write_json(frozen, cfg)
    data, stats, source_manifest = load_data(source / 'data')
    variants, metadata, manifest = build_visual_variants(data, feature_file, source_manifest)
    null, donors, null_manifest = capture_block_null(
        variants['fixed10'], data, seed=cfg['diagnostics']['permutation_seed'],
        block_captures=cfg['diagnostics']['permutation_block_captures'])
    variants['null_fixed10'] = null
    metadata['null_donor_sample_index'] = donors
    # Sensor mode ignores this legal visual input, preserving the canonical API.
    variants['sensor'] = variants['original52']
    manifest['variants']['sensor'] = copy.deepcopy(manifest['variants']['original52'])
    manifest['variants']['sensor']['description'] = 'visual matrix is an unused API placeholder; mode=sensor'
    manifest['variants']['null_fixed10'] = null_feature_provenance(
        data, metadata, donors, manifest['variants']['fixed10'], null_manifest)
    manifest['negative_control'] = null_manifest
    manifest['positive_variants_future_captures_used'] = manifest.pop('future_captures_used')
    manifest['negative_control_contains_future_donors'] = any(
        row['future_donor_fraction'] > 0 for row in null_manifest['partitions'].values())
    np.savez_compressed(out / 'feature_variants.npz', **variants)
    np.savez_compressed(out / 'feature_metadata.npz', **metadata)
    _write_json(out / 'feature_manifest.json', manifest)
    input_hashes = {str(p.resolve()): _sha(p) for p in
                    [source / 'data/dataset.npz', source / 'data/stats.json',
                     source / 'data/manifest.json', feature_file]}
    # Snapshot the final manuscripts and inherited source modules as well.
    workspace = Path(config_file).resolve().parent.parent
    project = Path(config_file).resolve().parent
    for p in [workspace / 'sci/latex_20261103/manuscript.tex',
              workspace / 'sci/latex_20261103/manuscript.pdf',
              workspace / 'sci/latex_zh_20261104/manuscript_zh.tex',
              workspace / 'sci/latex_zh_20261104/manuscript_zh.pdf'] + [
              project / 'mswi_experiments' / name for name in
              ['data.py', 'models.py', 'training.py', 'analysis.py', 'visual_features.py']]:
        if p.exists():
            input_hashes[str(p)] = _sha(p)
    _write_json(out / 'input_hashes.json', input_hashes)
    protocol = {
        'frozen_before_training_unix': time.time(),
        'question': 'Do flame descriptors add predictive information beyond the same observed process history?',
        'scope': 'one-step logged-transition prediction and held-out residual correction; no RL training or plant intervention',
        'config': cfg, 'source_run': str(source.resolve()),
        'same_samples_for_all_main_variants': True,
        'partition_counts': {name: len(data[name + '_idx']) for name in ('train', 'val', 'test')},
        'checkpoint_selection': 'validation normalized nine-channel increment MSE, same training budget for all main variants',
        'test_use': 'existing historically inspected test period; exploratory post-development diagnostic, not a fresh blind test',
        'decision_rule': 'report every prespecified variant, seed, physical output and stratum; no test-based choice of features, weights or horizon',
        'primary_comparison': 'fixed10 against sensor and timing4, temperature MAE; all other comparisons exploratory',
        'negative_control': null_manifest,
        'residual_protocol': 'sensor fitted on first 60% of outer training time with next 20% internal validation; last 20% calibrates residual correctors after source purges; outer validation selects ridge alpha; outer test only final scoring',
        'uncertainty': 'paired seed/calendar-day resampling, with 60/180-minute sensitivity; exploratory unadjusted intervals from a short test period',
        'normalization': 'training-only main models; early-fit-only residual sensor; calibration-only residual correctors',
        'no_paper_or_release_update': True,
        'python': sys.version, 'platform': platform.platform(),
        'input_hashes': input_hashes,
        'feature_archive_sha256': _sha(out / 'feature_variants.npz')}
    protocol_path = out / 'protocol.json'
    if protocol_path.exists():
        previous = json.loads(protocol_path.read_text())
        if previous['input_hashes'] != input_hashes or previous['feature_archive_sha256'] != protocol['feature_archive_sha256']:
            raise ValueError('prepared inputs differ from frozen study')
    else:
        _write_json(protocol_path, protocol)
    print(json.dumps({'prepared': str(out), 'variants': {k: list(v.shape) for k, v in variants.items()},
                      'partition_counts': protocol['partition_counts']}, ensure_ascii=False), flush=True)
    return out


def load_study(config_file):
    cfg, source, _, out = _paths(config_file)
    if not (out / 'protocol.json').exists():
        raise FileNotFoundError('prepare and freeze the protocol before training')
    if json.loads((out / 'config.json').read_text()) != cfg:
        raise ValueError('configuration differs from frozen study')
    data, stats, source_manifest = load_data(source / 'data')
    with np.load(out / 'feature_variants.npz', allow_pickle=False) as f:
        variants = {name: f[name] for name in f.files}
    with np.load(out / 'feature_metadata.npz', allow_pickle=False) as f:
        metadata = {name: f[name] for name in f.files}
    return cfg, data, stats, variants, metadata, out


def _train_one(config_file, variant, seed):
    from .training import fit_twin, predict_twin
    import torch
    cfg, data, stats, variants, metadata, out = load_study(config_file)
    dest = out / 'models' / variant / f'seed_{seed}'
    dest.mkdir(parents=True, exist_ok=True)
    if (dest / 'completed.json').exists():
        completed = json.loads((dest / 'completed.json').read_text())
        if completed['variant'] != variant or completed['seed'] != seed:
            raise ValueError('completed run identity does not match the requested experiment')
        if (_sha(dest / 'twin.pt') != completed['checkpoint_sha256'] or
                _sha(dest / 'test_predictions.npz') != completed['predictions_sha256']):
            raise ValueError('completed run checkpoint or predictions changed; refusing to reuse it')
        return completed
    model_data = dict(data)
    model_data['visual'] = variants[variant]
    model_stats = copy.deepcopy(stats)
    model_stats['v_mean'], model_stats['v_scale'] = _mean_scale(model_data['visual'][data['train_idx']])
    manifest = json.loads((out / 'feature_manifest.json').read_text())
    model_stats['visual_columns'] = manifest['variants'][variant]['columns']
    started = time.monotonic()
    with (dest / 'training.log').open('w') as log, redirect_stdout(log), redirect_stderr(log):
        twin, metrics = fit_twin(model_data, model_stats, 'sensor' if variant == 'sensor' else 'multi', seed, cfg, dest)
        # These probes only test dependence of a fitted model; they are not trained comparators.
        if variant == 'fixed10':
            for condition in ('mean_content', 'misaligned_content'):
                altered = variants['fixed10'].copy()
                if condition == 'mean_content':
                    altered[:, :48] = np.asarray(model_stats['v_mean'], dtype=np.float32)[:48]
                else:
                    altered[:, :48] = variants['null_fixed10'][:, :48]
                probe = dict(data)
                probe['visual'] = altered
                pred = predict_twin(twin, probe, data['test_idx'])
                np.savez_compressed(dest / f'sensitivity_{condition}.npz',
                    indices=data['test_idx'], time_ns=data['time_ns'][data['test_idx']],
                    y=data['z_target'][data['test_idx']], pred=pred)
        record = {'variant': variant, 'seed': seed, 'mode': twin.mode,
                  'parameters': sum(p.numel() for p in twin.parameters()),
                  'epochs_completed': metrics['epochs_completed'],
                  'elapsed_s': time.monotonic() - started,
                  'checkpoint_sha256': _sha(dest / 'twin.pt'),
                  'predictions_sha256': _sha(dest / 'test_predictions.npz'),
                  'threads': torch.get_num_threads()}
        _write_json(dest / 'completed.json', record)
    return record


def train(config_file, workers):
    cfg, _, _, _, _, out = load_study(config_file)
    tasks = [(variant, seed) for seed in cfg['diagnostics']['seeds'] for variant in cfg['diagnostics']['variants']]
    records = []
    with ProcessPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(_train_one, str(Path(config_file).resolve()), variant, seed): (variant, seed)
                   for variant, seed in tasks}
        for future in as_completed(futures):
            record = future.result()
            records.append(record)
            _write_json(out / 'training_progress.json', records)
            print(f"completed {len(records)}/{len(tasks)}: {record['variant']} seed={record['seed']} "
                  f"epochs={record['epochs_completed']} elapsed={record['elapsed_s']:.1f}s", flush=True)
    _write_json(out / 'training_manifest.json', {'runs': records, 'total_runs': len(records)})


def residual(config_file):
    from .visual_diagnostics_residual import run_residual_diagnostics
    cfg, data, _, variants, metadata, out = load_study(config_file)
    return run_residual_diagnostics(data, variants, metadata, cfg, out / 'residual')


def summarize(config_file):
    from .visual_diagnostics_statistics import summarize_predictions
    cfg, data, _, variants, metadata, out = load_study(config_file)
    result = summarize_predictions(data, variants, metadata, out, cfg)
    originals = json.loads((out / 'input_hashes.json').read_text())
    changed = [path for path, digest in originals.items() if _sha(Path(path)) != digest]
    if changed:
        raise AssertionError(f'original input/manuscript changed: {changed}')
    _write_json(out / 'preservation_check.json', {'status': 'passed', 'files_verified': len(originals)})
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', required=True)
    parser.add_argument('--stage', choices=['prepare', 'train', 'residual', 'summarize', 'all'], default='all')
    parser.add_argument('--workers', type=int, default=2)
    args = parser.parse_args()
    if args.workers < 1:
        parser.error('--workers must be positive')
    stages = ['prepare', 'train', 'residual', 'summarize'] if args.stage == 'all' else [args.stage]
    for stage in stages:
        if stage == 'prepare':
            prepare(args.config)
        elif stage == 'train':
            train(args.config, args.workers)
        elif stage == 'residual':
            residual(args.config)
        else:
            summarize(args.config)


if __name__ == '__main__':
    main()
