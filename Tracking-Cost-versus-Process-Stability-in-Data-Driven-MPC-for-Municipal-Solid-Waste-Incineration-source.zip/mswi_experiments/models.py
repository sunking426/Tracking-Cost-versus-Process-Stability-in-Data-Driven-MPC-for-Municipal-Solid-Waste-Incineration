"""Canonical recurrent twin and bounded sparse-action actor.

All network inputs are physical quantities. Scaling buffers come exclusively
from the prepared training partition; the twin returns physical CV increments.
"""
from __future__ import annotations

import copy
from typing import Mapping

import numpy as np
import torch
from torch import Tensor, nn
import torch.nn.functional as F


def _vector(stats: Mapping, name: str, *, positive: bool = False) -> Tensor:
    value = torch.as_tensor(stats[name], dtype=torch.float32)
    if value.ndim != 1 or not torch.isfinite(value).all():
        raise ValueError(f"{name} must be a finite one-dimensional vector")
    if positive and not (value > 0).all():
        raise ValueError(f"{name} must be strictly positive")
    return value


class Twin(nn.Module):
    """Two recurrent process branches and/or the recorded flame-feature branch."""

    def __init__(self, stats: Mapping, mode: str = "multi", hidden: int = 128):
        super().__init__()
        if mode not in {"multi", "sensor", "image"}:
            raise ValueError("mode must be multi, sensor or image")
        self.stats = copy.deepcopy(dict(stats))
        self.mode = mode
        self.hidden = int(hidden)
        for name in ("u_mean", "u_scale", "z_mean", "z_scale", "v_mean", "v_scale",
                     "delta_mean", "delta_scale"):
            self.register_buffer(name, _vector(stats, name, positive=name.endswith("scale")))
        self.u_dim = self.u_mean.numel()
        self.z_dim = self.z_mean.numel()
        self.v_dim = self.v_mean.numel()
        if self.u_scale.shape != self.u_mean.shape or self.z_scale.shape != self.z_mean.shape:
            raise ValueError("process means and scales have different dimensions")
        if self.v_scale.shape != self.v_mean.shape:
            raise ValueError("visual means and scales have different dimensions")
        if self.delta_mean.numel() != self.z_dim or self.delta_scale.numel() != self.z_dim:
            raise ValueError("increment statistics must match the CV dimension")
        if self.hidden <= 0 or self.u_dim == 0 or self.z_dim == 0 or self.v_dim == 0:
            raise ValueError("model dimensions must be positive")
        if mode != "image":
            self.mv_norm = nn.LayerNorm(self.u_dim)
            self.cv_norm = nn.LayerNorm(self.z_dim)
            self.mv_encoder = nn.GRU(self.u_dim, self.hidden, batch_first=True)
            self.cv_encoder = nn.GRU(self.z_dim, self.hidden, batch_first=True)
        if mode != "sensor":
            self.visual_norm = nn.LayerNorm(self.v_dim)
            self.visual_encoder = nn.Sequential(
                nn.Linear(self.v_dim, self.hidden), nn.ReLU(),
                nn.Linear(self.hidden, self.hidden),
            )
        branches = {"sensor": 2, "image": 1, "multi": 3}[mode]
        self.fusion = nn.Sequential(
            nn.Linear(branches * self.hidden, self.hidden),
            nn.LayerNorm(self.hidden), nn.ReLU(),
        )
        self.decoder = nn.Linear(self.hidden, self.z_dim)

    @property
    def state_dim(self) -> int:
        return self.hidden + self.u_dim + self.z_dim

    def _check_inputs(self, u_hist: Tensor, z_hist: Tensor, visual: Tensor) -> None:
        if u_hist.ndim != 3 or u_hist.shape[-1] != self.u_dim:
            raise ValueError("u_hist must have shape (batch, history, MV dimension)")
        if z_hist.ndim != 3 or z_hist.shape[-1] != self.z_dim:
            raise ValueError("z_hist must have shape (batch, history, CV dimension)")
        if visual.ndim != 2 or visual.shape[-1] != self.v_dim:
            raise ValueError("visual must have shape (batch, visual feature dimension)")
        if not (len(u_hist) == len(z_hist) == len(visual)):
            raise ValueError("model input batches have different lengths")

    def _process_sequences(self, u_hist: Tensor, z_hist: Tensor) -> tuple[Tensor, Tensor]:
        u = self.mv_norm((u_hist - self.u_mean) / self.u_scale)
        z = self.cv_norm((z_hist - self.z_mean) / self.z_scale)
        hu, _ = self.mv_encoder(u)
        hz, _ = self.cv_encoder(z)
        return hu, hz

    def encode(self, u_hist: Tensor, z_hist: Tensor, visual: Tensor) -> Tensor:
        self._check_inputs(u_hist, z_hist, visual)
        branches = []
        if self.mode != "image":
            hu, hz = self._process_sequences(u_hist, z_hist)
            branches.extend((hu.mean(dim=1), hz.mean(dim=1)))
        if self.mode != "sensor":
            v = self.visual_norm((visual - self.v_mean) / self.v_scale)
            branches.append(self.visual_encoder(v))
        return self.fusion(torch.cat(branches, dim=1))

    def retrieval_key(self, u_hist: Tensor, z_hist: Tensor) -> Tensor:
        if self.mode == "image":
            raise ValueError("image-only twin has no recurrent process retrieval key")
        hu, hz = self._process_sequences(u_hist, z_hist)
        ku = F.normalize(hu.flatten(start_dim=1), dim=1, eps=1e-8)
        kz = F.normalize(hz.flatten(start_dim=1), dim=1, eps=1e-8)
        return F.normalize(torch.cat((ku, kz), dim=1), dim=1, eps=1e-8)

    def forward(self, u_hist: Tensor, z_hist: Tensor, visual: Tensor) -> Tensor:
        normalized_delta = self.decoder(self.encode(u_hist, z_hist, visual))
        return normalized_delta * self.delta_scale + self.delta_mean


def make_state(twin: Twin, u_hist: Tensor, z_hist: Tensor, visual: Tensor,
               u_current: Tensor, z_current: Tensor) -> Tensor:
    """Explicit paper state: latent context plus latest normalized MV and CV."""
    h = twin.encode(u_hist, z_hist, visual)
    if u_current.shape != (len(h), twin.u_dim) or z_current.shape != (len(h), twin.z_dim):
        raise ValueError("current MV/CV dimensions do not match the twin")
    return torch.cat((h, (u_current - twin.u_mean) / twin.u_scale,
                      (z_current - twin.z_mean) / twin.z_scale), dim=1)


class Actor(nn.Module):
    """Sparse operation head retaining the original gate-times-magnitude idea."""

    def __init__(self, state_dim: int, action_dim: int = 8, hidden: int = 128):
        super().__init__()
        self.state_dim = int(state_dim)
        self.action_dim = int(action_dim)
        self.hidden = int(hidden)
        if min(self.state_dim, self.action_dim, self.hidden) <= 0:
            raise ValueError("actor dimensions must be positive")
        self.gate_head = nn.Linear(self.state_dim, self.action_dim)
        self.mag_head = nn.Sequential(
            nn.Linear(self.state_dim, 2 * self.hidden), nn.ReLU(),
            nn.Linear(2 * self.hidden, self.action_dim),
        )

    def forward_details(self, state: Tensor) -> tuple[Tensor, Tensor, Tensor]:
        if state.ndim != 2 or state.shape[-1] != self.state_dim:
            raise ValueError("actor state has the wrong shape")
        gate_logits = self.gate_head(state)
        magnitude = self.mag_head(state)
        action = torch.sigmoid(gate_logits) * torch.tanh(magnitude)
        return action, gate_logits, magnitude

    def forward(self, state: Tensor) -> Tensor:
        return self.forward_details(state)[0]


def actor_config(actor: Actor) -> dict:
    return {"state_dim": actor.state_dim, "action_dim": actor.action_dim,
            "hidden": actor.hidden}


def twin_config(twin: Twin) -> dict:
    return {"stats": twin.stats, "mode": twin.mode, "hidden": twin.hidden}
