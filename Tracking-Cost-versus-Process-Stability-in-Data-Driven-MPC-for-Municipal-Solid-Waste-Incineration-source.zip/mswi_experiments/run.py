"""One reproducible command-line entry point for the repaired research pipeline."""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path

import torch

from .data import load_data, prepare_data
from .training import fit_bc, fit_twin, load_actor, load_twin, seed_everything


PROJECT = Path(__file__).resolve().parents[1]


def read_config(path: Path) -> dict:
    path = path.resolve()
    config = json.loads(path.read_text())
    for key in ('feature_file',):
        value = Path(config['data'][key])
        config['data'][key] = str(value if value.is_absolute() else (path.parent / value).resolve())
    config['data']['process_files'] = [str(p if p.is_absolute() else (path.parent / p).resolve())
                                        for p in map(Path, config['data']['process_files'])]
    output = Path(config['output_dir'])
    config['output_dir'] = str(output if output.is_absolute() else (path.parent / output).resolve())
    return config


def provenance(config: dict, stage: str, output: Path) -> None:
    versions = {p: importlib.metadata.version(p) for p in
                ('numpy', 'torch', 'pandas', 'scikit-learn', 'matplotlib')}
    record = {'stage': stage, 'started_utc': datetime.now(timezone.utc).isoformat(),
              'python': sys.version, 'platform': platform.platform(), 'versions': versions,
              'device': 'cpu', 'config': config,
              'code_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                              for p in sorted(Path(__file__).parent.glob('*.py'))}}
    output.mkdir(parents=True, exist_ok=True)
    (output / 'run_manifest.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')


def train(config: dict, data: dict, stats: dict, output: Path, target: str) -> None:
    models = output / 'models'
    specifications = {'twin_multi': ('multi', 11), 'twin_sensor': ('sensor', 11),
                      'twin_image': ('image', 11), 'twin_eval': ('multi', 97)}
    for name, (mode, seed) in specifications.items():
        if target in ('all', name):
            provenance(config, name, models / name)
            fit_twin(data, stats, mode, seed, config, models / name)
    for name, twin_name in [('bc_multi', 'twin_multi'), ('bc_sensor', 'twin_sensor')]:
        if target in ('all', name):
            twin = load_twin(models / twin_name / 'twin.pt')
            provenance(config, name, models / name)
            fit_bc(data, stats, twin, 11, config, models / name)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, default=PROJECT / 'experiment_config.json')
    parser.add_argument('--stage', choices=['all', 'prepare', 'train', 'analyze', 'validate', 'control', 'statistics', 'figures'], default='all')
    parser.add_argument('--target', choices=['all', 'twin_multi', 'twin_sensor', 'twin_image', 'twin_eval', 'bc_multi', 'bc_sensor'], default='all')
    parser.add_argument('--image-dir', type=Path, help='Explicit real-JPG directory for optional flame/feedback visualizations')
    args = parser.parse_args(argv)
    config = read_config(args.config)
    output = Path(config['output_dir'])
    seed_everything(config['training']['seed'], config['training']['threads'])
    print(json.dumps({'stage': args.stage, 'device': 'cpu', 'output': str(output)}, ensure_ascii=False), flush=True)
    if args.stage in ('all', 'prepare'):
        data, stats, manifest = prepare_data(config, output / 'data')
        print(json.dumps(manifest['split'], ensure_ascii=False), flush=True)
    else:
        data, stats, manifest = load_data(output / 'data')
    if args.stage in ('all', 'train'):
        train(config, data, stats, output, args.target)
    if args.stage in ('all', 'analyze'):
        from .analysis import run_prediction_analysis
        provenance(config, 'prediction_analysis', output / 'analysis')
        twins = {m: load_twin(output / 'models' / f'twin_{m}' / 'twin.pt')
                 for m in ('multi', 'sensor', 'image')}
        result = run_prediction_analysis(data, stats, twins, config, output / 'analysis')
        print(json.dumps({'analysis_complete': True, 'one_step': result['onestep']}, ensure_ascii=False), flush=True)
    if args.stage in ('all', 'control'):
        from .evaluation import run_control_suite
        provenance(config, 'control_suite', output / 'control')
        load = lambda name: load_twin(output / 'models' / name / 'twin.pt')
        result = run_control_suite(data, stats, load('twin_multi'), load('twin_sensor'), load('twin_eval'),
                                   load_actor(output / 'models/bc_multi/actor.pt'),
                                   load_actor(output / 'models/bc_sensor/actor.pt'), config, output / 'control')
        print(json.dumps({'control_complete': True, 'methods': result['main_methods']}, ensure_ascii=False), flush=True)
    if args.stage in ('all', 'validate'):
        from .validation import run_horizon_validation
        provenance(config, 'horizon_validation', output / 'validation')
        twins = {name: load_twin(output / 'models' / f'twin_{name}' / 'twin.pt')
                 for name in ('multi', 'sensor', 'eval')}
        result = run_horizon_validation(data, stats, twins, config, output / 'validation')
        print(json.dumps({'validation_complete':True},ensure_ascii=False),flush=True)
    if args.stage in ('all', 'statistics'):
        from .statistics import run_paired_statistics
        provenance(config,'paired_statistics',output / 'statistics')
        run_paired_statistics(output / 'control',output / 'statistics',config)
        print(json.dumps({'paired_statistics_complete':True},ensure_ascii=False),flush=True)
    if args.stage in ('all', 'figures'):
        from .figures import make_figures
        make_figures(output)
        if args.image_dir is not None:
            from .flame_figures import make_flame_figures
            make_flame_figures(output, args.image_dir, feature_file=config['data']['feature_file'])
        print('Figures saved from recorded experiment outputs.', flush=True)


if __name__ == '__main__':
    main()
