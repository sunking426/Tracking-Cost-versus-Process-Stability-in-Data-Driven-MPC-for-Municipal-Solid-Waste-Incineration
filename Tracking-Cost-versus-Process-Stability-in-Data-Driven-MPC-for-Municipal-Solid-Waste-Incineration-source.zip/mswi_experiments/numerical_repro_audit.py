"""Temporary, explicit instrumentation of sealed numerical routines.

The scientific statements remain unchanged. Hooks observe array ownership,
copy/stack integrity and persistence. No retry, score selection or fallback.
"""
from __future__ import annotations
import hashlib
import inspect
import json
import os
import textwrap
import uuid
import zipfile
from pathlib import Path
import numpy as np


class AuditMismatch(AssertionError):
    pass


class AuditPaused(RuntimeError):
    pass


def digest(a):
    a = np.asarray(a)
    return hashlib.sha256(a.tobytes(order='C')).hexdigest()


def describe(a):
    a = np.asarray(a)
    ptr = int(a.__array_interface__['data'][0])
    return dict(shape=list(a.shape), dtype=a.dtype.str, strides=list(a.strides),
                bytes=a.nbytes, address=ptr, page_offset=ptr % os.sysconf('SC_PAGE_SIZE'),
                own_data=bool(a.flags.owndata), c_contiguous=bool(a.flags.c_contiguous),
                base_type=type(a.base).__name__, sha256=digest(a))


def fsync_file(f):
    f.flush()
    os.fsync(f.fileno())
    # macOS full hardware-cache synchronization where supported.
    import fcntl
    full = getattr(fcntl, 'F_FULLFSYNC', 51 if os.uname().sysname == 'Darwin' else None)
    if full is not None:
        try:
            fcntl.fcntl(f.fileno(), full)
            return 'fsync+F_FULLFSYNC'
        except OSError as exc:
            return 'fsync; F_FULLFSYNC unavailable: ' + str(exc)
    return 'fsync'


def durable_json(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f'.{os.getpid()}.{uuid.uuid4().hex}.partial')
    with tmp.open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False); f.write('\n'); fsync_file(f)
    os.replace(tmp, path)


class ArrayAudit:
    def __init__(self, run_dir, mirror_dir):
        self.run_dir = Path(run_dir); self.mirror_dir = Path(mirror_dir)
        self.run_dir.mkdir(parents=True, exist_ok=True)
        self.log = (self.run_dir/'array_events.jsonl').open('x', buffering=1)
        self.objectives = {}; self.next_token = 0; self.step_hashes = {}
        self.context = {}; self.io_checks = []; self.instrumented = []

    def emit(self, kind, **details):
        self.log.write(json.dumps({'kind':kind, **self.context, **details}, separators=(',', ':')) + '\n')

    def failure(self, kind, **details):
        self.emit('failure', failure_kind=kind, **details)
        fsync_file(self.log)
        durable_json(self.run_dir/'FIRST_FAILURE.json', dict(kind=kind, context=self.context, **details))
        raise AuditMismatch(kind)

    def compare_bytes(self, label, expected, actual, expected_meta=None):
        raw = np.asarray(actual).tobytes(order='C')
        if raw == expected:
            return
        meta = describe(actual)
        folder = self.run_dir/'failure_arrays'; folder.mkdir(exist_ok=True)
        name = label.replace('/', '_').replace(':', '_')
        # Capture both independently observed contents, not just their hashes.
        (folder/(name+'.expected.bin')).write_bytes(expected)
        (folder/(name+'.actual.bin')).write_bytes(raw)
        if len(raw) == len(expected):
            bad = np.flatnonzero(np.frombuffer(expected, dtype=np.uint8) != np.frombuffer(raw, dtype=np.uint8))
            starts = bad[np.r_[True, np.diff(bad) != 1]]
            ends = bad[np.r_[np.diff(bad) != 1, True]] + 1
            ranges = [[int(s), int(e)] for s,e in zip(starts[:32], ends[:32])]
            element = int(bad[0]) // np.asarray(actual).dtype.itemsize
            coord = np.unravel_index(element, actual.shape)
            address = meta['address'] + sum(int(i)*s for i,s in zip(coord, actual.strides))
            detail = dict(changed_bytes=int(len(bad)), byte_ranges_first32=ranges,
                          first_element_coordinate=[int(i) for i in coord], first_changed_address=address,
                          first_changed_address_page_offset=address % os.sysconf('SC_PAGE_SIZE'),
                          changed_actual_bytes_all_zero=bool(np.all(np.frombuffer(raw,dtype=np.uint8)[bad] == 0)))
        else:
            detail = dict(expected_bytes=len(expected), actual_bytes=len(raw))
        self.failure(label, expected=expected_meta, actual=meta, **detail)

    def begin_objective(self, local):
        if getattr(self, 'stop_file', None) is not None and self.stop_file.exists():
            raise AuditPaused('Diagnostic queue paused after another worker detected an anomaly')
        token = self.next_token; self.next_token += 1
        frame = inspect.currentframe().f_back
        while frame:
            if 'decision_step' in frame.f_locals:
                self.context = dict(decision_step=int(frame.f_locals['decision_step']),
                                    iteration=int(frame.f_locals.get('iteration', -1)), objective=token)
                break
            frame = frame.f_back
        self.objectives[token] = dict(copies=[], inputs={k: describe(local[k]) for k in
            ('plans','u_hist','z_hist','current','times')})
        self.emit('objective_inputs', arrays=self.objectives[token]['inputs'])
        return token

    def before_copy(self, token, step, z, action, reward):
        state = self.objectives[token]
        state['pending'] = {k:(a.tobytes(order='C'), describe(a)) for k,a in
                            [('prediction',z),('executed',action),('reward',reward)]}
        self.emit('before_trace_copy', forecast_step=int(step),
                  arrays={k:v[1] for k,v in state['pending'].items()})

    def after_copy(self, token, step, trace):
        state = self.objectives[token]; row = {}
        for k,(raw,meta) in state.pop('pending').items():
            got = trace[k][-1]
            self.compare_bytes(f'copy/{token}/{step}/{k}', raw, got, meta)
            row[k] = describe(got)
        state['copies'].append(row)
        self.emit('trace_copy_checked', forecast_step=int(step), arrays=row)

    def before_stack(self, token, trace):
        state = self.objectives[token]
        for step,row in enumerate(state['copies']):
            for k,meta in row.items():
                if digest(trace[k][step]) != meta['sha256']:
                    self.failure('trace_changed_after_copy_before_stack', objective=token,
                                 forecast_step=step, field=k, saved=meta, current=describe(trace[k][step]))
        state['source_list'] = trace

    def after_stack(self, token, trace):
        state = self.objectives[token]
        for step,row in enumerate(state['copies']):
            for k,meta in row.items():
                source = state['source_list'][k][step]
                if digest(source) != meta['sha256']:
                    self.failure('source_changed_during_stack', field=k, forecast_step=step, saved=meta, current=describe(source))
                self.compare_bytes(f'stack/{token}/{step}/{k}', source.tobytes(order='C'), trace[k][:,:,step], meta)
        state.pop('source_list')
        self.emit('trace_stack_checked', arrays={k:describe(v) for k,v in trace.items()})

    def end_objective(self, token, local):
        state = self.objectives.pop(token)
        for k,meta in state['inputs'].items():
            if digest(local[k]) != meta['sha256']:
                self.failure('objective_input_mutated', field=k, saved=meta, current=describe(local[k]))

    def reward_created(self, tracking):
        meta = describe(tracking)
        self.emit('tracking_created', array=meta)
        return meta

    def reward_done(self, tracking, guard):
        if digest(tracking) != guard['sha256']:
            self.failure('tracking_changed_after_creation', saved=guard, current=describe(tracking))

    def info(self, info, step):
        row = {k:describe(v) for k,v in info.items()}
        self.step_hashes[step] = row
        self.emit('trajectory_step_before_buffer', trajectory_step=step, arrays=row)

    def pack_check(self, arrays, buf):
        for step,row in self.step_hashes.items():
            for k,meta in row.items():
                if digest(buf[k][step]) != meta['sha256']:
                    self.failure('episode_buffer_mutated', step=step, field=k, saved=meta, current=describe(buf[k][step]))
                self.compare_bytes(f'episode_stack/{step}/{k}', buf[k][step].tobytes(order='C'), arrays[k][:,step], meta)

    def _write_one(self, path, arrays, expected):
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists():
            raise FileExistsError('Never overwrite a diagnostic repetition: '+str(path))
        tmp = path.with_name(path.name+f'.{os.getpid()}.{uuid.uuid4().hex}.partial')
        with tmp.open('xb') as f:
            np.savez_compressed(f, **arrays); sync = fsync_file(f)
        os.replace(tmp,path)
        fd=os.open(path.parent, os.O_RDONLY)
        try: os.fsync(fd)
        finally: os.close(fd)
        with np.load(path, allow_pickle=False) as loaded:
            if set(loaded.files)!=set(arrays): self.failure('readback_field_names', path=str(path))
            for k in arrays:
                value=loaded[k]; got=describe(value)
                if got['sha256']!=expected[k]['sha256'] or got['dtype']!=expected[k]['dtype'] or got['shape']!=expected[k]['shape']:
                    # Do not mistake mutated source memory for a storage-only failure.
                    self.failure('prewrite_readback_mismatch', path=str(path), field=k, prewrite=expected[k],
                                 readback=got, current_memory=describe(arrays[k]))
        for k,a in arrays.items():
            if digest(a)!=expected[k]['sha256']:
                self.failure('source_changed_during_serialization', path=str(path), field=k, prewrite=expected[k], current=describe(a))
        with zipfile.ZipFile(path) as z:
            offsets={i.filename:dict(zip_header_offset=i.header_offset, compression=i.compress_type,
                                    compressed_bytes=i.compress_size, uncompressed_bytes=i.file_size) for i in z.infolist()}
        result=dict(path=str(path), status='passed', sync=sync, file_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                    array_sha256={k:v['sha256'] for k,v in expected.items()}, zip_offsets=offsets,
                    alignment_note='Compressed ZIP offsets cannot be equated with uncompressed in-memory array offsets.')
        self.io_checks.append(result); self.emit('write_readback_checked', path=str(path), sync=sync)

    def save(self, path, arrays):
        expected={k:describe(v) for k,v in arrays.items()}
        self.emit('prewrite', arrays=expected)
        durable_json(self.run_dir/'PREWRITE_ARRAYS.json', expected)
        self._write_one(Path(path), arrays, expected)
        self._write_one(self.mirror_dir/'trajectory.npz', arrays, expected)
        durable_json(self.run_dir/'IO_CHECKS.json', self.io_checks)

    def close(self):
        fsync_file(self.log); self.log.close()


def instrument_function(fn, substitutions, audit, folder):
    """Literal, count-checked diagnostic insertions; original statements retained."""
    source=textwrap.dedent(inspect.getsource(fn)); transformed=source
    for old,new in substitutions:
        if transformed.count(old)!=1:
            raise AssertionError('Instrumentation source no longer matches: '+fn.__qualname__+' / '+old)
        transformed=transformed.replace(old,new)
    name=fn.__module__.replace('.','_')+'_'+fn.__qualname__.replace('.','_')
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    (folder/(name+'.original.py')).write_text(source)
    (folder/(name+'.instrumented.py')).write_text(transformed)
    scope=dict(fn.__globals__, _AUDIT=audit)
    exec(compile(transformed,str(folder/(name+'.instrumented.py')),'exec'),scope)
    audit.instrumented.append(dict(function=fn.__module__+'.'+fn.__qualname__,
                                   original_sha256=hashlib.sha256(source.encode()).hexdigest(),
                                   instrumented_sha256=hashlib.sha256(transformed.encode()).hexdigest()))
    return scope[fn.__name__]


def install(audit, study):
    from . import control,mpc_ablation,ridge_policy_planning,mpc_stability,mpc_temperature,ridge_policy
    folder=audit.run_dir/'instrumented_sources'
    original=control.reward_and_violation
    reward=instrument_function(original,[
        ('tracking = np.abs(cv[..., :3] - TARGETS[:3]) / TRACKING_SCALES[:3]',
         'tracking = np.abs(cv[..., :3] - TARGETS[:3]) / TRACKING_SCALES[:3]\n    _guard = _AUDIT.reward_created(tracking)'),
        ('return reward.astype(np.float32), violation, {',
         '_AUDIT.reward_done(tracking, _guard)\n    return reward.astype(np.float32), violation, {')],audit,folder)
    for module in (control,mpc_ablation,ridge_policy_planning,mpc_stability,mpc_temperature,ridge_policy):
        if getattr(module,'reward_and_violation',None) is original: module.reward_and_violation=reward
    fn=mpc_ablation.AblationCEM.objective_components
    line="trace['prediction'].append(z.copy());trace['executed'].append(a.reshape(n,c,8).copy());trace['reward'].append(reward.copy())"
    substitutions=[
        ('n,c,h,d=plans.shape','n,c,h,d=plans.shape\n    _token = _AUDIT.begin_objective(locals())'),
        (line, '_AUDIT.before_copy(_token,step,z,a.reshape(n,c,8),reward)\n        '+line+'\n        _AUDIT.after_copy(_token,step,trace)'),
        ("trace={k:np.stack(v,axis=2) for k,v in trace.items()}",
         "_AUDIT.before_stack(_token,trace)\n    trace={k:np.stack(v,axis=2) for k,v in trace.items()}\n    _AUDIT.after_stack(_token,trace)"),
        ('return (values,trace) if return_trace else values',
         '_AUDIT.end_objective(_token,locals())\n    return (values,trace) if return_trace else values')]
    mpc_ablation.AblationCEM.objective_components=instrument_function(fn,substitutions,audit,folder)
    # The S8 scorer is distinct but its original arithmetic also remains intact.
    fn=ridge_policy_planning.CEMPlanner.score
    line="trace['prediction'].append(z.copy());trace['executed'].append(a.reshape(n,c,8).copy());trace['reward'].append(r.copy())"
    substitutions=[('n,c,h,adim=plans.shape','n,c,h,adim=plans.shape\n    _token = _AUDIT.begin_objective(locals())'),
        (line,'_AUDIT.before_copy(_token,step,z,a.reshape(n,c,8),r)\n            '+line+'\n            _AUDIT.after_copy(_token,step,trace)'),
        ('if return_trace:return score,{k:np.stack(v,axis=2) for k,v in trace.items()}',
         "if return_trace:\n        _AUDIT.before_stack(_token,trace)\n        trace={k:np.stack(v,axis=2) for k,v in trace.items()}\n        _AUDIT.after_stack(_token,trace)\n        _AUDIT.end_objective(_token,locals())\n        return score,trace"),
        ('return score\n','_AUDIT.end_objective(_token,locals())\n    return score\n')]
    ridge_policy_planning.CEMPlanner.score=instrument_function(fn,substitutions,audit,folder)
    fn=study.run_case
    substitutions=[('for k,v in info.items():buf.setdefault(k,[]).append(v)',
        '_AUDIT.info(info,step)\n        for k,v in info.items():buf.setdefault(k,[]).append(v)'),
        ('for k,v in a.items():','_AUDIT.pack_check(a,buf)\n    for k,v in a.items():'),
        ("path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix('.partial.npz');np.savez_compressed(tmp,**a);tmp.replace(path)",
         '_AUDIT.save(path,a)')]
    study.run_case=instrument_function(fn,substitutions,audit,folder)
    durable_json(audit.run_dir/'INSTRUMENTATION.json',audit.instrumented)
