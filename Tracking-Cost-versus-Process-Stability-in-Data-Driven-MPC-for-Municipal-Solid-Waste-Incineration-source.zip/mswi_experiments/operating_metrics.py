"""Descriptive operating endpoints on saved physical trajectories only."""
from __future__ import annotations
import numpy as np
from .data import control_values

METRICS=('temperature_min_5min','temperature_below850_fraction','oxygen_in_band_fraction',
         'temperature_mean_abs_step','steam_mean_abs_step','oxygen_mean_abs_step')
UNITS=('degC','fraction','fraction','degC/step','t/h per step','percentage_points/step')


def operating_endpoints(pred_cv,z_hist,z_current,horizon):
    """Return per-episode endpoints, trailing5 temperature and raw controls.

First evaluated time is t+1. Four observations (t-3..t) supply the prefix
for trailing windows. Initial observations are never counted as extra steps.
"""
    pred=np.asarray(pred_cv,dtype=np.float64);history=np.asarray(z_hist,dtype=np.float64)
    initial=np.asarray(z_current,dtype=np.float64)
    if pred.ndim!=3 or pred.shape[2]!=9:raise ValueError('pred_cv must be(N,H,9)')
    n=len(pred)
    if not n or history.shape!=(n,10,9) or initial.shape!=(n,9):raise ValueError('aligned historical observations required')
    if not isinstance(horizon,(int,np.integer)) or horizon<1 or horizon>pred.shape[1]:raise ValueError('invalid saved horizon')
    if not all(np.isfinite(v).all() for v in (pred,history,initial)):raise ValueError('nonfinite trajectory/observation')
    controls=control_values(pred[:,:horizon]);initial_controls=control_values(initial)
    prefix=np.concatenate((control_values(history[:,-3:])[:,:,0],initial_controls[:,0,None]),axis=1)
    sequence=np.concatenate((prefix,controls[:,:,0]),axis=1)
    rolling=np.lib.stride_tricks.sliding_window_view(sequence,5,axis=1).mean(-1)
    if rolling.shape!=(n,horizon):raise AssertionError('one complete trailing window per control step')
    increments=np.abs(np.diff(np.concatenate((initial_controls[:,None],controls),axis=1),axis=1))
    value=np.column_stack((rolling.min(1),(rolling<850.).mean(1),
        ((controls[:,:,3]>=3.5)&(controls[:,:,3]<=4.)).mean(1),
        increments[:,:,0].mean(1),increments[:,:,2].mean(1),increments[:,:,3].mean(1)))
    return value,rolling,controls
