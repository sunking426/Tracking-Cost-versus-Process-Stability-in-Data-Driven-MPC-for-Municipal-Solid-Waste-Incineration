"""Validation-selected RGB dimension and group-penalty prediction probes.

This module changes how much of a frozen visual representation is available and
how strongly its regression coefficients are penalized. It adds no captures and
does not alter the original encoder, prior experiments, or process histories.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import time

import numpy as np

from .data import control_values
from .visual_diagnostics import load_study
from .visual_diagnostics_horizons import ALPHAS, CONTROL_NAMES, apply_direct_ridge, direct_interval, eligible_pairs
from .visual_diagnostics_statistics import DAY_NS
from .visual_representation_probe import (
    PARTITIONS, _archive, _json, _sha, fit_capture_pca, freeze_protocol,
    validate_capture_inputs, validate_encoder_artifact, validate_null_donors,
)


HORIZONS = (1, 5, 10)
DIMENSIONS = (32, 128, 512)
RHOS = (.1, 1., 10.)
RHO_TIE_ORDER = {1.: 0, .1: 1, 10.: 2}
BASE_DIMENSION = 194


def candidate_name(dimension, rho):
    return f"rgb{int(dimension)}_rho" + {.1: "0p1", 1.: "1", 10.: "10"}[float(rho)]


def prepare_group_ridge(train_x, train_change, val_x, val_change, base_dimension):
    """Train-only scaling and one centered Gram matrix per input dimension."""
    from sklearn.preprocessing import StandardScaler

    x, y = np.asarray(train_x, dtype=np.float64), np.asarray(train_change, dtype=np.float64)
    vx, vy = np.asarray(val_x, dtype=np.float64), np.asarray(val_change, dtype=np.float64)
    if (x.ndim != 2 or len(x) < 2 or y.shape != (len(x), 4)
            or vx.ndim != 2 or not len(vx) or vx.shape[1] != x.shape[1]
            or vy.shape != (len(vx), 4) or not isinstance(base_dimension, int)
            or not 1 <= base_dimension <= x.shape[1]):
        raise ValueError("invalid grouped Ridge matrices or base dimension")
    if any(not np.isfinite(a).all() for a in (x, y, vx, vy)):
        raise ValueError("grouped Ridge inputs must be finite")
    xs, ys = StandardScaler().fit(x), StandardScaler().fit(y)
    sx, sy = xs.transform(x), ys.transform(y)
    # Explicit centering preserves an unpenalized intercept, including roundoff
    # in StandardScaler outputs, matching sklearn's Ridge(fit_intercept=True).
    x_offset, y_offset = sx.mean(axis=0), sy.mean(axis=0)
    centered_x, centered_y = sx-x_offset, sy-y_offset
    return {"x_mean": xs.mean_, "x_scale": xs.scale_, "y_mean": ys.mean_, "y_scale": ys.scale_,
            "x_offset": x_offset, "y_offset": y_offset,
            "gram": centered_x.T @ centered_x, "cross": centered_x.T @ centered_y,
            "val_x": xs.transform(vx), "val_y": ys.transform(vy),
            "base_dimension": base_dimension}


def fit_group_ridge(prepared, rho=1., alphas=ALPHAS):
    """Apply group penalties after scaling, then choose alpha on validation.

    Stored coefficients use the original standardized feature coordinates and
    can therefore be replayed with the canonical apply_direct_ridge function.
    """
    from scipy.linalg import cho_factor, cho_solve

    rho = float(rho)
    alphas = np.asarray(alphas, dtype=np.float64)
    if (not np.isfinite(rho) or rho <= 0 or alphas.ndim != 1 or not len(alphas)
            or np.any(~np.isfinite(alphas)) or np.any(alphas <= 0)
            or len(np.unique(alphas)) != len(alphas)):
        raise ValueError("group penalties and alphas must be finite positive values")
    gram, cross = prepared["gram"], prepared["cross"]
    penalties = np.ones(len(gram), dtype=np.float64)
    penalties[prepared["base_dimension"]:] = rho
    candidates = []
    residuals = []
    for alpha in alphas:
        system = gram.copy()
        system[np.diag_indices_from(system)] += alpha*penalties
        beta = cho_solve(cho_factor(system, lower=True, check_finite=True), cross, check_finite=True)
        relative_residual = float(np.linalg.norm(system@beta-cross) / max(np.linalg.norm(cross), 1.))
        if not np.isfinite(beta).all() or not np.isfinite(relative_residual) or relative_residual > 1e-8:
            raise FloatingPointError("grouped Ridge linear system failed residual check")
        intercept = prepared["y_offset"] - prepared["x_offset"]@beta
        score = float(np.square(prepared["val_x"]@beta + intercept - prepared["val_y"]).mean())
        if not np.isfinite(score):
            raise FloatingPointError("nonfinite grouped Ridge validation loss")
        candidates.append((score, float(alpha), beta.T, intercept))
        residuals.append(relative_residual)
    score, alpha, coef, intercept = min(candidates, key=lambda item: (item[0], item[1]))
    return {key: np.asarray(prepared[key]) for key in ("x_mean", "x_scale", "y_mean", "y_scale")} | {
        "coef": coef, "intercept": intercept, "alpha": np.asarray(alpha),
        "alphas": alphas, "val_normalized_mse": np.asarray([c[0] for c in candidates]),
        "rho": np.asarray(rho), "base_dimension": np.asarray(prepared["base_dimension"]),
        "linear_system_relative_residual": np.asarray(residuals), "selected_val_score": np.asarray(score)}


def select_adaptive(candidates):
    """Select solely by validation score; exact ties follow the frozen order."""
    if not candidates:
        raise ValueError("no RGB candidates")
    for row in candidates.values():
        if not np.isfinite(row["selected_val_score"]):
            raise ValueError("nonfinite candidate validation score")
    return min(candidates, key=lambda name: (candidates[name]["selected_val_score"],
               candidates[name]["visual_dimension"], RHO_TIE_ORDER[float(candidates[name]["rho"])],
               candidates[name]["alpha"]))


def origin_design(data, variants, features, dimension, origins, null=False):
    """Only origin inputs; null changes the visual block and no other block."""
    if dimension not in (0, *DIMENSIONS):
        raise ValueError("unsupported RGB feature dimension")
    rows = np.asarray(origins, dtype=np.int64)
    mapping = features["sample_capture_index"]
    numeric = np.concatenate([data[key][rows].reshape(len(rows), -1) for key in ("u_hist", "z_hist")], axis=1)
    if numeric.shape[1] != 178 or variants["timing4"].shape[1] != 4 or features["quality"].shape[1] != 12:
        raise ValueError("grouped probe requires numeric178, timing4 and quality12")
    chunks = [numeric, variants["timing4"][rows], features["quality"][mapping[rows]]]
    if dimension:
        donor_rows = features["null_donor_sample_index"][rows] if null else rows
        matrix = features["rgb_raw"] if dimension == 512 else features["rgb_pca128"][:, :dimension]
        chunks.append(matrix[mapping[donor_rows]])
    x = np.concatenate(chunks, axis=1).astype(np.float64)
    if not len(x) or not np.isfinite(x).all():
        raise ValueError("invalid origin design")
    return x


def visual_contribution(fitted, x):
    """Describe the linear visual term, not predictive or causal importance."""
    start = int(fitted["base_dimension"])
    normalized = (np.asarray(x, dtype=np.float64)-fitted["x_mean"])/fitted["x_scale"]
    term = (normalized[:, start:]@fitted["coef"][:, start:].T)*fitted["y_scale"]
    return {"rms": np.sqrt(np.square(term).mean(axis=0)).tolist(),
            "sd": term.std(axis=0).tolist(), "mean": term.mean(axis=0).tolist(),
            "scope": "linear visual branch amplitude in physical target-change units; not information gain or causal importance"}


def _endpoint_priority(horizon, candidate, reference):
    main = horizon == 5 and candidate == "adaptive_rgb" and reference in ("quality", "matched_null")
    return {name: "prespecified_this_round_exploratory_primary" if main and name in ("steam", "oxygen")
            else "exploratory_secondary" for name in CONTROL_NAMES}


def _check_reference(saved, data, origins, destinations):
    truth = control_values(data["z_target"][destinations]).astype(np.float64)
    expected = {"indices": origins, "destination_indices": destinations,
                "time_ns": data["time_ns"][origins], "destination_time_ns": data["time_ns"][destinations],
                "truth": truth, "origin_previous": control_values(data["z_prev"][origins]).astype(np.float64)}
    for key, value in expected.items():
        if not np.array_equal(saved[key], value):
            raise ValueError("previous old52 reference has different paired " + key)
    if saved["pred"].shape != truth.shape or not np.isfinite(saved["pred"]).all():
        raise ValueError("invalid previous old52 predictions")
    if not np.array_equal(saved["error"], saved["pred"]-truth):
        raise ValueError("previous old52 saved error mismatch")


def run_utilization_probe(config_file):
    from threadpoolctl import threadpool_limits

    config_path = Path(config_file).resolve()
    config = json.loads(config_path.read_text())
    representation_path = (config_path.parent/config["representation_config"]).resolve()
    rep = json.loads(representation_path.read_text())
    base_path = (representation_path.parent/rep["base_config"]).resolve()
    base, data, _, variants, metadata, descriptor_study = load_study(base_path)
    previous_study = (representation_path.parent/rep["output_dir"]).resolve()
    output = (config_path.parent/config["output_dir"]).resolve()/"probe"
    output.mkdir(parents=True, exist_ok=True)
    if (output/"completed.json").exists():
        raise FileExistsError("completed utilization study is immutable; use a new output directory")
    paths = {k: (representation_path.parent/rep[k]).resolve() for k in
             ("embeddings_file", "quality_file", "encoder_manifest")}
    validate_encoder_artifact(paths["encoder_manifest"], paths["embeddings_file"])
    embeddings, quality = _archive(paths["embeddings_file"]), _archive(paths["quality_file"])
    quality_matrix, quality_columns, partitions = validate_capture_inputs(data, embeddings, quality)
    if quality_matrix.shape[1] != 12:
        raise ValueError("this protocol requires the frozen 12-column appearance baseline")
    mapping = embeddings["sample_capture_index"]
    donors, donor_info = validate_null_donors(data, mapping, metadata["null_donor_sample_index"])
    pairs = {h: {part: eligible_pairs(data, part, h) for part in PARTITIONS} for h in HORIZONS}
    if any(len(pair[0]) < 2 for parts in pairs.values() for pair in parts.values()):
        raise ValueError("insufficient eligible pairs")
    options = dict(base["diagnostics"])
    options.update({k: config[k] for k in ("bootstrap_draws", "bootstrap_seed", "confidence_level") if k in config})
    source_protocol = json.loads((descriptor_study/"protocol.json").read_text())
    for path, digest in source_protocol["input_hashes"].items():
        if _sha(path) != digest:
            raise ValueError("original input or manuscript changed")
    if _sha(descriptor_study/"feature_variants.npz") != source_protocol["feature_archive_sha256"]:
        raise ValueError("original descriptor feature archive changed")
    prior_results = json.loads((previous_study/"probe/results.json").read_text())
    if prior_results["status"] != "completed":
        raise ValueError("previous representation study is incomplete")
    reference_files = {}
    for h in HORIZONS:
        for part in PARTITIONS:
            path = previous_study/f"probe/horizon_{h:02d}/old52/{part}_predictions.npz"
            expected = prior_results["horizons"][str(h)]["methods"]["old52"]["split_metrics"][part]["predictions_sha256"]
            if _sha(path) != expected:
                raise ValueError("previous old52 reference file hash changed")
            reference_files[(h, part)] = path
    previous_pca = previous_study/"probe/pca_rgb.npz"
    source_files = [config_path, representation_path, base_path, *paths.values(),
                    descriptor_study/"protocol.json", descriptor_study/"feature_variants.npz",
                    descriptor_study/"feature_metadata.npz", previous_study/"probe/results.json", previous_pca,
                    *reference_files.values()]
    source_hashes = {str(path): _sha(path) for path in source_files} | source_protocol["input_hashes"]
    code_files = [Path(__file__).with_name(name).resolve() for name in
                  ("visual_utilization_probe.py", "visual_representation_probe.py", "visual_diagnostics_horizons.py",
                   "visual_diagnostics_statistics.py", "visual_diagnostics.py", "data.py")]
    protocol = freeze_protocol(output/"protocol.json", {
        "scope": "exploratory use of fixed RGB representations; no extra captured images, no CNN or RL training",
        "config": config, "horizons_minutes": list(HORIZONS), "visual_dimensions": list(DIMENSIONS),
        "rhos": list(RHOS), "alphas": list(ALPHAS), "base_dimension": BASE_DIMENSION,
        "input_composition": "numeric178 + timing4 + quality12, followed by current aligned RGB encoding",
        "target_definition": "4 control_values at destination z_target minus origin z_prev, h-1 continuous one-minute links inside the same partition",
        "targets": list(CONTROL_NAMES), "units": ["degC", "Pa", "t/h", "vol%"],
        "primary_endpoints": "5-minute steam and oxygen MAE; validation-selected adaptive_rgb versus quality and matched_null",
        "pca": {"dimensions": [32, 128], "fit": "unique training captures only, full SVD; PCA32 is first32 of PCA128", "raw512": "no PCA; also changes coordinate and regularization geometry, not only retained dimension", "previous32_check_atol": 1e-10},
        "ridge": {"scalers": "eligible training rows only; 4-target scaling", "intercept": "unpenalized",
                  "objective": "sum squared standardized residuals + alpha*sum(base coefficients squared) + alpha*rho*sum(visual coefficients squared)",
                  "implementation": "centered Gram matrix and positive diagonal penalties, scipy Cholesky solve; coefficients stored in original standardized coordinates",
                  "solver_relative_residual_limit": 1e-8,
                  "validation_selection": "mean standardized 4-output validation MSE; alpha within each D/rho, then among9 RGB candidates",
                  "tie_break": "exact score tie: smaller D, rho order [1,.1,10], smaller alpha",
                  "fit_before_score": "all horizons' candidate selections and matched-null fits complete before any scoring"},
        "negative_control": {"source": "previous six-capture block donor mapping", "partitions": donor_info,
                             "capacity": "same D/rho as selected RGB; alpha selected independently on validation",
                             "scope": "possible future donors within a partition; intentional noncausal negative control; base inputs remain aligned; fixed matched-capacity diagnostic, not a permutation test repeating the full model-selection procedure"},
        "contribution_scope": "visual linear-term RMS/SD describes model use only, not extra information or causal importance",
        "comparisons": "all9 candidates and adaptive versus quality and rgb32_rho1; adaptive versus matched_null and previous old52",
        "prior_reference": "old52 predictions loaded without refitting; exact sample, target and metadata pairing checked during scoring",
        "capture_counts": {part: len(rows) for part, rows in partitions.items()}, "quality_columns": quality_columns.tolist(),
        "eligible_counts": {str(h): {part: len(pair[0]) for part, pair in parts.items()} for h, parts in pairs.items()},
        "intervals": {"direction": "reference MAE minus candidate MAE; positive improvement", "bootstrap": "paired whole origin-calendar-day", "draws": int(options["bootstrap_draws"]),
                      "seed": int(options["bootstrap_seed"]), "confidence_level": float(options["confidence_level"]), "multiple_comparison_adjustment": "none", "neural_seed_axis": False,
                      "selection_scope": "conditional on the validation-selected fitted models; bootstrap does not repeat PCA, training or model selection"},
        "test_scope": "previously inspected historical test period; exploratory, not an untouched holdout",
        "source_input_hashes": source_hashes, "code_hashes": {str(f): _sha(f) for f in code_files}})
    _json(output/"config.json", config)
    artifacts = []
    result = {"status": "running", "protocol": protocol, "horizons": {}}
    with threadpool_limits(limits=1):
        pca, scores = fit_capture_pca(embeddings["rgb"], mapping, data["train_idx"], 128)
        old_pca = _archive(previous_pca)
        for key, actual in (("mean", pca["mean"]), ("components", pca["components"][:32]),
                            ("train_capture_indices", pca["train_capture_indices"])):
            if not np.allclose(actual, old_pca[key], rtol=0, atol=1e-10):
                raise ValueError("PCA128 first32 do not match the frozen previous PCA32")
        path = output/"pca_rgb128.npz"
        np.savez_compressed(path, **pca, capture_time_ns=embeddings["capture_time_ns"])
        artifacts.append(path)
        features = {"quality": quality_matrix, "rgb_pca128": scores, "rgb_raw": embeddings["rgb"],
                    "sample_capture_index": mapping, "null_donor_sample_index": donors,
                    "capture_time_ns": embeddings["capture_time_ns"]}
        path = output/"prepared_capture_features.npz"
        np.savez_compressed(path, **features, quality_columns=quality_columns)
        artifacts.append(path)
        selected_models = 0
        for horizon, parts in pairs.items():
            folder = output/f"horizon_{horizon:02d}"
            folder.mkdir(exist_ok=True)
            pair_file = folder/"eligible_pairs.npz"
            np.savez_compressed(pair_file, **{part+suffix: pair[pos] for part, pair in parts.items()
                                              for suffix, pos in (("_origin_indices", 0), ("_destination_indices", 1))})
            artifacts.append(pair_file)
            tr, td = parts["train"]
            vr, vd = parts["val"]
            train_change = control_values(data["z_target"][td]).astype(np.float64)-control_values(data["z_prev"][tr]).astype(np.float64)
            val_change = control_values(data["z_target"][vd]).astype(np.float64)-control_values(data["z_prev"][vr]).astype(np.float64)
            rows = {}

            def save_fit(name, dimension, rho, fitted, null=False):
                nonlocal selected_models
                dest = folder/name
                dest.mkdir(exist_ok=True)
                path = dest/"ridge_weights.npz"
                np.savez_compressed(path, **fitted)
                artifacts.append(path)
                row = {"visual_dimension": dimension, "rho": rho, "alpha": float(fitted["alpha"]),
                       "input_dimension": BASE_DIMENSION+dimension, "null": bool(null),
                       "selected_val_score": float(fitted["selected_val_score"]),
                       "alphas": fitted["alphas"].tolist(), "val_normalized_mse": fitted["val_normalized_mse"].tolist(),
                       "weights_sha256": _sha(path), "role": "selected fit"}
                _json(dest/"selection.json", row)
                rows[name] = row
                selected_models += 1

            for dimension in (0, *DIMENSIONS):
                tx, vx = [origin_design(data, variants, features, dimension, x) for x in (tr, vr)]
                prepared = prepare_group_ridge(tx, train_change, vx, val_change, BASE_DIMENSION)
                for rho in (RHOS if dimension else (1.,)):
                    name = candidate_name(dimension, rho) if dimension else "quality"
                    save_fit(name, dimension, rho, fit_group_ridge(prepared, rho))
                del prepared, tx, vx
            candidates = {name: row for name, row in rows.items() if name != "quality"}
            selected = select_adaptive(candidates)
            dimension, rho = rows[selected]["visual_dimension"], rows[selected]["rho"]
            tx, vx = [origin_design(data, variants, features, dimension, x, null=True) for x in (tr, vr)]
            null = fit_group_ridge(prepare_group_ridge(tx, train_change, vx, val_change, BASE_DIMENSION), rho)
            save_fit("matched_null", dimension, rho, null, null=True)
            rows["adaptive_rgb"] = dict(rows[selected], role="alias of validation-selected existing fit", selected_candidate=selected)
            _json(folder/"adaptive_selection.json", {"selected_candidate": selected, "selection_uses": "validation only", **rows["adaptive_rgb"]})
            result["horizons"][str(horizon)] = {"eligible_counts": protocol["eligible_counts"][str(horizon)],
                                              "adaptive_selected": selected, "methods": rows, "comparisons": {}}
            print(f"utilization fitting completed: horizon={horizon}, selected={selected}", flush=True)
        _json(output/"fitting_completed.json", {"completed_unix": time.time(), "selected_fits": selected_models,
                 "candidate_alpha_solves": selected_models*len(ALPHAS), "adaptive_records_are_aliases": True,
                 "test_predictions_written": False, "protocol_sha256": _sha(output/"protocol.json")})
        for horizon, parts in pairs.items():
            folder = output/f"horizon_{horizon:02d}"
            hresult = result["horizons"][str(horizon)]
            errors = {}
            for method, row in hresult["methods"].items():
                fitted_name = row.get("selected_candidate", method)
                fitted = _archive(folder/fitted_name/"ridge_weights.npz")
                dest = folder/method
                dest.mkdir(exist_ok=True)
                split_results = {}
                for part, (origins, destinations) in parts.items():
                    truth = control_values(data["z_target"][destinations]).astype(np.float64)
                    previous = control_values(data["z_prev"][origins]).astype(np.float64)
                    x = origin_design(data, variants, features, row["visual_dimension"], origins, null=row["null"])
                    pred = apply_direct_ridge(fitted, x, previous)
                    error = pred-truth
                    if not np.isfinite(error).all():
                        raise FloatingPointError("nonfinite utilization predictions")
                    path = dest/f"{part}_predictions.npz"
                    np.savez_compressed(path, indices=origins, destination_indices=destinations,
                                        time_ns=data["time_ns"][origins], destination_time_ns=data["time_ns"][destinations],
                                        truth=truth, origin_previous=previous, pred=pred, error=error)
                    artifacts.append(path)
                    split_results[part] = {"mae": np.abs(error).mean(axis=0).tolist(),
                                           "rmse": np.sqrt(np.square(error).mean(axis=0)).tolist(),
                                           "samples": len(origins), "predictions_sha256": _sha(path),
                                           "visual_contribution": visual_contribution(fitted, x)}
                    if part == "test":
                        errors[method] = error
                row.update(split_results["test"])
                row["split_metrics"] = split_results
            old_splits = {}
            for part, (origins, destinations) in parts.items():
                path = reference_files[(horizon, part)]
                saved = _archive(path)
                _check_reference(saved, data, origins, destinations)
                error = saved["error"]
                old_splits[part] = {"mae": np.abs(error).mean(axis=0).tolist(), "rmse": np.sqrt(np.square(error).mean(axis=0)).tolist(),
                                    "samples": len(origins), "predictions_file": str(path), "predictions_sha256": _sha(path)}
                if part == "test":
                    errors["old52_reference"] = error
            hresult["methods"]["old52_reference"] = {"role": "unchanged external reference; not refitted", "split_metrics": old_splits, **old_splits["test"]}
            candidates = [candidate_name(d, r) for d in DIMENSIONS for r in RHOS]+["adaptive_rgb"]
            contrasts = {(candidate, reference) for candidate in candidates for reference in ("quality", "rgb32_rho1") if candidate != reference}
            contrasts.update({("adaptive_rgb", "matched_null"), ("adaptive_rgb", "old52_reference")})
            days = data["time_ns"][parts["test"][0]]//DAY_NS
            for candidate, reference in sorted(contrasts):
                row = direct_interval(np.abs(errors[reference])-np.abs(errors[candidate]), days, options)
                row.update({"candidate": candidate, "reference": reference,
                            "endpoint_priorities": _endpoint_priority(horizon, candidate, reference)})
                hresult["comparisons"][candidate+"_vs_"+reference] = row
            _json(output/"results.json", result)
            print(f"utilization scoring completed: horizon={horizon}", flush=True)
    for path, digest in source_hashes.items():
        if _sha(path) != digest:
            raise AssertionError("source changed during utilization probing")
    for path, digest in protocol["code_hashes"].items():
        if _sha(path) != digest:
            raise AssertionError("code changed during utilization probing")
    result["status"] = "completed"
    _json(output/"results.json", result)
    _json(output/"artifact_hashes.json", {str(path.relative_to(output)): _sha(path) for path in artifacts})
    _json(output/"completed.json", {"status": "completed", "selected_fits": selected_models,
          "adaptive_aliases": len(HORIZONS), "external_old52_references": len(HORIZONS),
          "results_sha256": _sha(output/"results.json"), "protocol_sha256": _sha(output/"protocol.json"),
          "artifact_hashes_sha256": _sha(output/"artifact_hashes.json"), "source_and_code_unchanged": True})
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    run_utilization_probe(args.config)


if __name__ == "__main__":
    main()
