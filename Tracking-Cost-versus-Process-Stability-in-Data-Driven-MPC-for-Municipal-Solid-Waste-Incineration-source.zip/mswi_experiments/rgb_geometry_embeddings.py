"""Frozen four-group geometry and spatial-pooling representations.

No process targets are read. Both geometry variants use the same frozen
ResNet18 feature map; global and spatial summaries differ only in pooling.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import io
import json
from pathlib import Path
import time

import numpy as np
from PIL import Image
import torch
import torch.nn.functional as F

from .visual_image_audit import CROP_XYXY, crop_bounds, load_capture_index
from .visual_image_embeddings import MEAN, STD, load_encoder, sha256, write_json


GROUPS = {'A': {'geometry': 'squash', 'pool': 'global', 'dimension': 512},
          'B': {'geometry': 'letterbox', 'pool': 'global', 'dimension': 512},
          'C': {'geometry': 'squash', 'pool': 'spatial2x2', 'dimension': 2048},
          'D': {'geometry': 'letterbox', 'pool': 'spatial2x2', 'dimension': 2048}}


def letterbox_geometry(width, height, side=224):
    """Round the shorter side and center padding; extra odd pad goes right/bottom."""
    if (not isinstance(width, (int, np.integer)) or not isinstance(height, (int, np.integer))
            or not isinstance(side, (int, np.integer)) or min(width, height, side) < 1):
        raise ValueError('positive integer crop dimensions and output side required')
    if width >= height:
        resized_width, resized_height = side, max(1, round(height * side / width))
    else:
        resized_width, resized_height = max(1, round(width * side / height)), side
    left, top = (side-resized_width)//2, (side-resized_height)//2
    return {'roi_width': int(width), 'roi_height': int(height), 'side': int(side),
            'resized_width': int(resized_width), 'resized_height': int(resized_height),
            'left': int(left), 'top': int(top),
            'right': int(side-resized_width-left), 'bottom': int(side-resized_height-top)}


def _normalize(image):
    pixels = np.asarray(image, dtype=np.float32) / 255.
    values = ((pixels-MEAN)/STD).transpose(2, 0, 1)
    return torch.from_numpy(np.ascontiguousarray(values))


def geometry_tensors(image):
    """Return actual normalized squash and mean-color-padded letterbox inputs."""
    rgb = image.convert('RGB')
    bounds = crop_bounds(*rgb.size)
    roi = rgb.crop(bounds)
    geometry = letterbox_geometry(*roi.size)
    squash = _normalize(roi.resize((224, 224), Image.Resampling.BILINEAR))
    resized = _normalize(roi.resize((geometry['resized_width'], geometry['resized_height']),
                                    Image.Resampling.BILINEAR))
    # Exactly zero after normalization equals floating-point ImageNet mean RGB.
    # No uint8 mean-color rounding is introduced in the padding pixels.
    letterbox = torch.zeros((3, 224, 224), dtype=torch.float32)
    y, x = geometry['top'], geometry['left']
    letterbox[:, y:y+geometry['resized_height'], x:x+geometry['resized_width']] = resized
    geometry.update(crop_bounds=list(bounds), source_width=rgb.width, source_height=rgb.height)
    return squash, letterbox, geometry


def pool_feature_map(features):
    """Summaries of one layer4 map, with channel-major C×H×W flattening.

    Adaptive pooling of a 7×7 feature map to 2×2 uses ranges [0:4] and [3:7]
    along each axis. Those cells overlap by one feature-map position; they
    are not disjoint physical image quadrants or segmented combustion regions.
    """
    if (features.ndim != 4 or tuple(features.shape[1:]) != (512, 7, 7)
            or features.shape[0] < 1 or not torch.isfinite(features).all()):
        raise ValueError('finite ResNet18 layer4 maps (N,512,7,7) required')
    return F.adaptive_avg_pool2d(features, (1, 1)).flatten(1), F.adaptive_avg_pool2d(features, (2, 2)).flatten(1)


def _verify_source(record):
    path = Path(record['path'])
    digest = sha256(path)
    if digest != record['source_sha256']:
        raise ValueError('source image differs from original manifest: '+str(path))
    return {'capture_index': record['capture_index'], 'path': str(path),
            'sha256': digest, 'bytes': path.stat().st_size}


def _prepare(record):
    raw = Path(record['path']).read_bytes()
    if hashlib.sha256(raw).hexdigest() != record['source_sha256']:
        raise ValueError('source image changed after pre-extraction hash check')
    with Image.open(io.BytesIO(raw)) as image:
        if image.size != (record['source_width'], record['source_height']):
            raise ValueError('decoded source size differs from original manifest')
        return geometry_tensors(image)


def _verify_reference(reference_path, records, mapping):
    reference_path = Path(reference_path).resolve()
    manifest_path = reference_path.with_name('encoder_manifest.json')
    protocol_path = reference_path.with_name('encoder_protocol.json')
    manifest, protocol = [json.loads(p.read_text()) for p in (manifest_path, protocol_path)]
    if (manifest['status'] != 'completed' or manifest['embeddings_sha256'] != sha256(reference_path)
            or manifest['protocol_sha256'] != sha256(protocol_path)):
        raise ValueError('prior completed encoder reference is not intact')
    with np.load(reference_path, allow_pickle=False) as saved:
        if not np.array_equal(saved['sample_capture_index'], mapping):
            raise ValueError('capture mapping differs from original RGB extraction')
        if not np.array_equal(saved['capture_time_ns'], np.asarray([r['time_ns'] for r in records])):
            raise ValueError('capture order differs from original RGB extraction')
        rgb = saved['rgb'].copy()
    if rgb.shape != (len(records), 512) or not np.isfinite(rgb).all():
        raise ValueError('original RGB archive has invalid dimensions or values')
    return rgb, protocol, [reference_path, manifest_path, protocol_path]


def _input_examples(records, output):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    choices = sorted({0, len(records)//2, len(records)-1})
    fig, axes = plt.subplots(2, len(choices), figsize=(9, 6), squeeze=False,
                             constrained_layout=True)
    identities = []
    for col, idx in enumerate(choices):
        views = _prepare(records[idx])
        for row, name in enumerate(('Squash: A/C', 'Aspect preserved + padding: B/D')):
            pixels = np.clip(views[row].numpy().transpose(1, 2, 0)*STD+MEAN, 0, 1)
            axes[row, col].imshow(pixels)
            axes[row, col].set_title(name+'\n'+records[idx]['timestamp'], fontsize=8)
            axes[row, col].axis('off')
        identities.append({'capture_index': idx, 'timestamp': records[idx]['timestamp'],
                           'source_sha256': records[idx]['source_sha256'], 'geometry': views[2]})
    fig.suptitle('Actual model inputs from recorded flame images', fontsize=12)
    fig.savefig(output/'encoder_input_examples.png', dpi=150)
    plt.close(fig)
    return identities


def extract_embeddings(dataset_path, manifest_path, weight_path, reference_embeddings_path,
                       output_dir, batch_size=16):
    import torchvision
    if batch_size != 16:
        raise ValueError('this matched protocol fixes batch size16 to the original extraction')
    torch.set_num_threads(2)
    torch.use_deterministic_algorithms(True)
    output = Path(output_dir).resolve()
    output.mkdir(parents=True, exist_ok=True)
    if (output/'encoder_protocol.json').exists() or (output/'embeddings.npz').exists():
        raise FileExistsError('encoder artifacts are immutable; use a new output directory')
    records, mapping = load_capture_index(dataset_path, manifest_path)
    original, previous, reference_files = _verify_reference(reference_embeddings_path, records, mapping)
    if previous['batch_size'] != batch_size or previous['threads'] != 2:
        raise ValueError('original batch/thread configuration differs')
    weight_hash = sha256(weight_path)
    if weight_hash != previous['weights_sha256']:
        raise ValueError('weights differ from original frozen RGB encoder')
    with ThreadPoolExecutor(max_workers=2) as pool:
        raw_checks = list(pool.map(_verify_source, records))
    source_file = output/'source_records.json'
    write_json(source_file, {'captures': records, 'pre_extraction_hash_checks': raw_checks})
    geometry = geometry_tensors(Image.new('RGB', (records[0]['source_width'], records[0]['source_height'])))[2]
    paths = [Path(dataset_path), Path(manifest_path), Path(weight_path), *reference_files]
    code_paths = [Path(__file__), Path(__file__).with_name('visual_image_embeddings.py'),
                  Path(__file__).with_name('visual_image_audit.py')]
    protocol = {'schema_version': 1, 'frozen_before_extraction_unix': time.time(),
        'scope': 'target-free frozen geometry by pooling factorial; no process targets or model selection',
        'groups': GROUPS, 'encoder': 'ResNet18 IMAGENET1K_V1; same layer4 feature map for both pools',
        'weights_sha256': weight_hash, 'device': 'cpu', 'threads': 2, 'batch_size': batch_size,
        'torch_version': torch.__version__, 'torchvision_version': torchvision.__version__,
        'crop_normalized_xyxy': list(CROP_XYXY), 'normalization_mean': MEAN.tolist(), 'normalization_std': STD.tolist(),
        'squash': 'PIL bilinear directly to224×224, identical to prior original RGB extraction',
        'letterbox': 'PIL bilinear, longest side224, shorter side Python round, centered padding with odd extra pixel right/bottom, exact normalized zeros outside ROI',
        'padding_color': 'ImageNet floating-point channel means; not black or an observed flame region',
        'spatial_pooling': 'torch adaptive_avg_pool2d(layer4, (2,2)); 7×7 supports [0:4] and [3:7], overlapping one map position; channel-major512×2×2 flatten',
        'geometry_for_first_capture': geometry,
        'captures': len(records), 'samples': len(mapping), 'augmentation': None,
        'source_records_sha256': sha256(source_file),
        'source_input_hashes': {str(p.resolve()): sha256(p) for p in paths},
        'code_hashes': {str(p.resolve()): sha256(p) for p in code_paths},
        'A_reference_requirement': 'All6198×512 original RGB coordinates must match exactly; no tolerance fallback',
    }
    write_json(output/'encoder_protocol.json', protocol)
    encoder = load_encoder(weight_path)
    trunk = torch.nn.Sequential(*list(encoder.children())[:-2]).eval().requires_grad_(False)
    arrays = {name: np.empty((len(records), group['dimension']), dtype=np.float32)
              for name, group in GROUPS.items()}
    started = time.monotonic()
    geometries = []
    with ThreadPoolExecutor(max_workers=2) as pool, torch.inference_mode():
        for begin in range(0, len(records), batch_size):
            end = min(begin+batch_size, len(records))
            prepared = list(pool.map(_prepare, records[begin:end]))
            geometries.extend(row[2] for row in prepared)
            for view, global_name, spatial_name in ((0,'A','C'),(1,'B','D')):
                batch = torch.stack([row[view] for row in prepared])
                features = trunk(batch)
                global_feature, spatial = pool_feature_map(features)
                arrays[global_name][begin:end] = global_feature.cpu().numpy()
                arrays[spatial_name][begin:end] = spatial.cpu().numpy()
            if not np.array_equal(arrays['A'][begin:end], original[begin:end]):
                difference = float(np.max(np.abs(arrays['A'][begin:end]-original[begin:end])))
                write_json(output/'A_reference_failure.json', {'begin':begin,'end':end,'max_difference':difference})
                raise ValueError('A does not exactly reproduce original RGB features; no downstream processing permitted')
            if begin==0 or end==len(records) or (begin//batch_size)%20==0:
                progress={'captures_done':end,'captures_total':len(records),'elapsed_seconds':time.monotonic()-started}
                write_json(output/'encoder_progress.json',progress);print(json.dumps(progress),flush=True)
    for array in arrays.values():
        if not np.isfinite(array).all(): raise FloatingPointError('nonfinite image representation')
    destination=output/'embeddings.npz'
    np.savez_compressed(destination, capture_time_ns=np.asarray([r['time_ns'] for r in records],dtype=np.int64),
                        sample_capture_index=mapping, **arrays)
    write_json(output/'geometry_records.json', geometries)
    audits=[]
    with torch.inference_mode():
        for begin in sorted({0,(len(records)//2//batch_size)*batch_size,((len(records)-1)//batch_size)*batch_size}):
            end=min(begin+batch_size,len(records));prepared=[_prepare(r) for r in records[begin:end]]
            for view,global_name,spatial_name in ((0,'A','C'),(1,'B','D')):
                values=pool_feature_map(trunk(torch.stack([row[view] for row in prepared])))
                for name,value in zip((global_name,spatial_name),values):
                    value=value.cpu().numpy();expected=arrays[name][begin:end]
                    exact=bool(np.array_equal(value,expected))
                    audits.append({'group':name,'begin':begin,'end':end,'exact':exact,
                                   'max_abs_difference':float(np.max(np.abs(value-expected)))})
                    if not exact: raise ValueError('representative batch replay is not exact')
    example_records=_input_examples(records,output)
    for path, expected in protocol['source_input_hashes'].items():
        if sha256(path)!=expected: raise ValueError('frozen input changed during extraction')
    for path, expected in protocol['code_hashes'].items():
        if sha256(path)!=expected: raise ValueError('encoder code changed during extraction')
    result={'status':'completed','protocol_sha256':sha256(output/'encoder_protocol.json'),
        'embeddings_sha256':sha256(destination),'weights_sha256':weight_hash,
        'source_files_checked':len(records),'captures':len(records),'samples':len(mapping),
        'group_shapes':{name:list(value.shape) for name,value in arrays.items()},
        'A_reference_exact':bool(np.array_equal(arrays['A'],original)),
        'A_reference_max_difference':float(np.max(np.abs(arrays['A']-original))),
        'A_reference_coordinates':int(original.size),'batch_replay':audits,
        'elapsed_seconds':time.monotonic()-started,'trained_on_project_targets':False,
        'input_examples':example_records,'input_examples_sha256':sha256(output/'encoder_input_examples.png'),
        'geometry_records_sha256':sha256(output/'geometry_records.json')}
    write_json(output/'encoder_manifest.json',result)
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dataset',required=True);p.add_argument('--image-manifest',required=True)
    p.add_argument('--weights',required=True);p.add_argument('--reference',required=True)
    p.add_argument('--output',required=True);p.add_argument('--batch-size',type=int,default=16)
    a=p.parse_args()
    extract_embeddings(a.dataset,a.image_manifest,a.weights,a.reference,a.output,a.batch_size)


if __name__=='__main__': main()
