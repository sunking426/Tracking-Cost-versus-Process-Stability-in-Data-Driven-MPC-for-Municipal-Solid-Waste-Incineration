"""Four fixed RGB geometry/pooling variants on observed outcomes and one-step CVs.

All choices use training/validation only. The previously inspected test period
is exploratory, and these supervised tasks identify no counterfactual control
benefit. The original numerical predictor and manuscript are left unchanged.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import shutil

import numpy as np
from threadpoolctl import threadpool_limits

from .data import load_data
from .numeric_baselines import (_check_data, fit_linear_candidates, linear_increment,
                                numeric_features, sha256, write_json)
from .rgb_control_diagnostic_models import (fit_candidates, load_model, predict_proba,
                                            save_model)
from .ridge_rgb_residual_data import _visual_inputs
from .ridge_validation import resolve_predictor
from .visual_representation_probe import fit_capture_pca

TASKS = ('thermal_change', 'action_change')
SPLITS = ('train', 'val', 'test')
GEOMETRIES = ('A', 'B', 'C', 'D')
METHODS = ('numeric', 'quality', *GEOMETRIES)
C_GRID = [.001, .01, .1, 1, 10]
ALPHA_GRID = [.001, .01, .1, 1, 10, 100, 1000, 10000]
SNAPSHOT_NAMES = (
    'rgb_geometry_study.py', 'rgb_geometry_embeddings.py', 'rgb_geometry_report.py',
    'rgb_control_diagnostic_data.py', 'rgb_control_diagnostic_models.py',
    'rgb_control_diagnostic_report.py', 'numeric_baselines_report.py',
    'ridge_validation_report.py', 'visual_diagnostics_statistics.py',
    'ridge_rgb_residual_data.py', 'ridge_validation.py', 'ridge_dynamics.py',
    'numeric_baselines.py', 'visual_representation_probe.py', 'data.py',
)


def archive(path):
    with np.load(path, allow_pickle=False) as source:
        return {key: source[key] for key in source.files}


def verify(hashes, root=None):
    for name, expected in hashes.items():
        path = Path(name) if root is None else Path(root) / name
        if sha256(path) != expected:
            raise ValueError('frozen input changed: ' + str(path))


def paths(config_file):
    path = Path(config_file).resolve()
    cfg = json.loads(path.read_text())
    fixed = {'pca_components':32, 'C_grid':C_GRID, 'alpha_grid':ALPHA_GRID,
             'alarm_quantile':.9, 'primary_task':'thermal_change',
             'primary_metric':'average_precision', 'primary_comparator':'quality',
             'geometry_tie_tolerance':1e-12}
    if any(cfg.get(k) != v for k,v in fixed.items()):
        raise ValueError('configuration differs from fixed four-geometry protocol')
    if int(cfg['threads']) < 1:
        raise ValueError('threads must be positive')
    return cfg, path.parent, path.parent / cfg['output_dir']


def select_geometry(rows, metric):
    """Validation records only; fixed A/B/C/D tie order, tolerance 1e-12."""
    geometry_rows = [row for row in rows if row['method'] in GEOMETRIES]
    by_name = {row['method']:row for row in geometry_rows}
    if set(by_name) != set(GEOMETRIES) or len(geometry_rows) != len(GEOMETRIES):
        raise ValueError('geometry selection requires exactly A, B, C and D')
    scores = {key:float(by_name[key]['selected'][metric]) for key in GEOMETRIES}
    if not all(np.isfinite(v) for v in scores.values()):
        raise ValueError('geometry validation scores must be finite')
    best = min(scores.values())
    return next(key for key in GEOMETRIES if scores[key] <= best + 1e-12)


def assert_reuse_equivalence(current, previous, method, old_method):
    """A frozen classifier is reusable only with identical rows, labels and X."""
    for split in SPLITS:
        for suffix in ('indices', 'time_ns', *TASKS):
            key = split + '_' + suffix
            if not np.array_equal(current[key], previous[key]):
                raise ValueError('reuse rows/labels differ: ' + key)
        if not np.array_equal(current[split+'_'+method], previous[split+'_'+old_method]):
            raise ValueError('reuse design differs: ' + split + '_' + method)
    return {'all_splits_exact':True, 'old_method':old_method,
            'rows_labels_and_design':'np.array_equal across train, validation and test'}


def assemble_classification(previous, capture_scores):
    """Replace only the visual tail; stale features retain current quality."""
    result = {k:v for k,v in previous.items()
              if not any(k.endswith('_'+s) for s in ('rgb','stale'))}
    for split in SPLITS:
        quality = previous[split+'_quality']
        for geometry in GEOMETRIES:
            scores = np.asarray(capture_scores[geometry], dtype=np.float64)
            if scores.ndim != 2 or scores.shape[1] != 32 or not np.isfinite(scores).all():
                raise ValueError('each geometry requires finite 32-dimensional capture PCA')
            current = previous[split+'_current_capture_index']
            stale = previous[split+'_stale_capture_index']
            result[split+'_'+geometry] = np.concatenate((quality, scores[current]), axis=1)
            result[split+'_'+geometry+'_stale'] = np.concatenate((quality, scores[stale]), axis=1)
    return result


def _load_previous(project, cfg):
    prior = project / cfg['classification_study']
    complete = json.loads((prior/'completed.json').read_text())
    frozen = json.loads((prior/'selection_frozen.json').read_text())
    if complete.get('status') != 'complete' or frozen.get('status') != 'complete':
        raise ValueError('inherited classification study is incomplete')
    verify(frozen['files'], prior)
    inputs = json.loads((prior/'input_hashes.json').read_text()); verify(inputs)
    old_config = json.loads((prior/'config.json').read_text())
    if any(old_config[key] != cfg[key] for key in ('C_grid','alarm_quantile')):
        raise ValueError('inherited classifier tuning protocol differs')
    if complete['source_selection_sha256'] != sha256(prior/'selection_frozen.json'):
        raise ValueError('inherited classification completion does not bind selection')
    selected = json.loads((prior/'selection.json').read_text())
    files = [prior/name for name in ('completed.json','selection.json','selection_frozen.json',
             'prepare_frozen.json','prepared.npz','preparation.json','input_hashes.json')]
    files.extend(prior/r['model_path'] for r in selected['models'])
    return prior, archive(prior/'prepared.npz'), selected, files


def _encoder_inputs(out, old_embeddings):
    folder = out/'encoder'
    manifest_path, protocol_path = folder/'encoder_manifest.json', folder/'encoder_protocol.json'
    manifest = json.loads(manifest_path.read_text())
    protocol = json.loads(protocol_path.read_text())
    if (manifest.get('status') != 'completed' or manifest.get('A_reference_exact') is not True
            or manifest.get('A_reference_max_difference') != 0.0):
        raise ValueError('encoder incomplete or reference A not exact')
    verify({'embeddings.npz':manifest['embeddings_sha256'],
            'encoder_protocol.json':manifest['protocol_sha256']}, folder)
    verify(protocol['source_input_hashes'])
    verify(protocol['code_hashes'])
    embeddings = archive(folder/'embeddings.npz')
    for name in ('capture_time_ns','sample_capture_index'):
        if not np.array_equal(embeddings[name], old_embeddings[name]):
            raise ValueError('encoder capture mapping differs: '+name)
    if not np.array_equal(embeddings['A'], old_embeddings['rgb']):
        raise ValueError('A must equal the original global RGB embedding exactly')
    count = len(embeddings['capture_time_ns'])
    for key, width in zip(GEOMETRIES,(512,512,2048,2048)):
        values = embeddings[key]
        if values.shape != (count,width) or not np.isfinite(values).all():
            raise ValueError('invalid geometry embedding: '+key)
    return embeddings, [manifest_path,protocol_path,folder/'embeddings.npz']


def prepare(config_file):
    cfg, project, out = paths(config_file)
    out.mkdir(parents=True, exist_ok=True)
    if any(p.name != 'encoder' for p in out.iterdir()):
        raise FileExistsError('prepared study is immutable; only an existing encoder directory is allowed')
    prior, previous, _, prior_paths = _load_previous(project,cfg)
    source = project / cfg['source_run'] / 'data'
    data, stats, source_manifest = load_data(source); _check_data(data,stats)
    input_paths = [source/name for name in ('dataset.npz','stats.json','manifest.json')]
    selected, checkpoint, ridge_study, ridge = resolve_predictor(project,cfg['current_predictor'])
    verify(json.loads((ridge_study/'selection_frozen.json').read_text())['files'],ridge_study)
    ridge_protocol = json.loads((ridge_study/'protocol.json').read_text())
    if ridge_protocol['source_manifest'] != source_manifest:
        raise ValueError('numeric regression baseline source data identity differs')
    if (float(ridge.weights['alpha']) != 100.0 or
            not np.array_equal(ridge.weights['delta_scale'], np.asarray(stats['delta_scale']))):
        raise ValueError('numeric regression baseline must be frozen Ridge100 with canonical scales')
    visual = project/cfg['visual_study']
    x226, _, mapping, _, _, _, visual_paths, visual_info = _visual_inputs(
        data,visual,project/cfg['descriptor_study'],input_paths)
    old_embeddings = archive(visual/'embeddings.npz')
    embeddings, encoder_paths = _encoder_inputs(out,old_embeddings)
    all_paths = [*input_paths,*prior_paths,*visual_paths,*encoder_paths,project/cfg['current_predictor'],
                 checkpoint,ridge_study/'selection.json',ridge_study/'selection_frozen.json',
                 ridge_study/'selection_candidates.csv',ridge_study/'protocol.json']
    hashes = {str(p.resolve()):sha256(p) for p in all_paths}
    unique_training = np.unique(mapping[np.asarray(data['train_idx'])])
    if len(unique_training) != 4339 or len(embeddings['capture_time_ns']) != 6198:
        raise ValueError('this protocol requires original 4339 training / 6198 total captures')
    if not np.array_equal(x226[:,:178],numeric_features(data)):
        raise ValueError('inherited regression numerical design changed')
    capture_scores, pca_records = {}, {}
    (out/'pca').mkdir()
    for geometry in GEOMETRIES:
        dest = out/'pca'/f'{geometry}.npz'
        if geometry == 'A':
            origin = visual/'probe/pca_rgb.npz'; fitted = archive(origin)
            shutil.copyfile(origin,dest)
            scores = (embeddings['A'].astype(np.float64)-fitted['mean']) @ fitted['components'].T
            # Exact saved features are required for classifier reuse, not rounded equality.
            if not np.array_equal(scores[mapping],x226[:,194:]):
                raise ValueError('A PCA replay is not exactly the original RGB design')
        else:
            fitted,scores = fit_capture_pca(embeddings[geometry],mapping,data['train_idx'],
                                           components=cfg['pca_components'])
            np.savez_compressed(dest,**fitted,capture_time_ns=embeddings['capture_time_ns'])
        if not np.array_equal(fitted['train_capture_indices'],unique_training):
            raise ValueError('PCA fitting capture scope differs from unique outer training')
        capture_scores[geometry] = scores
        pca_records[geometry] = {'path':str(dest.relative_to(out)), 'reused':geometry=='A',
            'input_dimensions':int(embeddings[geometry].shape[1]),'output_dimensions':32,
            'train_unique_captures':len(unique_training),
            'explained_variance_ratio':fitted['explained_variance_ratio'].tolist(),
            'explained_variance_fraction':float(np.sum(fitted['explained_variance_ratio'])),
            'sha256':sha256(dest)}
        print('Prepared PCA',geometry,pca_records[geometry]['explained_variance_fraction'],flush=True)
    classification = assemble_classification(previous,capture_scores)
    reuse = {method:assert_reuse_equivalence(classification,previous,method,old)
             for method,old in (('numeric','numeric'),('quality','quality'),('A','rgb'),('A_stale','stale'))}
    regression = {'numeric':x226[:,:178], 'quality':x226[:,:194],
                  'z_prev':np.asarray(data['z_prev'],dtype=np.float64),
                  'z_target':np.asarray(data['z_target'],dtype=np.float64),
                  'time_ns':data['time_ns'], 'delta_scale':np.asarray(stats['delta_scale'])}
    for geometry in GEOMETRIES:
        regression[geometry] = np.concatenate((regression['quality'],capture_scores[geometry][mapping]),axis=1)
    for split, class_n, reg_n in zip(SPLITS,(43135,9136,9120),(43406,9228,9226)):
        indices = np.asarray(data[split+'_idx'])
        regression[split+'_indices'] = indices
        if len(indices)!=reg_n or len(classification[split+'_indices'])!=class_n:
            raise ValueError('original common partition counts changed')
        if not np.array_equal(classification[split+'_current_capture_index'],mapping[classification[split+'_indices']]):
            raise ValueError('classification capture mapping differs from original rows')
    np.savez_compressed(out/'classification_prepared.npz',**classification)
    np.savez_compressed(out/'regression_prepared.npz',**regression)
    shutil.copyfile(source/'stats.json',out/'stats.json')
    write_json(out/'config.json',cfg)
    protocol = {
        'schema_version':1, 'scope':'Observed thermal/operation-label classification and one-step nine-CV prediction. No simulation, retrieval, RL training, or controller evaluation.',
        'geometry':{'A':'Squash224, global average pool512','B':'Letterbox224, global average pool512',
                    'C':'Squash224, spatial2x2 pool2048','D':'Letterbox224, spatial2x2 pool2048'},
        'encoder':'Identical frozen ResNet18 weights/ROI/normalization; encoder protocol specifies geometry and exact reference replay.',
        'pca':'32 components for every group; full-SVD PCA on 4339 unique ORIGINAL outer-training captures, no labels; A reuses exactly equal saved transform.',
        'classification':'Same original43135/9136/9120 origins, tasks, training thresholds and source separation. Numeric219; quality235; geometry267.',
        'classification_selection':'Each L2 logistic C chosen by validation log loss; then A/B/C/D geometry chosen per task by validation log loss. Geometry ties within1e-12 prefer A,B,C,D. All frozen before test scoring.',
        'stale':'For each task only its validation-selected geometry is shifted to prior60–70min capture; current numeric219+timing4+quality12 remain identical. Fit its C on validation; never change chosen geometry using stale results.',
        'baseline_reuse':'Old numeric/quality/A/stale-A classifiers only after exact all-split rows, labels and design equality. Model bytes copied with provenance.',
        'regression':'Same original43406/9228/9226 rows; nine physical CV increments, canonical delta_scale; numeric178 frozen Ridge100; quality194; geometry226. Five new direct Ridge fits with fixed alpha grid and validation NMSE selection.',
        'regression_geometry_selection':'Auxiliary A/B/C/D chosen by validation normalized MSE, ties within1e-12 prefer A,B,C,D; descriptive only.',
        'primary_endpoint':'Test thermal_change AP of validation-selected geometry minus quality; all four groups and prespecified factor contrasts reported.',
        'alarm_threshold':'Each classifier uses its frozen validation90th score percentile.',
        'limits':['Previously inspected test period; exploratory evidence, not a new blind holdout.',
                  'Recorded large operation changes are neither optimal actions nor verified manual interventions.',
                  'Thermal movement is not a safety label and observed outcomes do not identify alternative-action effects.',
                  'Different feature geometry is compared with matched PCA width; equal retained variance is not guaranteed.',
                  'Manuscript, release package and current numerical predictor remain unchanged.']}
    write_json(out/'protocol.json',protocol)
    write_json(out/'input_hashes.json',hashes)
    write_json(out/'preparation.json',{'status':'complete','schema_version':1,'pca':pca_records,
        'classifier_reuse_checks':reuse,'numeric_predictor':selected,
        'numeric_checkpoint':str(checkpoint.resolve()),'visual':visual_info,
        'classification_counts':{s:len(classification[s+'_indices']) for s in SPLITS},
        'regression_counts':{s:len(regression[s+'_indices']) for s in SPLITS},
        'label_thresholds':json.loads((prior/'preparation.json').read_text())['thresholds']})
    names = ['classification_prepared.npz','regression_prepared.npz','stats.json','config.json',
             'protocol.json','input_hashes.json','preparation.json',*[f'pca/{g}.npz' for g in GEOMETRIES]]
    verify(hashes)
    write_json(out/'prepare_frozen.json',{'status':'complete','files':{name:sha256(out/name) for name in names}})
    print('Four-geometry inputs/PCA/protocol frozen; no validation or test scoring performed.',flush=True)
    return out


def load_prepared(config_file):
    cfg,project,out = paths(config_file)
    if cfg != json.loads((out/'config.json').read_text()):
        raise ValueError('configuration changed after preparation')
    frozen = json.loads((out/'prepare_frozen.json').read_text())
    if frozen.get('status')!='complete': raise ValueError('preparation incomplete')
    verify(frozen['files'],out); verify(json.loads((out/'input_hashes.json').read_text()))
    data,_,_ = load_data(project/cfg['source_run']/'data')
    return cfg,project,out,data,archive(out/'classification_prepared.npz'),archive(out/'regression_prepared.npz')


def _classifier_row(task,method,weights,candidates,chosen,path,*,reused=False,geometry=None,source=None):
    return {'task':task,'method':method,'model_path':path,'selected':chosen,'candidates':candidates,
            'reused':reused,'geometry':geometry,'alarm_threshold':float(weights['threshold']),
            'source_model':source}


def fit(config_file):
    cfg,project,out,data,classification,regression = load_prepared(config_file)
    if (out/'selection.json').exists() or (out/'models').exists():
        raise FileExistsError('model selection already started; artifacts are immutable')
    prior,previous,prior_selection,_ = _load_previous(project,cfg)
    old_rows = {(r['task'],r['variant']):r for r in prior_selection['models']}
    (out/'models').mkdir()
    class_rows,reg_rows,selected_geometry = [],[],{}
    for task in TASKS:
        task_rows = []
        for method in METHODS:
            name = f'models/{task}_{method}.npz'; origin = None
            old = {'numeric':'numeric','quality':'quality','A':'rgb'}.get(method)
            if old is not None:
                assert_reuse_equivalence(classification,previous,method,old)
                row = old_rows[(task,old)]; origin=prior/row['model_path']
                weights=load_model(origin); candidates=row['candidates']; chosen=row['selected']
                shutil.copyfile(origin,out/name)
            else:
                weights,candidates,chosen = fit_candidates(classification['train_'+method],classification['train_'+task],
                    classification['val_'+method],classification['val_'+task],cfg['C_grid'],alarm_quantile=cfg['alarm_quantile'])
                save_model(out/name,weights)
            task_rows.append(_classifier_row(task,method,weights,candidates,chosen,name,
                reused=origin is not None,geometry=method if method in GEOMETRIES else None,
                source=str(origin.resolve()) if origin else None))
            print('Classifier',task,method,chosen['val_log_loss'],'reused' if origin else 'fitted',flush=True)
        geometry=select_geometry(task_rows,'val_log_loss'); selected_geometry[task]=geometry
        # Geometry is determined above, before fitting the matched stale comparator.
        method='selected_stale'; design=geometry+'_stale'; name=f'models/{task}_{method}.npz'; origin=None
        if geometry=='A':
            assert_reuse_equivalence(classification,previous,design,'stale')
            row=old_rows[(task,'stale')]; origin=prior/row['model_path']
            weights=load_model(origin); candidates=row['candidates']; chosen=row['selected']
            shutil.copyfile(origin,out/name)
        else:
            weights,candidates,chosen=fit_candidates(classification['train_'+design],classification['train_'+task],
                classification['val_'+design],classification['val_'+task],cfg['C_grid'],alarm_quantile=cfg['alarm_quantile'])
            save_model(out/name,weights)
        task_rows.append(_classifier_row(task,method,weights,candidates,chosen,name,reused=origin is not None,
            geometry=geometry,source=str(origin.resolve()) if origin else None))
        class_rows.extend(task_rows)
        print('Validation-selected geometry',task,geometry,'matched stale',chosen['val_log_loss'],flush=True)
    selected,checkpoint,ridge_study,ridge=resolve_predictor(project,cfg['current_predictor'])
    if not np.array_equal(regression['numeric'],numeric_features(data)):
        raise ValueError('frozen numeric regression design mismatch')
    source_rows=json.loads((ridge_study/'selection.json').read_text())['models']
    source_row=next(r for r in source_rows if r['id']=='ridge')
    for method in METHODS:
        name=f'models/regression_{method}.npz'; origin=None
        if method=='numeric':
            origin=checkpoint; weights=ridge.weights
            if not np.array_equal(weights['delta_scale'],regression['delta_scale']):
                raise ValueError('frozen numeric regression scales mismatch')
            shutil.copyfile(origin,out/name)
            with (ridge_study/'selection_candidates.csv').open(newline='') as stream:
                candidates=[{'kind':r['kind'],'alpha':float(r['alpha']),
                             'val_normalized_mse':float(r['val_normalized_mse'])}
                            for r in csv.DictReader(stream) if r['model_id']=='ridge']
            chosen={'kind':source_row['selected_kind'],'alpha':float(source_row['selected_alpha']),
                    'val_normalized_mse':float(source_row['val_normalized_mse'])}
        else:
            weights,candidates,chosen=fit_linear_candidates(regression[method],regression['z_target']-regression['z_prev'],
                regression['z_prev'],regression['z_target'],regression['train_indices'],regression['val_indices'],
                regression['delta_scale'],cfg['alpha_grid'])
            np.savez_compressed(out/name,**weights)
        reg_rows.append({'method':method,'model_path':name,'selected':chosen,'candidates':candidates,
                         'reused':origin is not None,'source_model':str(origin.resolve()) if origin else None})
        print('Regression',method,chosen,'reused' if origin else 'fitted',flush=True)
    selection={'status':'complete','classification':class_rows,'regression':reg_rows,
               'selected_geometry':selected_geometry,
               'selected_regression_geometry':select_geometry(reg_rows,'val_normalized_mse'),
               'prepare_frozen_sha256':sha256(out/'prepare_frozen.json'),
               'selection_rule':'validation only; test not scored; geometry ties1e-12 prefer A,B,C,D'}
    write_json(out/'selection.json',selection)
    frozen=dict(json.loads((out/'prepare_frozen.json').read_text())['files'])
    for name in ['prepare_frozen.json','selection.json',*[r['model_path'] for r in class_rows+reg_rows]]:
        frozen[name]=sha256(out/name)
    snapshot=out/'code_snapshot'; snapshot.mkdir()
    source_hashes={}
    for name in SNAPSHOT_NAMES:
        source=project/'mswi_experiments'/name
        shutil.copyfile(source,snapshot/name)
        frozen['code_snapshot/'+name]=sha256(snapshot/name); source_hashes[str(source)]=sha256(source)
    verify(json.loads((out/'input_hashes.json').read_text()))
    write_json(out/'selection_frozen.json',{'status':'complete','files':frozen,'source_code_hashes':source_hashes})
    print('All14 classifiers,6 regressors, selected geometries and code frozen before testing.',flush=True)
    return out


def predict(config_file):
    cfg,project,out,_,classification,regression=load_prepared(config_file)
    if (out/'predictions_manifest.json').exists(): raise FileExistsError('predictions already completed')
    frozen=json.loads((out/'selection_frozen.json').read_text())
    if frozen.get('status')!='complete': raise ValueError('selection incomplete')
    verify(frozen['files'],out); verify(frozen['source_code_hashes'])
    selection=json.loads((out/'selection.json').read_text()); files=[]
    for row in selection['classification']:
        task,method=row['task'],row['method']; weights=load_model(out/row['model_path'])
        design=row['geometry']+'_stale' if method=='selected_stale' else method
        if method=='selected_stale' and row['geometry']!=selection['selected_geometry'][task]:
            raise ValueError('stale geometry differs from frozen task choice')
        for split in ('val','test'):
            probability=predict_proba(weights,classification[split+'_'+design]); threshold=float(weights['threshold'])
            name=f'classification/{split}/{task}_{method}.npz'; path=out/name
            path.parent.mkdir(parents=True,exist_ok=True)
            if path.exists(): raise FileExistsError(path)
            np.savez_compressed(path,indices=classification[split+'_indices'],time_ns=classification[split+'_time_ns'],
                y=classification[split+'_'+task],probability=probability,
                alarm=(probability>=threshold).astype(np.int8),threshold=np.asarray(threshold))
            files.append({'kind':'classification','split':split,'task':task,'method':method,'path':name,'sha256':sha256(path)})
    for row in selection['regression']:
        method=row['method']; weights=archive(out/row['model_path'])
        for split in ('val','test'):
            indices=regression[split+'_indices']
            pred=regression['z_prev'][indices]+linear_increment(weights,regression[method][indices])
            name=f'regression/{split}/{method}.npz'; path=out/name; path.parent.mkdir(parents=True,exist_ok=True)
            if path.exists(): raise FileExistsError(path)
            np.savez_compressed(path,indices=indices,time_ns=regression['time_ns'][indices],
                truth_cv=regression['z_target'][indices],pred_cv=pred)
            files.append({'kind':'regression','split':split,'method':method,'path':name,'sha256':sha256(path)})
    verify(frozen['files'],out); verify(frozen['source_code_hashes'])
    write_json(out/'predictions_manifest.json',{'status':'complete','files':files,
        'selection_sha256':sha256(out/'selection.json'),'selection_frozen_sha256':sha256(out/'selection_frozen.json')})
    print('Saved28 classification and12 regression validation/test archives.',flush=True)
    return out


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage',choices=('prepare','fit','predict','all'))
    parser.add_argument('--config',default='rgb_geometry_20261106.json')
    args=parser.parse_args(); cfg,_,_=paths(args.config)
    with threadpool_limits(limits=cfg['threads']):
        for stage in ('prepare','fit','predict') if args.stage=='all' else (args.stage,):
            globals()[stage](args.config)


if __name__=='__main__': main()
