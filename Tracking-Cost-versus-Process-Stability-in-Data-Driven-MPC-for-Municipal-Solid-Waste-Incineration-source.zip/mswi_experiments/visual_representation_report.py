"""Validate and visualize completed frozen-encoder predictive diagnostics.

Only saved results and paired predictions are consumed. This module neither
fits models nor selects favorable outcomes, and does not edit the manuscript.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

import numpy as np

from .visual_diagnostics_report import _pyplot, _save_figure, _style_axis
from .visual_diagnostics_statistics import CONTROL_NAMES, DAY_NS
from .visual_representation_probe import METHODS, HORIZONS


QUANTITIES_ZH = ("炉膛温度", "负压", "蒸汽流量", "氧浓度")
UNITS = ("°C", "Pa", "t/h", "vol%")
COLORS = {"rgb32": "#1f77b4", "gray32": "#ff7f0e", "old52": "#2ca02c",
          "quality": "#777777", "null_rgb32": "#555555"}
FIVE_MINUTE_ROWS = (
    ("old52", "timing", "原52维描述符 vs 采集时序"),
    ("quality", "timing", "质量/颜色统计 vs 采集时序"),
    ("rgb32", "quality", "RGB编码 vs 质量/颜色统计"),
    ("gray32", "quality", "灰度编码 vs 质量/颜色统计"),
    ("null_rgb32", "quality", "打乱RGB编码 vs 质量/颜色统计"),
    ("rgb32", "null_rgb32", "RGB编码 vs 打乱RGB编码"),
)


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+"\n")


def _csv(path, rows):
    if not rows:
        raise ValueError("Cannot write an empty representation result table")
    with Path(path).open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)


def _source(path, root, sources):
    sources[Path(path).relative_to(root).as_posix()] = _sha(path)


def load_completed_probe(study_dir):
    """Check all 21 test archives and comparison means before plotting."""
    root = Path(study_dir).resolve(); probe = root/"probe"
    files = {name: probe/name for name in ("results.json", "protocol.json", "completed.json", "artifact_hashes.json")}
    content = {name: json.loads(path.read_text()) for name,path in files.items()}
    result, protocol, complete, hashes = (content[name] for name in files)
    if (result["status"] != "completed" or complete["status"] != "completed"
            or complete["fits"] != len(HORIZONS)*len(METHODS)
            or complete["results_sha256"] != _sha(files["results.json"])
            or complete["protocol_sha256"] != _sha(files["protocol.json"])
            or complete["artifact_hashes_sha256"] != _sha(files["artifact_hashes.json"])
            or result["protocol"] != protocol):
        raise ValueError("Representation probe is incomplete or disagrees with its completion record")
    if (protocol["methods"] != list(METHODS) or protocol["horizons_minutes"] != list(HORIZONS)
            or protocol["target_names"] != list(CONTROL_NAMES)
            or set(result["horizons"]) != {str(h) for h in HORIZONS}
            or protocol["intervals"]["multiple_comparison_adjustment"] != "none"):
        raise ValueError("Unexpected representation protocol")
    sources = {}; arrays = {}; checks = []
    for path in files.values(): _source(path, root, sources)
    for horizon in HORIZONS:
        cell = result["horizons"][str(horizon)]
        if set(cell["methods"]) != set(METHODS):
            raise ValueError("A method is missing from the completed probe")
        n = cell["eligible_counts"]["test"]
        shared = None; arrays[horizon] = {}
        for method in METHODS:
            path = probe/f"horizon_{horizon:02d}"/method/"test_predictions.npz"
            digest = _sha(path)
            if digest != hashes[str(path.relative_to(probe))] or digest != cell["methods"][method]["predictions_sha256"]:
                raise ValueError(f"Prediction hash mismatch: {path}")
            with np.load(path, allow_pickle=False) as archive:
                row = {k: archive[k].copy() for k in
                       ("indices", "destination_indices", "time_ns", "destination_time_ns", "truth", "pred", "error")}
            if (row["truth"].shape != (n,4) or row["pred"].shape != (n,4)
                    or row["error"].shape != (n,4) or not np.isfinite(row["error"]).all()
                    or not np.isfinite(row["truth"]).all() or not np.isfinite(row["pred"]).all()
                    or not np.array_equal(row["error"], row["pred"]-row["truth"])):
                raise ValueError("Invalid stored predictions or errors")
            paired_keys = ("indices", "destination_indices", "time_ns", "destination_time_ns", "truth")
            if shared is None: shared = row
            elif any(not np.array_equal(shared[k], row[k]) for k in paired_keys):
                raise ValueError("Methods do not share test indices, times and targets")
            for key in paired_keys[:-1]:
                if row[key].shape != (n,): raise ValueError("Invalid identity vector shape")
            if not np.all(row["destination_time_ns"]-row["time_ns"] == (horizon-1)*60_000_000_000):
                raise ValueError("Destination times do not follow the requested horizon")
            mae = np.abs(row["error"]).mean(axis=0)
            rmse = np.sqrt(np.square(row["error"]).mean(axis=0))
            if (not np.allclose(mae, cell["methods"][method]["mae"], rtol=0, atol=1e-10)
                    or not np.allclose(rmse, cell["methods"][method]["rmse"], rtol=0, atol=1e-10)):
                raise ValueError("Saved test MAE/RMSE disagree with paired predictions")
            arrays[horizon][method] = row; _source(path, root, sources)
            checks.append({"horizon":horizon, "method":method, "samples":n,
                           "hash_verified":True, "mae_and_rmse_verified":True, "paired_identity_verified":True})
        days = shared["time_ns"]//DAY_NS
        for key, contrast in cell["comparisons"].items():
            candidate, reference = contrast["candidate"], contrast["reference"]
            expected = (np.abs(arrays[horizon][reference]["error"])-np.abs(arrays[horizon][candidate]["error"])).mean(axis=0)
            lo, hi = np.asarray(contrast["ci_lower"]), np.asarray(contrast["ci_upper"])
            if (key != candidate+"_vs_"+reference or not np.allclose(expected, contrast["difference"], rtol=0, atol=1e-10)
                    or lo.shape != (4,) or hi.shape != (4,) or not np.isfinite(np.r_[lo,hi]).all()
                    or np.any(lo>hi) or contrast["samples"] != n or contrast["time_blocks"] != len(np.unique(days))
                    or contrast["multiple_comparison_adjustment"] != "none" or not contrast["exploratory"]
                    or contrast["deterministic_fits"] != 1):
                raise ValueError("Invalid paired comparison or interval metadata")
        required = {candidate+"_vs_"+reference for candidate,reference,_ in FIVE_MINUTE_ROWS}
        if not required.issubset(cell["comparisons"]):
            raise ValueError("Required complete contrasts are missing")
    return result, arrays, sources, checks


def export_tables(root, results, arrays):
    """Write every saved method/quantity and every saved contrast, not a subset."""
    root = Path(root); output=root/"statistics";output.mkdir(parents=True,exist_ok=True)
    overall=[];comparisons=[];daily=[]
    for horizon in HORIZONS:
        cell=results['horizons'][str(horizon)]
        for method in METHODS:
            values=cell['methods'][method]
            for q,name in enumerate(CONTROL_NAMES):
                overall.append({'horizon_minutes':horizon,'method':method,'quantity':name,'unit':UNITS[q],
                                'input_composition':results['protocol']['input_composition'][method],
                                'samples':values['samples'],'alpha':values['alpha'],'input_dimension':values['input_dimension'],
                                'mae':values['mae'][q],'rmse':values['rmse'][q]})
            row=arrays[horizon][method];days=row['time_ns']//DAY_NS
            for day in np.unique(days):
                error=row['error'][days==day]
                mae=np.abs(error).mean(axis=0);rmse=np.sqrt(np.square(error).mean(axis=0))
                for q,name in enumerate(CONTROL_NAMES):
                    daily.append({'horizon_minutes':horizon,'method':method,'quantity':name,'unit':UNITS[q],
                                  'origin_calendar_date':str(np.datetime64(int(day),'D')),
                                  'samples':len(error),'mae':float(mae[q]),'rmse':float(rmse[q])})
        for key,row in cell['comparisons'].items():
            for q,name in enumerate(CONTROL_NAMES):
                comparisons.append({'horizon_minutes':horizon,'comparison':key,'candidate':row['candidate'],
                    'reference':row['reference'],'quantity':name,'unit':UNITS[q],
                    'endpoint_priority':row['endpoint_priorities'][name],'mae_reduction':row['difference'][q],
                    'ci_lower':row['ci_lower'][q],'ci_upper':row['ci_upper'][q],
                    'confidence_level':row['confidence_level'],'draws':row['draws'],'samples':row['samples'],
                    'calendar_days':row['time_blocks'],'multiple_comparison_adjustment':row['multiple_comparison_adjustment'],
                    'exploratory':True,'neural_training_seed_axis':False})
    paths=[]
    for name,rows in [('overall.csv',overall),('comparisons.csv',comparisons),('per_day.csv',daily)]:
        path=output/name;_csv(path,rows);paths.append(path)
    return paths


def five_minute_figure(plt, results):
    cell=results['horizons']['5'];figure,axes=plt.subplots(2,2,figsize=(15,10.5))
    for q,ax in enumerate(axes.flat):
        bounds=[0.]
        for pos,(candidate,reference,label) in enumerate(FIVE_MINUTE_ROWS):
            row=cell['comparisons'][candidate+'_vs_'+reference]
            mean,lo,hi=(row[key][q] for key in ('difference','ci_lower','ci_upper'))
            color=COLORS[candidate];marker='s' if candidate=='null_rgb32' else 'D' if reference=='null_rgb32' else 'o'
            ax.hlines(pos,lo,hi,color=color,lw=1.6);ax.vlines([lo,hi],pos-.065,pos+.065,color=color,lw=1)
            ax.plot(mean,pos,marker=marker,color=color,markersize=6,markerfacecolor='white' if candidate=='null_rgb32' else color)
            bounds.extend([mean,lo,hi])
        low,high=min(bounds),max(bounds);pad=max((high-low)*.1,1e-6)
        ax.set_xlim(low-pad,high+pad);ax.axvline(0,color='black',ls='--',lw=.9)
        ax.set_yticks(np.arange(len(FIVE_MINUTE_ROWS)),[r[2] for r in FIVE_MINUTE_ROWS],fontsize=10.5)
        ax.set_ylim(len(FIVE_MINUTE_ROWS)-.5,-.5)
        ax.set_title(QUANTITIES_ZH[q]);ax.set_xlabel(f'对照MAE－候选MAE（{UNITS[q]}）');_style_axis(ax)
    figure.suptitle('5分钟预测：视觉编码是否超出时序与简单颜色统计',fontsize=17,y=.98)
    days=cell['comparisons']['rgb32_vs_quality']['time_blocks'];n=cell['eligible_counts']['test']
    caption=(f'正值表示候选误差更小；各行使用所标明的对照。{n:,} 个共同测试窗口，{days} 个日历日；日块95%探索性区间，未做多重比较校正。\n'
             '所有方案含数值历史；除纯数值方案外均含采集时序。质量/颜色基线含12维统计；RGB、灰度和打乱编码均在此基线上增加。\n'
             '“灰度”只指编码器输入，质量基线仍含RGB统计。本轮主比较为RGB对质量及打乱编码的蒸汽/氧浓度MAE。')
    figure.text(.5,.023,caption,ha='center',va='bottom',fontsize=10)
    figure.subplots_adjust(left=.21,right=.98,top=.89,bottom=.16,wspace=.74,hspace=.44)
    return figure


def horizon_figure(plt, results):
    figure,axes=plt.subplots(2,2,figsize=(14,10))
    x=np.asarray(HORIZONS,dtype=float)
    for q,ax in enumerate(axes.flat):
        for method,offset,label in [('rgb32',-.14,'RGB编码＋质量基线'),('gray32',.14,'灰度编码＋质量基线')]:
            rows=[results['horizons'][str(h)]['comparisons'][method+'_vs_quality'] for h in HORIZONS]
            mean=np.asarray([r['difference'][q] for r in rows]);lo=np.asarray([r['ci_lower'][q] for r in rows]);hi=np.asarray([r['ci_upper'][q] for r in rows])
            ax.plot(x+offset,mean,color=COLORS[method],marker='o',lw=1.5,label=label)
            ax.vlines(x+offset,lo,hi,color=COLORS[method],lw=1.5)
            ax.hlines(lo,x+offset-.12,x+offset+.12,color=COLORS[method],lw=1)
            ax.hlines(hi,x+offset-.12,x+offset+.12,color=COLORS[method],lw=1)
        ax.axhline(0,color='black',ls='--',lw=.9);ax.set_xticks(x,[str(h) for h in HORIZONS]);ax.set_xlim(.3,10.7)
        ax.set_xlabel('预测时域（分钟）');ax.set_ylabel(f'相对质量基线的MAE减小量（{UNITS[q]}）')
        ax.set_title(QUANTITIES_ZH[q]);_style_axis(ax,grid_axis='y')
    handles,labels=axes[0,0].get_legend_handles_labels();figure.legend(handles,labels,loc='upper center',bbox_to_anchor=(.5,.925),ncol=2,frameon=False)
    figure.suptitle('独立Ridge预测：冻结视觉编码的条件增益',fontsize=17,y=.98)
    counts='/'.join(f"{results['horizons'][str(h)]['eligible_counts']['test']:,}" for h in HORIZONS)
    days=results['horizons']['5']['comparisons']['rgb32_vs_quality']['time_blocks']
    caption=('正值表示误差减小；对照含数值历史、采集时序及12维质量/颜色统计。灰度仅限定编码器输入，基线仍含RGB统计。\n'
             f'各时域独立拟合Ridge；按起点日历日配对重采样的95%探索性区间，未校正多重比较，无神经训练种子轴；{days} 个日历日。\n'
             f'1/5/10分钟测试窗口分别为 {counts}；不同物理量纵轴单位和尺度不同。')
    figure.text(.5,.025,caption,ha='center',va='bottom',fontsize=10)
    figure.subplots_adjust(left=.10,right=.98,top=.82,bottom=.17,wspace=.34,hspace=.43)
    return figure


def render_representation_report(study_dir):
    root=Path(study_dir).resolve()
    results,arrays,sources,checks=load_completed_probe(root)
    table_paths=export_tables(root,results,arrays)
    out=root/'figures';out.mkdir(exist_ok=True)
    plt,font=_pyplot();images=[]
    for name,builder in [('five_minute_effects',five_minute_figure),('representation_horizon_effects',horizon_figure)]:
        figure=builder(plt,results);images.extend(_save_figure(figure,out,name));plt.close(figure)
    manifest={'status':'rendered_pending_visual_review','source_sha256':sources,
              'renderer_sha256':_sha(Path(__file__)),
              'style_helper_sha256':_sha(Path(__file__).with_name('visual_diagnostics_report.py')),
              'figure_sha256':{str(p.relative_to(root)):_sha(p) for p in images},
              'table_sha256':{str(p.relative_to(root)):_sha(p) for p in table_paths},
              'validated_predictions':checks,'chinese_font':font,'colors':COLORS,
              'difference_direction':'reference MAE minus candidate MAE; positive favors candidate',
              'grayscale_scope':'grayscale encoder input only; all encoded models retain the RGB quality statistics',
              'interval_scope':results['protocol']['intervals'],'test_scope':results['protocol']['test_scope'],
              'csv_scope':'all horizons, all methods, all four quantities and all saved comparisons',
              'figure_scope':{'five_minute_effects':[f'{a}_vs_{b}' for a,b,_ in FIVE_MINUTE_ROWS],
                              'representation_horizon_effects':['rgb32_vs_quality','gray32_vs_quality']}}
    _json(out/'representation_figure_manifest.json',manifest)
    return manifest


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--study',required=True)
    args=parser.parse_args();manifest=render_representation_report(args.study)
    print(json.dumps({'status':manifest['status'],'verified_prediction_files':len(manifest['validated_predictions'])}))


if __name__=='__main__':
    main()
