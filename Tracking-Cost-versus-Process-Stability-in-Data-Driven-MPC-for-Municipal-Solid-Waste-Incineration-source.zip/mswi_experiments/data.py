"""Causal, provenance-recorded datasets built directly from the plant CSVs.

Legacy pickle caches are deliberately not consumed.  All experiment modes share
the same retained observations and chronological partitions.
"""
from __future__ import annotations

import csv
import hashlib
import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np


MINUTE_NS = 60_000_000_000
MV_COLUMNS = (
    "V4::DPU1001.SH0406.EALM040106.OP",
    "V4::DPU1001.SH0014.EALM29831.OP",
    "V4::DPU1001.SH0043.EALM03822.OP",
    "V4::DPU1014.SH0420.EALM120201.OP",
    "V4::DPU1002.SH0028.PA03729.OUT",
    "V4::DPU1002.SH0039.AALM01.PV",
    "V4::DPU1002.SH0043.AALM01.PV",
    "V4::DPU1002.SH0047.AALM01.PV",
)
MV_NAMES = (
    "primary_air_fan_frequency", "primary_air_temperature_valve_opening",
    "secondary_air_fan_frequency", "induced_draft_fan_frequency",
    "feeder_stopping_time", "drying_grate_stopping_time",
    "combustion_grate_stopping_time", "burnout_grate_stopping_time",
)
CV_COLUMNS = (
    "V4::DPU1002.SH0410.EALM060106.OP",
    "V4::DPU1002.SH0411.EALM060204.OP",
    "V4::DPU1002.SH0410.EALM060107.OP",
    "V4::DPU1002.SH0410.EALM060104.OP",
    "V4::DPU1002.SH0410.EALM060105.OP",
    "V4::DPU1002.SH0410.EALM060101.OP",
    "V4::DPU1001.SH0401.EALM010204.OP",
    "V4::DPU1001.SH0052.EALM11201.OP",
    "V4::DPU1001.SH0401.EALM010208.OP",
)
CV_NAMES = tuple(f"furnace_temperature_{i}" for i in range(1, 7)) + (
    "furnace_negative_pressure", "main_steam_flow", "flue_gas_oxygen",
)
FEATURE_COLUMNS = tuple(
    [f"ft_{i}_area{area}" for area in range(1, 5) for i in range(1, 13)]
    + [f"fire_line_area{area}" for area in range(1, 5)]
)
_NUMBER = re.compile(r"^\s*([-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?)(?:\(([^)]*)\))?\s*$")


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _time_ns(value: str) -> int:
    value = value.strip().lstrip("$")
    parsed = datetime.strptime(value, "%Y-%m-%d %H:%M:%S")
    return int(np.datetime64(parsed, "ns").astype(np.int64))


def _iso(value: int) -> str:
    return str(np.datetime64(int(value), "ns"))


def _number(value: str) -> float:
    """Read an explicit numeric/quality token; BAD readings remain missing."""
    match = _NUMBER.fullmatch(value)
    if match is None:
        return float("nan")
    if match.group(2) is not None and match.group(2).upper() != "GOOD":
        return float("nan")
    result = float(match.group(1))
    return result if np.isfinite(result) and result != -9999 else float("nan")


def read_process_files(paths: list[Path]) -> tuple[np.ndarray, np.ndarray, np.ndarray, dict[str, Any]]:
    """Read the DCS vendor format, rejecting malformed/truncated rows."""
    times: list[int] = []
    values: list[list[float]] = []
    sources = []
    wanted = MV_COLUMNS + CV_COLUMNS
    for path in paths:
        path = Path(path).resolve()
        count = 0
        with path.open("r", encoding="utf-8", errors="replace", newline="") as stream:
            reader = csv.reader(stream)
            version = next(reader, None)
            header = next(reader, None)
            if version is None or not version[0].startswith("$DataFileVersion:"):
                raise ValueError(f"{path}: missing DCS file-version header")
            if header is None or header[0] != "$TagName":
                raise ValueError(f"{path}: missing DCS tag-name header")
            missing = sorted(set(wanted) - set(header))
            if missing:
                raise ValueError(f"{path}: required process tags absent: {missing}")
            positions = [header.index(name) for name in wanted]
            for row_no, row in enumerate(reader, 3):
                if not row or row[0] in ("$TagDesc", "$Time"):
                    continue
                if len(row) != len(header):
                    raise ValueError(f"{path}:{row_no}: {len(row)} columns, expected {len(header)}; source may be incomplete")
                stamp = _time_ns(row[0])
                if stamp % MINUTE_NS:
                    raise ValueError(f"{path}:{row_no}: process record is not minute-aligned")
                times.append(stamp)
                values.append([_number(row[position]) for position in positions])
                count += 1
        sources.append({"path": str(path), "sha256": _sha256(path), "bytes": path.stat().st_size, "rows": count})
    if not times:
        raise ValueError("No process observations were read")
    t = np.asarray(times, dtype=np.int64)
    x = np.asarray(values, dtype=np.float32)
    order = np.argsort(t, kind="stable")
    t, x = t[order], x[order]
    duplicate = np.flatnonzero(np.diff(t) == 0)
    for index in duplicate:
        if not np.array_equal(x[index], x[index + 1], equal_nan=True):
            raise ValueError(f"Conflicting process observations at {_iso(t[index])}")
    keep = np.r_[True, np.diff(t) != 0]
    t, x = t[keep], x[keep]
    metadata = {"sources": sources, "duplicate_identical_records_removed": int(len(duplicate)),
                "unique_minutes": len(t), "start": _iso(t[0]), "end": _iso(t[-1]),
                "invalid_numeric_readings_before_fill": int((~np.isfinite(x)).sum())}
    return t, x[:, :8], x[:, 8:], metadata


def read_visual_features(path: Path) -> tuple[np.ndarray, np.ndarray, np.ndarray, dict[str, Any]]:
    """Read 52 descriptors and their earliest actual source-capture timestamps.

    Single-capture exports have no history field. Corrected temporal descriptors
    explicitly carry feature_source_start_time; that metadata is never a feature.
    """
    path = Path(path).resolve()
    times: list[int] = []
    features: list[list[float]] = []
    source_times: list[int] = []
    invalid = 0
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        fields = reader.fieldnames or []
        missing = sorted(set(FEATURE_COLUMNS + ("time", "img_name")) - set(fields))
        if missing:
            raise ValueError(f"{path}: image feature schema missing {missing}")
        history_export = 'feature_source_start_time' in fields
        unexpected = set(fields) - set(FEATURE_COLUMNS) - {"time", "img_name", 'feature_source_start_time'}
        if any(not name.startswith("Unnamed:") for name in unexpected):
            raise ValueError(f"{path}: unrecognised nonmetadata columns: {sorted(unexpected)}")
        for row in reader:
            stamp = _time_ns(row["time"])
            name_stamp = _time_ns(Path(row["img_name"]).stem)
            if stamp != name_stamp:
                raise ValueError(f"{path}: image name/time mismatch at {row['img_name']}")
            first_source = _time_ns(row['feature_source_start_time']) if history_export else stamp
            if first_source > stamp:
                raise ValueError(f'{path}: visual descriptor uses a future source capture')
            vector = [_number(row[name]) for name in FEATURE_COLUMNS]
            if not np.isfinite(vector).all():
                invalid += 1
                continue
            times.append(stamp)
            source_times.append(first_source)
            features.append(vector)
    if not times:
        raise ValueError("No valid visual observations were read")
    t = np.asarray(times, dtype=np.int64)
    v = np.asarray(features, dtype=np.float32)
    origins = np.asarray(source_times, dtype=np.int64)
    order = np.argsort(t, kind="stable")
    t, v, origins = t[order], v[order], origins[order]
    duplicate = np.flatnonzero(np.diff(t) == 0)
    for index in duplicate:
        if not np.array_equal(v[index], v[index + 1]) or origins[index] != origins[index+1]:
            raise ValueError(f"Conflicting visual observations at {_iso(t[index])}")
    keep = np.r_[True, np.diff(t) != 0]
    t, v, origins = t[keep], v[keep], origins[keep]
    metadata = {"path": str(path), "sha256": _sha256(path), "bytes": path.stat().st_size,
                "valid_images": len(t), "invalid_feature_rows_removed": invalid,
                "duplicate_identical_records_removed": len(duplicate),
                "start": _iso(t[0]), "end": _iso(t[-1]), "feature_count": len(FEATURE_COLUMNS),
                "feature_columns": list(FEATURE_COLUMNS),
                "excluded_metadata": [name for name in fields if name not in FEATURE_COLUMNS],
                "source_timing": 'explicit causal descriptor history' if history_export else 'single recorded capture',
                "maximum_descriptor_history_minutes": float(((t-origins)/MINUTE_NS).max()),
                "correction": "52 real numeric measurements; legacy 53rd dimension came from coercing img_name and is excluded."}
    return t, v, origins, metadata


def _causal_fill(values: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Return filled values and source row of each value; initial gaps stay NaN."""
    finite = np.isfinite(values)
    source = np.where(finite, np.arange(len(values))[:, None], -1)
    source = np.maximum.accumulate(source, axis=0)
    result = values[np.maximum(source, 0), np.arange(values.shape[1])[None, :]].copy()
    result[source < 0] = np.nan
    return result, source


def build_samples(
    process_times: np.ndarray, u: np.ndarray, z: np.ndarray,
    visual_times: np.ndarray, visual: np.ndarray, window: int = 10,
    image_gap_minutes: int = 10,
    visual_source_start_times: np.ndarray | None = None,
) -> tuple[dict[str, np.ndarray], dict[str, Any]]:
    """Build one-step prediction and following-action records with provenance."""
    if window < 1 or image_gap_minutes < 0:
        raise ValueError("window must be positive and image gap nonnegative")
    if u.shape != (len(process_times), 8) or z.shape != (len(process_times), 9):
        raise ValueError("Expected eight MV and nine CV channels")
    if len(process_times) <= window + 1 or len(visual_times) == 0:
        raise ValueError("Insufficient observations")
    if np.any(np.diff(process_times) <= 0) or np.any(np.diff(visual_times) <= 0):
        raise ValueError("Input timestamps must be unique and increasing")
    visual_origins = np.asarray(visual_times if visual_source_start_times is None else visual_source_start_times,dtype=np.int64)
    if visual_origins.shape != visual_times.shape or (visual_origins > visual_times).any():
        raise ValueError('Visual source history must match captures and contain no future source')
    grid = np.arange(process_times[0], process_times[-1] + MINUTE_NS, MINUTE_NS, dtype=np.int64)
    positions = np.searchsorted(grid, process_times)
    raw = np.full((len(grid), 17), np.nan, dtype=np.float32)
    raw[positions] = np.concatenate([u, z], axis=1)
    present = np.zeros(len(grid), dtype=bool)
    present[positions] = True
    filled, source = _causal_fill(raw)
    candidate = np.arange(window, len(grid) - 1, dtype=np.int64)
    spans = candidate[:, None] + np.arange(-window, 2)[None, :]
    contiguous = present[spans].all(axis=1)
    valid_numeric = np.isfinite(filled[spans]).all(axis=(1, 2))
    cutoff = grid[candidate] - MINUTE_NS
    image_index = np.searchsorted(visual_times, cutoff, side="right") - 1
    nonnegative = image_index >= 0
    safe_image = np.maximum(image_index, 0)
    ages = cutoff - visual_times[safe_image]
    valid_image = nonnegative & (ages >= 0) & (ages <= image_gap_minutes * MINUTE_NS)
    keep = contiguous & valid_numeric & valid_image
    i, image_index = candidate[keep], image_index[keep]
    if not len(i):
        raise ValueError("No valid aligned windows remain")
    uh = filled[i[:, None] + np.arange(-window, 1)[None, :], :8]
    zh = filled[i[:, None] + np.arange(-window, 0)[None, :], 8:]
    earliest_row = source[spans[keep]].min(axis=(1, 2))
    origin = np.minimum(grid[earliest_row], visual_origins[image_index])
    data = {
        "u_hist": uh.astype(np.float32), "z_hist": zh.astype(np.float32),
        "visual": visual[image_index].astype(np.float32),
        "z_prev": filled[i - 1, 8:].copy(), "z_target": filled[i, 8:].copy(),
        "u_current": filled[i, :8].copy(), "z_current": filled[i, 8:].copy(),
        "action": (filled[i + 1, :8] - filled[i, :8]).astype(np.float32),
        "time_ns": grid[i], "visual_time_ns": visual_times[image_index],
        "visual_source_start_ns": visual_origins[image_index],
        "source_start_ns": origin, "source_end_ns": grid[i + 1],
    }
    metadata = {"minute_grid_rows": len(grid), "actual_process_minutes": int(present.sum()),
                "missing_timeline_minutes": int((~present).sum()), "candidate_windows": len(candidate),
                "excluded_nonconsecutive_windows": int((~contiguous).sum()),
                "excluded_unfilled_numeric_windows": int((~valid_numeric).sum()),
                "excluded_missing_or_stale_visual_windows": int((~valid_image).sum()),
                "retained_before_split_purge": len(i), "causal_fill_cells": int((~np.isfinite(raw) & np.isfinite(filled)).sum()),
                "window_minutes": window, "image_gap_minutes": image_gap_minutes,
                "image_alignment": "latest exact capture timestamp <= prediction time minus one minute; no future image or numeric interpolation",
                "numeric_quality": "BAD/nonfinite/-9999 treated as missing, then past-only forward fill; no backfill or centred smoothing"}
    return data, metadata


def assign_partitions(data: dict[str, np.ndarray], fractions: tuple[float, float, float],
                      purge_minutes: int) -> dict[str, Any]:
    if len(fractions) != 3 or not np.isclose(sum(fractions), 1) or min(fractions) <= 0:
        raise ValueError("split must contain three positive fractions summing to one")
    n = len(data["time_ns"])
    cut1 = int(data["time_ns"][int(n * fractions[0])])
    cut2 = int(data["time_ns"][int(n * (fractions[0] + fractions[1]))])
    intervals = {
        "train": (int(data["source_start_ns"].min()), cut1),
        "val": (cut1 + purge_minutes * MINUTE_NS, cut2),
        "test": (cut2 + purge_minutes * MINUTE_NS, int(data["source_end_ns"].max()) + 1),
    }
    used = np.full(n, -1, dtype=np.int8)
    metadata: dict[str, Any] = {"nominal_fractions": list(fractions), "purge_minutes": purge_minutes, "partitions": {}}
    for label, (name, (start, stop)) in enumerate(intervals.items()):
        indices = np.flatnonzero((data["source_start_ns"] >= start) & (data["source_end_ns"] < stop))
        if len(indices) == 0:
            raise ValueError(f"No {name} windows remain after temporal/source purge")
        if (used[indices] >= 0).any():
            raise AssertionError("Partitions overlap")
        used[indices] = label
        data[f"{name}_idx"] = indices.astype(np.int64)
        metadata["partitions"][name] = {"samples": len(indices), "start": _iso(data["time_ns"][indices[0]]),
            "end": _iso(data["time_ns"][indices[-1]]), "earliest_source": _iso(data["source_start_ns"][indices].min()),
            "latest_source": _iso(data["source_end_ns"][indices].max())}
    following = np.full(n, -1, dtype=np.int64)
    adjacent = (np.diff(data["time_ns"]) == MINUTE_NS) & (used[:-1] >= 0) & (used[:-1] == used[1:])
    following[:-1][adjacent] = np.arange(1, n)[adjacent]
    data["next_idx"] = following
    metadata["excluded_split_boundary_windows"] = int((used < 0).sum())
    metadata["retained_in_partitions"] = int((used >= 0).sum())
    return metadata


def _mean_scale(values: np.ndarray) -> tuple[list[float], list[float]]:
    mean = values.mean(axis=0, dtype=np.float64)
    scale = values.std(axis=0, dtype=np.float64)
    scale[scale < 1e-6] = 1.0
    return mean.tolist(), scale.tolist()


def control_values(values: np.ndarray) -> np.ndarray:
    """Map nine CV channels to mean temperature, pressure, steam and oxygen."""
    values = np.asarray(values)
    if values.ndim < 1 or values.shape[-1] != 9:
        raise ValueError("Control mapping requires exactly nine CV channels on the last axis")
    return np.concatenate([values[..., :6].mean(axis=-1, keepdims=True), values[..., 6:]], axis=-1)


def training_statistics(data: dict[str, np.ndarray]) -> dict[str, Any]:
    indices = data["train_idx"]
    stats: dict[str, Any] = {}
    for prefix, values in (("u", data["u_hist"][indices].reshape(-1, 8)),
                           ("z", data["z_hist"][indices].reshape(-1, 9)),
                           ("v", data["visual"][indices]),
                           ("delta", data["z_target"][indices] - data["z_prev"][indices])):
        stats[f"{prefix}_mean"], stats[f"{prefix}_scale"] = _mean_scale(values)
    action = data["action"][indices]
    bound = np.quantile(np.abs(action), .995, axis=0)
    scale = np.where(bound > 1e-6, bound, 1.0)
    stats["action_bound"] = np.where(bound > 1e-6, bound, 0.0).tolist()
    stats["action_scale"] = scale.tolist()
    stats["u_low"] = np.quantile(data["u_current"][indices], .005, axis=0).tolist()
    stats["u_high"] = np.quantile(data["u_current"][indices], .995, axis=0).tolist()
    z = data["z_current"][indices]
    controlled = control_values(z)
    stats["control_low"] = np.quantile(controlled, .01, axis=0).tolist()
    stats["control_high"] = np.quantile(controlled, .99, axis=0).tolist()
    stats["control_targets"] = [1000.0, -50.0, 32.0, 3.8]
    stats["oxygen_target_band"] = [3.5, 4.0]
    stats["control_envelope_definition"] = "training 1st/99th percentiles; data-derived operating bounds, not certified plant safety limits"
    stats["mv_columns"] = list(MV_COLUMNS)
    stats["mv_names"] = list(MV_NAMES)
    stats["cv_columns"] = list(CV_COLUMNS)
    stats["cv_names"] = list(CV_NAMES)
    stats["visual_columns"] = list(FEATURE_COLUMNS)
    stats["window"] = data["z_hist"].shape[1]
    return stats


def prepare_data(config: dict[str, Any], output_dir: str | Path):
    options = config.get("data", {})
    project = Path(__file__).resolve().parents[1]
    repository = project.parent
    default_files = [repository / "datav2/ts" / name for name in (
        "DataFile(20250401.000000~20250430.235959).csv",
        "DataFile(20250501.000000~20250531.235959).csv",
        "DataFile(20250601.000000~20250604.235959).csv")]
    paths = [Path(p) for p in options.get("process_files", default_files)]
    feature_path = Path(options.get("feature_file", project / "image_features_all.csv"))
    window = int(options.get("window", 10))
    image_gap = int(options.get("image_gap_minutes", 10))
    purge = int(options.get("purge_minutes", window + image_gap + 1))
    if purge < window + image_gap + 1:
        raise ValueError("Temporal purge must cover window plus image age plus next action")
    times, u, z, process_meta = read_process_files(paths)
    image_times, visual, visual_origins, image_meta = read_visual_features(feature_path)
    data, build_meta = build_samples(times, u, z, image_times, visual, window, image_gap,
                                    visual_source_start_times=visual_origins)
    split_meta = assign_partitions(data, tuple(options.get("split", [.7, .15, .15])), purge)
    stats = training_statistics(data)
    manifest = {"schema_version": 2, "process": process_meta, "visual": image_meta,
                "construction": build_meta, "split": split_meta,
                "array_shapes": {key: list(value.shape) for key, value in data.items()},
                "statistics_source": "train_idx only", "legacy_pickle_caches_used": False,
                "temperature_control_definition": "arithmetic mean of the six furnace-temperature channels",
                "action_definition": "next-minute logged MV minus current MV",
                "input_column_mapping": {"mv": dict(zip(MV_NAMES, MV_COLUMNS)), "cv": dict(zip(CV_NAMES, CV_COLUMNS))}}
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(output / "dataset.npz", **data)
    (output / "stats.json").write_text(json.dumps(stats, ensure_ascii=False, indent=2) + "\n")
    (output / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    return data, stats, manifest


def load_data(output_dir: str | Path):
    directory = Path(output_dir)
    with np.load(directory / "dataset.npz", allow_pickle=False) as archive:
        data = {name: archive[name] for name in archive.files}
    stats = json.loads((directory / "stats.json").read_text())
    manifest = json.loads((directory / "manifest.json").read_text())
    return data, stats, manifest
