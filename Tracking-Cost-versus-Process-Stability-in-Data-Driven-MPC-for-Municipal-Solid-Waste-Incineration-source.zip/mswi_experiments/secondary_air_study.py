"""Validation-only secondary-air step 2. Does not freeze the main method."""
from __future__ import annotations
import argparse
import datetime
import json
from pathlib import Path
import shutil
import time
import numpy as np
import torch
from threadpoolctl import threadpool_limits
from .ridge_policy_study import read_npz,write_json,sha
from .ridge_dynamics import RidgeDynamics
from .ridge_policy import RidgePolicyEnv
from .mpc_channels import ChannelExecution,ChannelCEM
ROOT=Path(__file__).resolve().parents[1]
REF=ROOT/'experiment_runs/ridge_control_probe_20261106'
PRIOR=ROOT/'experiment_runs/ridge_policy_pipeline_20261107'
OLD=ROOT/'experiment_runs/mpc_temperature_20261107'
DESIGN=ROOT/'experiment_protocols/secondary_air_control_20261107'
OUT=ROOT/'experiment_runs/secondary_air_control_20261107'
MODELS=('full','early','middle','late','pooled_matched')
VARIANTS=('A','B','C','D');WEIGHTS=dict(zip(VARIANTS,(1,2,4,8)))
SAMPLE_KEYS=('u_hist','z_hist','z_current','time_ns','indices')

def protocol():return json.loads((DESIGN/'protocol.json').read_text())
def shared(secondary=True):
    stats=json.loads((REF/'stats.json').read_text())
    execution=ChannelExecution(stats,read_npz(REF/'support.npz'),secondary)
    return stats,execution,RidgeDynamics.load(REF/'evaluation_models/full.npz')

def verify_sources():
    for path,expected in json.loads((DESIGN/'source_bindings.json').read_text()).items():
        if sha(path)!=expected:raise AssertionError('registered source changed: '+path)

def prepare():
    verify_sources()
    if (OUT/'trajectories').exists():raise AssertionError('readiness must precede new runs')
    for name in ('protocol.json','PRESET_zh.txt','source_bindings.json'):shutil.copy2(DESIGN/name,OUT/name)
    inputs=read_npz(REF/'inputs/val.npz');stats,e,model=shared(False);checks=[]
    if len(inputs['indices'])!=256:raise AssertionError('fixed256 starts')
    for vid in VARIANTS:
        planner=ChannelCEM(model,e,WEIGHTS[vid]);env=RidgePolicyEnv(model,e,horizon=10)
        env.reset(options={'inputs':inputs});old=read_npz(OLD/f'trajectories/{vid}/full.npz')
        for step in range(3):
            request,diag=planner.plan(env.u,env.z,env.current,env.times,env.indices,step)
            _,_,_,_,info=env.step_request(request)
            for k in ('pred_cv','u_path','requested_action','executed_action','reward'):
                np.testing.assert_array_equal(info[k],old[k][:,step])
            for k in ('best_requested_plan_b','selected_planning_score','selected_original_return','selected_temperature_cost','hold_temperature_cost','noise_sha256'):
                np.testing.assert_array_equal(diag[k],old[k][:,step])
            checks.append(dict(variant=vid,step=step,bitwise_equal=True))
        print('compatibility',vid,'256 starts x3 decisions passed',flush=True)
    write_json(OUT/'compatibility_before_run.json',dict(status='passed',checks=checks,episodes=256,decisions_per_variant=3))

def freeze():
    verify_sources()
    if json.loads((OUT/'compatibility_before_run.json').read_text())['status']!='passed':raise AssertionError('readiness')
    files=[ROOT/'mswi_experiments'/n for n in ('mpc_channels.py','secondary_air_study.py','secondary_air_report.py')]+[ROOT/'tests/test_mpc_channels.py']
    files += [DESIGN/n for n in ('protocol.json','PRESET_zh.txt','source_bindings.json')]
    hashes={str(p):sha(p) for p in files};path=OUT/'implementation_frozen.json'
    if path.exists():
        if json.loads(path.read_text())['hashes']!=hashes:raise AssertionError('implementation changed after freeze')
    else:
        write_json(path,dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),hashes=hashes))
        deps=[ROOT/p for p in ('mswi_experiments/control.py','mswi_experiments/data.py','mswi_experiments/visual_diagnostics_statistics.py','mswi_experiments/mpc_temperature.py')]
        deps+=list((ROOT/'mswi_experiments').glob('ridge_*.py'))
        for p in files+deps:
            dest=OUT/'code_snapshot'/p.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)

def run_case(vid,mid):
    path=OUT/f'trajectories/{vid}/{mid}.npz'
    if path.exists():
        if sha(path)!=json.loads(path.with_suffix('.json').read_text())['sha256']:raise AssertionError('trajectory changed')
        return
    stats,execution,full=shared();planner=ChannelCEM(full,execution,WEIGHTS[vid])
    env=RidgePolicyEnv(RidgeDynamics.load(REF/f'evaluation_models/{mid}.npz'),execution,horizon=10)
    inputs=read_npz(REF/'inputs/val.npz');env.reset(options={'inputs':inputs});buffers={};start=time.perf_counter()
    for step in range(10):
        request,diag=planner.plan(env.u,env.z,env.current,env.times,env.indices,step)
        _,_,done,cut,info=env.step_request(request)
        if done.any() or cut.all()!=(step==9):raise AssertionError('truncation')
        info.update(diag)
        for k,v in info.items():buffers.setdefault(k,[]).append(v)
    arrays={k:np.stack(v,axis=1) for k,v in buffers.items()}
    arrays.update(indices=inputs['indices'],time_ns=inputs['time_ns'],initial_u=inputs['u_hist'][:,-1],initial_z_current=inputs['z_current'])
    for k,v in arrays.items():
        if np.issubdtype(v.dtype,np.number) and not np.isfinite(v).all():raise FloatingPointError(k)
    path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix('.partial.npz');np.savez_compressed(tmp,**arrays);tmp.replace(path)
    write_json(path.with_suffix('.json'),dict(variant=vid,model=mid,split='val',episodes=256,horizon=10,
        elapsed_seconds=time.perf_counter()-start,sha256=sha(path),support_certificate_counts=planner.support.counts,
        original_return10=float(arrays['reward'].astype(float).sum(1).mean())))
    print('complete',vid,mid,'seconds',round(time.perf_counter()-start,1),flush=True)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=('prepare','freeze','run'));parser.add_argument('--shard',type=int,default=0);parser.add_argument('--shards',type=int,default=1)
    args=parser.parse_args();torch.set_num_threads(4)
    with threadpool_limits(4):
        if args.stage=='prepare':prepare()
        elif args.stage=='freeze':freeze()
        else:
            if not 0<=args.shard<args.shards:raise ValueError('invalid shard')
            freeze()
            for v,m in [(v,m) for v in VARIANTS for m in MODELS][args.shard::args.shards]:run_case(v,m)
if __name__=='__main__':main()
