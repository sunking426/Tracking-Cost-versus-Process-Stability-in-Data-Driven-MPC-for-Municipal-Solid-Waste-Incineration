"""Binary logged-outcome probes and paired calendar-day uncertainty.

These probes concern observed temperature movement or recorded adjustment,
not an optimal action, a safety limit, or a causal control effect. Fitting uses
training and validation inputs only. Test prediction is an explicit saved-weight
calculation. Bootstrap uncertainty retains all windows from a sampled day.
"""
from __future__ import annotations

from pathlib import Path
import warnings

import numpy as np
from scipy.special import expit
from sklearn.exceptions import ConvergenceWarning
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, roc_auc_score
from sklearn.preprocessing import StandardScaler


DAY_NS = 86_400_000_000_000
ENDPOINTS = ('average_precision', 'brier', 'log_loss')
SOLVER = 'lbfgs'
MAX_ITER = 10000
TOL = 1e-6
RANDOM_STATE = 20261106
MODEL_FIELDS = {'schema_version', 'coef', 'intercept', 'x_mean', 'x_scale',
                'C', 'n_iter', 'max_iter', 'tol', 'random_state', 'threshold',
                'alarm_quantile', 'converged', 'solver'}


def _matrix(value, *, width=None):
    x = np.asarray(value, dtype=np.float64)
    if (x.ndim != 2 or min(x.shape) < 1 or not np.isfinite(x).all()
            or (width is not None and x.shape[1] != width)):
        raise ValueError('features require a nonempty finite matrix of the fitted width')
    return x


def _labels(value, length=None):
    y = np.asarray(value)
    if (y.ndim != 1 or not len(y) or (length is not None and len(y) != length)
            or not np.isfinite(y).all() or not np.isin(y, (0, 1)).all()):
        raise ValueError('labels must be an aligned nonempty binary vector')
    return y.astype(np.int64, copy=False)


def _probabilities(value, length):
    p = np.asarray(value, dtype=np.float64)
    if p.shape != (length,) or not np.isfinite(p).all() or np.any((p < 0) | (p > 1)):
        raise ValueError('probabilities must be finite, aligned, and in [0,1]')
    return p


def _loss_rows(y, p):
    # Use binary float64 probability clipping consistently in selection/reporting.
    clipped = np.clip(p, np.finfo(np.float64).eps, 1-np.finfo(np.float64).eps)
    return np.column_stack(((p-y)**2, -(y*np.log(clipped)+(1-y)*np.log1p(-clipped))))


def validate_weights(weights):
    if set(weights) != MODEL_FIELDS:
        raise ValueError('binary model fields differ from the saved schema')
    coef = np.asarray(weights['coef'], dtype=np.float64)
    if coef.ndim != 1 or not len(coef) or not np.isfinite(coef).all():
        raise ValueError('saved coefficients must be a finite vector')
    for key in ('x_mean','x_scale'):
        value = np.asarray(weights[key], dtype=np.float64)
        if value.shape != coef.shape or not np.isfinite(value).all():
            raise ValueError('invalid fitted feature standardization')
        if key == 'x_scale' and np.any(value <= 0):
            raise ValueError('fitted feature scales must be positive')
    for key in MODEL_FIELDS - {'coef','x_mean','x_scale','solver'}:
        value = np.asarray(weights[key])
        if value.shape != () or not np.isfinite(value):
            raise ValueError(f'invalid saved scalar {key}')
    if (int(weights['schema_version']) != 1 or str(np.asarray(weights['solver']).item()) != SOLVER
            or not bool(weights['converged']) or float(weights['C']) <= 0
            or not 0 <= float(weights['threshold']) <= 1
            or not 0 < float(weights['alarm_quantile']) < 1
            or int(weights['n_iter']) < 1 or int(weights['n_iter']) > int(weights['max_iter'])
            or int(weights['max_iter']) != MAX_ITER or float(weights['tol']) != TOL
            or int(weights['random_state']) != RANDOM_STATE):
        raise ValueError('saved model parameters violate the frozen fitting contract')
    return len(coef)


def predict_proba(weights, x):
    """Calculate probabilities from explicit saved arrays; no estimator refit."""
    width = validate_weights(weights)
    x = _matrix(x, width=width)
    with np.errstate(over='raise', invalid='raise'):
        logits = ((x-weights['x_mean'])/weights['x_scale']) @ weights['coef'] + weights['intercept']
    if not np.isfinite(logits).all():
        raise FloatingPointError('binary predictor generated a nonfinite logit')
    return expit(logits)


def save_model(path, weights):
    validate_weights(weights)
    path = Path(path)
    if path.suffix != '.npz':
        raise ValueError('model archive path must end in .npz')
    np.savez_compressed(path, **weights)


def load_model(path):
    with np.load(path, allow_pickle=False) as saved:
        weights = {key:saved[key] for key in saved.files}
    validate_weights(weights)
    for value in weights.values(): value.flags.writeable = False
    return weights


def fit_candidates(xtrain, ytrain, xval, yval, Cs, *, alarm_quantile=.9):
    """Train-only scaling; select C by validation log loss, then fix alarm cut.

    The alarm threshold is the linear-interpolation quantile of the selected
    validation probabilities. It is never recalculated from a test batch.
    Every candidate must converge; a failed optimization is not silently dropped.
    """
    xt = _matrix(xtrain); xv = _matrix(xval, width=xt.shape[1])
    yt, yv = _labels(ytrain, len(xt)), _labels(yval, len(xv))
    if np.unique(yt).size != 2:
        raise ValueError('logistic fitting requires both training classes')
    Cs = list(Cs)
    if (not Cs or any(not np.isfinite(c) or float(c) <= 0 for c in Cs)
            or len(np.unique(Cs)) != len(Cs) or not 0 < alarm_quantile < 1):
        raise ValueError('C grid must be unique and positive; alarm quantile must lie in (0,1)')
    scaler = StandardScaler().fit(xt)
    xs, vs = scaler.transform(xt), scaler.transform(xv)
    candidates, fitted = [], {}
    for C in Cs:
        estimator = LogisticRegression(C=float(C), penalty='l2', fit_intercept=True,
            solver=SOLVER, max_iter=MAX_ITER, tol=TOL, random_state=RANDOM_STATE,
            class_weight=None, warm_start=False)
        with warnings.catch_warnings(record=True) as issued:
            warnings.simplefilter('always', ConvergenceWarning)
            estimator.fit(xs, yt)
        if any(issubclass(item.category, ConvergenceWarning) for item in issued):
            raise RuntimeError(f'logistic candidate C={C} did not converge within {MAX_ITER} iterations')
        for item in issued:
            warnings.warn(item.message, item.category)
        iterations = int(estimator.n_iter_[0])
        coefficient = estimator.coef_[0].copy()
        intercept = float(estimator.intercept_[0])
        probability = expit(vs @ coefficient + intercept)
        if not np.isfinite(probability).all():
            raise FloatingPointError('nonfinite candidate validation probabilities')
        loss = float(_loss_rows(yv, probability)[:,1].mean())
        row = {'C':float(C), 'val_log_loss':loss, 'n_iter':iterations, 'converged':True}
        candidates.append(row)
        fitted[float(C)] = (coefficient, intercept, probability)
    best = min(row['val_log_loss'] for row in candidates)
    selected = min((row for row in candidates if row['val_log_loss'] <= best+1e-12), key=lambda r:r['C'])
    coefficient, intercept, probability = fitted[selected['C']]
    threshold = float(np.quantile(probability, alarm_quantile, method='linear'))
    weights = {
        'schema_version':np.asarray(1), 'coef':coefficient,
        'intercept':np.asarray(intercept), 'x_mean':scaler.mean_.copy(), 'x_scale':scaler.scale_.copy(),
        'C':np.asarray(selected['C']), 'n_iter':np.asarray(selected['n_iter']),
        'max_iter':np.asarray(MAX_ITER), 'tol':np.asarray(TOL), 'random_state':np.asarray(RANDOM_STATE),
        'threshold':np.asarray(threshold), 'alarm_quantile':np.asarray(float(alarm_quantile)),
        'converged':np.asarray(True), 'solver':np.asarray(SOLVER),
    }
    validate_weights(weights)
    chosen = dict(selected, threshold=threshold, alarm_quantile=float(alarm_quantile),
                  val_alarm_fraction=float(np.mean(probability >= threshold)))
    return weights, candidates, chosen


def binary_metrics(y, probability, threshold):
    y = _labels(y); p = _probabilities(probability, len(y))
    if not np.isfinite(threshold) or not 0 <= threshold <= 1:
        raise ValueError('alarm threshold must lie in [0,1]')
    alarm = p >= threshold
    positives = int(y.sum()); negatives = len(y)-positives
    tp = int(np.sum(alarm & (y == 1))); fp = int(np.sum(alarm & (y == 0)))
    fn, tn = positives-tp, negatives-fp
    both = positives > 0 and negatives > 0
    losses = _loss_rows(y,p)
    return {
        'samples':len(y), 'positives':positives, 'negatives':negatives,
        'prevalence':positives/len(y), 'average_precision':float(average_precision_score(y,p)) if both else None,
        'roc_auc':float(roc_auc_score(y,p)) if both else None,
        'brier':float(losses[:,0].mean()), 'log_loss':float(losses[:,1].mean()),
        'threshold':float(threshold), 'alarm_count':int(alarm.sum()), 'alarm_fraction':float(alarm.mean()),
        'true_positive':tp, 'false_positive':fp, 'false_negative':fn, 'true_negative':tn,
        'precision':tp/(tp+fp) if tp+fp else None, 'recall':tp/positives if positives else None,
        'false_positive_rate':fp/negatives if negatives else None,
        'discrimination_defined':both,
        'undefined_reason':None if both else 'only one outcome class is present',
    }


def weighted_average_precision(y, probability, sample_weight):
    """Weighted stepwise average precision, including exact tied-score groups.

    Return NaN when either class has zero weight: the diagnostic then has no
    positive-versus-negative ranking comparison. Brier/log loss remain defined.
    """
    y = _labels(y); p = _probabilities(probability,len(y))
    weight = np.asarray(sample_weight,dtype=np.float64)
    if weight.shape != y.shape or not np.isfinite(weight).all() or np.any(weight < 0) or weight.sum() <= 0:
        raise ValueError('weights must be finite, nonnegative, aligned, and have positive sum')
    pos, neg = float(weight[y == 1].sum()), float(weight[y == 0].sum())
    if pos == 0 or neg == 0: return float('nan')
    order = np.argsort(-p,kind='stable')
    ends = np.r_[np.flatnonzero(np.diff(p[order]) != 0),len(y)-1]
    cumulative_positive = np.cumsum(weight[order]*y[order])[ends]
    cumulative_total = np.cumsum(weight[order])[ends]
    group_positive = np.diff(np.r_[0.,cumulative_positive])
    precision = np.divide(cumulative_positive,cumulative_total,out=np.zeros_like(cumulative_total),where=cumulative_total>0)
    return float(np.sum(group_positive*precision)/pos)


def _ranking_blocks(y, probability, inverse, blocks):
    # Unique probabilities sort ascending; invert groups for descending ranking.
    unique, group = np.unique(probability,return_inverse=True)
    group = len(unique)-1-group
    positive = np.zeros((len(unique),blocks),dtype=np.float64)
    total = np.zeros_like(positive)
    np.add.at(total,(group,inverse),1.)
    np.add.at(positive,(group,inverse),y)
    return positive,total


def _ranked_block_ap(ranking, weights):
    positive, total = (weights @ values.T for values in ranking)
    cumulative_positive = np.cumsum(positive,axis=1)
    cumulative_total = np.cumsum(total,axis=1)
    precision = np.divide(cumulative_positive,cumulative_total,out=np.zeros_like(cumulative_total),where=cumulative_total>0)
    count = cumulative_positive[:,-1]
    negatives = cumulative_total[:,-1]-count
    result = np.full(len(weights),np.nan)
    valid = (count > 0) & (negatives > 0)
    result[valid] = (positive[valid]*precision[valid]).sum(axis=1)/count[valid]
    return result


def paired_day_bootstrap(y, reference, candidate, time_ns, *, draws=10000,
                         seed=20261106, confidence_level=.95, batch_size=64):
    """Recompute nonlinear AP for each paired whole-day bootstrap sample.

    Repeated days give every original window in that day its multiplicity.
    Quantiles use only defined draws and retain their explicit denominators;
    any omitted AP draws make the interval conditional on both classes being
    represented. No replicate model fits or artificial training seeds are used.
    """
    y = _labels(y); ref = _probabilities(reference,len(y)); cand = _probabilities(candidate,len(y))
    times = np.asarray(time_ns)
    if times.shape != y.shape or not np.issubdtype(times.dtype,np.integer):
        raise ValueError('integer nanosecond timestamps must identify every window')
    if (isinstance(draws,bool) or not isinstance(draws,(int,np.integer)) or draws < 1
            or isinstance(batch_size,bool) or not isinstance(batch_size,(int,np.integer)) or batch_size < 1
            or not 0 < confidence_level < 1):
        raise ValueError('positive integer draws/batch size and a valid confidence level required')
    blocks,inverse,counts = np.unique(times//DAY_NS,return_inverse=True,return_counts=True)
    ranking_ref = _ranking_blocks(y,ref,inverse,len(blocks))
    ranking_cand = _ranking_blocks(y,cand,inverse,len(blocks))
    losses = _loss_rows(y,ref)-_loss_rows(y,cand)
    loss_sum = np.zeros((len(blocks),2),dtype=np.float64)
    np.add.at(loss_sum,inverse,losses)
    rng = np.random.default_rng(seed)
    samples = np.empty((draws,3),dtype=np.float64)
    for begin in range(0,draws,batch_size):
        end = min(begin+batch_size,draws)
        weights = rng.multinomial(len(blocks),np.full(len(blocks),1/len(blocks)),end-begin)
        samples[begin:end,0] = _ranked_block_ap(ranking_cand,weights)-_ranked_block_ap(ranking_ref,weights)
        samples[begin:end,1:] = (weights @ loss_sum)/(weights @ counts)[:,None]
    ref_ap = weighted_average_precision(y,ref,np.ones(len(y)))
    cand_ap = weighted_average_precision(y,cand,np.ones(len(y)))
    point = np.r_[cand_ap-ref_ap,losses.mean(axis=0)]
    lower,upper,valid_counts = [],[],[]
    tail = (1-confidence_level)/2
    for j in range(3):
        values = samples[:,j]; values = values[np.isfinite(values)]
        valid_counts.append(len(values))
        quantiles = np.quantile(values,[tail,1-tail]) if len(values) else [None,None]
        lower.append(float(quantiles[0]) if len(values) else None)
        upper.append(float(quantiles[1]) if len(values) else None)
    warnings_list = []
    if len(blocks) < 10: warnings_list.append('fewer than ten calendar-day blocks; time uncertainty is weakly identified')
    if len(blocks) == 1: warnings_list.append('one day block provides no between-day variation')
    if min(valid_counts) < draws: warnings_list.append('AP intervals condition on resamples containing both outcome classes; undefined draw counts are retained')
    return {
        'endpoint_names':list(ENDPOINTS), 'difference':[float(v) if np.isfinite(v) else None for v in point],
        'ci_lower':lower, 'ci_upper':upper, 'valid_draws':valid_counts,
        'undefined_draws':[int(draws-v) for v in valid_counts], 'draws':int(draws),
        'seed':int(seed), 'confidence_level':float(confidence_level), 'samples':len(y),
        'time_blocks':len(blocks), 'block_labels':blocks.tolist(), 'block_sample_counts':counts.tolist(),
        'training_fits_per_method':1, 'resampling':'paired whole start-calendar-day multinomial bootstrap, sample-count weighted',
        'direction':'positive favors candidate: candidate-reference AP; reference-candidate Brier and log loss',
        'exploratory':True, 'multiple_comparison_adjustment':'none',
        'warnings':warnings_list,
    }
