"""Frozen, target-free ImageNet representations of existing flame captures."""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import io
import json
from pathlib import Path
import time

import numpy as np
from PIL import Image
import torch

from .visual_image_audit import CROP_XYXY, crop_bounds, load_capture_index


MEAN = np.asarray([.485, .456, .406], dtype=np.float32)
STD = np.asarray([.229, .224, .225], dtype=np.float32)
WEIGHT_URL = 'https://download.pytorch.org/models/resnet18-f37072fd.pth'


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path, value):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    tmp.replace(path)


def image_tensors(image):
    """Use the entire original ROI union; no overlay or augmentation is added.

    Fixed 224x224 bilinear resize deliberately preserves the full ROI instead of
    the ImageNet default center crop. It changes aspect ratio. RGB and grayscale
    use identical geometry and the pretrained model's channel normalization.
    """
    image = image.convert('RGB')
    roi = image.crop(crop_bounds(*image.size))
    views = (roi, roi.convert('L').convert('RGB'))
    arrays = []
    for view in views:
        pixels = np.asarray(view.resize((224, 224), Image.Resampling.BILINEAR), dtype=np.float32) / 255.
        arrays.append(torch.from_numpy(np.ascontiguousarray(((pixels - MEAN) / STD).transpose(2, 0, 1))))
    return tuple(arrays)


def _prepare(record):
    raw = Path(record['path']).read_bytes()
    if hashlib.sha256(raw).hexdigest() != record['source_sha256']:
        raise ValueError('source JPG bytes differ from recorded descriptor manifest')
    with Image.open(io.BytesIO(raw)) as image:
        if image.size != (record['source_width'], record['source_height']):
            raise ValueError('source image dimensions differ from manifest')
        return image_tensors(image)


def load_encoder(weight_path):
    from torchvision.models import resnet18
    if not sha256(weight_path).startswith('f37072fd'):
        raise ValueError('expected official ResNet18 ImageNet1K V1 weights')
    model = resnet18(weights=None)
    model.load_state_dict(torch.load(weight_path, map_location='cpu', weights_only=True), strict=True)
    model.fc = torch.nn.Identity()
    model.eval().requires_grad_(False)
    return model


def extract_embeddings(dataset_path, manifest_path, weight_path, output_dir, batch_size=16):
    if batch_size < 1:
        raise ValueError('batch_size must be positive')
    import torchvision
    torch.set_num_threads(2)
    torch.use_deterministic_algorithms(True)
    output = Path(output_dir).resolve()
    output.mkdir(parents=True, exist_ok=True)
    records, sample_capture_index = load_capture_index(dataset_path, manifest_path)
    protocol = {
        'frozen_before_extraction_unix': time.time(),
        'scope': 'target-free frozen ImageNet encoder; no plant label fine tuning or test-based feature selection',
        'encoder': 'torchvision resnet18 IMAGENET1K_V1, avgpool flattened, classifier removed, eval mode',
        'encoder_dimension': 512, 'views': ['rgb', 'gray'],
        'weights_url': WEIGHT_URL, 'weights_sha256': sha256(weight_path),
        'torch_version': torch.__version__, 'torchvision_version': torchvision.__version__,
        'crop_normalized_xyxy': list(CROP_XYXY),
        'resize': 'PIL bilinear to exactly 224x224 after crop, full ROI retained; aspect ratio changes; differs from official center-crop geometry',
        'gray': 'PIL RGB to L, then repeat to RGB before resize',
        'normalization_mean': MEAN.tolist(), 'normalization_std': STD.tolist(),
        'augmentation': None, 'device': 'cpu', 'threads': 2, 'batch_size': batch_size,
        'captures': len(records), 'samples': len(sample_capture_index),
        'input_hashes': {str(Path(p).resolve()): sha256(p) for p in [dataset_path, manifest_path]},
        'code_hashes': {str(p.resolve()): sha256(p) for p in [Path(__file__), Path(__file__).with_name('visual_image_audit.py')]},
        'source_mapping': 'exact dataset.visual_time_ns to manifest capture time; all JPEG hashes checked when decoded',
    }
    protocol_file = output / 'encoder_protocol.json'
    if protocol_file.exists():
        previous = json.loads(protocol_file.read_text())
        protocol['frozen_before_extraction_unix'] = previous['frozen_before_extraction_unix']
        if protocol != previous:
            raise ValueError('extraction differs from existing frozen protocol')
    else:
        write_json(protocol_file, protocol)
    completed = output / 'encoder_manifest.json'
    if completed.exists():
        saved = json.loads(completed.read_text())
        if saved['protocol_sha256'] != sha256(protocol_file) or saved['embeddings_sha256'] != sha256(output/'embeddings.npz'):
            raise ValueError('completed encoder artifacts changed')
        return saved
    encoder = load_encoder(weight_path)
    rgb = np.empty((len(records), 512), dtype=np.float32)
    gray = np.empty_like(rgb)
    started = time.monotonic()
    with ThreadPoolExecutor(max_workers=2) as pool, torch.inference_mode():
        for start in range(0, len(records), batch_size):
            stop = min(start + batch_size, len(records))
            prepared = list(pool.map(_prepare, records[start:stop]))
            for view, destination in ((0, rgb), (1, gray)):
                batch = torch.stack([value[view] for value in prepared])
                encoded = encoder(batch).cpu().numpy()
                if encoded.shape != (stop-start, 512) or not np.isfinite(encoded).all():
                    raise ValueError('invalid frozen encoder output')
                destination[start:stop] = encoded
            if start == 0 or stop == len(records) or (start // batch_size) % 20 == 0:
                progress = {'captures_done': stop, 'captures_total': len(records), 'elapsed_seconds': time.monotonic()-started}
                write_json(output/'encoder_progress.json', progress)
                print(json.dumps(progress), flush=True)
    destination = output/'embeddings.npz'
    np.savez_compressed(destination, capture_time_ns=np.asarray([r['time_ns'] for r in records], dtype=np.int64),
                        sample_capture_index=sample_capture_index, rgb=rgb, gray=gray)
    # Recompute representative complete batches using precisely the saved batch shape.
    audits = []
    with torch.inference_mode():
        for start in sorted({0, (len(records)//2//batch_size)*batch_size, ((len(records)-1)//batch_size)*batch_size}):
            stop = min(start+batch_size, len(records))
            prepared = [_prepare(record) for record in records[start:stop]]
            for view, name, expected in ((0, 'rgb', rgb), (1, 'gray', gray)):
                result = encoder(torch.stack([value[view] for value in prepared])).cpu().numpy()
                equal = bool(np.array_equal(result, expected[start:stop]))
                audits.append({'view': name, 'capture_start': start, 'capture_stop': stop,
                               'exact': equal, 'max_abs_difference': float(np.abs(result-expected[start:stop]).max())})
                if not equal:
                    raise ValueError('frozen encoder batch replay failed')
    # Save actual model inputs for inspection, not generated or altered flame scenes.
    from matplotlib import pyplot as plt
    chosen = [0, len(records)//2, len(records)-1]
    figure, axes = plt.subplots(2, 3, figsize=(9, 6), constrained_layout=True)
    for column, index in enumerate(chosen):
        prepared = _prepare(records[index])
        for row, tensor in enumerate(prepared):
            pixels = np.clip(tensor.numpy().transpose(1, 2, 0)*STD+MEAN, 0, 1)
            axes[row, column].imshow(pixels)
            axes[row, column].set_title(f"{records[index]['timestamp']}\n{'RGB' if row == 0 else 'Gray'}", fontsize=8)
            axes[row, column].axis('off')
    figure.savefig(output/'encoder_input_examples.png', dpi=150)
    plt.close(figure)
    result = {'status': 'completed', 'protocol_sha256': sha256(protocol_file),
              'embeddings_sha256': sha256(destination), 'weights_sha256': sha256(weight_path),
              'captures': len(records), 'samples': len(sample_capture_index),
              'source_files_checked': len(records), 'elapsed_seconds': time.monotonic()-started,
              'replay': audits, 'trained_on_project_targets': False,
              'rgb_shape': list(rgb.shape), 'gray_shape': list(gray.shape)}
    write_json(completed, result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dataset', required=True)
    parser.add_argument('--image-manifest', required=True)
    parser.add_argument('--weights', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--batch-size', type=int, default=16)
    args = parser.parse_args()
    extract_embeddings(args.dataset, args.image_manifest, args.weights, args.output, args.batch_size)


if __name__ == '__main__':
    main()
