"""Paired starting-point summaries of the frozen B/C evaluations."""
from __future__ import annotations
import argparse,csv,importlib.util,json
from pathlib import Path
import numpy as np
from .s8_cross_evaluation import ROOT,OUT,DESIGN,REF,MODELS,SEEDS,verify
from .ridge_policy_study import read_npz,write_json
from .frozen_mpc import file_sha256

METRIC_SOURCE=ROOT/'experiment_runs/factory_feedback_reassessment_v2_20261108/metrics.py'
spec=importlib.util.spec_from_file_location('saved_factory_metrics',METRIC_SOURCE)
metrics=importlib.util.module_from_spec(spec);spec.loader.exec_module(metrics)
EXTRA=('cost_temperature','cost_pressure','cost_steam','cost_oxygen','cost_movement','cost_violation',
       'primary_air_cumulative_change','induced_draft_cumulative_change')
NAMES=metrics.NAMES+EXTRA
VARIABLES=('temperature','steam','oxygen')


def csv_write(path,rows):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def wide_tables(folder,layer,summary,differences):
    mids=sorted({r['model'] for r in summary},key=lambda m:(('gru23',)+MODELS).index(m))
    for label,rows,keys,value in (
        ('metrics',summary,('method','horizon','metric'),'mean'),
        ('paired_differences',differences,('method','reference','horizon','metric'),'difference')):
        grouped={}
        for r in rows:
            key=tuple(r[k] for k in keys);grouped.setdefault(key,{})[r['model']]=r
        output=[]
        for key,by_model in grouped.items():
            row=dict(zip(keys,key))
            for mid in mids:
                for field in (value,'ci_low','ci_high'):row[mid+'_'+field]=by_model[mid][field]
            output.append(row)
        csv_write(folder/f'{layer}_{label}_by_model.csv',output)


def metric_values(a,inputs,h):
    np.testing.assert_array_equal(a['indices'],inputs['indices'])
    np.testing.assert_array_equal(a['initial_z_current'],inputs['z_current'])
    core,rolling,low,high=metrics.calculate(a['pred_cv'],inputs['z_hist'],inputs['z_current'],a['reward'],h)
    costs=np.column_stack([a['tracking_cost'][:,:h,j].astype(float).sum(1) for j in range(3)]+
        [a[k][:,:h].astype(float).sum(1) for k in ('oxygen_cost','movement_cost','violation_cost')])
    err=float(np.max(abs(costs.sum(1)+a['reward'][:,:h].astype(float).sum(1))))
    if err>1e-3:raise AssertionError('original reward decomposition')
    delta=a['u_path'][:,h-1]-a['initial_u']
    values=np.column_stack((core,costs,delta[:,0],delta[:,3]))
    return values,{'minimum_five_minute_proxy':float(rolling.min()),'point_low850_count':int(low.sum()),
        'any_point_low850_episodes':int(low.any((1,2)).sum()),'reward_decomposition_max_roundoff':err}


def collect(layer,partial=False):
    inputs=read_npz(REF/'inputs/val.npz');result={};audit=[];bindings={}
    mids=('gru23',) if layer=='B' else MODELS
    for mid in mids:
        if partial and not (OUT/f'trajectories/{layer}/{mid}').exists():continue
        for method in ('hold','bc','C0','S8'):
            for h in (10,50):
                samples=[]
                for seed in SEEDS if method=='bc' else (0,):
                    for rep in range(5) if layer=='C' else (0,):
                        path=OUT/f'trajectories/{layer}/{mid}/{method}/seed{seed}_rep{rep}.npz'
                        digest=file_sha256(path)
                        if digest!=json.loads(path.with_suffix('.json').read_text())['sha256']:raise AssertionError('trajectory hash')
                        bindings[str(path.relative_to(ROOT))]=digest
                        v,detail=metric_values(read_npz(path),inputs,h);samples.append(v)
                        audit.append(dict(layer=layer,model=mid,method=method,seed=seed,replicate=rep,horizon=h,**detail))
                # Average per-trajectory metrics, never average trajectories before SD.
                result[(mid,method,h)]=np.mean(samples,axis=0)
    return result,audit,bindings


def bootstrap_weights():
    rng=np.random.default_rng(20261108)
    ids=rng.integers(0,256,size=(10000,256));w=np.zeros((10000,256))
    np.add.at(w,(np.arange(10000)[:,None],ids),1/256)
    return w


def summaries(layer,data,w):
    summary=[];differences=[];ratios=[]
    for (mid,method,h),values in data.items():
        mean=values.mean(0);lo,hi=np.quantile(w@values,[.025,.975],axis=0)
        for j,name in enumerate(NAMES):summary.append(dict(layer=layer,model=mid,method=method,horizon=h,metric=name,
            mean=float(mean[j]),ci_low=float(lo[j]),ci_high=float(hi[j]),starts=256))
        for ref in ('hold','bc'):
            if method==ref:continue
            other=data[(mid,ref,h)];delta=values-other;dlo,dhi=np.quantile(w@delta,[.025,.975],axis=0)
            for j,name in enumerate(NAMES):differences.append(dict(layer=layer,model=mid,method=method,reference=ref,
                horizon=h,metric=name,difference=float(delta[:,j].mean()),ci_low=float(dlo[j]),ci_high=float(dhi[j])))
        if method in ('C0','S8'):
            for kind in ('detrended_sd','raw_sd'):
                for v in VARIABLES:
                    j=NAMES.index(kind+'_'+v);ref=data[(mid,'bc',h)][:,j]
                    ratio=float(values[:,j].mean()/ref.mean());lo,hi=np.quantile((w@values[:,j])/(w@ref),[.025,.975])
                    ratios.append(dict(layer=layer,model=mid,method=method,horizon=h,metric=kind+'_'+v,
                        ratio_to_BC=ratio,ci_low=float(lo),ci_high=float(hi)))
    return summary,differences,ratios


def position(B,C,w):
    grid=[];bchecks=[];design=[]
    for mid in MODELS:
        for v in VARIABLES:
            j=NAMES.index('detrended_sd_'+v);s=C[(mid,'S8',10)][:,j];b=C[(mid,'bc',10)][:,j]
            diff=s-b;lo,hi=np.quantile(w@diff,[.025,.975])
            grid.append(dict(model=mid,variable=v,S8=float(s.mean()),BC=float(b.mean()),
                difference=float(diff.mean()),ci_low=float(lo),ci_high=float(hi),passed=bool(s.mean()<=b.mean())))
    counts={v:sum(not r['passed'] for r in grid if r['variable']==v) for v in VARIABLES}
    cpass=sum(r['passed'] for r in grid)>=10 and max(counts.values())<2
    for v in VARIABLES:
        j=NAMES.index('detrended_sd_'+v);diff=B[('gru23','S8',10)][:,j]-B[('gru23','bc',10)][:,j]
        lo,hi=np.quantile(w@diff,[.025,.975])
        bchecks.append(dict(variable=v,difference=float(diff.mean()),ci_low=float(lo),ci_high=float(hi),
            noninferior_mean=bool(diff.mean()<=0),interval_contains_zero=bool(lo<=0<=hi)))
    bpass=sum(r['noninferior_mean'] for r in bchecks)>=2 and all(r['noninferior_mean'] or r['interval_contains_zero'] for r in bchecks)
    for v in VARIABLES:
        j=NAMES.index('detrended_sd_'+v)
        diff=np.mean([C[(m,'S8',10)][:,j]-C[(m,'C0',10)][:,j] for m in MODELS],axis=0)
        lo,hi=np.quantile(w@diff,[.025,.975])
        design.append(dict(variable=v,S8_minus_C0=float(diff.mean()),ci_low=float(lo),ci_high=float(hi),passed=bool(diff.mean()<0)))
    dpass=all(r['passed'] for r in design)
    return {'C':{'passed':bool(cpass),'passing_cells':sum(r['passed'] for r in grid),'worse_models_per_variable':counts,'details':grid},
        'B':{'passed':bool(bpass),'details':bchecks},'design_effect':{'passed':bool(dpass),'details':design},
        'positioning':'controller' if cpass and bpass and dpass else 'framework',
        'meaning':'writing-position decision only; not plant validation, deployment permission, or proof of safety'}


def figures(ratios,kind='detrended_sd'):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    for layer,mids in (('B',('gru23',)),('C',MODELS)):
        mids=tuple(m for m in mids if any(r['layer']==layer and r['model']==m for r in ratios))
        if not mids:continue
        for h in (10,50):
            columns=min(2,len(mids));nrows=(len(mids)+columns-1)//columns
            fig,axes=plt.subplots(nrows,columns,figsize=(4*columns,3.6*nrows+.2),squeeze=False,sharey=True)
            for ax,mid in zip(axes.flat,mids):
                for j,(method,color) in enumerate((('C0','#1f77b4'),('S8','#ff7f0e'))):
                    vals=[next(r for r in ratios if (r['layer'],r['model'],r['method'],r['horizon'],r['metric'])==(layer,mid,method,h,kind+'_'+v)) for v in VARIABLES]
                    x=np.arange(3)+(j-.5)*.32;y=np.array([r['ratio_to_BC'] for r in vals]);lo=np.array([r['ci_low'] for r in vals]);hi=np.array([r['ci_high'] for r in vals])
                    ax.bar(x,y,width=.3,label=method,color=color)
                    # Bootstrap intervals need not enclose the point estimate exactly.
                    ax.vlines(x,lo,hi,color='black',linewidth=1);ax.scatter(x,lo,marker='_',color='black');ax.scatter(x,hi,marker='_',color='black')
                ax.axhline(1,color='gray',ls='--',lw=1);ax.set_xticks(range(3),['Temperature','Steam','Oxygen']);ax.set_title(mid);ax.grid(axis='y',alpha=.15)
            for ax in axes[:,0]:ax.set_ylabel(('Detrended' if kind=='detrended_sd' else 'Raw')+' SD / BC')
            for ax in list(axes.flat)[len(mids):]:ax.set_visible(False)
            list(axes.flat)[len(mids)-1].legend(frameon=False)
            fig.suptitle(f'{layer}: {h}-step feedback evaluation\nExploratory 95% intervals',fontsize=11);fig.tight_layout()
            suffix='sd_ratio' if kind=='detrended_sd' else 'raw_sd_ratio'
            fig.savefig(OUT/f'report/{layer}_{suffix}_h{h}.png',dpi=180);fig.savefig(OUT/f'report/{layer}_{suffix}_h{h}.pdf');plt.close(fig)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--layer',choices=('B','C','both'),default='both');ap.add_argument('--partial',action='store_true');args=ap.parse_args()
    verify();folder=OUT/'report';folder.mkdir(exist_ok=True)
    w=bootstrap_weights();all_summary=[];all_differences=[];all_ratios=[];all_audit=[];bindings={};data={}
    for layer in ('B','C') if args.layer=='both' else (args.layer,):
        data[layer],audit,bound=collect(layer,args.partial);s,d,r=summaries(layer,data[layer],w)
        all_summary+=s;all_differences+=d;all_ratios+=r;all_audit+=audit;bindings.update(bound)
        np.savez_compressed(folder/f'{layer}_per_start_metrics.npz',names=np.array(NAMES),
            **{f'{m}__{g}__h{h}':v for (m,g,h),v in data[layer].items()})
        csv_write(folder/f'{layer}_metrics.csv',s);csv_write(folder/f'{layer}_paired_differences.csv',d);csv_write(folder/f'{layer}_sd_ratios.csv',r)
        wide_tables(folder,layer,s,d)
    csv_write(folder/f'{args.layer}_trajectory_audit.csv',all_audit)
    if args.layer=='both':
        missing=[m for m in MODELS if (m,'S8',10) not in data['C']]
        result=position(data['B'],data['C'],w) if not missing else {'status':'incomplete','missing_C_models':missing,'positioning':'not_fully_assessed'}
        write_json(folder/'positioning.json',result);figures(all_ratios);figures(all_ratios,'raw_sd')
        print(json.dumps(result,ensure_ascii=False,indent=2))
    write_json(folder/f'{args.layer}_analysis_bindings.json',{'script_sha256':file_sha256(Path(__file__)),
        'metrics_sha256':file_sha256(METRIC_SOURCE),'input_trajectories':bindings,
        'no_new_control_simulation':True,'test_rows_used':0})

if __name__=='__main__':main()
