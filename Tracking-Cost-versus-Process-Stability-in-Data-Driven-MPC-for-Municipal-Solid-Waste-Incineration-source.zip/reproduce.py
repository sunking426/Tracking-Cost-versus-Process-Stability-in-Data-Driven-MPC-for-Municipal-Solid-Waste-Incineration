#!/usr/bin/env python3
"""Command-line entry point for the manuscript experiments."""
from reproduction.cli import main
if __name__ == '__main__':
    main()
