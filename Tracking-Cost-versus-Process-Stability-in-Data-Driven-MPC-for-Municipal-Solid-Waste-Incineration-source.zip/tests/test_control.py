"""Contract tests only; these synthetic fixtures are not experimental results."""
import json
import numpy as np
import pytest
import torch

from mswi_experiments.control import (
    TwinEnv, project_normalized_actions, project_state_actions, reward_and_violation,
)
from mswi_experiments.models import Actor, Twin
from mswi_experiments.rl import build_logged_transitions, train_td3
from mswi_experiments.evaluation import (
    select_evaluation_starts, trajectory_metrics, offline_advisory_replay,
)


def fixture_data():
    n = 40
    z = np.tile(np.asarray([1000.] * 6 + [-50., 32., 3.8], dtype=np.float32), (n, 1))
    u = np.zeros((n, 8), dtype=np.float32)
    v = np.zeros((n, 4), dtype=np.float32)
    data = {
        "u_hist": np.repeat(u[:, None], 11, axis=1),
        "z_hist": np.repeat(z[:, None], 10, axis=1),
        "visual": v, "u_current": u, "z_current": z, "z_prev": z.copy(),
        "z_target": z.copy(), "action": np.zeros_like(u),
        "train_idx": np.arange(24), "val_idx": np.arange(24, 28),
        "test_idx": np.arange(28, 40), "next_idx": np.r_[np.arange(1, n), -1],
        "time_ns": np.arange(n, dtype=np.int64) * 60_000_000_000,
    }
    stats = {
        "u_mean": [0.] * 8, "u_scale": [1.] * 8, "z_mean": z[0].tolist(),
        "z_scale": [1.] * 9, "v_mean": [0.] * 4, "v_scale": [1.] * 4,
        "delta_mean": [0.] * 9, "delta_scale": [1.] * 9,
        "action_scale": [1.] * 8, "action_bound": [.25] * 8,
        "u_low": [-1.] * 8, "u_high": [1.] * 8,
        "control_low": [800., -100., 0., 0.], "control_high": [1200., 0., 100., 10.],
    }
    return data, stats


class FixedMemory:
    def query(self, u_hist, z_hist):
        return torch.zeros((len(u_hist), 4)), np.zeros(len(u_hist), dtype=np.int64)


def zero_twin(stats):
    model = Twin(stats, "multi", hidden=8)
    with torch.no_grad():
        model.decoder.weight.zero_()
        model.decoder.bias.zero_()
    return model


def test_negative_reward_and_interval():
    data, stats = fixture_data()
    z = data["z_current"][:1].copy()
    reward, violation, _ = reward_and_violation(z, np.zeros((1, 8)), stats)
    np.testing.assert_allclose(reward, 0, atol=1e-6)
    assert not violation[0]
    z[:, :6] = 1050
    z[:, 8] = 4.5
    reward, _, _ = reward_and_violation(z, np.ones((1, 8)), stats)
    np.testing.assert_allclose(reward, -2.05, atol=1e-6)
    z[0, 0] = np.nan
    with pytest.raises(FloatingPointError, match="Nonfinite"):
        reward_and_violation(z, np.ones((1, 8)), stats)


def test_step_history_action_bounds_and_reset_validation():
    data, stats = fixture_data()
    stats["u_high"] = [.1] * 8
    env = TwinEnv(zero_twin(stats), FixedMemory(), stats, data, {})
    initial = env.reset(np.asarray([0, 1]))
    following, reward, info = env.step(np.ones((2, 8)))
    np.testing.assert_allclose(following["u_current"], .1, atol=1e-6)
    np.testing.assert_allclose(info["executed_action"], .1, atol=1e-6)
    np.testing.assert_allclose(following["u_hist"][:, -1], following["u_current"])
    np.testing.assert_allclose(following["z_hist"][:, -1], initial["z_current"])
    assert np.all(reward <= 0)
    data["u_current"][0, 0] = 2.
    with pytest.raises(ValueError, match="outside"):
        env.reset(np.asarray([0]))


def test_state_action_projection_respects_mv_limits_and_actor_gradients():
    _, stats = fixture_data()
    stats["u_mean"] = [10.] * 8
    stats["u_scale"] = [2.] * 8
    stats["u_low"], stats["u_high"] = [9.] * 8, [11.] * 8
    stats["action_scale"] = [2.] * 8
    stats["action_bound"] = [.5] * 7 + [0.]
    current_u = torch.tensor([[11., 10.9, 9., 9.1, 10., 10., 10., 10.]])
    # Unrelated latent/CV values must not be used to recover the latest MV.
    state = torch.cat((torch.full((1, 5), 100.), (current_u - 10.) / 2.,
                       torch.full((1, 9), -100.)), dim=1)
    requested = torch.tensor([[.8, .8, -.8, -.8, .1, -.1, .9, .8]], requires_grad=True)
    projected = project_state_actions(requested, state, stats)
    np.testing.assert_allclose(projected.detach(), [[0., .05, 0., -.05, .1, -.1, .25, 0.]], atol=1e-6)
    projected.sum().backward()
    np.testing.assert_allclose(requested.grad, [[0., 0., 0., 0., 1., 1., 0., 0.]], atol=1e-6)
    _, physical, next_u = project_normalized_actions(requested.detach(), current_u, stats)
    np.testing.assert_allclose(physical, projected.detach() * 2., atol=1e-6)
    assert torch.all(next_u <= 11.) and torch.all(next_u >= 9.)


def test_logged_and_generated_boundary_actions_share_execution_semantics():
    data, stats = fixture_data()
    data["u_current"][:] = .9
    data["u_hist"][:] = .9
    data["u_current"][1::2] = 1.
    data["u_hist"][1::2] = 1.
    data["action"][:-1] = np.diff(data["u_current"], axis=0)
    twin = zero_twin(stats)
    logged = build_logged_transitions(data, stats, twin)
    position = int(np.flatnonzero(logged.indices == 0)[0])
    env = TwinEnv(twin, FixedMemory(), stats, data, {})
    env.reset(np.asarray([0]))
    _, _, info = env.step(np.ones((1, 8)))
    np.testing.assert_allclose(logged.actions[position], info["normalized_executed_action"][0], atol=1e-6)
    projected = project_state_actions(torch.ones((1, 8)), logged.states[position:position + 1], stats)
    np.testing.assert_allclose(projected, info["normalized_executed_action"], atol=1e-6)


def test_count_aggregation_and_distinct_paired_starts():
    data, stats = fixture_data()
    starts, metadata = select_evaluation_starts(data, stats, episodes=3, horizon=2)
    assert len(set(starts)) == 3
    assert np.all(np.diff(data["time_ns"][starts]) >= 2 * 60_000_000_000)
    reward = np.asarray([[-1., -2.], [-2., -3.]])
    cv = np.tile(np.asarray([1000., -50., 32., 3.8]), (2, 2, 1))
    metrics = trajectory_metrics(reward, cv, np.asarray([[False, False], [True, False]]))
    assert metrics["stable_episodes"] == 1
    assert metrics["stability_rate"] == .5
    assert metrics["violation_rate"] == .25
    assert metrics["mean_return"] == -4.


def test_logged_replay_excludes_split_crossing():
    data, stats = fixture_data()
    logged = build_logged_transitions(data, stats, zero_twin(stats), batch_size=5)
    assert 23 not in logged.indices
    assert len(logged.indices) == 23
    assert logged.states.shape[1] == 25
    assert (logged.rewards <= 0).all()


def test_td3_really_updates_critics_and_saves_targets(tmp_path):
    data, stats = fixture_data()
    twin = zero_twin(stats)
    env = TwinEnv(twin, FixedMemory(), stats, data, {})
    actor = Actor(twin.state_dim, 8, hidden=8)
    config = {"training": {"threads": 1}, "rl": {
        "updates": 4, "batch_size": 4, "rollout_batch_size": 2,
        "rollout_horizon": 2, "rollout_every": 2, "critic_hidden": 8, "log_every": 2,
    }}
    learned, metrics = train_td3(actor, twin, env, data, stats, 7, config, tmp_path)
    assert metrics["updates"] == 4 and metrics["actor_updates"] == 2
    assert metrics["generated_transitions"] == 8
    saved = torch.load(tmp_path / "training_state.pt", weights_only=True)
    assert "critic_state_dict" in saved and "target_critic_state_dict" in saved
    assert "target_actor_state_dict" in saved
    assert any(not torch.equal(value, saved["target_critic_state_dict"][name])
               for name, value in saved["critic_state_dict"].items())
    assert np.isfinite(metrics["final_training_row"]["critic_loss"])
    assert (tmp_path / "actor.pt").exists()


def test_logged_only_td3_never_calls_surrogate_and_uses_no_generated_data(tmp_path):
    data, stats = fixture_data()
    twin = zero_twin(stats)
    actor = Actor(twin.state_dim, 8, hidden=8)
    class ForbiddenEnvironment:
        def reset(self, *args, **kwargs):
            raise AssertionError("A logged-only learner must not request simulator transitions")
        def step(self, *args, **kwargs):
            raise AssertionError("A logged-only learner must not step a simulator")
    config = {"training": {"threads": 1}, "rl": {
        "updates": 4, "batch_size": 4, "critic_hidden": 8,
        "synthetic_fraction": 0., "rollout_batch_size": 0,
        "rollout_horizon": 0, "rollout_every": 0, "log_every": 2,
    }}
    learned, metrics = train_td3(actor, twin, ForbiddenEnvironment(), data, stats, 7, config, tmp_path)
    assert metrics["generated_transitions"] == 0
    assert metrics["sampled_synthetic_fraction"] == 0
    assert metrics["replay_mode"] == "logged_only"
    assert metrics["actor_updates"] == 2
    assert any(not torch.equal(old, new) for old, new in zip(actor.parameters(), learned.parameters()))


def test_td3_queries_critics_and_bc_with_executed_boundary_actions(tmp_path, monkeypatch):
    import mswi_experiments.rl as rl
    data, stats = fixture_data()
    data["u_current"][:] = 1.
    data["u_hist"][:] = 1.
    twin = zero_twin(stats)
    actor = Actor(twin.state_dim, 8, hidden=8)
    with torch.no_grad():
        for parameter in actor.parameters():
            parameter.zero_()
        actor.gate_head.bias.fill_(2.)
        actor.mag_head[-1].bias.fill_(2.)
    critic_actions = []
    original_critic = rl.TwinCritic

    class ObservedCritic(original_critic):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            def record_actions(module, inputs):
                critic_actions.append(inputs[0][:, -8:].detach().clone())
            self.q1.register_forward_pre_hook(record_actions)
            self.q2.register_forward_pre_hook(record_actions)

    monkeypatch.setattr(rl, "TwinCritic", ObservedCritic)
    config = {"training": {"threads": 1}, "rl": {
        "updates": 2, "batch_size": 4, "rollout_batch_size": 2,
        "rollout_horizon": 1, "rollout_every": 2, "critic_hidden": 8,
        "policy_delay": 1, "policy_noise": 0., "exploration_noise": 0.,
    }}
    env = TwinEnv(twin, FixedMemory(), stats, data, {})
    _, metrics = train_td3(actor, twin, env, data, stats, 7, config, tmp_path)
    # The actor requests outward positive increments, but every current MV is
    # already at its upper bound. Target, sampled and actor Q queries must all
    # contain zero executed increments, and the projected BC error is zero.
    assert len(critic_actions) >= 10
    assert all(torch.count_nonzero(actions) == 0 for actions in critic_actions)
    assert metrics["final_training_row"]["bc_loss"] == 0.
    assert "executed" in metrics["critic_action_semantics"]


def test_offline_replay_does_not_invent_operator_outcomes(tmp_path):
    data, stats = fixture_data()
    twin = zero_twin(stats)
    actor = Actor(twin.state_dim, 8, hidden=8)
    with torch.no_grad():
        for parameter in actor.parameters():
            parameter.zero_()
    metrics = offline_advisory_replay(
        actor, twin, data, stats, {"evaluation": {"advisory_steps": 5}}, tmp_path, 11
    )
    assert metrics["observed_steps"] == 5
    assert metrics["direction_denominator_active"] == 0
    assert metrics["direction_agreement_active_logged_channels"] is None
    assert metrics["operator_adoption_rate"] is None and metrics["alarm_rate"] is None
    assert metrics["action_support_ratio"] == 1.0
    assert metrics["mean_normalized_action_deviation"] == 0.0
