import numpy as np
import pytest
from mswi_experiments.mpc_stability import stability_components,StabilityCEM,choose_stability
from mswi_experiments.mpc_stability_study import shared,REF,SAMPLE_KEYS
from mswi_experiments.mpc_temperature import TemperatureCEM
from mswi_experiments.ridge_policy import RidgePolicyEnv
from mswi_experiments.ridge_policy_study import read_npz


def test_stability_uses_current_and_absolute_signed_increments():
    cur=np.zeros((1,9));cur[0,7:9]=[30,3.7]
    pred=np.broadcast_to(cur[:,None,None],(1,2,3,9)).copy()
    pred[0,0,:,7]=[31,29,32];pred[0,0,:,8]=[3.8,3.6,3.9]
    f,o=stability_components(pred,cur)
    np.testing.assert_allclose(f,[[1.2,0]],atol=1e-12)
    np.testing.assert_allclose(o,[[1.2,0]],atol=1e-12)
    cur[0,7]=35;f,_=stability_components(pred,cur)
    assert f[0,0]==pytest.approx((4+2+3)/5)
    with pytest.raises(ValueError):stability_components(pred,np.zeros((2,9)))


def small():
    row=read_npz(REF/'inputs/val.npz');return {k:row[k][[0,127]] for k in SAMPLE_KEYS}


def test_lambda_zero_matches_old_C_and_shared_noise():
    parent,e,full=shared();s=small();args=(s['u_hist'],s['z_hist'],s['z_current'],s['time_ns'],s['indices'],2)
    old=TemperatureCEM(full,e,4);a,od=old.plan(*args)
    fingerprints=[]
    for w in (0,1,2,4,8):
        new=StabilityCEM(full,e,w,parent);request,d=new.plan(*args);fingerprints.append(d['noise_sha256'])
        if w==0:
            np.testing.assert_array_equal(request,a)
            for k in od:np.testing.assert_array_equal(d[k],od[k])
        np.testing.assert_array_equal(d['selected_planning_score'],d['selected_original_return']-3*d['selected_temperature_cost']-w*d['selected_stability_cost'])
    for f in fingerprints:np.testing.assert_array_equal(f,od['noise_sha256'])


def test_candidate_penalty_matches_executed_standard_feedback():
    parent,e,full=shared();s=small();planner=StabilityCEM(full,e,8,parent)
    plans=np.random.default_rng(88).uniform(-1,1,(2,3,10,2));plans[:,0]=0
    score,original,jt,jf,jo=planner.objective_components(plans,s['u_hist'],s['z_hist'],s['z_current'],s['time_ns'])
    old=TemperatureCEM(full,e,4);oldscore=old.candidate_metrics(plans,s['u_hist'],s['z_hist'],s['z_current'],s['time_ns'])[0]
    np.testing.assert_allclose(score,oldscore-8*(jf+jo),atol=1e-12,rtol=0)
    for j in range(3):
        env=RidgePolicyEnv(full,e,horizon=10);env.reset(options={'inputs':s});r=np.zeros(2);t=np.zeros(2);f=np.zeros(2);o=np.zeros(2);previous=s['z_current'].copy()
        for k in range(10):
            _,reward,_,_,info=env.step(plans[:,j,k]);r+=reward.astype(float);t+=info['tracking_cost'][:,0].astype(float)
            next_z=info['pred_cv'];f+=abs(next_z[:,7]-previous[:,7])/5;o+=abs(next_z[:,8]-previous[:,8])/.5;previous=next_z
        for observed,expected in [(original[:,j],r),(jt[:,j],t),(jf[:,j],f),(jo[:,j],o),(score[:,j],r-3*t-8*(f+o))]:np.testing.assert_allclose(observed,expected,atol=1e-5,rtol=0)


def test_selection_both_gates_maximin_tie_and_no_old_cost_floor():
    ref=np.tile([-30,50,20,1,.2,.1],(4,1)).astype(float);bc=np.tile([.1,.05],(4,1))
    cand={}
    for w in (0,1,2,4,8):
        r=ref.copy();r[:,0]+=.3;v=bc.copy();cand[w]=(r,v)
    cand[0][1][0,0]+=.001
    result=choose_stability(ref,bc,cand)
    assert result['recommended_lambda']==1  # small positive gain sufficient; smaller lambda wins tie
    cand[8][0][:,0]+=1
    assert choose_stability(ref,bc,cand)['recommended_lambda']==8
    cand[8][0][0,2]=1.011*ref[0,2]
    assert choose_stability(ref,bc,cand)['recommended_lambda']==1
    for w in cand:cand[w][1][2,1]+=.001
    result=choose_stability(ref,bc,cand)
    assert result['recommended_lambda'] is None and result['retained_reference_lambda']==0


def test_stability_zero_reference_has_no_tolerance_and_all_models_must_gain():
    ref=np.tile([-30,50,20,1,.2,.1],(4,1)).astype(float);r=ref.copy();r[:,0]+=1
    bc=np.zeros((4,2));v=bc.copy();v[3,1]=1e-12
    assert choose_stability(ref,bc,{1:(r,v)})['recommended_lambda'] is None
    v[:]=0;r[2,0]=ref[2,0]
    assert choose_stability(ref,bc,{1:(r,v)})['recommended_lambda'] is None
