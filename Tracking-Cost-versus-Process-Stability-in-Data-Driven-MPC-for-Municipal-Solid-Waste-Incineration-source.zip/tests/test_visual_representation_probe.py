import json

import numpy as np
import pytest

from mswi_experiments.data import MINUTE_NS
from mswi_experiments.visual_representation_probe import (
    _comparison_priority, fit_capture_pca, freeze_protocol, origin_design,
    validate_capture_inputs, validate_encoder_artifact, validate_null_donors,
)


def fixture_data():
    n = 12
    mapping = np.repeat(np.arange(6), 2)
    capture_times = (np.arange(6) * 2 - 1) * MINUTE_NS
    data = {"time_ns": np.arange(n) * MINUTE_NS,
            "visual_time_ns": capture_times[mapping],
            "train_idx": np.arange(4), "val_idx": np.arange(4, 8), "test_idx": np.arange(8, 12),
            "u_hist": np.zeros((n, 11, 8)), "z_hist": np.zeros((n, 10, 9))}
    rng = np.random.default_rng(4)
    embeddings = {"capture_time_ns": capture_times, "sample_capture_index": mapping,
                  "rgb": rng.normal(size=(6, 512)), "gray": rng.normal(size=(6, 512))}
    quality = {"capture_time_ns": capture_times, "sample_capture_index": mapping,
               "quality": rng.normal(size=(6, 2)), "columns": np.array(["brightness", "contrast"])}
    return data, embeddings, quality


def test_unique_train_pca_ignores_duplicate_weight_and_heldout_values():
    rng = np.random.default_rng(14)
    x = rng.normal(size=(10, 6))
    mapping = np.array([0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    train_rows = np.arange(7)
    fitted, scores = fit_capture_pca(x, mapping, train_rows, 3)
    np.testing.assert_array_equal(fitted["train_capture_indices"], [0, 1, 2, 3])
    np.testing.assert_allclose(fitted["mean"], x[:4].mean(axis=0), rtol=0, atol=0)
    altered = x.copy()
    altered[4:] += 1e6
    fit2, _ = fit_capture_pca(altered, mapping, train_rows, 3)
    np.testing.assert_array_equal(fit2["components"], fitted["components"])
    np.testing.assert_array_equal(fit2["mean"], fitted["mean"])
    np.testing.assert_array_equal(scores, (x - fitted["mean"]) @ fitted["components"].T)
    with pytest.raises(ValueError, match="unique training"):
        fit_capture_pca(x, mapping, train_rows, 5)


def test_capture_validation_matches_frozen_selection_and_rejects_future():
    data, embeddings, quality = fixture_data()
    aligned, columns, partitions = validate_capture_inputs(data, embeddings, quality)
    np.testing.assert_array_equal(aligned, quality["quality"])
    assert list(columns) == ["brightness", "contrast"]
    assert {k: len(v) for k, v in partitions.items()} == {"train": 2, "val": 2, "test": 2}
    changed = dict(data)
    changed["time_ns"] = data["time_ns"].copy()
    changed["time_ns"][4] -= MINUTE_NS
    with pytest.raises(ValueError, match="cutoff"):
        validate_capture_inputs(changed, embeddings, quality)
    bad = dict(quality)
    bad["capture_time_ns"] = quality["capture_time_ns"] + 1
    with pytest.raises(ValueError, match="missing"):
        validate_capture_inputs(data, embeddings, bad)


def test_capture_validation_rejects_cross_split_repeated_capture():
    data, embeddings, quality = fixture_data()
    data["train_idx"] = np.array([0, 1, 2, 3, 4])
    with pytest.raises(ValueError, match="multiple outer"):
        validate_capture_inputs(data, embeddings, quality)


def test_null_donors_preserve_capture_groups_and_reject_cross_partition():
    data, embeddings, _ = fixture_data()
    donors = np.array([2, 2, 0, 0, 6, 6, 4, 4, 10, 10, 8, 8])
    safe, meta = validate_null_donors(data, embeddings["sample_capture_index"], donors)
    np.testing.assert_array_equal(safe, donors)
    assert all(v["future_donor_fraction"] == .5 for v in meta.values())
    broken = donors.copy()
    broken[0] = 4
    with pytest.raises(ValueError, match="same outer"):
        validate_null_donors(data, embeddings["sample_capture_index"], broken)
    broken = donors.copy()
    broken[0] = 0
    with pytest.raises(ValueError, match="share null donor"):
        validate_null_donors(data, embeddings["sample_capture_index"], broken)


def test_incremental_design_holds_quality_timing_fixed_under_null():
    data, _, _ = fixture_data()
    n = len(data["time_ns"])
    variants = {"timing4": np.arange(n * 4).reshape(n, 4), "original52": np.ones((n, 52))}
    features = {"quality": np.ones((n, 12)) * 8, "rgb32": np.ones((n, 32)) * 3,
                "gray32": np.ones((n, 32)) * 5, "null_rgb32": np.ones((n, 32)) * 7}
    rows = np.array([0, 3, 8])
    baseline = origin_design(data, variants, features, "quality", rows)
    rgb = origin_design(data, variants, features, "rgb32", rows)
    null = origin_design(data, variants, features, "null_rgb32", rows)
    assert baseline.shape == (3, 194)
    assert rgb.shape == null.shape == (3, 226)
    np.testing.assert_array_equal(rgb[:, :194], baseline)
    np.testing.assert_array_equal(null[:, :194], baseline)
    assert np.all(rgb[:, 194:] == 3) and np.all(null[:, 194:] == 7)
    assert origin_design(data, variants, features, "sensor", rows).shape[1] == 178
    assert origin_design(data, variants, features, "old52", rows).shape[1] == 234


def test_protocol_freeze_and_primary_scope(tmp_path):
    path = tmp_path / "protocol.json"
    first = freeze_protocol(path, {"pca": 32, "inputs": {"a": "sha"}})
    assert first["frozen_before_fitting_unix"] > 0
    assert freeze_protocol(path, {"pca": 32, "inputs": {"a": "sha"}}) == first
    with pytest.raises(ValueError, match="frozen protocol"):
        freeze_protocol(path, {"pca": 16, "inputs": {"a": "sha"}})
    assert json.loads(path.read_text()) == first
    priority = _comparison_priority(5, "rgb32", "quality")
    assert priority["steam"].endswith("primary") and priority["oxygen"].endswith("primary")
    assert priority["temperature"] == priority["pressure"] == "exploratory_secondary"
    assert all(v == "exploratory_secondary" for v in _comparison_priority(10, "rgb32", "quality").values())


def test_encoder_manifest_rejects_incomplete_or_tampered_embeddings(tmp_path):
    from mswi_experiments.visual_representation_probe import _sha

    archive = tmp_path / "embeddings.npz"
    np.savez_compressed(archive, rgb=np.ones((2, 512)))
    manifest = tmp_path / "encoder_manifest.json"
    record = {"status": "running", "embeddings_sha256": _sha(archive)}
    manifest.write_text(json.dumps(record))
    with pytest.raises(ValueError, match="completed run"):
        validate_encoder_artifact(manifest, archive)
    record["status"] = "completed"
    manifest.write_text(json.dumps(record))
    assert validate_encoder_artifact(manifest, archive) == record
    np.savez_compressed(archive, rgb=np.zeros((2, 512)))
    with pytest.raises(ValueError, match="does not match"):
        validate_encoder_artifact(manifest, archive)
    record.pop("embeddings_sha256")
    manifest.write_text(json.dumps(record))
    with pytest.raises(ValueError, match="does not match"):
        validate_encoder_artifact(manifest, archive)


def test_synthetic_complete_probe_freezes_before_pca_and_replays(tmp_path, monkeypatch):
    import mswi_experiments.visual_representation_probe as probe

    rng = np.random.default_rng(39)
    n = 220
    mapping = np.repeat(np.arange(n // 2), 2)
    capture_times = (2 * np.arange(n // 2) - 1) * MINUTE_NS
    data = {"time_ns": np.arange(n) * MINUTE_NS, "visual_time_ns": capture_times[mapping],
            "train_idx": np.arange(100), "val_idx": np.arange(100, 160), "test_idx": np.arange(160, n),
            "u_hist": rng.normal(size=(n, 11, 8)), "z_hist": rng.normal(size=(n, 10, 9)),
            "z_prev": rng.normal(size=(n, 9)), "next_idx": np.r_[np.arange(1, n), -1]}
    data["z_target"] = data["z_prev"] + rng.normal(size=(n, 9)) * .1
    variants = {"timing4": rng.normal(size=(n, 4)), "original52": rng.normal(size=(n, 52))}
    donors = np.full(n, -1, dtype=np.int64)
    for part in probe.PARTITIONS:
        rows = data[part + "_idx"]
        donor_first = rows[::2][::-1]
        donors[rows] = np.repeat(donor_first, 2)
    old = tmp_path / "old"
    old.mkdir()
    np.savez_compressed(old / "feature_variants.npz", **variants)
    np.savez_compressed(old / "feature_metadata.npz", null_donor_sample_index=donors)
    base_path = tmp_path / "base.json"
    base_path.write_text("{}\n")
    old_protocol = {"input_hashes": {str(base_path): probe._sha(base_path)},
                    "feature_archive_sha256": probe._sha(old / "feature_variants.npz")}
    (old / "protocol.json").write_text(json.dumps(old_protocol))
    np.savez_compressed(tmp_path / "embeddings.npz", capture_time_ns=capture_times,
                        sample_capture_index=mapping, rgb=rng.normal(size=(n // 2, 512)),
                        gray=rng.normal(size=(n // 2, 512)))
    np.savez_compressed(tmp_path / "quality.npz", capture_time_ns=capture_times,
                        quality=rng.normal(size=(n // 2, 12)), columns=np.array([f"q{i}" for i in range(12)]),
                        sample_capture_index=mapping)
    (tmp_path / "encoder.json").write_text(json.dumps({"source": "synthetic test fixture", "status": "completed",
                                                       "embeddings_sha256": probe._sha(tmp_path / "embeddings.npz")}))
    config = {"base_config": "base.json", "embeddings_file": "embeddings.npz", "quality_file": "quality.npz",
              "encoder_manifest": "encoder.json", "output_dir": "new", "bootstrap_draws": 16}
    config_path = tmp_path / "config.json"
    config_path.write_text(json.dumps(config))
    base = {"diagnostics": {"bootstrap_draws": 16, "bootstrap_seed": 4, "confidence_level": .95}}
    monkeypatch.setattr(probe, "load_study", lambda _: (base, data, {}, variants,
                         {"null_donor_sample_index": donors}, old))
    original_pca = probe.fit_capture_pca
    pca_calls = []

    def checked_pca(*args, **kwargs):
        assert (tmp_path / "new/probe/protocol.json").exists()
        pca_calls.append(True)
        return original_pca(*args, **kwargs)

    monkeypatch.setattr(probe, "fit_capture_pca", checked_pca)
    result = probe.run_representation_probe(config_path)
    assert result["status"] == "completed" and len(pca_calls) == 2
    output = tmp_path / "new/probe"
    features = probe._archive(output / "prepared_features.npz")
    completion = json.loads((output / "fitting_completed.json").read_text())
    assert completion["fits"] == 21 and completion["test_predictions_written"] is False
    for horizon in probe.HORIZONS:
        assert len(result["horizons"][str(horizon)]["methods"]) == 7
        for method in probe.METHODS:
            folder = output / f"horizon_{horizon:02d}" / method
            fitted = probe._archive(folder / "ridge_weights.npz")
            for part in probe.PARTITIONS:
                saved = probe._archive(folder / f"{part}_predictions.npz")
                replay = probe.apply_direct_ridge(fitted, probe.origin_design(data, variants, features, method, saved["indices"]), saved["origin_previous"])
                np.testing.assert_array_equal(replay, saved["pred"])
                assert (folder / f"{part}_predictions.npz").stat().st_mtime >= completion["completed_unix"]
    with pytest.raises(FileExistsError, match="immutable"):
        probe.run_representation_probe(config_path)
