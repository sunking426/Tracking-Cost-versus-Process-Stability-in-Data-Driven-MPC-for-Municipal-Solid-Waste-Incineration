import copy
import csv
from pathlib import Path
import tempfile
import unittest

import numpy as np

from mswi_experiments.data import FEATURE_COLUMNS, MINUTE_NS, read_visual_features
from mswi_experiments.visual_diagnostics_features import STATIC_COLUMNS, build_visual_variants


class TestVisualDiagnosticsFeatures(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.path = Path(self.temporary.name) / "features.csv"
        self.base = int(np.datetime64("2025-04-01T00:00:00", "ns").astype(np.int64))
        # Deliberately irregular: count-based and fixed-duration histories differ.
        self.minutes = [0, 2, 9, 20, 59, 60, 65, 80, 100, 125]
        with self.path.open("w", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=[*FEATURE_COLUMNS, "time", "img_name", "feature_source_start_time"])
            writer.writeheader()
            for index, minute in enumerate(self.minutes):
                stamp = str(np.datetime64(self.base + minute * MINUTE_NS, "ns")).replace("T", " ")[:19]
                row = {name: float(index * 10 + position) for position, name in enumerate(FEATURE_COLUMNS)}
                for area in range(1, 5):
                    row[f"ft_12_area{area}"] = row[f"ft_9_area{area}"]
                writer.writerow({**row, "time": stamp, "img_name": stamp + ".jpg", "feature_source_start_time": stamp})
        times, visual, origins, _ = read_visual_features(self.path)
        chosen = np.array([1, 2, 3, 5, 6, 8], dtype=np.int64)
        self.data = {"time_ns": times[chosen] + 2 * MINUTE_NS,
                     "visual_time_ns": times[chosen], "visual_source_start_ns": origins[chosen],
                     "source_start_ns": times[chosen].copy(), "source_end_ns": times[chosen] + 3 * MINUTE_NS,
                     "visual": visual[chosen].copy(),
                     "train_idx": np.array([0, 1, 2]), "val_idx": np.array([3]), "test_idx": np.array([4]),
                     "sentinel": np.arange(12).reshape(6, 2)}
        def iso(minute):
            return str(np.datetime64(self.base + minute * MINUTE_NS, "ns"))
        self.manifest = {"split": {"partitions": {
            "train": {"earliest_source": iso(0), "latest_source": iso(22)},
            "val": {"earliest_source": iso(60), "latest_source": iso(62)},
            "test": {"earliest_source": iso(65), "latest_source": iso(67)}}}}

    def test_static_slots_and_original_arrays_preserved(self):
        before = copy.deepcopy(self.data)
        variants, metadata, manifest = build_visual_variants(self.data, self.path, self.manifest)
        assert {name: value.shape[1] for name, value in variants.items()} == {
            "original52": 52, "static40": 40, "fixed10": 52, "fixed60": 52, "timing4": 4}
        positions = [FEATURE_COLUMNS.index(name) for name in STATIC_COLUMNS]
        np.testing.assert_array_equal(variants["static40"], before["visual"][:, positions])
        np.testing.assert_array_equal(variants["original52"], before["visual"])
        for area in range(1, 5):
            for slot in (7, 8, 12):
                assert f"ft_{slot}_area{area}" not in STATIC_COLUMNS
        for name in before:
            np.testing.assert_array_equal(self.data[name], before[name])
        assert all(np.isfinite(matrix).all() for matrix in variants.values())
        assert metadata["partition_id"].tolist() == [0, 0, 0, 1, 2, -1]
        assert manifest["unassigned_purge_samples"] == 1
        variants["original52"][0, 0] += 1
        np.testing.assert_array_equal(self.data["visual"], before["visual"])

    def test_irregular_actual_duration_and_singleton_zero(self):
        variants, metadata, _ = build_visual_variants(self.data, self.path, self.manifest)
        # At minute 9, 0/2/9 belong to the 10-minute window; at 20 only 20 does.
        assert metadata["capture_count10"][:3].tolist() == [2, 3, 1]
        assert metadata["span10"][:3].tolist() == [2., 9., 0.]
        np.testing.assert_allclose(variants["fixed10"][1, 40:48], np.full(8, np.std([0., 10., 20.])), rtol=1e-6)
        np.testing.assert_array_equal(variants["fixed10"][2, 40:48], np.zeros(8))
        assert metadata["capture_count60"][2] == 4
        assert metadata["span60"][2] == 20
        np.testing.assert_array_equal(metadata["age_minutes"], np.ones(6))
        np.testing.assert_array_equal(variants["timing4"], variants["fixed10"][:, -4:])

    def test_windows_clip_sources_at_partition_start(self):
        variants, metadata, manifest = build_visual_variants(self.data, self.path, self.manifest)
        # At minute60, minute59 is within 10 minutes but belongs to an earlier partition.
        assert metadata["capture_count10"][3] == 1
        assert metadata["capture_count60"][3] == 1
        assert metadata["boundary_removed_count10"][3] == 1
        assert metadata["source_begin10_ns"][3] == self.base + 60 * MINUTE_NS
        np.testing.assert_array_equal(variants["fixed10"][3, 40:48], np.zeros(8))
        # Test minute65 excludes both minute59 and minute60, without dropping the row.
        assert metadata["capture_count10"][4] == 1
        assert metadata["boundary_removed_count10"][4] == 2
        assert len(variants["fixed10"]) == len(self.data["time_ns"])
        assert all(v["cross_boundary_samples_after_clipping"] == 0 for v in manifest["variants"].values())

    def test_capture_after_existing_selection_is_never_used(self):
        data = copy.deepcopy(self.data)
        # Even when minute9 is available at the cutoff, the existing minute2
        # selection stays fixed; the diagnostic must not select a newer frame.
        data["time_ns"][0] = self.base + 10 * MINUTE_NS
        variants, metadata, _ = build_visual_variants(data, self.path, self.manifest)
        assert metadata["capture_count10"][0] == 2
        assert metadata["chosen_capture_index"][0] == 1
        assert metadata["source_end10_ns"][0] == self.base + 2 * MINUTE_NS
        assert variants["timing4"][0, 0] == 7

    def test_purge_source_union_covers_all_duration_windows(self):
        _, metadata, _ = build_visual_variants(self.data, self.path, self.manifest)
        # At minute20 the baseline current frame starts at20, fixed10 at20,
        # but fixed60 reaches minute0. A residual subpartition must purge it.
        assert metadata["source_start_ns"][2] == self.base
        np.testing.assert_array_equal(metadata["source_end_ns"], self.data["source_end_ns"])
        np.testing.assert_array_equal(metadata["variant_source_start_ns_fixed60"], metadata["source_begin60_ns"])

    def test_future_selected_capture_is_rejected(self):
        data = copy.deepcopy(self.data)
        data["time_ns"][0] = data["visual_time_ns"][0]
        with self.assertRaisesRegex(ValueError, "future"):
            build_visual_variants(data, self.path, self.manifest)

    def test_mismatched_capture_values_and_cross_partition_original_rejected(self):
        data = copy.deepcopy(self.data)
        data["visual"][0, 0] += 1
        with self.assertRaisesRegex(ValueError, "differ"):
            build_visual_variants(data, self.path, self.manifest)
        manifest = copy.deepcopy(self.manifest)
        manifest["split"]["partitions"]["train"]["earliest_source"] = "2025-04-01T00:03:00"
        with self.assertRaisesRegex(ValueError, "original visual source crosses"):
            build_visual_variants(self.data, self.path, manifest)


if __name__ == "__main__":
    unittest.main()
