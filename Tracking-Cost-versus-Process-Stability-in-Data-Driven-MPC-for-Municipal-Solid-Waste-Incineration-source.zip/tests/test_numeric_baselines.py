"""Small synthetic fixtures for numerical baseline contracts, not study results."""
import json

import numpy as np
import pytest
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler

from mswi_experiments import numeric_baselines as nb
from mswi_experiments.training import fit_twin


def fixture():
    rng = np.random.default_rng(19)
    n = 48
    data = {'u_hist': rng.normal(size=(n, 11, 8)).astype('f4'),
            'z_hist': rng.normal(size=(n, 10, 9)).astype('f4'),
            'visual': rng.normal(size=(n, 3)).astype('f4'),
            'u_current': rng.normal(size=(n, 8)).astype('f4'),
            'action': rng.normal(size=(n, 8)).astype('f4'),
            'time_ns': np.arange(n, dtype='i8') * 60_000_000_000,
            'train_idx': np.arange(30), 'val_idx': np.arange(30, 39),
            'test_idx': np.arange(39, 48)}
    data['z_prev'] = data['z_hist'][:, -1].copy()
    data['z_target'] = data['z_prev'] + .1 * rng.normal(size=(n, 9)).astype('f4')
    data['z_current'] = data['z_target'].copy()
    stats = {'u_mean': [0.] * 8, 'u_scale': [1.] * 8,
             'z_mean': [0.] * 9, 'z_scale': [1.] * 9,
             'v_mean': [0.] * 3, 'v_scale': [1.] * 3,
             'delta_mean': [0.] * 9, 'delta_scale': np.linspace(.1, .9, 9).tolist()}
    return data, stats


def test_numeric_input_excludes_target_action_visual_and_time():
    data, _ = fixture()
    original = nb.numeric_features(data)
    assert original.shape == (48, 178)
    np.testing.assert_array_equal(original[:, :88], data['u_hist'].reshape(48, -1))
    for field in ('z_current', 'z_target', 'action', 'visual', 'time_ns'):
        data[field] = data[field] + 1000
    np.testing.assert_array_equal(original, nb.numeric_features(data))


def test_numeric_input_rejects_wrong_history():
    data, _ = fixture()
    data['u_hist'] = data['u_hist'][:, :-1]
    with pytest.raises(ValueError, match='11,8'):
        nb.numeric_features(data)


def test_loss_weights_all_nine_channels_by_shared_increment_scale():
    scale = np.arange(1., 10.)
    y = np.zeros((2, 9))
    pred = np.broadcast_to(scale, (2, 9))
    assert nb.normalized_mse(y, pred, scale) == 1.
    with pytest.raises(ValueError):
        nb.normalized_mse(y[:, :4], pred[:, :4], scale[:4])


def test_linear_fit_matches_independent_sklearn_and_train_only_scaling():
    data, stats = fixture()
    x = nb.numeric_features(data)
    x[data['test_idx']] += 10000
    y, reference = data['z_target'].astype('f8'), data['z_prev'].astype('f8')
    scale = np.asarray(stats['delta_scale'])
    fitted, candidates, selected = nb.fit_linear_candidates(
        x, y - reference, reference, y, data['train_idx'], data['val_idx'], scale, [1.])
    tr, va = data['train_idx'], data['val_idx']
    scaler = StandardScaler().fit(x[tr])
    model = Ridge(alpha=1., solver='cholesky').fit(scaler.transform(x[tr]), (y[tr] - reference[tr]) / scale)
    expected = model.predict(scaler.transform(x[va])) * scale
    np.testing.assert_allclose(nb.linear_increment(fitted, x[va]), expected, rtol=1e-12, atol=1e-12)
    np.testing.assert_array_equal(fitted['x_mean'], scaler.mean_)
    np.testing.assert_array_equal(fitted['delta_scale'], scale)
    assert selected['alpha'] == 1. and len(candidates) == 1


def test_zero_correction_is_available_and_ties_prefer_zero_then_larger_alpha():
    data, stats = fixture()
    x, y = nb.numeric_features(data), data['z_target'].astype('f8')
    fitted, candidates, selected = nb.fit_linear_candidates(
        x, np.zeros_like(y), y, y, data['train_idx'], data['val_idx'], stats['delta_scale'],
        [1., 10.], include_zero=True)
    assert selected['kind'] == 'zero'
    assert np.count_nonzero(nb.linear_increment(fitted, x)) == 0
    assert np.isnan(fitted['alpha'])
    assert nb.choose_candidate(candidates[1:])['alpha'] == 10.
    with pytest.raises(ValueError):
        nb.choose_candidate([{'kind': 'ridge', 'alpha': 1, 'val_normalized_mse': float('nan')}])


def test_fit_twin_can_defer_test_without_relabeling_validation(tmp_path, monkeypatch):
    data, stats = fixture()
    cfg = {'training': {'hidden': 8, 'batch_size': 15, 'epochs': 1, 'patience': 1, 'threads': 1}}
    test_before = data['test_idx'].copy()
    def forbidden(*args, **kwargs):
        raise AssertionError('fit_twin must not call prediction when test is deferred')
    monkeypatch.setattr('mswi_experiments.training.predict_twin', forbidden)
    _, metrics = fit_twin(data, stats, 'sensor', 11, cfg, tmp_path, evaluate_test=False)
    np.testing.assert_array_equal(data['test_idx'], test_before)
    assert metrics['test_evaluated'] is False and 'test' not in metrics
    assert (tmp_path / 'twin.pt').exists()
    assert not (tmp_path / 'test_predictions.npz').exists()
    assert not (tmp_path / 'test_predictions.csv').exists()


def test_staged_study_freezes_before_test_and_roundtrips_predictions(tmp_path):
    data, stats = fixture()
    source = tmp_path / 'source/data'
    source.mkdir(parents=True)
    np.savez_compressed(source / 'dataset.npz', **data)
    (source / 'stats.json').write_text(json.dumps(stats))
    (source / 'manifest.json').write_text(json.dumps({'fixture': 'synthetic'}))
    cfg = {'source_run': 'source', 'output_dir': 'output',
           'training': {'hidden': 8, 'batch_size': 15, 'epochs': 1, 'patience': 1, 'threads': 1},
           'diagnostics': {'seeds': [11], 'ridge_alphas': [1., 10.]}}
    config = tmp_path / 'config.json'
    config.write_text(json.dumps(cfg))
    out = nb.prepare(config)
    assert nb.prepare(config) == out
    models = nb.train(config)
    assert len(models) == 4
    assert (out / 'selection_frozen.json').exists()
    assert not (out / 'predictions').exists()
    assert not list((out / 'models').rglob('test_predictions.npz'))
    with pytest.raises(ValueError, match='training output already exists'):
        nb.train(config)
    files = nb.predict(config)
    assert len(files) == 12
    with np.load(out / 'predictions/persistence/test.npz') as archive:
        np.testing.assert_array_equal(archive['indices'], data['test_idx'])
        np.testing.assert_array_equal(archive['pred'], data['z_prev'][data['test_idx']])
        np.testing.assert_array_equal(archive['y'], data['z_target'][data['test_idx']])
    before = {}
    for row in files:
        with np.load(out / row['path']) as archive:
            before[row['path']] = archive['pred'].copy()
    for row in nb.predict(config):
        with np.load(out / row['path']) as archive:
            np.testing.assert_array_equal(before[row['path']], archive['pred'])
    selected = json.loads((out / 'selection.json').read_text())
    selected['models'][0]['val_normalized_mse'] += 1.
    (out / 'selection.json').write_text(json.dumps(selected))
    with pytest.raises(ValueError, match='frozen selection'):
        nb.predict(config)


def test_linear_coefficients_do_not_fit_validation_or_test_labels():
    data, stats = fixture()
    x = nb.numeric_features(data)
    reference = data['z_prev'].astype('f8')
    y = data['z_target'].astype('f8')
    def run(truth):
        return nb.fit_linear_candidates(x, truth - reference, reference, truth,
                                       data['train_idx'], data['val_idx'], stats['delta_scale'], [1.])
    original, candidates, _ = run(y)
    changed_test = y.copy()
    changed_test[data['test_idx']] += 1e6
    test_fit, test_candidates, _ = run(changed_test)
    assert candidates == test_candidates
    np.testing.assert_array_equal(original['coef'], test_fit['coef'])
    np.testing.assert_array_equal(original['intercept'], test_fit['intercept'])
    changed_val = y.copy()
    changed_val[data['val_idx']] += 100
    val_fit, val_candidates, _ = run(changed_val)
    np.testing.assert_array_equal(original['coef'], val_fit['coef'])
    np.testing.assert_array_equal(original['intercept'], val_fit['intercept'])
    assert candidates != val_candidates
