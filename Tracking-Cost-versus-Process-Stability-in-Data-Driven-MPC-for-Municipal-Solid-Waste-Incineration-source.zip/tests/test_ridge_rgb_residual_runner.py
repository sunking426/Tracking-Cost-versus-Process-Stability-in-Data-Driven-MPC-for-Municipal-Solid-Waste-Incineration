import hashlib

import pytest

from mswi_experiments.ridge_rgb_residual import check_records


def test_frozen_inputs_reject_mutation_and_disappearance(tmp_path):
    source = tmp_path/'input.txt'
    source.write_bytes(b'original observations')
    records = {str(source): hashlib.sha256(source.read_bytes()).hexdigest()}
    check_records(records)
    source.write_bytes(b'different observations')
    with pytest.raises(ValueError, match='frozen artifact'):
        check_records(records)
    source.unlink()
    with pytest.raises(ValueError, match='frozen artifact'):
        check_records(records)
