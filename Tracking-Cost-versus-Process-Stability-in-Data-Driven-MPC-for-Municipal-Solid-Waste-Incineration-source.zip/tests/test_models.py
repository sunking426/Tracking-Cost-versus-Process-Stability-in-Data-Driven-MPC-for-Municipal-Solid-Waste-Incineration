"""Model contracts and supervised-training smoke tests, using labelled synthetic fixtures."""
import numpy as np
import pytest
import torch

from mswi_experiments.models import Actor, Twin, make_state
from mswi_experiments.training import fit_bc, fit_twin, hurdle_loss, load_actor, load_twin


def fixture():
    rng = np.random.default_rng(5)
    n, u_dim, z_dim, v_dim = 72, 8, 9, 7
    stats = {"u_mean": [0.] * u_dim, "u_scale": [1.] * u_dim,
             "z_mean": [0.] * z_dim, "z_scale": [1.] * z_dim,
             "v_mean": [0.] * v_dim, "v_scale": [1.] * v_dim,
             "delta_mean": [0.] * z_dim, "delta_scale": [1.] * z_dim,
             "action_scale": [1.] * u_dim, "action_bound": [1.] * u_dim}
    data = {"u_hist": rng.normal(size=(n, 11, u_dim)).astype("f4"),
            "z_hist": rng.normal(size=(n, 10, z_dim)).astype("f4"),
            "visual": rng.normal(size=(n, v_dim)).astype("f4"),
            "z_prev": rng.normal(size=(n, z_dim)).astype("f4"),
            "u_current": rng.normal(size=(n, u_dim)).astype("f4"),
            "z_current": rng.normal(size=(n, z_dim)).astype("f4"),
            "action": np.zeros((n, u_dim), dtype="f4"),
            "time_ns": np.arange(n, dtype="i8"), "train_idx": np.arange(48),
            "val_idx": np.arange(48, 60), "test_idx": np.arange(60, 72)}
    data["z_target"] = data["z_prev"] + .05 * rng.normal(size=(n, z_dim)).astype("f4")
    data["action"][::3, 0] = .2
    return data, stats


@pytest.mark.parametrize("mode", ["multi", "sensor", "image"])
def test_modes_output_physical_increment_and_state(mode):
    data, stats = fixture()
    twin = Twin(stats, mode=mode, hidden=16)
    u, z, v = [torch.from_numpy(data[k][:4]) for k in ("u_hist", "z_hist", "visual")]
    result = twin(u, z, v)
    assert result.shape == (4, 9)
    state = make_state(twin, u, z, v, torch.from_numpy(data["u_current"][:4]),
                       torch.from_numpy(data["z_current"][:4]))
    assert state.shape == (4, 33)
    actor = Actor(33, 8, hidden=16)
    a, logits, magnitude = actor.forward_details(state)
    assert a.shape == (4, 8) and (a.abs() <= 1).all()
    assert torch.allclose(a, torch.sigmoid(logits) * torch.tanh(magnitude))


def test_sensor_mode_ignores_visual_but_multi_is_connected():
    data, stats = fixture()
    u, z, v = [torch.from_numpy(data[k][:4]) for k in ("u_hist", "z_hist", "visual")]
    sensor = Twin(stats, mode="sensor", hidden=16).eval()
    assert torch.equal(sensor(u, z, v), sensor(u, z, v + torch.randn_like(v)))
    multi = Twin(stats, mode="multi", hidden=16)
    visual = v.clone().requires_grad_()
    multi(u, z, visual).square().sum().backward()
    assert visual.grad is not None and visual.grad.abs().sum() > 0
    key = multi.retrieval_key(u, z)
    assert key.shape == (4, 21 * 16)
    assert torch.allclose(key.norm(dim=1), torch.ones(4), atol=1e-6)


def test_increment_scaling_is_inverted():
    _, stats = fixture()
    stats["delta_mean"] = [2.] * 9
    stats["delta_scale"] = [3.] * 9
    twin = Twin(stats, hidden=16)
    with torch.no_grad():
        twin.decoder.weight.zero_()
        twin.decoder.bias.fill_(1.)
    result = twin(torch.zeros(2, 11, 8), torch.zeros(2, 10, 9), torch.zeros(2, 7))
    assert torch.equal(result, torch.full((2, 9), 5.))


def test_hurdle_gate_labels_preserve_physical_zero():
    raw = torch.tensor([[0., 1.]])
    # Correct gate logits have low probability for physical zero, high for nonzero.
    target = torch.tensor([[0., .5]])
    prediction = target.clone()
    correct = hurdle_loss(prediction, torch.tensor([[-10., 10.]]), target, raw)
    wrong = hurdle_loss(prediction, torch.tensor([[10., -10.]]), target, raw)
    assert correct < wrong


def test_training_roundtrip_and_frozen_twin(tmp_path):
    data, stats = fixture()
    cfg = {"training": {"hidden": 16, "batch_size": 24, "epochs": 1, "patience": 1, "threads": 1}}
    twin, tm = fit_twin(data, stats, "multi", 8, cfg, tmp_path / "twin")
    loaded = load_twin(tmp_path / "twin/twin.pt")
    assert loaded.v_dim == 7 and tm["test"]["n"] == 12
    before = {k: v.clone() for k, v in twin.state_dict().items()}
    actor, bm = fit_bc(data, stats, twin, 8, cfg, tmp_path / "bc")
    restored = load_actor(tmp_path / "bc/actor.pt")
    assert restored.state_dim == 33 and bm["test_action"]["n"] == 12
    assert all(torch.equal(before[k], v) for k, v in twin.state_dict().items())
    assert not any(p.requires_grad for p in twin.parameters())
    assert (tmp_path / "twin/test_predictions.csv").exists()
    assert (tmp_path / "bc/test_actions.csv").exists()
