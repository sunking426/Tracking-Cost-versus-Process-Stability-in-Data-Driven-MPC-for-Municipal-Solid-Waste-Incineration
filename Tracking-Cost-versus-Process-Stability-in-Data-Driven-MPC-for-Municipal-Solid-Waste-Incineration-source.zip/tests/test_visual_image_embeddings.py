import numpy as np
from PIL import Image
import pytest

from mswi_experiments.visual_image_embeddings import image_tensors, MEAN, STD, load_encoder


def test_image_tensor_excludes_border_overlays_and_preserves_roi_edges():
    pixels = np.zeros((100, 100, 3), dtype=np.uint8)
    pixels[:25] = (255, 0, 0)
    pixels[88:] = (255, 0, 0)
    pixels[25:88, 21:79] = (0, 255, 0)
    rgb, gray = image_tensors(Image.fromarray(pixels))
    actual = rgb.numpy().transpose(1, 2, 0)*STD+MEAN
    np.testing.assert_allclose(actual, np.broadcast_to([0, 1, 0], actual.shape), atol=1e-7)
    assert rgb.shape == gray.shape == (3, 224, 224)


def test_gray_has_equal_channels_before_imagenet_normalization():
    pixels = np.random.default_rng(4).integers(0, 256, size=(90, 120, 3), dtype=np.uint8)
    _, gray = image_tensors(Image.fromarray(pixels))
    values = gray.numpy().transpose(1, 2, 0)*STD+MEAN
    np.testing.assert_allclose(values[:, :, 0], values[:, :, 1], atol=1e-7)
    np.testing.assert_allclose(values[:, :, 1], values[:, :, 2], atol=1e-7)


def test_wrong_encoder_weight_rejected_before_deserialization(tmp_path):
    weights = tmp_path/'bad.pth'
    weights.write_bytes(b'not the official weights')
    with pytest.raises(ValueError, match='official'):
        load_encoder(weights)
