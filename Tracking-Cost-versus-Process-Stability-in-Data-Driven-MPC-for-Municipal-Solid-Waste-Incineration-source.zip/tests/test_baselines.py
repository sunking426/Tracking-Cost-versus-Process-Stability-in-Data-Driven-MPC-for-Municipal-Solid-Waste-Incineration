"""Planning contract tests; synthetic systems here are not paper results."""
import numpy as np
import pytest
import torch

from mswi_experiments.baselines import CEMMPCPolicy
from mswi_experiments.models import Actor, Twin

from test_control import fixture_data, FixedMemory, zero_twin


def test_cem_replans_zero_for_zero_dynamics_and_respects_fixed_budget():
    data, stats = fixture_data()
    twin = zero_twin(stats)
    actor = Actor(twin.state_dim, 8, hidden=8)
    policy = CEMMPCPolicy(twin, FixedMemory(), stats, actor,
        horizon=4, block_steps=2, population=8, elite=2, iterations=2)
    from mswi_experiments.control import observations_from_data
    observation = observations_from_data(data, np.array([0,1]))
    untouched = {k:v.clone() for k,v in observation.items()}
    policy.reset(observation)
    action = policy(observation)
    np.testing.assert_array_equal(action, np.zeros((2,8)))
    assert all(torch.equal(observation[k], untouched[k]) for k in observation)
    first = action.copy()
    policy(observation)
    metadata = policy.metrics()
    assert metadata['planning_calls'] == 2
    assert metadata['forward_transitions'] == 2 * 2 * 8 * 2 * 4
    assert metadata['planning_elapsed_seconds'] > 0
    assert metadata['dynamics_source'].startswith('training twin')
    policy.reset(observation)
    np.testing.assert_array_equal(policy(observation), first)


def test_cem_scores_current_history_without_reading_future_logs():
    data, stats = fixture_data()
    data['z_current'][:,:6] = 950.
    data['z_hist'][:,:,:6] = 950.
    stats['action_bound'] = [.25] + [0.] * 7
    class ResponsiveTwin(Twin):
        def forward(self, u_hist, z_hist, visual):
            delta = torch.zeros((len(u_hist),9))
            delta[:,:6] = 20. * u_hist[:,-1,:1]
            return delta
    twin = ResponsiveTwin(stats, 'multi', hidden=8)
    actor = Actor(twin.state_dim, 8, hidden=8)
    with torch.no_grad():
        for p in actor.parameters():p.zero_()
        actor.gate_head.bias.fill_(2.)
        actor.mag_head[-1].bias[0] = 2.
    from mswi_experiments.control import observations_from_data
    observation = observations_from_data(data, np.array([0]))
    policy = CEMMPCPolicy(twin, FixedMemory(), stats, actor,
        horizon=4, block_steps=2, population=8, elite=2, iterations=2)
    policy.reset(observation)
    action = policy(observation)
    assert action[0,0] > 0
    # No source dataset is held by the planner. Candidate simulation receives
    # only repetitions of the supplied observation, never data['next_idx'].
    assert not hasattr(policy, 'data')
    assert not hasattr(policy, 'eval_twin')
    assert np.max(np.abs(action)) <= 1


def test_cem_rejects_invalid_block_or_search_budgets():
    data, stats = fixture_data()
    twin=zero_twin(stats);actor=Actor(twin.state_dim,8,hidden=8)
    with pytest.raises(ValueError,match='complete action blocks'):
        CEMMPCPolicy(twin,FixedMemory(),stats,actor,horizon=5,block_steps=2)


def test_extended_suite_keeps_paired_starts_and_supports_arbitrary_seeds(tmp_path):
    from mswi_experiments.evaluation import run_control_suite
    data, stats = fixture_data()
    full=zero_twin(stats);sensor=Twin(stats,'sensor',hidden=8);evaluation=zero_twin(stats)
    with torch.no_grad():sensor.decoder.weight.zero_();sensor.decoder.bias.zero_()
    bc_full=Actor(full.state_dim,8,hidden=8);bc_sensor=Actor(sensor.state_dim,8,hidden=8)
    config={'training':{'threads':1},'retrieval':{'max_items':4,'k':2},
        'rl':{'seeds':[7,19],'updates':2,'batch_size':4,'critic_hidden':8,
              'rollout_batch_size':2,'rollout_horizon':1,'log_every':2},
        'mpc':{'horizon':2,'block_steps':1,'population':4,'elite':2,'iterations':1},
        'evaluation':{'episodes':2,'horizon':3,'advisory_steps':3,
                      'additional_baselines':['offline_td3bc','cem_mpc']}}
    results=run_control_suite(data,stats,full,sensor,evaluation,bc_full,bc_sensor,config,tmp_path)
    assert len(results['results'])==11
    starts=results['evaluation_start_indices']
    for method,entry in results['results'].items():
        for relative in entry['evaluation_files']:
            saved=np.load(tmp_path/relative,allow_pickle=False)
            np.testing.assert_array_equal(saved['start_indices'],starts)
            assert saved['rewards'].shape==(2,3)
        if method not in {'linear_feedback','nearest_logged','bc','cem_mpc'}:
            assert [r['seed'] for r in entry['by_seed']]==[7,19]
    for seed in results['results']['offline_td3bc']['by_seed']:
        assert seed['training']['generated_transitions']==0
        assert seed['training']['replay_mode']=='logged_only'
    planning=results['results']['cem_mpc']['by_seed'][0]['planning']
    assert planning['planning_calls']==3 and planning['forward_transitions']==48
