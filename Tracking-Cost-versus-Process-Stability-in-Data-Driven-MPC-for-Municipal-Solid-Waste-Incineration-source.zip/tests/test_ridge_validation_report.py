"""Statistical semantics and artifact integrity for recursive Ridge reports."""
import csv
import hashlib
import json
from pathlib import Path

import numpy as np
import pytest

from mswi_experiments.ridge_validation_report import (
    BRANCHES, DAY_NS, MINUTE_NS, direction_labels, endpoint_differences,
    event_context, load_completed_validation, response_directions,
    summarize_validation, trajectory_metrics,
)


def _json(path,value):Path(path).write_text(json.dumps(value))
def _sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def synthetic_validation(root, *, with_events=True):
    root=Path(root);n=12;h=10
    cfg={"horizon":h,"endpoints":[1,5,10],"event_minimum_separation_minutes":10,
         "example_count":4,"bootstrap_draws":100,"bootstrap_seed":20261104,"confidence_level":.95}
    stats={"delta_scale":list(range(1,10)),"cv_names":[f"CV{j}" for j in range(9)],
           "mv_names":[f"MV{j}" for j in range(8)]}
    thresholds={"direction_deadbands":[.1,.2,.3,.4],"nonzero_tolerance":1e-6,
                "mv_thresholds":[.5]*8}
    _json(root/"config.json",cfg);_json(root/"stats.json",stats)
    _json(root/"protocol.json",{"scope":"synthetic fixture"})
    _json(root/"event_thresholds.json",thresholds)
    all_chains={};event_summary={};records=[]
    for si,split in enumerate(("train","val","test")):
        chain=si*100+np.arange(n)[:,None]+np.arange(h)
        all_chains[split+"_chains"]=chain
        starts=(20000+si*4+np.arange(n)//6)*DAY_NS+np.arange(n)%6*MINUTE_NS
        times=starts[:,None]+np.arange(h)*MINUTE_NS
        initial=np.tile([900.]*6+[-100.,30.,7.],(n,1))+np.arange(n)[:,None]*.01
        truth=initial[:,None]+np.arange(1,h+1)[None,:,None]*np.arange(1,10)[None,None,:]*.1
        logged=truth+.03*np.arange(1,h+1)[None,:,None]
        held=logged+np.arange(h)[None,:,None]*.01
        teacher=truth+.03
        persistence=np.repeat(initial[:,None],h,axis=1)
        mv=np.zeros((n,h,8));mv[:,:,0]=np.arange(h)
        for branch,pred in zip(BRANCHES,(logged,held,persistence,teacher)):
            relative=f"rollouts/{split}/{branch}.npz";path=root/relative;path.parent.mkdir(parents=True,exist_ok=True)
            np.savez_compressed(path,indices=chain,start_time_ns=starts,time_ns=times,
                truth_cv=truth,pred_cv=pred,initial_zprev=initial,
                mv_path=np.repeat(mv[:,:1],h,axis=1) if branch=="ridge_hold_mv" else mv)
            records.append({"split":split,"branch":branch,"path":relative,"sha256":_sha(path),
                            "starts":n,"horizon":h,"shape":[n,h,9]})
        delta=np.zeros((n,8))
        if with_events:delta[0,0]=1.;delta[11,:2]=[-1.,1.]
        trigger=abs(delta)>=.5;nonzero=abs(delta)>1e-6;selected=np.flatnonzero(trigger.any(1))
        future=np.zeros((n,h-1,8),dtype=bool);future[11,3,0]=True
        event={"chain_start_indices":chain[:,0],"chain_start_time_ns":starts,
            "candidate_positions":selected,"candidate_indices":chain[selected,0],
            "selected_positions":selected,"selected_indices":chain[selected,0],"selected_time_ns":starts[selected],
            "example_positions":selected,"example_indices":chain[selected,0],"current_delta":delta,
            "trigger_mask":trigger,"current_nonzero_mask":nonzero,"current_sign":np.sign(delta).astype(np.int8),
            "current_nonzero_channels":nonzero.sum(1),"future_change_mask":future,
            "future_change_steps":future.any(2).sum(1),"future_change_cells":future.sum((1,2)),
            "future_changed_channels":future.any(1).sum(1)}
        (root/"events").mkdir(exist_ok=True);np.savez_compressed(root/f"events/{split}.npz",**event)
        event_summary[split]={"chains":n,"candidate_count":len(selected),"selected_count":len(selected),
                              "example_indices":chain[selected,0].tolist()}
    np.savez_compressed(root/"chains.npz",**all_chains)
    _json(root/"event_summary.json",event_summary)
    frozen_names=["config.json","stats.json","protocol.json","event_thresholds.json","event_summary.json","chains.npz"]
    frozen_names += [f"events/{s}.npz" for s in ("train","val","test")]
    _json(root/"prepare_frozen.json",{"status":"complete","files":{name:_sha(root/name) for name in frozen_names}})
    _json(root/"run_manifest.json",{"status":"complete","model_kind":"ridge","files":records,
        "prepare_frozen_sha256":_sha(root/"prepare_frozen.json"),"trajectories_dropped":0,
        "predictions_clipped":False,"model_retrained":False})
    return root


def test_ternary_direction_uses_strict_deadband_and_keeps_neutral_denominators():
    bands=np.array([.1,.2,.3,.4])
    labels=direction_labels(np.array([bands,-bands,bands*1.01,-bands*1.01]),bands)
    np.testing.assert_array_equal(labels,[[0]*4,[0]*4,[1]*4,[-1]*4])
    initial=np.zeros((3,9));truth=np.zeros((3,9));truth[0]=2;truth[1]=-2
    result=response_directions(truth,initial,initial,bands)
    for row in result:
        assert row["samples"]==3 and row["observed_active_count"]==2 and row["observed_neutral_count"]==1
        assert row["active_accuracy"]==0. and row["overall_accuracy"]==pytest.approx(1/3)
        assert row["confusion"]==[[0,1,0],[0,1,0],[0,1,0]]


def test_response_temperature_aggregates_before_direction_classification():
    initial=np.zeros((1,9));truth=initial.copy();truth[0,:6]=[1,-1,1,-1,1,-1]
    result=response_directions(truth,initial,initial,np.repeat(.1,4))
    assert result[0]["observed_active_count"]==0
    assert result[0]["active_accuracy"] is None
    assert result[0]["overall_accuracy"]==1.


def test_empty_events_preserve_zero_and_null_without_nan():
    empty=np.empty((0,9));result=response_directions(empty,empty,empty,np.ones(4))
    assert all(r["samples"]==0 and r["overall_accuracy"] is None and r["active_accuracy"] is None for r in result)
    metric=trajectory_metrics(np.empty((0,5,9)),np.empty((0,5,9)),np.ones(9))
    assert metric["samples"]==0 and metric["segments"]==0 and metric["steps"]==5
    assert metric["normalized_mse"] is None


def test_trajectory_error_includes_all_steps_not_only_endpoint():
    truth=np.zeros((2,3,9));pred=np.zeros_like(truth);pred[:,0]=3.
    metric=trajectory_metrics(truth,pred,np.ones(9))
    assert metric["samples"]==6 and metric["normalized_mse"]==3.
    assert metric["physical_mae"]==[1.]*4


def test_paired_endpoint_metric_uses_common_scale_and_no_fake_seed_repeats():
    y=np.zeros((4,9));ref=np.ones((4,9))*2;cand=np.ones((4,9))
    difference=endpoint_differences(ref,cand,y,np.arange(1.,10.))
    assert difference.shape==(1,4,5)
    assert difference[0,0,0]==pytest.approx(sum(3/j**2 for j in range(1,10))/9)
    np.testing.assert_array_equal(difference[0,:,1:],np.ones((4,4)))


def test_complete_report_preserves_tf_diagnostic_and_all_event_denominators(tmp_path):
    root=synthetic_validation(tmp_path)
    result=summarize_validation(root)
    assert len(result["rollout_checks"])==12
    assert len(result["comparisons"])==3
    assert all("teacher" not in key for key in result["comparisons"])
    assert result["event_context"]["test"]["selected_count"]==2
    assert result["event_context"]["test"]["multiple_current_mv_fraction"]==.5
    assert result["event_context"]["test"]["further_operation_change_fraction"]==.5
    assert len(result["metrics"]["test"]["ridge_teacher_forced"])==10
    counts={name:len(list(csv.DictReader((root/"statistics"/name).open()))) for name in
            ("step_curves.csv","endpoints.csv","channels.csv","per_day.csv","comparisons.csv",
             "event_metrics.csv","event_directions.csv","event_confusion.csv")}
    assert counts=={"step_curves.csv":120,"endpoints.csv":36,"channels.csv":324,"per_day.csv":72,
                    "comparisons.csv":45,"event_metrics.csv":72,"event_directions.csv":144,"event_confusion.csv":1296}


def test_report_preserves_empty_event_groups(tmp_path):
    root=synthetic_validation(tmp_path,with_events=False)
    result=summarize_validation(root)
    for branch in BRANCHES:
        event=result["event_metrics"]["test"][branch]["10"]
        assert event["endpoint"]["normalized_mse"] is None
        assert event["trajectory"]["samples"]==0
        assert all(x["overall_accuracy"] is None for x in event["directions"])
    assert result["event_context"]["test"]["multiple_current_mv_fraction"] is None


def test_corrupted_horizon_alignment_is_rejected_even_with_updated_hash(tmp_path):
    root=synthetic_validation(tmp_path);path=root/"rollouts/test/ridge_logged.npz"
    with np.load(path) as raw:row={k:raw[k].copy() for k in raw.files}
    row["time_ns"][0,0]+=MINUTE_NS;np.savez_compressed(path,**row)
    manifest=json.loads((root/"run_manifest.json").read_text())
    next(r for r in manifest["files"] if r["path"]==str(path.relative_to(root)))["sha256"]=_sha(path)
    _json(root/"run_manifest.json",manifest)
    with pytest.raises(ValueError,match="minute alignment"):load_completed_validation(root)


def test_changed_event_selection_rejected_by_frozen_hash(tmp_path):
    root=synthetic_validation(tmp_path);path=root/"events/test.npz"
    with np.load(path) as raw:row={k:raw[k].copy() for k in raw.files}
    row["example_positions"]=row["example_positions"][::-1]
    np.savez_compressed(path,**row)
    with pytest.raises(ValueError,match="frozen prepared artifact"):load_completed_validation(root)
