"""Small fixtures for selection, split isolation and saved residual inference."""
import json

import numpy as np
import pytest
from sklearn.preprocessing import StandardScaler
import torch

from mswi_experiments import ridge_rgb_residual_model as rm
from mswi_experiments.training import seed_everything


def prepared(path, *, poison_test=False):
    rng = np.random.default_rng(81)
    arrays = {"delta_scale": np.linspace(0.2, 1.0, 9)}
    offset = 0
    for split, n in (("train", 24), ("val", 10), ("test", 9)):
        x = rng.normal(size=(n, 226))
        if split != "train":
            x += 20
        null_x = x.copy()
        null_x[:, 194:] = np.roll(x[:, 194:], 1, axis=0)
        base = rng.normal(size=(n, 9))
        truth = base + (0.5 if split == "train" else 0.0)
        arrays.update({f"{split}_indices": np.arange(offset, offset+n, dtype=np.int64),
                       f"{split}_time_ns": np.arange(offset, offset+n, dtype=np.int64) * 60_000_000_000,
                       f"{split}_capture_index": np.arange(offset, offset+n, dtype=np.int64),
                       f"{split}_x": x, f"{split}_null_x": null_x,
                       f"{split}_base": base, f"{split}_truth": truth})
        offset += n + 12
    if poison_test:
        arrays["test_truth"] = np.full_like(arrays["test_truth"], np.nan)
        arrays["test_x"] = np.full_like(arrays["test_x"], np.nan)
    np.savez_compressed(path, **arrays)
    return arrays


def config():
    return {"seeds": [11], "training": {"epochs": 2, "patience": 2, "batch_size": 12,
                                          "threads": 1, "lr": 0.001, "weight_decay": 0.0001,
                                          "grad_clip": 1.0, "min_delta": 1e-5}}


def test_fixed_architecture_and_initialization_are_paired_across_ablations():
    models = []
    for method in rm.METHODS:
        seed_everything(11, 1)
        models.append(rm.ResidualHead(method))
    expected = sum(p.numel() for p in models[0].parameters())
    for model in models:
        assert sum(p.numel() for p in model.parameters()) == expected
        assert torch.equal(model(torch.randn(3, 226)), torch.zeros(3, 9))
        for name, value in models[0].named_parameters():
            assert torch.equal(dict(model.named_parameters())[name], value)
    assert [int(m.mask.sum()) for m in models] == [178, 194, 226, 226]


@pytest.mark.parametrize("method,stop", [("numeric", 178), ("quality", 194)])
def test_disabled_inputs_do_not_change_a_nonzero_network_prediction(method, stop):
    seed_everything(19, 1)
    model = rm.ResidualHead(method)
    with torch.no_grad():
        model.network[-1].weight.fill_(0.1)
    x = torch.randn(6, 226)
    altered = x.clone()
    altered[:, stop:] += 1e4
    assert torch.count_nonzero(model(x)) > 0
    assert torch.equal(model(x), model(altered))


def test_fit_never_accesses_test_arrays_and_uses_training_only_scaler(tmp_path, monkeypatch):
    path = tmp_path / "prepared.npz"
    arrays = prepared(path, poison_test=True)
    with np.load(path, allow_pickle=False) as a:
        archive_type = type(a)
    original_getitem = archive_type.__getitem__
    def guarded_getitem(self, key):
        if str(key).startswith("test_"):
            raise AssertionError("training accessed a test array")
        return original_getitem(self, key)
    monkeypatch.setattr(archive_type, "__getitem__", guarded_getitem)
    out = tmp_path / "study"
    result = rm.fit_all(path, config(), out)
    assert result["test_evaluated"] is False
    assert len(result["models"]) == 4
    assert not (out / "predictions").exists()
    with np.load(out / "residual_scaler.npz", allow_pickle=False) as a:
        expected = StandardScaler().fit(arrays["train_x"])
        np.testing.assert_array_equal(a["x_mean"], expected.mean_)
        np.testing.assert_array_equal(a["x_scale"], expected.scale_)
        np.testing.assert_array_equal(a["fit_indices"], arrays["train_indices"])


def test_zero_selection_and_trained_diagnostic_are_both_retained_and_replay(tmp_path):
    path = tmp_path / "prepared.npz"
    arrays = prepared(path)
    out = tmp_path / "study"
    result = rm.fit_all(path, config(), out)
    for record in result["models"]:
        assert record["selected_epoch"] == 0
        assert record["selected_kind"] == "zero"
        assert record["val_normalized_mse"] == 0
        assert record["trained_epoch"] >= 1
        assert record["trained_val_normalized_mse"] > 0
        assert record["optimizer_steps"] == 4
        checkpoint = torch.load(out / record["checkpoint"], weights_only=True)
        assert "selected_optimizer_state_dict" in checkpoint
        assert "trained_optimizer_state_dict" in checkpoint
    replay = rm.predict_all(path, config(), out)
    assert len(replay["files"]) == 15
    assert replay["test_evaluated"] is True
    for record in result["models"]:
        field = "test_null_x" if record["method"] == "null_rgb" else "test_x"
        file = out / "predictions" / record["method"] / "seed_11/test.npz"
        with np.load(file, allow_pickle=False) as a:
            np.testing.assert_array_equal(a["prediction"], arrays["test_base"])
            np.testing.assert_array_equal(a["correction"], 0)
            assert np.any(a["trained_correction"] != 0)
            prediction, correction = rm.predict_checkpoint(out / record["checkpoint"], arrays[field],
                                                            arrays["test_base"], trained=True, batch_size=12)
            np.testing.assert_array_equal(a["trained_prediction"], prediction)
            np.testing.assert_array_equal(a["trained_correction"], correction)
    with pytest.raises(ValueError, match="already exists"):
        rm.fit_all(path, config(), out)


def test_prediction_requires_complete_frozen_selection_and_unchanged_inputs(tmp_path):
    path = tmp_path / "prepared.npz"
    arrays = prepared(path)
    out = tmp_path / "study"
    with pytest.raises(ValueError, match="frozen"):
        rm.predict_all(path, config(), out)
    rm.fit_all(path, config(), out)
    arrays["test_truth"][0, 0] += 1
    np.savez_compressed(path, **arrays)
    with pytest.raises(ValueError, match="data changed"):
        rm.predict_all(path, config(), out)


def test_checkpoint_physical_formula_and_no_extra_residual_mean(tmp_path):
    path = tmp_path / "prepared.npz"
    arrays = prepared(path)
    out = tmp_path / "study"
    manifest = rm.fit_all(path, config(), out)
    record = next(r for r in manifest["models"] if r["method"] == "rgb")
    checkpoint = out / record["checkpoint"]
    model, mean, scale, target_scale = rm.load_head(checkpoint, trained=True)
    x = ((arrays["test_x"] - mean) / scale).astype(np.float32)
    state = {k: v.cpu().numpy() for k, v in model.state_dict().items()}
    x *= state["mask"]
    for layer in (0, 2, 4):
        x = x @ state[f"network.{layer}.weight"].T + state[f"network.{layer}.bias"]
        if layer != 4:
            x = np.maximum(x, 0)
    independent = arrays["test_base"] + x.astype(np.float64) * target_scale
    pred, correction = rm.predict_checkpoint(checkpoint, arrays["test_x"], arrays["test_base"], trained=True)
    np.testing.assert_allclose(pred, independent, rtol=1e-6, atol=1e-6)
    np.testing.assert_allclose(correction, x.astype(np.float64) * target_scale, rtol=1e-6, atol=1e-6)


@pytest.mark.parametrize("change", ["base_nan", "null_numeric_change", "repeated_indices"])
def test_rejects_broken_prepared_contract(tmp_path, change):
    path = tmp_path / "prepared.npz"
    arrays = prepared(path)
    if change == "base_nan":
        arrays["train_base"][0, 0] = np.nan
    elif change == "null_numeric_change":
        arrays["train_null_x"][0, 0] += 1
    else:
        arrays["train_indices"][1] = arrays["train_indices"][0]
    np.savez_compressed(path, **arrays)
    with pytest.raises(ValueError):
        rm.fit_all(path, config(), tmp_path / "study")


def test_no_test_label_effect_on_fitted_states(tmp_path):
    good, poisoned = tmp_path / "good.npz", tmp_path / "poisoned.npz"
    prepared(good)
    prepared(poisoned, poison_test=True)
    a, b = rm.fit_all(good, config(), tmp_path / "a"), rm.fit_all(poisoned, config(), tmp_path / "b")
    for first, second in zip(a["models"], b["models"]):
        assert first["val_normalized_mse"] == second["val_normalized_mse"]
        assert first["trained_val_normalized_mse"] == second["trained_val_normalized_mse"]
        state_a = torch.load(tmp_path / "a" / first["checkpoint"], weights_only=True)
        state_b = torch.load(tmp_path / "b" / second["checkpoint"], weights_only=True)
        for field in ("selected_state_dict", "trained_state_dict"):
            for name in state_a[field]:
                assert torch.equal(state_a[field][name], state_b[field][name])
