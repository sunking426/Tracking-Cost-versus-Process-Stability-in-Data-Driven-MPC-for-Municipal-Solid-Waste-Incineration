import csv
import copy
from pathlib import Path

import numpy as np
import unittest
import tempfile

from mswi_experiments.data import (
    MINUTE_NS, MV_COLUMNS, CV_COLUMNS, FEATURE_COLUMNS, _causal_fill,
    build_samples, assign_partitions, training_statistics, read_process_files,
    read_visual_features, prepare_data, load_data,
    control_values,
)


def arrays(n=500):
    start = np.datetime64("2025-04-01T00:00:00", "ns").astype(np.int64)
    t = start + np.arange(n) * MINUTE_NS
    u = np.repeat(np.arange(n, dtype=np.float32)[:, None], 8, axis=1)
    z = np.repeat((np.arange(n) * 2).astype(np.float32)[:, None], 9, axis=1)
    v = np.repeat(np.arange(n, dtype=np.float32)[:, None], 52, axis=1)
    return t, u, z, v


class TestDataContracts(unittest.TestCase):
    def test_control_mapping_has_one_definition_for_arbitrary_batches(self):
        values = np.arange(2 * 3 * 9, dtype=np.float32).reshape(2, 3, 9)
        mapped = control_values(values)
        assert mapped.shape == (2, 3, 4)
        np.testing.assert_array_equal(mapped[..., 0], values[..., :6].mean(axis=-1))
        np.testing.assert_array_equal(mapped[..., 1:], values[..., 6:])
        assert control_values(values[0, 0]).shape == (4,)
        with self.assertRaisesRegex(ValueError, "nine CV channels"):
            control_values(np.zeros((3, 8)))

    def test_causal_fill_does_not_backfill_or_interpolate(self):
        values = np.array([[np.nan], [1.], [np.nan], [9.]], dtype=np.float32)
        filled, origin = _causal_fill(values)
        assert np.isnan(filled[0, 0])
        assert filled[:, 0].tolist()[1:] == [1., 1., 9.]
        assert origin[:, 0].tolist() == [-1, 1, 1, 3]


    def test_image_lookup_respects_exact_time_and_one_minute_lag(self):
        t, u, z, v = arrays(30)
        image_times = t + MINUTE_NS // 2
        data, _ = build_samples(t, u, z, image_times, v, window=2, image_gap_minutes=10)
        assert np.all(data["visual_time_ns"] <= data["time_ns"] - MINUTE_NS)
        # At minute 2, image 1:30 would be future relative to the 1:00 cutoff.
        assert data["visual"][0, 0] == 0
        assert data["u_hist"].shape[1:] == (3, 8)
        assert data["z_hist"].shape[1:] == (2, 9)
        assert np.array_equal(data["action"], np.ones_like(data["action"]))


    def test_missing_process_minute_is_not_invented_as_a_valid_window(self):
        t, u, z, v = arrays(30)
        keep = np.arange(30) != 10
        data, meta = build_samples(t[keep], u[keep], z[keep], t, v, window=2)
        invalid = set(t[[9, 10, 11, 12]].tolist())
        assert not invalid.intersection(data["time_ns"].tolist())
        assert meta["missing_timeline_minutes"] == 1


    def test_partitions_purge_all_sources_and_transitions(self):
        t, u, z, v = arrays()
        data, _ = build_samples(t, u, z, t, v, window=10)
        manifest = assign_partitions(data, (.7, .15, .15), 21)
        train, val, test = (data[f"{name}_idx"] for name in ("train", "val", "test"))
        assert data["source_end_ns"][train].max() < data["source_start_ns"][val].min()
        assert data["source_end_ns"][val].max() < data["source_start_ns"][test].min()
        for partition in (train, val, test):
            linked = data["next_idx"][partition]
            assert set(linked[linked >= 0]).issubset(set(partition))
        assert manifest["excluded_split_boundary_windows"] > 0


    def test_statistics_do_not_depend_on_validation_or_test_values(self):
        t, u, z, v = arrays()
        data, _ = build_samples(t, u, z, t, v, window=10)
        assign_partitions(data, (.7, .15, .15), 21)
        before = training_statistics(data)
        changed = copy.deepcopy(data)
        other = np.r_[data["val_idx"], data["test_idx"]]
        for name in ("u_hist", "z_hist", "visual", "action", "z_current", "u_current", "z_target"):
            changed[name][other] += 1_000_000
        assert before == training_statistics(changed)


    def test_vendor_reader_rejects_truncated_row_and_preserves_bad_quality(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        path = Path(temporary.name) / "process.csv"
        with path.open("w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["$DataFileVersion: 3"])
            writer.writerow(["$TagName", *MV_COLUMNS, *CV_COLUMNS])
            writer.writerow(["$Time", *(["Data(Quality)"] * 17)])
            writer.writerow(["$2025-04-01 00:00:00", "1(BAD)", *(["2(GOOD)"] * 16)])
        _, u, z, meta = read_process_files([path])
        assert np.isnan(u[0, 0])
        assert meta["invalid_numeric_readings_before_fill"] == 1
        with path.open("a") as f:
            f.write("$2025-04-01 00:01:00,1(GOOD)\n")
        with self.assertRaisesRegex(ValueError, "source may be incomplete"):
            read_process_files([path])


    def test_visual_schema_excludes_filename_and_time(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        path = Path(temporary.name) / "features.csv"
        with path.open("w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=[*FEATURE_COLUMNS, "img_name", "time", "Unnamed: 0"])
            writer.writeheader()
            writer.writerow({**{name: "1" for name in FEATURE_COLUMNS},
                             "img_name": "2025-04-01 00:00:30.jpg", "time": "2025-04-01 00:00:30", "Unnamed: 0": 3})
        t, values, origins, meta = read_visual_features(path)
        assert values.shape == (1, 52)
        assert meta["feature_count"] == 52
        assert set(meta["excluded_metadata"]) == {"img_name", "time", "Unnamed: 0"}
        np.testing.assert_array_equal(origins,t)

    def test_descriptor_history_is_metadata_and_cannot_use_future_captures(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'history.csv'
            def write(origin):
                with path.open('w',newline='') as f:
                    writer=csv.DictWriter(f,fieldnames=[*FEATURE_COLUMNS,'time','img_name','feature_source_start_time'])
                    writer.writeheader();writer.writerow({**{name:1 for name in FEATURE_COLUMNS},
                        'time':'2025-04-01 01:00:00','img_name':'2025-04-01 01:00:00.jpg',
                        'feature_source_start_time':origin})
            write('2025-04-01 00:10:00')
            t,v,origins,meta=read_visual_features(path)
            assert v.shape==(1,52)
            assert int(t[0]-origins[0])==50*MINUTE_NS
            assert meta['source_timing']=='explicit causal descriptor history'
            write('2025-04-01 01:01:00')
            with self.assertRaisesRegex(ValueError,'future source'):
                read_visual_features(path)

    def test_rolling_visual_source_history_is_purged_at_partition_boundaries(self):
        t,u,z,v=arrays(1000)
        ordinary,_=build_samples(t,u,z,t,v)
        rolling,_=build_samples(t,u,z,t,v,visual_source_start_times=t-50*MINUTE_NS)
        ordinary_split=assign_partitions(ordinary,(.7,.15,.15),21)
        rolling_split=assign_partitions(rolling,(.7,.15,.15),21)
        assert np.array_equal(rolling['visual_source_start_ns'],rolling['visual_time_ns']-50*MINUTE_NS)
        assert rolling['source_start_ns'][rolling['val_idx'][0]]>=ordinary['source_start_ns'][ordinary['val_idx'][0]]
        assert rolling['time_ns'][rolling['val_idx'][0]]>ordinary['time_ns'][ordinary['val_idx'][0]]
        for label in ['val','test']:
            idx=rolling[label+'_idx']
            assert rolling['visual_source_start_ns'][idx].min()==rolling['source_start_ns'][idx].min()
            assert len(idx)<len(ordinary[label+'_idx'])


if __name__ == "__main__":
    unittest.main()
