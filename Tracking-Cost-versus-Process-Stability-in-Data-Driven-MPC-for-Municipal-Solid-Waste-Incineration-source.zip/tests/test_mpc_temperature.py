import hashlib
import numpy as np
import pytest
from mswi_experiments.mpc_temperature import TemperatureCEM,rank_candidates,acceptance_tier,select_configuration
from mswi_experiments.mpc_temperature_study import REF,SAMPLE_KEYS,shared
from mswi_experiments.ridge_policy_study import read_npz
from mswi_experiments.ridge_policy_planning import CEMPlanner

def test_elites_never_include_infeasible_candidates():
    score=np.array([[1.,999.,3.,1000.]]);feasible=np.array([[True,False,True,False]])
    winner,elite,count=rank_candidates(score,feasible)
    assert winner.tolist()==[2] and count.tolist()==[2]
    assert set(elite[0])=={0,2} and elite.shape==(1,16)
    with pytest.raises(AssertionError):rank_candidates(score,np.zeros_like(feasible))

def reference():return np.tile(np.array([-30.,50.,30.,1.,.3,.1]),(4,1))

def test_one_percent_is_relative_and_does_not_relax_cost():
    r=reference();c=r.copy();c[:,0]+=1;c[:,1:]=1.01*r[:,1:]
    assert not acceptance_tier(r,c,0)['pass']
    result=acceptance_tier(r,c,.01);assert result['pass']
    assert result['allowed_degradation'][0][-1]==pytest.approx(.001)
    c[:,5]=.11;assert not acceptance_tier(r,c,.01)['pass']
    c=r.copy();c[:,0]-=1;assert not acceptance_tier(r,c,.01)['pass']

def test_zero_reference_has_no_added_absolute_tolerance():
    r=reference();r[:,5]=0;c=r.copy();c[:,0]+=1;c[:,5]=1e-12
    assert not acceptance_tier(r,c,.01)['pass']
    c[:,5]=0;assert acceptance_tier(r,c,.01)['pass']

def test_strict_tier_has_priority_and_maximin_ties_are_fixed():
    r=reference();c={k:r.copy() for k in 'ABCDE'}
    c['A'][:,0]+=.1;c['B'][:,0]+=5;c['B'][:,1:]*=1.005
    x=select_configuration(r,c);assert x['selected']=='A' and x['selected_tier']=='strict_pass'
    c['C']=c['A'].copy();assert select_configuration(r,c)['selected']=='A'
    c['A']=r.copy();c['C']=r.copy();assert select_configuration(r,c)['selected']=='B'
    c={k:r.copy() for k in 'ABCDE'};assert select_configuration(r,c)['selected'] is None

def test_common_noise_and_original_A_and_E_constraint():
    if not (REF/'inputs/val.npz').exists():pytest.skip('local study fixtures unavailable')
    stats,execution,model=shared();inputs=read_npz(REF/'inputs/val.npz');ids=np.array([0,127])
    r={k:inputs[k][ids] for k in SAMPLE_KEYS};args=(r['u_hist'],r['z_hist'],r['z_current'],r['time_ns'],r['indices'],3)
    original=CEMPlanner(model,execution);oa,od=original.plan(*args)
    fingerprints=[]
    for weight,constrained in [(1,False),(2,False),(4,False),(8,False),(1,True)]:
        planner=TemperatureCEM(model,execution,weight,constrained);a,d=planner.plan(*args)
        fingerprints.append(d['noise_sha256'])
        if weight==1 and not constrained:
            np.testing.assert_array_equal(a,oa);np.testing.assert_array_equal(d['selected_original_return'],od['planner_score'])
            np.testing.assert_array_equal(d['best_requested_plan_b'],od['best_requested_plan_b'])
        if constrained:assert np.all(d['planned_temperature_margin']>=0)
        else:np.testing.assert_allclose(d['selected_planning_score'],d['selected_original_return']-(weight-1)*d['selected_temperature_cost'],atol=1e-12,rtol=0)
    for x in fingerprints[1:]:np.testing.assert_array_equal(x,fingerprints[0])
    expected=[]
    for idx in r['indices']:
        rng=np.random.default_rng(np.random.SeedSequence([2026,int(idx),3]));h=hashlib.sha256()
        for _ in range(4):h.update(rng.normal(size=(117,10,2)).tobytes())
        expected.append(h.hexdigest().encode())
    np.testing.assert_array_equal(fingerprints[0],np.array(expected))
