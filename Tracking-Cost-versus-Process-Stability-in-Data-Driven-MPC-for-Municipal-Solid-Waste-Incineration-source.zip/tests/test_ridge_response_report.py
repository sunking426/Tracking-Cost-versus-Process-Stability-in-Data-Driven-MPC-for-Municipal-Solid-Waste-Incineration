import copy

import numpy as np
import pytest

from mswi_experiments.ridge_response_report import (
    admission, coverage_summary, physical_responses, response_screen, render,
)


CFG={'response_deadband_sigma':.05,'max_response_amplitude_ratio':3.,
     'gate_endpoints':[1,5,10],'minimum_supported_executable_fraction':.8}


def fixture_response():
    # Every relationship is above the fixed deadband with modest variation.
    response=np.ones((5,10,4,8))*.2
    response[1]*=.9;response[2]*=1.1;response[3]*=1.2
    return response


def test_physical_aggregation_averages_six_temperature_channels():
    a=np.zeros((5,10,9,8));a[:,:,0]=6;a[:,:,6]=2;a[:,:,7]=3;a[:,:,8]=4
    p=physical_responses(a,np.arange(1,9))
    assert p.shape==(5,10,4,8)
    np.testing.assert_array_equal(p[0,0],np.outer([1,2,3,4],np.arange(1,9)))


def test_consistent_inverse_response_across_time_is_allowed():
    a=fixture_response();a[:,:5]*=-1
    s=response_screen(a,np.ones(4),CFG)
    assert s['stable_pairs'].all() and s['response_eligible'].all()
    assert not s['material_flips'].any()


def test_material_same_horizon_disagreement_blocks_channel():
    a=fixture_response();a[2,4,1,3]=-.2
    s=response_screen(a,np.ones(4),CFG)
    assert s['stable_pairs'][:,3].all()
    assert s['material_flips'][1,1,3]
    assert not s['response_eligible'][3]
    assert s['response_eligible'][[0,1,2,4,5,6,7]].all()


def test_tiny_sign_disagreement_does_not_count_as_material():
    a=fixture_response();a[:,0,0,0]=.001;a[2,0,0,0]=-.001
    s=response_screen(a,np.ones(4),CFG)
    assert not s['material_flips'][0,0,0] and s['response_eligible'][0]


def test_amplitude_disagreement_cannot_be_called_stable():
    a=fixture_response();a[2,9,:,0]=4
    s=response_screen(a,np.ones(4),CFG)
    assert s['same_sign'][:,0].all()
    assert not s['stable_pairs'][:,0].any() and not s['response_eligible'][0]


def test_full_reference_is_not_size_matched_but_can_flag_opposition():
    a=fixture_response();a[0,9,:,0]=-.2
    s=response_screen(a,np.ones(4),CFG)
    assert not s['material_flips'][:,:,0].any()
    assert s['reference_opposes'][:,0].all() and not s['stable_pairs'][:,0].any()


def test_zero_responses_cannot_pass_ratio_or_deadband():
    s=response_screen(np.zeros((5,10,4,8)),np.ones(4),CFG)
    assert not s['stable_pairs'].any() and not s['response_eligible'].any()
    assert np.isinf(s['amplitude_ratio']).all()


def test_admission_requires_both_signs_and_validation_coverage():
    s=response_screen(fixture_response(),np.ones(4),CFG)
    c={'joint_fraction':np.ones((8,2)).tolist()};c['joint_fraction'][3][0]=.799
    g=admission(s,c,CFG)
    assert g['eligible_channels']==[0,1,2,4,5,6,7]
    c['joint_fraction'][3][0]=.8
    assert admission(s,c,CFG)['eligible_channels']==list(range(8))


def test_coverage_separates_projected_execution_from_support():
    requests=np.zeros((16,8));requests[np.arange(16),np.repeat(np.arange(8),2)]=np.tile([-.1,.1],8)
    execution=np.broadcast_to(requests,(10,16,8)).copy();execution[:2,0]*=.5
    full=np.ones((10,16),bool);full[:2,0]=False
    supported=np.ones((10,16),bool);supported[2:4,0]=False
    v={'full_request_executed':full,'supported':supported,'executed_delta':execution,
       'requested_delta':requests,'baseline_supported':np.ones(10,bool),'logged_supported':np.zeros(10,bool)}
    c=coverage_summary(v)
    assert c['full_request_fraction'][0][0]==.8
    assert c['requested_support_fraction'][0][0]==.8
    assert c['joint_fraction'][0][0]==.6
    assert c['mean_amplitude_fraction'][0][0]==.9
    assert c['baseline_support_fraction']==1 and c['logged_support_fraction']==0


@pytest.mark.parametrize('shape',[(5,9,4,8),(4,10,4,8),(5,10,9,8)])
def test_bad_response_shape_raises(shape):
    with pytest.raises(ValueError):response_screen(np.zeros(shape),np.ones(4),CFG)


def test_scientific_figures_render_all_three_sets(tmp_path):
    a=fixture_response();s=response_screen(a,np.ones(4),CFG)
    cov={'joint_fraction':np.ones((8,2)).tolist()}
    result={'stable_pairs':s['stable_pairs'].tolist(),'material_flips':s['material_flips'].tolist(),
            'coverage':{'val':cov,'test':copy.deepcopy(cov)}}
    render(tmp_path,result,{'step':a,'pulse':a})
    assert len(list((tmp_path/'figures').glob('*.png')))==3
    assert len(list((tmp_path/'figures').glob('*.svg')))==3
