import numpy as np
import torch
from mswi_experiments.retrieval import VisualMemory


class KeyModel(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.anchor = torch.nn.Parameter(torch.zeros(1))

    def retrieval_key(self, u, z):
        return torch.cat([u.flatten(1), z.flatten(1)], dim=1)


def test_memory_cannot_return_held_out_sample(tmp_path):
    data = {'u_hist': np.array([[[1., 0.]], [[0., 1.]], [[-1., 0.]]], dtype=np.float32),
            'z_hist': np.zeros((3, 1, 1), dtype=np.float32),
            'visual': np.array([[10., 0.], [20., 0.], [999., 999.]], dtype=np.float32)}
    memory = VisualMemory(KeyModel(), data, np.array([0, 1]), max_items=2, k=2)
    visual, indices = memory.query(data['u_hist'][2:], data['z_hist'][2:])
    assert set(indices).issubset({0, 1})
    assert not np.any(visual.numpy() == 999.)
    memory.save(tmp_path)
    saved = np.load(tmp_path / 'visual_memory.npz', allow_pickle=False)
    np.testing.assert_array_equal(saved['indices'], [0, 1])


def test_exact_record_is_retrieved():
    data = {'u_hist': np.eye(3, dtype=np.float32)[:, None, :],
            'z_hist': np.zeros((3, 1, 1), dtype=np.float32),
            'visual': np.arange(6, dtype=np.float32).reshape(3, 2)}
    memory = VisualMemory(KeyModel(), data, np.array([0, 1, 2]), max_items=3, k=3)
    visual, indices = memory.query(data['u_hist'][1:2], data['z_hist'][1:2])
    np.testing.assert_array_equal(indices, [1])
    np.testing.assert_array_equal(visual.numpy(), data['visual'][1:2])
