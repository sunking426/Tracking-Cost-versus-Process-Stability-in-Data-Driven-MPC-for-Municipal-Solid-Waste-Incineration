import numpy as np
import pytest
from mswi_experiments.mpc_ablation import AblationExecution,AblationCEM,CandidateNoise
from mswi_experiments.mpc_stability_study import shared,REF,SAMPLE_KEYS
from mswi_experiments.mpc_stability import StabilityCEM
from mswi_experiments.ridge_policy_study import read_npz
from mswi_experiments.ridge_policy import RidgePolicyEnv


def setup():
    p,e,m=shared();s=read_npz(REF/'inputs/val.npz')
    return p,e,m,{k:s[k][[0,127]] for k in SAMPLE_KEYS}


def test_disabled_dimensions_bitwise_equivalent_and_crn():
    p,e,m,s=setup();old=StabilityCEM(m,e,8,p)
    eight=AblationExecution(e.stats,read_npz(REF/'support.npz'),8,zero_extra=True)
    new=AblationCEM(m,eight)
    args=(s['u_hist'],s['z_hist'],s['z_current'],s['time_ns'],s['indices'])
    for step in range(2):
        a,od=old.plan(*args,step);b,nd=new.plan(*args,step)
        np.testing.assert_array_equal(a,b)
        for k,v in od.items():
            if k=='best_requested_plan_b':
                np.testing.assert_array_equal(v,nd[k][...,:2]);assert np.all(nd[k][...,2:]==0)
            else:np.testing.assert_array_equal(v,nd[k])
    generators=[CandidateNoise(s['indices'],7,d,pop) for d,pop in ((2,128),(8,128),(8,512))]
    for _ in range(4):
        a,b,c=[g.draw() for g in generators]
        np.testing.assert_array_equal(a,b[...,:2]);np.testing.assert_array_equal(b,c[:,:117])


@pytest.mark.parametrize('channels,admission',[(8,'supported'),(2,'complete'),(2,'projection')])
def test_nonzero_candidates_match_recursive_canonical_dynamics(channels,admission):
    p,e,m,s=setup();ex=AblationExecution(e.stats,read_npz(REF/'support.npz'),channels,admission)
    planner=AblationCEM(m,ex);plans=np.random.default_rng(188).uniform(-1,1,(2,3,10,channels));plans[:,0]=0
    values,trace=planner.objective_components(plans,s['u_hist'],s['z_hist'],s['z_current'],s['time_ns'],True)
    for j in range(3):
        env=RidgePolicyEnv(m,ex,horizon=10);env.reset(options={'inputs':s})
        ret=np.zeros(2);tc=np.zeros(2);f=np.zeros(2);o=np.zeros(2);last=s['z_current']
        for step in range(10):
            _,r,_,_,info=env.step(plans[:,j,step]);ret+=r.astype(float);tc+=info['tracking_cost'][:,0].astype(float)
            nxt=info['pred_cv'];f+=abs(nxt[:,7]-last[:,7])/5;o+=abs(nxt[:,8]-last[:,8])/.5;last=nxt
            np.testing.assert_allclose(nxt,trace['prediction'][:,j,step],atol=1e-9,rtol=0)
        for a,b in zip(values,(ret-3*tc-8*(f+o),ret,tc,f,o)):np.testing.assert_allclose(a[:,j],b,atol=1e-5,rtol=0)


def test_admission_difference_is_explicit():
    _,e,_,_=setup();sup=read_npz(REF/'support.npz')
    complete=np.array([True,False,True,False]);supported=np.array([True,True,False,False]);nonzero=np.ones(4,dtype=bool)
    for mode,expected in [('supported',[1,0,0,0]),('complete',[1,0,1,0]),('projection',[1,1,1,1])]:
        ex=AblationExecution(e.stats,sup,2,mode)
        np.testing.assert_array_equal(ex.admit(complete,supported,nonzero),expected)
