"""Ridge dynamics contracts using synthetic systems, never study outcomes."""
import numpy as np
import pytest

from mswi_experiments.data import MINUTE_NS
from mswi_experiments.numeric_baselines import linear_increment, numeric_features
from mswi_experiments.ridge_dynamics import (
    RidgeDynamics, continuous_chains, persistence_rollout, recursive_rollout,
)


def weights():
    return {'x_mean': np.zeros(178), 'x_scale': np.ones(178),
            'coef': np.zeros((9, 178)), 'intercept': np.zeros(9),
            'delta_scale': np.ones(9), 'kind': np.asarray('ridge'), 'alpha': np.asarray(100.)}


def histories(n=2):
    rng = np.random.default_rng(71)
    return rng.normal(size=(n, 11, 8)), rng.normal(size=(n, 10, 9))


def chain_data():
    n = 36
    times = np.arange(n, dtype=np.int64)*MINUTE_NS
    following = np.arange(1, n+1, dtype=np.int64); following[-1] = -1
    # Purged records remain in source arrays but do not belong to a partition.
    return {'time_ns': times, 'next_idx': following,
            'source_start_ns': times-MINUTE_NS,
            'source_end_ns': times+MINUTE_NS,
            'train_idx': np.arange(0, 8), 'val_idx': np.arange(12, 20),
            'test_idx': np.arange(24, 36)}


def test_loading_reuses_exact_canonical_one_step_scaling(tmp_path):
    rng = np.random.default_rng(14)
    w = weights()
    w.update(x_mean=rng.normal(size=178), x_scale=rng.uniform(.2, 3, 178),
             coef=rng.normal(size=(9, 178)), intercept=rng.normal(size=9),
             delta_scale=rng.uniform(.1, 4, 9))
    path = tmp_path/'ridge.npz'; np.savez_compressed(path, **w)
    model = RidgeDynamics.load(path)
    u, z = histories()
    expected_delta = linear_increment(w, numeric_features({'u_hist': u, 'z_hist': z}))
    np.testing.assert_array_equal(model.predict_delta(u, z), expected_delta)
    np.testing.assert_array_equal(model.predict_next(u, z), z[:, -1] + expected_delta)
    assert model.source_path == path.resolve()
    assert model.predict_next(u, z).dtype == np.float64
    with pytest.raises(ValueError):
        model.weights['coef'][0, 0] = 12


def test_recursive_feedback_and_mv_alignment_match_known_linear_system():
    w = weights()
    # First channel: z_t = 1.5*z_(t-1) + u_t + 0.1*u_(t-1).
    w['coef'][0, 88+9*9] = .5
    w['coef'][0, 10*8] = 1.
    w['coef'][0, 9*8] = .1
    # Other CVs have constant increments 1..8.
    w['intercept'][1:] = np.arange(1, 9)
    model = RidgeDynamics(w)
    u, z = np.zeros((2, 11, 8)), np.zeros((2, 10, 9))
    u[:, -2, 0] = [2, 4]; u[:, -1, 0] = [3, 5]
    z[:, -1, 0] = [10, -2]
    path = np.repeat(u[:, -1, None], 4, axis=1)
    path[:, 1:, 0] = [[7, -1, 6], [1, 8, -2]]
    initial_u, initial_z, initial_path = u.copy(), z.copy(), path.copy()
    actual = recursive_rollout(model, u, z, path)
    expected = np.zeros((2, 4, 9))
    old_u, old_z = u[:, -2, 0].copy(), z[:, -1, 0].copy()
    for k in range(4):
        current_u = path[:, k, 0]
        old_z = 1.5*old_z + current_u + .1*old_u
        expected[:, k, 0] = old_z
        expected[:, k, 1:] = (k+1)*np.arange(1, 9)
        old_u = current_u
    np.testing.assert_allclose(actual, expected, atol=1e-13)
    np.testing.assert_array_equal(u, initial_u)
    np.testing.assert_array_equal(z, initial_z)
    np.testing.assert_array_equal(path, initial_path)


def test_future_cv_labels_cannot_change_recursive_forecast_or_chain_selection():
    data = chain_data(); chains = continuous_chains(data, 'test', 4)
    u, z = histories(len(chains)); path = np.repeat(u[:, -1, None], 4, axis=1)
    w = weights(); w['coef'][0, 88+9*9] = .5
    model = RidgeDynamics(w)
    baseline = recursive_rollout(model, u, z, path)
    data['z_target'] = np.full((len(data['time_ns']), 9), 1e20)
    data['z_current'] = -data['z_target']; data['action'] = np.full((36, 8), -1e30)
    np.testing.assert_array_equal(chains, continuous_chains(data, 'test', 4))
    np.testing.assert_array_equal(baseline, recursive_rollout(model, u, z, path))


def test_persistence_holds_initial_state_without_future_updates():
    _, z = histories()
    p = persistence_rollout(z, 10)
    assert p.shape == (2, 10, 9)
    for k in range(10):
        np.testing.assert_array_equal(p[:, k], z[:, -1])


def test_chains_preserve_partition_and_all_overlapping_eligible_starts():
    data = chain_data()
    chains = continuous_chains(data, 'test', 10)
    np.testing.assert_array_equal(chains, np.arange(24, 27)[:, None]+np.arange(10))
    # next_idx points into a purged row; no such chain is allowed.
    train = continuous_chains(data, 'train', 4)
    np.testing.assert_array_equal(train, np.arange(5)[:, None]+np.arange(4))
    assert np.isin(train, data['train_idx']).all()
    assert continuous_chains(data, 'val', 10).shape == (0, 10)
    np.testing.assert_array_equal(continuous_chains(data, 'val', 1)[:, 0], data['val_idx'])


def test_chains_stop_at_missing_links_and_wrong_timestamps():
    data = chain_data(); data['next_idx'][28] = -1
    np.testing.assert_array_equal(continuous_chains(data, 'test', 4)[:, 0], [24, 25, 29, 30, 31, 32])
    data = chain_data(); data['next_idx'][28] = 30
    np.testing.assert_array_equal(continuous_chains(data, 'test', 4)[:, 0], [24, 25, 29, 30, 31, 32])


def test_source_partition_overlap_is_rejected():
    data = chain_data(); data['source_start_ns'][data['val_idx'][0]] = 0
    with pytest.raises(ValueError, match='source ranges overlap'):
        continuous_chains(data)


@pytest.mark.parametrize('field,value', [('x_scale', np.zeros(178)),
                                       ('coef', np.zeros((9, 177))),
                                       ('delta_scale', np.full(9, np.nan)),
                                       ('kind', np.asarray('zero')),
                                       ('alpha', np.asarray(-1.))])
def test_model_rejects_invalid_saved_contracts(field, value):
    w = weights(); w[field] = value
    with pytest.raises(ValueError):
        RidgeDynamics(w)


def test_forecasting_rejects_invalid_shapes_inputs_and_shifted_first_mv():
    model = RidgeDynamics(weights()); u, z = histories()
    with pytest.raises(ValueError): model.predict_delta(u[:, :-1], z)
    bad = z.copy(); bad[0, 0, 0] = np.nan
    with pytest.raises(ValueError): model.predict_next(u, bad)
    path = np.repeat(u[:, -1, None], 2, axis=1)
    shifted = path.copy(); shifted[:, 0, 0] += 1
    with pytest.raises(ValueError, match='first MV'): recursive_rollout(model, u, z, shifted)
    path[0, 1, 0] = np.inf
    with pytest.raises(ValueError, match='finite'): recursive_rollout(model, u, z, path)
    with pytest.raises(ValueError): persistence_rollout(z, 0)
    with pytest.raises(ValueError): continuous_chains(chain_data(), horizon=1.5)


def test_nonfinite_model_output_is_not_clipped_or_silently_replaced():
    class BrokenDynamics:
        def predict_next(self, u, z):
            return np.full((len(u), 9), np.inf)
    u, z = histories(); path = u[:, -1, None]
    with pytest.raises(FloatingPointError): recursive_rollout(BrokenDynamics(), u, z, path)
