"""Behavioral contracts for fixed-block long-horizon prediction validation."""
import copy
import json

import numpy as np
import pytest
import torch

from mswi_experiments.data import MINUTE_NS
from mswi_experiments.models import Twin
from mswi_experiments.validation import (
    chronological_blocks, run_horizon_validation, select_validation_chains,
)


def fixture(n=900):
    t=np.arange(n,dtype=np.float32)
    u=t[:,None]+np.arange(8,dtype=np.float32)[None]
    z=t[:,None]*.25+np.arange(9,dtype=np.float32)[None]
    rng=np.random.default_rng(3)
    data={'u_hist':np.stack([u-lag for lag in range(10,-1,-1)],axis=1),
          'z_hist':np.stack([z-lag*.25 for lag in range(10,0,-1)],axis=1),
          'u_current':u,'z_current':z.copy(),'z_target':z.copy(),'z_prev':z-.25,
          'action':np.ones_like(u),'visual':rng.normal(size=(n,7)).astype(np.float32),
          'time_ns':np.arange(n,dtype=np.int64)*MINUTE_NS,
          'train_idx':np.arange(n//2),'val_idx':np.arange(n//2,n*2//3),
          'test_idx':np.arange(n*2//3,n),'next_idx':np.arange(1,n+1)}
    for i in (n//2-1,n*2//3-1,n-1):data['next_idx'][i]=-1
    stats={name:[0.]*width for name,width in [('u_mean',8),('z_mean',9),('v_mean',7),('delta_mean',9)]}
    stats.update({name:[1.]*width for name,width in [('u_scale',8),('z_scale',9),('v_scale',7),('delta_scale',9)]})
    return data,stats


def test_chronological_blocks_and_chains_are_fixed_and_disjoint():
    data,_=fixture()
    chains,labels,blocks,description=select_validation_chains(data,count=3,horizon=50)
    assert chains.shape==(3,50)
    assert np.unique(chains).size==chains.size
    assert [x['rollout_chains'] for x in description]==[1,1,1]
    for b in range(3):assert np.isin(chains[labels==b],blocks[b]).all()
    changed=copy.deepcopy(data)
    changed['z_target']+=100000
    changed['visual']*=100000
    np.testing.assert_array_equal(chains,select_validation_chains(changed,count=3,horizon=50)[0])
    shuffled=data['test_idx'][::-1]
    assert all(np.array_equal(a,b) for a,b in zip(blocks,chronological_blocks(shuffled,data['time_ns'])))


def test_chain_selection_cannot_cross_gaps_or_time_blocks():
    data,_=fixture()
    # This leaves fewer than one complete fifty-step trajectory in the first
    # hundred-row block, despite many valid rows elsewhere in the test period.
    data['next_idx'][620]=-1
    data['next_idx'][660]=-1
    with pytest.raises(ValueError,match='complete disjoint'):
        select_validation_chains(data,count=3,horizon=50)
    with pytest.raises(ValueError,match='one chain'):
        select_validation_chains(data,count=2,horizon=50)


def test_validation_writes_shared_raw_evidence_and_true_persistence(tmp_path):
    data,stats=fixture()
    torch.manual_seed(7)
    twins={name:Twin(stats,mode='sensor' if name=='sensor' else 'multi',hidden=4)
           for name in ('multi','sensor','eval')}
    before={name:{k:v.clone() for k,v in twin.state_dict().items()} for name,twin in twins.items()}
    result=run_horizon_validation(data,stats,twins,
        {'training':{'threads':1},'retrieval':{'max_items':8,'k':3},
         'validation':{'rollout_starts':3,'max_horizon':50,'horizons':[1,5,10,20,50]}},tmp_path)
    assert result==json.loads((tmp_path/'validation_results.json').read_text())
    assert set(result['models'])=={'multi','sensor','eval','persistence'}
    assert result['horizons']==[1,5,10,20,50]
    common=None
    for name in result['models']:
        with np.load(tmp_path/f'{name}_rollout.npz',allow_pickle=False) as raw:
            if common is None:common=raw['indices'].copy()
            np.testing.assert_array_equal(common,raw['indices'])
            assert raw['truth'].shape==raw['prediction'].shape==(3,50,4)
            expected=np.abs(raw['prediction'].astype(float)-raw['truth']).mean(axis=0)
            np.testing.assert_allclose(expected,result['models'][name]['rollout']['per_step']['mae'])
            np.testing.assert_allclose(expected[49],result['models'][name]['rollout']['mae'][-1])
            if name!='persistence':assert np.isin(raw['memory_source_index'],data['train_idx']).all()
            else:
                np.testing.assert_array_equal(raw['memory_source_index'],-np.ones((3,50)))
                expected_cv=np.repeat(data['z_prev'][common[:,0],None,:],50,axis=1)
                np.testing.assert_array_equal(raw['prediction_cv'],expected_cv)
        assert len((tmp_path/f'{name}_rollout.csv').read_text().splitlines())==151
    np.testing.assert_allclose(result['models']['persistence']['onestep']['mae'],[.25]*4)
    np.testing.assert_allclose(result['models']['persistence']['rollout']['mae'][-1],[12.5]*4)
    for name,twin in twins.items():
        assert all(torch.equal(before[name][k],v) for k,v in twin.state_dict().items())
    manifest=json.loads((tmp_path/'validation_manifest.json').read_text())
    assert manifest['previously_inspected_test_period'] is True
    assert manifest['block_chain_allocation']==[1,1,1]
