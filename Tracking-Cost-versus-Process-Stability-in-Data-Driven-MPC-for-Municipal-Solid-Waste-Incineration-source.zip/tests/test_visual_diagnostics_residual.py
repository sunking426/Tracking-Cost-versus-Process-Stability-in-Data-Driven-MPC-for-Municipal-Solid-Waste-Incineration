"""Behavioral checks for source-separated sensor-residual calibration."""
import copy

import numpy as np
import pytest

from mswi_experiments.data import MINUTE_NS
from mswi_experiments.visual_diagnostics_residual import (
    CORRECTORS, _apply_residual_ridge, _fit_residual_ridge,
    _source_disjoint_split, run_residual_diagnostics,
)


def fixture():
    rng = np.random.default_rng(8)
    n = 800
    time = np.arange(n, dtype=np.int64) * MINUTE_NS
    z = rng.normal(size=(n, 9)).astype(np.float32)
    u = rng.normal(size=(n, 8)).astype(np.float32)
    data = {"u_hist": np.repeat(u[:, None, :], 11, axis=1),
            "z_hist": np.repeat(z[:, None, :], 10, axis=1),
            "z_prev": z.copy(), "z_target": z + .25, "z_current": z.copy(),
            "u_current": u, "action": np.ones_like(u),
            "visual": rng.normal(size=(n, 52)).astype(np.float32),
            "time_ns": time, "source_start_ns": time - 10 * MINUTE_NS,
            "source_end_ns": time + MINUTE_NS,
            "train_idx": np.arange(480), "val_idx": np.arange(530, 640),
            "test_idx": np.arange(690, 800)}
    metadata = {name: data[name].copy() for name in ("source_start_ns", "source_end_ns")}
    variants = {name: rng.normal(size=(n, dim)).astype(np.float32)
                for name, dim in [("timing4", 4), ("original52", 52), ("static40", 40),
                                  ("fixed10", 52), ("fixed60", 52), ("null_fixed10", 52)]}
    return data, variants, metadata


def test_split_retains_complete_sources_in_separate_time_intervals():
    data, _, metadata = fixture()
    # A long actual descriptor history crosses a nominal split despite its timestamp.
    metadata["source_start_ns"][325] = data["time_ns"][270]
    metadata["source_end_ns"][280] = data["time_ns"][290]
    split = _source_disjoint_split(data, metadata)
    assert 325 not in split["inner_val"] and 280 not in split["early_fit"]
    ordered = [split[name] for name in ("early_fit", "inner_val", "calibration", "val", "test")]
    for left, right in zip(ordered, ordered[1:]):
        assert split["source_end_ns"][left].max() < split["source_start_ns"][right].min()
    assert split["source_start_ns"][split["inner_val"]].min() >= split["cut_times_ns"][0] + 21 * MINUTE_NS
    assert split["source_start_ns"][split["calibration"]].min() >= split["cut_times_ns"][1] + 21 * MINUTE_NS
    assert set(split["early_fit"]).isdisjoint(split["inner_val"])
    assert set(split["inner_val"]).isdisjoint(split["calibration"])


def test_missing_or_overlapping_sources_fail_explicitly():
    data, _, metadata = fixture()
    del metadata["source_start_ns"]
    with pytest.raises(ValueError, match="source_start_ns"):
        _source_disjoint_split(data, metadata)
    data, _, metadata = fixture()
    metadata["source_start_ns"][data["val_idx"][0]] = data["time_ns"][470]
    with pytest.raises(ValueError, match="outer residual partitions have overlapping"):
        _source_disjoint_split(data, metadata)


def test_ridge_uses_calibration_scalers_and_saved_weights_replay(tmp_path):
    rng = np.random.default_rng(19)
    x = rng.normal(size=(300, 6))
    residual = x @ rng.normal(size=(6, 4)) + [5., -10., 1., .5]
    x[:, -1] = 3.  # Constant features must remain reproducible.
    fitted = _fit_residual_ridge(x[:180], residual[:180], x[180:240], residual[180:240])
    np.testing.assert_allclose(fitted["x_mean"], x[:180].mean(axis=0))
    np.testing.assert_allclose(fitted["residual_mean"], residual[:180].mean(axis=0))
    assert fitted["x_scale"][-1] == 1.
    prediction = _apply_residual_ridge(fitted, x[240:])
    np.savez_compressed(tmp_path / "weights.npz", **fitted)
    with np.load(tmp_path / "weights.npz", allow_pickle=False) as saved:
        replay = _apply_residual_ridge(dict(saved), x[240:])
    np.testing.assert_array_equal(prediction, replay)
    expected = (((x[240:] - fitted["x_mean"]) / fitted["x_scale"]) @ fitted["coef"].T
                + fitted["intercept"]) * fitted["residual_scale"] + fitted["residual_mean"]
    np.testing.assert_array_equal(prediction, expected)


def test_full_diagnostic_selection_and_scaling_ignore_outer_test(monkeypatch, tmp_path):
    import mswi_experiments.visual_diagnostics_residual as module

    data, variants, metadata = fixture()
    config = {"training": {"threads": 1, "batch_size": 64}, "diagnostics": {"seeds": [11]}}
    fit_calls, predict_calls = [], []

    def fake_fit(training_data, stats, mode, seed, training_config, outdir):
        fit_calls.append((copy.deepcopy(stats), np.asarray(training_data["train_idx"]).copy(),
                          np.asarray(training_data["val_idx"]).copy(), np.asarray(training_data["test_idx"]).copy()))
        return object(), {"seed": seed}

    def fake_predict(model, prediction_data, indices, batch_size):
        predict_calls.append(np.asarray(indices).copy())
        return np.asarray(prediction_data["z_prev"])[indices] + .1

    monkeypatch.setattr(module, "fit_twin", fake_fit)
    monkeypatch.setattr(module, "predict_twin", fake_predict)
    result = run_residual_diagnostics(data, variants, metadata, config, tmp_path / "first")
    # Completely different test outcomes and feature marginals must not alter selection.
    changed = copy.deepcopy(data)
    test = data["test_idx"]
    changed["z_target"][test] += 10000
    changed["u_hist"][test] += 5000
    changed_variants = {name: value.copy() for name, value in variants.items()}
    for value in changed_variants.values():
        value[test] += 3000
    again = run_residual_diagnostics(changed, changed_variants, metadata, config, tmp_path / "second")
    assert fit_calls[0][0] == fit_calls[1][0]
    stats, early, inner, internal_test = fit_calls[0]
    np.testing.assert_array_equal(inner, internal_test)
    assert not set(early).intersection(test)
    np.testing.assert_allclose(stats["u_mean"], data["u_hist"][early].reshape(-1, 8).mean(axis=0, dtype=np.float64))
    assert sum(np.array_equal(call, test) for call in predict_calls) == 2  # Once per run.
    for name in CORRECTORS:
        left = result["seeds"]["11"]["correctors"][name]
        right = again["seeds"]["11"]["correctors"][name]
        assert left["alpha"] == right["alpha"]
        assert left["val_normalized_mse"] == right["val_normalized_mse"]
        first = np.load(tmp_path / "first" / left["weights_file"])
        second = np.load(tmp_path / "second" / right["weights_file"])
        for key in first.files:
            np.testing.assert_array_equal(first[key], second[key])
        assert right["metrics"]["test"]["mae"][0] > left["metrics"]["test"]["mae"][0] + 1000
    split = _source_disjoint_split(data, metadata)
    saved = np.load(tmp_path / "first/seed_11/fixed10/test_predictions.npz")
    fitted = dict(np.load(tmp_path / "first/seed_11/fixed10/ridge_weights.npz"))
    design = module._design(data, variants, "fixed10", split["test"])
    correction = _apply_residual_ridge(fitted, design)
    np.testing.assert_array_equal(saved["prediction"], saved["sensor_prediction"] + correction)
