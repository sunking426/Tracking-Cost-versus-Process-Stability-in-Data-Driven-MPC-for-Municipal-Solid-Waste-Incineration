"""Portable figure inputs and read-only summary output contracts."""
import hashlib
import json

from PIL import Image
import pytest

from mswi_experiments.figures import make_summary_figures
from mswi_experiments.flame_figures import _read_descriptor_records


def descriptor_input(tmp_path):
    path = tmp_path / 'features.csv'
    path.write_text('time,img_name,ft_1_area1\n2025-01-01 00:00:00,frame.jpg,0.5\n')
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    regions = {f'area{i}': [.1, .2, .3, .4] for i in range(1, 5)}
    path.with_suffix('.manifest.json').write_text(json.dumps({
        'output_sha256': digest, 'regions_normalized_xyxy': regions,
    }))
    manifest = {'schema_version': 2, 'visual': {
        'path': '/a/different/computer/features.csv', 'sha256': digest,
        'source_timing': 'explicit causal descriptor history',
    }}
    return path, manifest, regions


def test_relocated_visual_csv_is_explicit_and_content_verified(tmp_path):
    path, manifest, regions = descriptor_input(tmp_path)
    records, actual_regions = _read_descriptor_records(manifest, path)
    assert records['2025-01-01 00:00:00']['img_name'] == 'frame.jpg'
    assert actual_regions == list(regions.values())
    path.write_text(path.read_text().replace('0.5', '0.6'))
    with pytest.raises(ValueError, match='prepared dataset'):
        _read_descriptor_records(manifest, path)


def test_relocated_visual_csv_requires_matching_roi_provenance(tmp_path):
    path, manifest, _ = descriptor_input(tmp_path)
    path.with_suffix('.manifest.json').write_text(json.dumps({'output_sha256': 'wrong'}))
    with pytest.raises(ValueError, match='ROI provenance'):
        _read_descriptor_records(manifest, path)


def summary_sources(tmp_path):
    # Synthetic plot fixture only, not an empirical experiment or paper result.
    methods = ['linear_feedback', 'nearest_logged', 'bc', 'twin_td3',
               'sensor_td3bc', 'full_td3bc', 'offline_td3bc', 'cem_mpc']
    comparisons = ['sensor_td3bc', 'bc', 'offline_td3bc', 'cem_mpc',
                   'no_bc_init', 'no_bc_reg', 'no_policy_retrieval']
    validation = {'horizons': [1, 10, 50], 'models': {
        name: {'onestep': {'mae': [1., 2., 3., 4.]},
               'rollout': {'rmse': [[1., 2., 3., 4.]] * 3}}
        for name in ['multi', 'sensor', 'eval', 'persistence']}}
    statistics = {'primary_horizon': 10, 'horizons': {str(h): {
        'methods': {name: {'mean': [-float(h), 1., 2., 3., 4., .1, .5],
                           'seed_mean_sd': [0.] * 7} for name in methods},
        'comparisons': [{'comparator': name, 'mean_difference': [0.] * 7,
                         'seed_reset_crossed_ci95': [[-1., 1.]] * 7}
                        for name in comparisons],
    } for h in [10, 50]}}
    controls = {'main_methods': methods, 'advisory': {'observed_steps': 360}}
    sources = {}
    for relative, record in [('validation/validation_results.json', validation),
                             ('statistics/paired_statistics.json', statistics),
                             ('control/results.json', controls)]:
        path = tmp_path / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(record))
        sources[path] = path.read_bytes()
    return sources, validation, statistics


def test_summary_figures_need_no_paper_or_previous_run_and_preserve_sources(tmp_path):
    run = tmp_path / 'relocated-run'
    sources, validation, statistics = summary_sources(run)
    destination = tmp_path / 'generated-summary'
    result = make_summary_figures(run, destination)
    assert result == json.loads((destination / 'summary.json').read_text())
    assert result['prediction'] == validation
    assert result['control'] == statistics
    assert result['paper_figure_sources']['Fig3.png'] == 'recursive_horizons.png'
    assert result['paper_figure_sources']['Fig10.png'] == 'paired_return_intervals.png'
    for name in result['figures']:
        with Image.open(destination / name) as picture:
            picture.verify()
    for path, original in sources.items():
        assert path.read_bytes() == original
        assert result['source_sha256'][str(path.relative_to(run))] == hashlib.sha256(original).hexdigest()
    assert not (run / 'summary').exists()
    assert not (tmp_path / 'sci').exists()


def test_summary_missing_required_records_fails_without_partial_output(tmp_path):
    destination = tmp_path / 'generated-summary'
    with pytest.raises(FileNotFoundError):
        make_summary_figures(tmp_path / 'missing-run', destination)
    assert not destination.exists()
