"""Behavioral checks for paired visual-study uncertainty and pre-target strata."""
import copy
import csv
import json

import numpy as np
import pytest

from mswi_experiments.data import MINUTE_NS
from mswi_experiments.visual_diagnostics_statistics import (
    METHODS, build_strata, paired_block_interval, summarize_predictions,
)


def fixture(n=40):
    t = np.arange(n, dtype=np.float32)
    last = t[:, None] * .25 + np.arange(9, dtype=np.float32)[None]
    change = (t % 4)[:, None] * .125
    hist = np.stack([last - change, last], axis=1)
    times = np.arange(n, dtype=np.int64) * 6 * 60 * MINUTE_NS
    ages = np.tile(np.array([0., 2., 2.5, 5., 7.]), n // 5)
    data = {"z_hist": hist, "z_target": last + .25,
            "time_ns": times, "visual_time_ns": times - MINUTE_NS - (ages * MINUTE_NS).astype(np.int64),
            "train_idx": np.arange(20), "val_idx": np.arange(20, 28),
            "test_idx": np.arange(28, 40)}
    metadata = {"age_minutes": ages}
    variants = {method: np.zeros((n, 4), dtype=np.float32) for method in METHODS[1:]}
    return data, variants, metadata


def test_paired_bootstrap_preserves_difference_and_weights_unequal_blocks():
    # Two fits; the first block has three windows. Equal block means would be
    # 4, whereas the required window-weighted mean is 3.
    values = np.array([[[1.], [1.], [1.], [5.]],
                       [[3.], [3.], [3.], [7.]]])
    result = paired_block_interval(values, np.array([0, 0, 0, 1]), draws=10000, seed=19)
    assert result["difference"] == [3.]
    assert result["block_sample_counts"] == [3, 1]
    assert result["ci_lower"] == [1.] and result["ci_upper"] == [7.]
    assert result == paired_block_interval(values, [0, 0, 0, 1], draws=10000, seed=19)


def test_paired_constant_shift_cancels_arbitrary_shared_prediction_error():
    rng = np.random.default_rng(13)
    shared = rng.normal(size=(3, 30, 4)) * 100
    reference_error = shared + 10
    candidate_error = shared + 8
    result = paired_block_interval(reference_error - candidate_error,
                                   np.repeat(np.arange(10), 3), draws=200)
    np.testing.assert_allclose(result["difference"], 2., rtol=0, atol=1e-14)
    np.testing.assert_allclose(result["ci_lower"], 2., rtol=0, atol=1e-14)
    np.testing.assert_allclose(result["ci_upper"], 2., rtol=0, atol=1e-14)


def test_duplicate_seed_arrays_do_not_narrow_time_uncertainty():
    values = np.arange(12, dtype=float).reshape(1, 12, 1)
    blocks = np.repeat(np.arange(4), 3)
    original = paired_block_interval(values, blocks, draws=1000, seed=3)
    duplicated = paired_block_interval(np.repeat(values, 5, axis=0), blocks,
                                       draws=1000, seed=3)
    np.testing.assert_allclose(original["ci_lower"], duplicated["ci_lower"], rtol=0, atol=1e-12)
    np.testing.assert_allclose(original["ci_upper"], duplicated["ci_upper"], rtol=0, atol=1e-12)
    assert any("seed copies" in message for message in duplicated["warnings"])


def test_single_block_is_explicit_and_input_validation_rejects_bad_shapes():
    result = paired_block_interval(np.ones((1, 8, 2)), np.zeros(8), draws=20)
    assert result["ci_lower"] == result["ci_upper"] == [1., 1.]
    assert any("one_time_block" in message for message in result["warnings"])
    assert any("one_training_seed" in message for message in result["warnings"])
    with pytest.raises(ValueError, match="block_ids"):
        paired_block_interval(np.ones((1, 8, 2)), np.zeros(7))
    with pytest.raises(ValueError, match="finite"):
        paired_block_interval(np.full((1, 8, 2), np.nan), np.zeros(8))


def test_strata_thresholds_use_training_history_and_no_future_target():
    data, _, metadata = fixture()
    masks, specification = build_strata(data, metadata)
    changed = copy.deepcopy(data)
    changed["z_target"][:] = 1e9
    # Neither validation nor test observations may alter the training cutoffs.
    changed["z_hist"][data["val_idx"]] += 1000
    changed["z_hist"][data["test_idx"]] *= 1000
    changed_masks, changed_specification = build_strata(changed, metadata)
    assert specification == changed_specification
    for name in masks:
        np.testing.assert_array_equal(masks[name][data["train_idx"]],
                                      changed_masks[name][data["train_idx"]])
    for names in [("freshness_0_2_minutes", "freshness_2_5_minutes", "freshness_5_10_minutes"),
                  ("ordinary_dynamics", "high_dynamics"),
                  ("low_steam_load", "middle_steam_load", "high_steam_load")]:
        np.testing.assert_array_equal(sum(masks[name].astype(int) for name in names), 1)
    # Exact freshness boundaries belong only to their declared interval.
    assert masks["freshness_0_2_minutes"][1]
    assert masks["freshness_2_5_minutes"][3]
    assert masks["freshness_5_10_minutes"][4]


def save_predictions(root, data, seeds):
    indices = data["test_idx"]
    y = data["z_target"][indices]
    offsets = {method: 1. for method in METHODS}
    offsets.update(fixed10=.5, fixed60=.75, timing4=1.25)
    for method in METHODS:
        for position, seed in enumerate(seeds):
            path = root / "models" / method / f"seed_{seed}"
            path.mkdir(parents=True)
            prediction = y + offsets[method] + .125 * position
            np.savez_compressed(path / "test_predictions.npz", indices=indices,
                time_ns=data["time_ns"][indices], y=y, pred=prediction, error=prediction-y)


def test_summary_is_recomputable_keeps_all_strata_and_primary_comparisons(tmp_path):
    data, variants, metadata = fixture()
    seeds = [11, 23]
    save_predictions(tmp_path, data, seeds)
    config = {"diagnostics": {"seeds": seeds, "bootstrap_draws": 100, "bootstrap_seed": 99}}
    result = summarize_predictions(data, variants, metadata, tmp_path, config)
    assert result == json.loads((tmp_path / "statistics/summary.json").read_text())
    np.testing.assert_allclose(result["overall"]["sensor"]["mae"], 1.0625)
    np.testing.assert_allclose(result["overall"]["fixed10"]["mae"], .5625)
    for reference, expected in [("sensor", .5), ("timing4", .75)]:
        comparison = result["comparisons"][f"fixed10_vs_{reference}"]
        assert comparison["pair_priority"] == "prespecified_primary"
        assert comparison["primary_quantity"] == "temperature"
        assert comparison["endpoint_priorities"]["temperature"] == "prespecified_primary"
        assert comparison["endpoint_priorities"]["pressure"] == "prespecified_secondary"
        assert comparison["endpoint_priorities"]["steam"] == "prespecified_secondary"
        assert comparison["endpoint_priorities"]["oxygen"] == "prespecified_secondary"
        for interval in comparison["intervals"].values():
            np.testing.assert_allclose(interval["difference"], expected)
            np.testing.assert_allclose(interval["ci_lower"], expected)
            np.testing.assert_allclose(interval["ci_upper"], expected)
    assert result["strata"]["low_steam_load"]["samples"] == 0
    assert result["strata"]["low_steam_load"]["methods"]["fixed10"] is None
    assert len(result["source_prediction_sha256"]) == len(METHODS) * len(seeds)
    with np.load(tmp_path / "statistics/paired_error_arrays.npz", allow_pickle=False) as raw:
        np.testing.assert_array_equal(raw["indices"], data["test_idx"])
        np.testing.assert_allclose(np.abs(raw["error_fixed10"]).mean(axis=(0, 1)),
                                   result["overall"]["fixed10"]["mae"])
    assert (tmp_path / "statistics/strata.csv").exists()
    exploratory = result["comparisons"]["original52_vs_sensor"]
    assert exploratory["primary_quantity"] is None
    assert set(exploratory["endpoint_priorities"].values()) == {"exploratory"}
    negative = result["comparisons"]["fixed10_vs_null_fixed10"]
    assert negative["pair_priority"] == "exploratory_negative_control"
    assert set(negative["endpoint_priorities"].values()) == {"exploratory_negative_control"}
    np.testing.assert_allclose(negative["intervals"]["calendar_day"]["difference"], .5)
    with (tmp_path / "statistics/comparisons.csv").open() as handle:
        rows = list(csv.DictReader(handle))
    primary_rows = [row for row in rows if row["endpoint_priority"] == "prespecified_primary"]
    assert len(primary_rows) == 6  # two fixed pairs, three declared block definitions
    assert all(row["quantity"] == "temperature" and row["candidate"] == "fixed10"
               and row["reference"] in {"sensor", "timing4"} for row in primary_rows)


def test_summary_rejects_sample_misalignment_and_duplicate_seed_identity(tmp_path):
    data, variants, metadata = fixture()
    save_predictions(tmp_path, data, [11])
    with pytest.raises(ValueError, match="distinct training seeds"):
        summarize_predictions(data, variants, metadata, tmp_path,
                              {"diagnostics": {"seeds": [11, 11]}})
    path = tmp_path / "models/fixed10/seed_11/test_predictions.npz"
    with np.load(path) as raw:
        content = {name: raw[name] for name in raw.files}
    content["indices"] = content["indices"][::-1]
    np.savez_compressed(path, **content)
    with pytest.raises(ValueError, match="misaligned prediction identities"):
        summarize_predictions(data, variants, metadata, tmp_path,
                              {"diagnostics": {"seeds": [11]}})
