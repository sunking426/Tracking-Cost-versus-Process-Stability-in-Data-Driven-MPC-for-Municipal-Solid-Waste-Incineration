import numpy as np
import pytest
import torch
from mswi_experiments.ridge_policy import policy_numeric, Execution, ExactSupport, PolicyContext, ACTIVE, INACTIVE, RidgePolicyEnv
from mswi_experiments.ridge_policy_study import ROOT, OUT, REF, read_npz, shared
from mswi_experiments.data import MINUTE_NS

def test_policy_window_uses_observed_current_and_drops_oldest_cv():
    u=np.arange(88).reshape(1,11,8);z=np.arange(90).reshape(1,10,9);current=np.arange(9)[None]+1000
    x=policy_numeric(u,z,current)
    np.testing.assert_array_equal(x[0,:88],u.ravel())
    np.testing.assert_array_equal(x[0,88:169],z[:,1:].ravel())
    np.testing.assert_array_equal(x[0,169:],current.ravel())

def test_exact_tree_respects_time_exclusion_expansion():
    bank=np.zeros((20,25));bank[:,0]=np.arange(20)
    values={'bank_standardized':bank,'bank_time_ns':np.arange(20)*MINUTE_NS,'exclusion_minutes':np.array(11),
        'x_mean':np.zeros(25),'x_scale':np.ones(25),'threshold':np.array(12.)}
    support=ExactSupport(values);u=np.zeros((1,8));z=np.zeros((1,9));d=np.zeros((1,8));times=np.array([0])
    distance,ok,idx=support.query(u,z,d,times)
    assert distance[0]==12 and ok[0] and idx[0]==12
    assert support.audit(u,z,d,times)['decisions_equal']

@pytest.fixture(scope='module')
def prepared():
    if not (OUT/'policy_context.npz').exists():pytest.skip('study inputs not prepared')
    return shared()

def test_executed_actor_tensor_matches_environment_and_zero_rejected_gradient(prepared):
    stats,execution,_,_=prepared;row=read_npz(REF/'inputs/val.npz')
    u=row['u_hist'][:32,-1].copy();z=row['z_current'][:32];t=row['time_ns'][:32]
    b=torch.linspace(-1.5,1.5,64).reshape(32,2).requires_grad_()
    actual,_,blocked=execution.apply(execution.request(b.detach().numpy()),u,z,t)
    a=execution.tensor(b,u,z,t)
    np.testing.assert_allclose(a.detach().numpy(),actual['executed'],atol=1e-7)
    assert np.all(actual['physical'][:,INACTIVE]==0)
    assert np.all(np.abs(actual['physical'][:,ACTIVE])<=.1*execution.bound[ACTIVE]+1e-10)
    a.sum().backward()
    assert torch.isfinite(b.grad).all()
    if blocked.any():assert torch.all(b.grad[blocked]==0)
    # A deliberately unsupported CV maps every nonzero proposal to hold.
    b=torch.ones((1,2),requires_grad=True)
    a=execution.tensor(b,u[:1],np.full((1,9),1e9),t[:1]);a.sum().backward()
    assert torch.all(a==0) and torch.all(b.grad==0)

def test_training_donors_exclude_sources_and_capture_and_logs_stay_eight_dimensional(prepared):
    stats,_,context,_=prepared;x=read_npz(OUT/'logged_train.npz')
    position={int(k):i for i,k in enumerate(context.v['indices'])}
    for key in ('donor','next_donor','hold_donor'):
        at=np.array([position[int(k)] for k in x[key]])
        overlap=(context.v['source_start'][at]<=x['exclusion_high'])&(context.v['source_end'][at]>=x['exclusion_low'])
        assert not overlap.any()
        assert not (context.v['capture'][at,None]==x['excluded_captures']).any()
    source=read_npz(ROOT/'experiment_runs/corrected_vision/data/dataset.npz');ids=x['indices']
    np.testing.assert_allclose(x['action'],source['action'][ids]/np.asarray(stats['action_scale']),rtol=1e-7)
    assert np.any(x['action'][:,INACTIVE]!=0)
    np.testing.assert_array_equal(x['next_z'],source['z_current'][source['next_idx'][ids]])
    for root in np.unique(x['block_root'])[:100]:
        rows=np.flatnonzero(x['block_root']==root)
        assert len(rows)<=10
        np.testing.assert_array_equal(x['hold_state'][rows,178:],np.broadcast_to(x['hold_state'][rows[0],178:],(len(rows),52)))
        np.testing.assert_array_equal(x['hold_next_state'][rows,178:],x['hold_state'][rows,178:])

def test_visual_null_and_fifty_step_truncation_not_terminal(prepared):
    _,execution,context,model=prepared;row=read_npz(REF/'inputs/val.npz')
    row={k:v[:2] for k,v in row.items()}
    a=RidgePolicyEnv(model,execution,context,50,'full');b=RidgePolicyEnv(model,execution,context,50,'sensor')
    sa,_=a.reset(options={'inputs':row});sb,_=b.reset(options={'inputs':row})
    assert np.any(sa[:,178:]!=sb[:,178:])
    for i in range(50):
        _,ra,done,cut,ia=a.step(np.zeros((2,2)));_,rb,_,_,ib=b.step(np.zeros((2,2)))
        np.testing.assert_array_equal(ia['pred_cv'],ib['pred_cv']);np.testing.assert_array_equal(ra,rb)
        assert not done.any() and cut.all()==(i==49)

def test_out_of_scope_reset_does_not_repair_inactive_control(prepared):
    stats,execution,context,model=prepared;row=read_npz(REF/'inputs/val.npz')
    row={k:v[:1].copy() for k,v in row.items()};row['u_hist'][0,-1,1]=stats['u_high'][1]+1
    with pytest.raises(ValueError,match='outside scope'):RidgePolicyEnv(model,execution,context).reset(options={'inputs':row})

def test_cem_support_certificates_and_affine_rollouts_match_canonical(prepared):
    from mswi_experiments.ridge_policy_planning import CEMPlanner
    _,execution,_,model=prepared;source=read_npz(REF/'inputs/val.npz')
    row={k:v[:4] for k,v in source.items()};rng=np.random.default_rng(37)
    plans=rng.uniform(-1,1,(4,16,10,2));plans[:,0]=0
    planner=CEMPlanner(model,execution)
    scores,trace=planner.score(plans,row['u_hist'],row['z_hist'],row['z_current'],row['time_ns'],return_trace=True)
    repeated={k:np.repeat(v,16,axis=0) for k,v in row.items()}
    env=RidgePolicyEnv(model,execution,horizon=10);env.reset(options={'inputs':repeated});canonical=[]
    for step in range(10):
        _,reward,_,_,info=env.step(plans[:,:,step].reshape(-1,2))
        np.testing.assert_allclose(info['pred_cv'].reshape(4,16,9),trace['prediction'][:,:,step],atol=1e-8,rtol=1e-10)
        np.testing.assert_allclose(info['executed_action'].reshape(4,16,8),trace['executed'][:,:,step],atol=1e-10,rtol=0)
        np.testing.assert_allclose(reward.reshape(4,16),trace['reward'][:,:,step],atol=1e-6,rtol=0)
        canonical.append(reward.reshape(4,16).astype(float))
    np.testing.assert_allclose(scores,np.stack(canonical).sum(0),atol=1e-5,rtol=0)
