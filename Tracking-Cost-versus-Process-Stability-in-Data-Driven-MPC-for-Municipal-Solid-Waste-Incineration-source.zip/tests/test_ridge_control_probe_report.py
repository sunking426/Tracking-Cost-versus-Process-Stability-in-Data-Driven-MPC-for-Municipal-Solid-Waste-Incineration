import numpy as np
import pytest

from mswi_experiments.control import reward_and_violation
from mswi_experiments.ridge_control_probe_report import episode_metrics,improvements,render,MODELS


def test_episode_metrics_recover_physical_tracking_units():
    z=np.tile(np.array([1010.]*6+[-40.,33.,4.5]),(3,10,1))
    a=np.zeros((3,10,8))
    stats={'control_low':[900.,-100.,20.,1.],'control_high':[1100.,0.,40.,5.]}
    reward,violation,costs=reward_and_violation(z,a,stats)
    row={'reward':reward,'violation':violation,**costs}
    metrics=episode_metrics(row)
    assert metrics.shape==(3,6)
    np.testing.assert_allclose(metrics[:,1:],[ [10.,10.,1.,.5,0.]]*3,rtol=1e-6)
    np.testing.assert_allclose(metrics[:,0],reward.sum(1),atol=1e-5)


def test_gain_direction_reward_up_costs_down():
    reference=np.array([[-20.,5.,6.,7.,8.,.2]])
    candidate=np.array([[-19.,4.,5.,6.,7.,.1]])
    np.testing.assert_allclose(improvements(reference,candidate),[[[1,1,1,1,1,.1]]])
    np.testing.assert_array_equal(reference,[[-20.,5.,6.,7.,8.,.2]])


def test_hypothetical_factual_truth_does_not_enter_control_metrics():
    row={'reward':-np.ones((2,10)),'violation':np.zeros((2,10)),
         'tracking_cost':np.ones((2,10,3)),'oxygen_cost':np.ones((2,10)),
         'truth_cv':np.zeros((2,10,9))}
    expected=episode_metrics(row)
    row['truth_cv'][:]=1e8
    np.testing.assert_array_equal(expected,episode_metrics(row))


def test_positive_reward_rejected():
    with pytest.raises(ValueError):episode_metrics({'reward':np.ones((2,10)),
        'tracking_cost':np.ones((2,10,3)),'oxygen_cost':np.ones((2,10)),
        'violation':np.zeros((2,10))})


def test_response_comparison_figure_all_models(tmp_path):
    contrasts={}
    for m in MODELS:
        for p in ['grid_mpc','linear_bc']:
            contrasts['test/'+m+'/'+p+'_vs_hold']={'difference':[1.],'ci_lower':[-.5],'ci_upper':[2.]}
    render(tmp_path,{'contrasts':contrasts})
    assert (tmp_path/'figures/return_comparisons.png').stat().st_size>1000
    assert (tmp_path/'figures/return_comparisons.svg').stat().st_size>1000
