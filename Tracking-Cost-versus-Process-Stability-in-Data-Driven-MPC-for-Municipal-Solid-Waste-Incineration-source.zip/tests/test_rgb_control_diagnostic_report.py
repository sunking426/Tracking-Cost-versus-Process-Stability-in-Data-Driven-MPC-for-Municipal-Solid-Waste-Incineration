import numpy as np
import pytest

from mswi_experiments.rgb_control_diagnostic_report import validate_probability_archive


def row():
    p=np.array([.1,.4,.9])
    return dict(indices=np.arange(3),time_ns=np.arange(3)*60_000_000_000,
                y=np.array([0,1,1]),probability=p,alarm=(p>=.5).astype(int),threshold=np.asarray(.5))


def test_valid_probability_record():
    validate_probability_archive(row())


def test_saved_alarm_cannot_use_a_different_threshold():
    a=row();a['alarm'][1]=1
    with pytest.raises(ValueError,match='alarm differs'): validate_probability_archive(a)


@pytest.mark.parametrize('name,value',[('y',np.array([0,2,1])),
    ('probability',np.array([-.1,.4,.9])),('indices',np.array([0,0,2])),
    ('time_ns',np.array([120,60,180])),('probability',np.array([.1,np.nan,.9]))])
def test_invalid_labels_scores_and_identities_fail(name,value):
    a=row();a[name]=value
    with pytest.raises(ValueError):validate_probability_archive(a)
