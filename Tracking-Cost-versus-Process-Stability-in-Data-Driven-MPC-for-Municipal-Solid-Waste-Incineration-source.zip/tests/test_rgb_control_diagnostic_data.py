import numpy as np
import pytest

from mswi_experiments.data import MINUTE_NS, control_values
from mswi_experiments.numeric_baselines import numeric_features
from mswi_experiments.rgb_control_diagnostic_data import (
    build_prepared, numerical_decision_features, prepare_data, select_common_origins,
)


def fixture_data():
    size = 180
    times = np.concatenate([np.arange(size)+100+250*k for k in range(3)])
    def u(t):
        return np.stack([np.sin(t/(3+j))*j + (t % (j+5))*.1 for j in range(1,9)],axis=-1)
    def z(t):
        return np.stack([1000+20*np.sin(t/(7+j)) for j in range(6)]
                        + [-50+np.cos(t/3),32+np.sin(t/4),4+.1*np.sin(t/6)],axis=-1)
    uh = u(times[:,None]+np.arange(-10,1))
    zh = z(times[:,None]+np.arange(-10,0))
    y = z(times)
    captures = np.concatenate([np.arange(90+250*k,271+250*k,10) for k in range(3)])
    mapping = np.searchsorted(captures,times-1,side='right')-1
    following = np.arange(1,len(times)+1)
    following[[size-1,2*size-1,3*size-1]] = -1
    d = {'time_ns':times*MINUTE_NS,'source_start_ns':(times-10)*MINUTE_NS,
         'source_end_ns':(times+1)*MINUTE_NS,'visual_time_ns':captures[mapping]*MINUTE_NS,
         'u_hist':uh,'z_hist':zh,'z_prev':zh[:,-1],'z_target':y,
         'action':u(times+1)-u(times),'next_idx':following,
         'train_idx':np.arange(size),'val_idx':np.arange(size,2*size),'test_idx':np.arange(2*size,3*size)}
    rng = np.random.default_rng(41)
    rgb = rng.normal(size=(len(captures),32))
    timing = np.column_stack((times-1-captures[mapping],np.ones((len(times),3))))
    quality = rng.normal(size=(len(times),12))
    design = np.column_stack((numeric_features(d),timing,quality,rgb[mapping]))
    return d, design, captures*MINUTE_NS, mapping, rgb


def test_numerical_summary_uses_only_known_eleven_points_and_correct_order():
    data,*_ = fixture_data()
    features, names = numerical_decision_features(data)
    assert features.shape == (540,219) and len(names)==219
    np.testing.assert_array_equal(features[:,:178],numeric_features(data))
    np.testing.assert_array_equal(features[:,178:187],data['z_target'])
    values = control_values(np.concatenate((data['z_hist'],data['z_target'][:,None]),axis=1))
    for j in range(4):
        observed = values[:,:,j]
        delta = observed[:,-1,None]-observed[:,[-2,-6,-11]]
        expected = np.column_stack((delta,np.abs(delta),observed.std(axis=1),np.ptp(observed,axis=1)))
        np.testing.assert_allclose(features[:,187+8*j:195+8*j],expected,rtol=0,atol=0)


def test_stale_inputs_causal_same_partition_and_common_rows():
    data,design,times,mapping,rgb = fixture_data()
    arrays, meta = build_prepared(data,design,times,mapping,rgb,{})
    for split in ('train','val','test'):
        idx = arrays[split+'_indices']; current=arrays[split+'_current_capture_index']; stale=arrays[split+'_stale_capture_index']
        assert len(idx)>50
        assert set(stale).issubset(set(mapping[data[split+'_idx']]))
        age = (data['time_ns'][idx]-MINUTE_NS-times[stale])/MINUTE_NS
        assert age.min()>=60 and age.max()<=70
        assert (times[stale]<times[current]).all()
        for method,width in meta['feature_dimensions'].items():
            assert arrays[split+'_'+method].shape==(len(idx),width)
            np.testing.assert_array_equal(arrays[split+'_'+method][:,:219],arrays[split+'_numeric'])
        np.testing.assert_array_equal(arrays[split+'_rgb'][:,:235],arrays[split+'_stale'][:,:235])
        np.testing.assert_array_equal(arrays[split+'_stale'][:,235:],rgb[stale])
        assert np.all(np.diff(data['time_ns'][arrays[split+'_chains']],axis=1)==MINUTE_NS)


def test_future_outcome_and_next_action_labels_match_declared_horizons():
    data,design,times,mapping,rgb = fixture_data()
    arrays,meta = build_prepared(data,design,times,mapping,rgb,{})
    temperature=data['z_target'][:,:6].mean(1)
    threshold=meta['thresholds']['thermal_abs_temperature_change_degC']
    for split in ('train','val','test'):
        chain=arrays[split+'_chains']; start=chain[:,0]
        expected=np.max(np.abs(temperature[chain[:,1:]]-temperature[start,None]),axis=1)
        np.testing.assert_array_equal(arrays[split+'_thermal_magnitude'],expected)
        np.testing.assert_array_equal(arrays[split+'_thermal_change'],expected>threshold)
        np.testing.assert_array_equal(arrays[split+'_signed_action'],data['u_hist'][chain[:,1],-1]-data['u_hist'][start,-1])
    assert threshold==np.quantile(arrays['train_thermal_magnitude'],.8)


def test_test_outcomes_cannot_change_training_thresholds_or_inputs():
    data,design,times,mapping,rgb = fixture_data()
    first,meta = build_prepared(data,design,times,mapping,rgb,{})
    altered={k:v.copy() for k,v in data.items()}
    altered['z_target'][data['test_idx']]+=np.arange(len(data['test_idx']))[:,None]*100
    second,meta2=build_prepared(altered,design,times,mapping,rgb,{})
    assert meta['thresholds']==meta2['thresholds']
    for name in first:
        if name.startswith('train_'):
            np.testing.assert_array_equal(first[name],second[name])
    assert not np.array_equal(first['test_thermal_change'],second['test_thermal_change'])


def test_action_labels_reject_an_unrelated_next_step():
    data,design,times,mapping,rgb = fixture_data()
    data['action'][90,0]+=10
    with pytest.raises(ValueError,match='action label disagrees'):
        build_prepared(data,design,times,mapping,rgb,{})


def test_empty_training_action_channels_have_no_artificial_events():
    data,design,times,mapping,rgb = fixture_data()
    data['u_hist'][:,:,-1]=0;data['action'][:,-1]=0
    design[:,:178]=numeric_features(data)
    arrays,meta=build_prepared(data,design,times,mapping,rgb,{})
    assert meta['thresholds']['action_per_channel_threshold'][-1] is None
    for split in ('train','val','test'):
        assert not arrays[split+'_action_channel_trigger'][:,-1].any()


def test_stale_matching_never_wraps_to_last_capture_when_none_is_past():
    data,_,times,mapping,_=fixture_data()
    selected,counts=select_common_origins(data,times,mapping)
    assert counts['train']['removed_without_stale_image']>0
    # First decision is minute151; cutoff150 and capture90 give exactly60min.
    assert selected['train']['chains'][0,0]==51
    assert selected['train']['stale_capture_index'][0]==mapping[0]


@pytest.mark.parametrize('fault',['future','mapping','rgb','shape'])
def test_invalid_visual_sources_fail(fault):
    data,design,times,mapping,rgb=fixture_data()
    if fault=='future':
        data['visual_time_ns'][100]=data['time_ns'][100]+MINUTE_NS
    elif fault=='mapping': mapping[100]+=1
    elif fault=='rgb': rgb[0,0]+=1
    else: design=design[:,:225]
    with pytest.raises(ValueError): build_prepared(data,design,times,mapping,rgb,{})


def test_preparation_refuses_overwriting_existing_artifacts(tmp_path):
    (tmp_path/'prepared.npz').write_bytes(b'preserve')
    with pytest.raises(FileExistsError): prepare_data({},tmp_path)
    assert (tmp_path/'prepared.npz').read_bytes()==b'preserve'
