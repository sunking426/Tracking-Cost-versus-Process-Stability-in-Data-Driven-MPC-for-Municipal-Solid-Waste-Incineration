"""Behavioral checks for frozen probes, recursive forecasts, and saved evidence."""
import copy
import json

import numpy as np
import pytest
import torch

from mswi_experiments.analysis import (
    HORIZONS, _encode_latents, _endpoint_metrics, _fit_linear_probe,
    _recursive_rollouts, _select_rollout_chains, run_prediction_analysis,
)
from mswi_experiments.data import MINUTE_NS, control_values
from mswi_experiments.models import Twin


def fixture(n=300):
    """Synthetic minute records, deliberately separate from official artifacts."""
    rng = np.random.default_rng(21)
    t = np.arange(n, dtype=np.float32)
    z = t[:, None] * .25 + np.arange(9, dtype=np.float32)[None, :]
    u = t[:, None] + np.arange(8, dtype=np.float32)[None, :]
    data = {"u_hist": np.stack([u - lag for lag in range(10, -1, -1)], axis=1),
            "z_hist": np.stack([z - lag * .25 for lag in range(10, 0, -1)], axis=1),
            "z_prev": z - .25, "z_target": z.copy(), "z_current": z.copy(),
            "u_current": u, "action": np.ones_like(u),
            "visual": rng.normal(size=(n, 7)).astype(np.float32),
            "time_ns": np.arange(n, dtype=np.int64) * MINUTE_NS,
            "train_idx": np.arange(n // 2),
            "val_idx": np.arange(n // 2, n * 2 // 3),
            "test_idx": np.arange(n * 2 // 3, n),
            "next_idx": np.arange(1, n + 1)}
    for end in (n // 2 - 1, n * 2 // 3 - 1, n - 1):
        data["next_idx"][end] = -1
    stats = {"u_mean": [0.] * 8, "u_scale": [1.] * 8,
             "z_mean": [0.] * 9, "z_scale": [1.] * 9,
             "v_mean": [0.] * 7, "v_scale": [1.] * 7,
             "delta_mean": [0.] * 9, "delta_scale": [1.] * 9}
    return data, stats


def test_probe_selection_and_scaling_do_not_use_test_targets():
    rng = np.random.default_rng(3)
    x = rng.normal(size=(500, 5))
    y = x @ np.array([[1., 3.], [-2., 0.], [0., 1.], [.5, 0.], [0., -1.]]) + [1000., -50.]
    args = (x[:350], x[350:425], x[425:], y[:350], y[350:425])
    metrics, prediction, fitted = _fit_linear_probe(*args, y[425:])
    changed, changed_prediction, changed_fit = _fit_linear_probe(*args, y[425:] + 10_000.)
    np.testing.assert_array_equal(prediction, changed_prediction)
    np.testing.assert_array_equal(fitted["val_normalized_mse"], changed_fit["val_normalized_mse"])
    assert metrics["alpha"] == changed["alpha"]
    np.testing.assert_allclose(fitted["x_mean"], x[:350].mean(axis=0))
    np.testing.assert_allclose(fitted["y_mean"], y[:350].mean(axis=0))
    np.testing.assert_allclose(prediction, y[425:], atol=.01)
    assert max(metrics["mae"]) < .005 and min(changed["mae"]) > 9999.


def test_encoder_returns_pure_latent_and_keeps_weights_frozen():
    data, stats = fixture()
    twin = Twin(stats, hidden=8)
    before = {name: value.clone() for name, value in twin.state_dict().items()}
    idx = np.array([7, 2, 9])
    latent = _encode_latents(twin, data, idx, batch_size=2)
    assert latent.shape == (3, 8)  # No appended real current MV/CV.
    assert not twin.training
    assert all(parameter.grad is None for parameter in twin.parameters())
    assert all(torch.equal(before[name], value) for name, value in twin.state_dict().items())
    changed = copy.deepcopy(data)
    changed["z_current"] += 1_000_000.
    changed["z_target"] += 1_000_000.
    np.testing.assert_array_equal(latent, _encode_latents(twin, changed, idx, batch_size=2))
    one = _encode_latents(twin, data, idx[:1])
    np.testing.assert_allclose(latent[:1], one, rtol=1e-5, atol=1e-6)


class UnitIncrement(torch.nn.Module):
    def forward(self, u, z, v):
        return torch.ones((len(u), 9), device=u.device)


class RecordedMemory:
    def __init__(self, source=0):
        self.source = source
        self.calls = []

    def query(self, u, z):
        self.calls.append((u.detach().clone(), z.detach().clone()))
        return torch.zeros(len(u), 7), np.full(len(u), self.source, dtype=np.int64)


def test_recursive_forecast_never_resets_to_future_true_cv_or_images():
    data, _ = fixture()
    chains = _select_rollout_chains(data, count=2)
    memory = RecordedMemory()
    raw = _recursive_rollouts(UnitIncrement(), memory, data, chains)
    expected = data["z_prev"][chains[:, 0], None, :] + np.arange(1, 21)[None, :, None]
    np.testing.assert_allclose(raw["prediction_cv"], expected)
    for step, (u_history, z_history) in enumerate(memory.calls):
        np.testing.assert_array_equal(u_history[:, -1].numpy(), data["u_current"][chains[:, step]])
        if step:
            np.testing.assert_allclose(z_history[:, -1].numpy(), expected[:, step - 1])
    changed = copy.deepcopy(data)
    future = chains[:, 1:].ravel()
    for name in ("z_hist", "z_prev", "z_target", "z_current", "visual", "u_hist"):
        changed[name][future] += 1_000_000.
    new_raw = _recursive_rollouts(UnitIncrement(), RecordedMemory(), changed, chains)
    np.testing.assert_array_equal(raw["prediction_cv"], new_raw["prediction_cv"])
    assert not np.array_equal(raw["truth_cv"], new_raw["truth_cv"])
    np.testing.assert_array_equal(raw["prediction"], control_values(expected.astype(np.float32)))


def test_recursive_memory_rejects_test_source():
    data, _ = fixture()
    chains = _select_rollout_chains(data, count=1)
    with pytest.raises(ValueError, match="non-training source"):
        _recursive_rollouts(UnitIncrement(), RecordedMemory(source=int(data["test_idx"][0])), data, chains)


def test_rollout_start_selection_obeys_test_partition_and_minute_continuity():
    data, _ = fixture()
    data["next_idx"][209] = 5  # Invalid link into training.
    data["next_idx"][240] = 242  # Jump over a missing minute.
    chains = _select_rollout_chains(data, count=3)
    assert len(np.unique(chains)) == chains.size
    assert set(chains.ravel()).issubset(set(data["test_idx"]))
    assert not {209, 240}.intersection(chains[:, :-1].ravel())
    np.testing.assert_array_equal(data["next_idx"][chains[:, :-1]], chains[:, 1:])
    assert (np.diff(data["time_ns"][chains], axis=1) == MINUTE_NS).all()
    with pytest.raises(ValueError, match="complete disjoint"):
        _select_rollout_chains(data, count=50)


def test_horizon_metrics_use_endpoint_instead_of_averaging_earlier_steps():
    truth = np.zeros((2, 20, 4))
    prediction = np.ones_like(truth) * np.arange(1, 21)[None, :, None]
    result = _endpoint_metrics(truth, prediction)
    assert result["horizons"] == [1, 5, 10, 20]
    np.testing.assert_array_equal(result["mae"], np.repeat(np.array(HORIZONS)[:, None], 4, axis=1))
    np.testing.assert_array_equal(result["rmse"], result["mae"])


def test_analysis_saves_recomputable_raw_artifacts(tmp_path):
    data, stats = fixture()
    torch.manual_seed(2)
    twins = {mode: Twin(stats, mode=mode, hidden=8) for mode in ("multi", "sensor", "image")}
    config = {"training": {"threads": 1, "seed": 2},
              "retrieval": {"max_items": 12, "k": 3},
              "analysis": {"rollout_starts": 3, "tsne_max_samples": 15,
                           "tsne_iterations": 250, "seed": 2026}}
    result = run_prediction_analysis(data, stats, twins, config, tmp_path)
    assert set(result) == {"probe", "onestep", "rollout", "tsne_file"}
    assert result == json.loads((tmp_path / "analysis_results.json").read_text())
    assert result["onestep"]["n"] == len(data["test_idx"])
    assert len(result["rollout"]["starts"]) == 3
    with np.load(tmp_path / "onestep.npz", allow_pickle=False) as raw:
        np.testing.assert_allclose(result["onestep"]["mae"], np.abs(raw["error"]).mean(axis=0), rtol=1e-6)
        np.testing.assert_array_equal(raw["indices"], data["test_idx"])
    with np.load(tmp_path / "rollout.npz", allow_pickle=False) as raw:
        assert raw["truth"].shape == (3, 20, 4)
        assert np.isin(raw["memory_source_index"], data["train_idx"]).all()
        np.testing.assert_allclose(result["rollout"]["mae"][-1], np.abs(raw["error"][:, -1]).mean(axis=0), rtol=1e-6)
        median_position = np.argsort(np.abs(raw["error"][:, -1, 0]), kind="stable")[1]
        assert result["rollout"]["example"]["start_index"] == raw["indices"][median_position, 0]
    with np.load(result["tsne_file"], allow_pickle=False) as raw:
        assert raw["sensor"].shape == raw["multi"].shape == (15, 2)
        np.testing.assert_array_equal(raw["steam"], data["z_target"][raw["indices"], 7])
        assert np.isfinite(raw["sensor"]).all() and np.isfinite(raw["multi"]).all()
    for mode in twins:
        with np.load(tmp_path / f"probe_{mode}.npz", allow_pickle=False) as raw:
            np.testing.assert_array_equal(raw["indices"], data["test_idx"])
            np.testing.assert_allclose(result["probe"][mode]["mae"], np.abs(raw["error"]).mean(axis=0), rtol=1e-6)
        assert len((tmp_path / f"probe_{mode}.csv").read_text().splitlines()) == 1 + len(data["test_idx"])
    assert (tmp_path / "analysis_manifest.json").exists()
    assert len((tmp_path / "rollout.csv").read_text().splitlines()) == 61
