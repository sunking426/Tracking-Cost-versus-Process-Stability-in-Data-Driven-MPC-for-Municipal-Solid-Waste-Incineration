"""Behavioral tests for training-only preparation and fixed-alpha diagnostics."""
from copy import deepcopy
import json
from pathlib import Path

import numpy as np
import pytest

from mswi_experiments import ridge_response_study as study
from mswi_experiments.data import MINUTE_NS


def data_fixture(n=900):
    rng=np.random.default_rng(943)
    u=rng.normal(scale=.3,size=(n+10,8));z=rng.normal(size=(n+10,9))
    data={'u_hist':np.stack([u[i:i+11] for i in range(n)]),
          'z_hist':np.stack([z[i:i+10] for i in range(n)]),
          'u_current':u[10:].copy(),'z_current':z[10:].copy(),
          'z_target':z[10:].copy(),'z_prev':z[9:-1].copy(),
          'time_ns':np.arange(n,dtype=np.int64)*MINUTE_NS,
          'source_start_ns':(np.arange(n,dtype=np.int64)-10)*MINUTE_NS,
          'source_end_ns':(np.arange(n,dtype=np.int64)+1)*MINUTE_NS,
          'train_idx':np.arange(450),'val_idx':np.arange(500,650),
          'test_idx':np.arange(700,850),'next_idx':np.full(n,-1,dtype=np.int64),
          'action':np.zeros((n,8))}
    for split in ('train','val','test'):
        rows=data[split+'_idx'];data['next_idx'][rows[:-1]]=rows[1:]
        data['action'][rows[:-1]]=data['u_current'][rows[1:]]-data['u_current'][rows[:-1]]
    stats={'delta_scale':np.ones(9).tolist(),'u_low':np.full(8,-2.).tolist(),
        'u_high':np.full(8,2.).tolist(),'action_bound':np.full(8,.5).tolist(),
        'action_scale':np.full(8,.5).tolist(),'control_low':[-5.]*4,'control_high':[5.]*4,
        'mv_names':[f'mv{i}' for i in range(8)],'cv_names':[f'cv{i}' for i in range(9)]}
    return data,stats


def study_fixture(tmp_path):
    data,stats=data_fixture();source=tmp_path/'source/data';source.mkdir(parents=True)
    np.savez_compressed(source/'dataset.npz',**data)
    (source/'stats.json').write_text(json.dumps(stats));(source/'manifest.json').write_text('{}')
    prior=tmp_path/'prior';model=prior/'models/ridge.npz';model.parent.mkdir(parents=True)
    rng=np.random.default_rng(1)
    np.savez_compressed(model,x_mean=np.zeros(178),x_scale=np.ones(178),
        coef=rng.normal(0,.001,size=(9,178)),intercept=np.zeros(9),delta_scale=np.ones(9),
        kind=np.asarray('ridge'),alpha=np.asarray(100.))
    selection={'status':'complete','models':[{'id':'ridge','method':'ridge',
        'base_model_path':None,'model_path':'models/ridge.npz','selected_alpha':100.}]}
    (prior/'selection.json').write_text(json.dumps(selection))
    (prior/'selection_frozen.json').write_text(json.dumps({'status':'complete','files':{
        'selection.json':study.sha256(prior/'selection.json'),'models/ridge.npz':study.sha256(model)}}))
    (prior/'stats.json').write_text(json.dumps(stats))
    (prior/'input_hashes.json').write_text(json.dumps({str(q.resolve()):study.sha256(q) for q in source.iterdir()}))
    predictor={'kind':'ridge','model_id':'ridge','selected_study':'prior','checkpoint':'prior/models/ridge.npz',
        'checkpoint_sha256':study.sha256(model),'selection_sha256':study.sha256(prior/'selection.json')}
    (tmp_path/'current_predictor.json').write_text(json.dumps(predictor))
    codes=tmp_path/'mswi_experiments';codes.mkdir()
    for name in study.SNAPSHOT_NAMES:(codes/name).write_text('# source snapshot fixture\n')
    config={**deepcopy(study.FIXED),'source_run':'source','current_predictor':'current_predictor.json',
            'output_dir':'output','threads':1}
    path=tmp_path/'config.json';path.write_text(json.dumps(config))
    return path,data,stats


def test_equal_training_blocks_are_source_disjoint_and_pooled_matched():
    data,_=data_fixture();rows,meta=study.training_blocks(data)
    assert meta['equal_block_samples']==140
    assert [len(rows[k]) for k in ('early','middle','late','pooled_matched')]==[140]*4
    for left,right in [('early','middle'),('middle','late')]:
        assert data['time_ns'][rows[right][0]]-10*MINUTE_NS>data['time_ns'][rows[left][-1]]
        assert not np.intersect1d(rows[left],rows[right]).size
    assert set(rows['pooled_matched'])<=set(data['train_idx'])
    assert np.intersect1d(rows['pooled_matched'],rows['early']).size>0
    changed=deepcopy(data);changed['z_target'][:]=1e8;changed['u_current'][:]=1e9
    again,_=study.training_blocks(changed)
    for k in rows:np.testing.assert_array_equal(rows[k],again[k])


def test_anchor_selection_uses_current_mv_and_time_only():
    data,stats=data_fixture();selected,info=study.select_anchors(data,stats,'test')
    assert len(selected)==13 and info['complete_chains']==140
    assert np.all(np.diff(data['time_ns'][selected[:,0]])>=11*MINUTE_NS)
    assert selected.shape[1]==11
    changed=deepcopy(data);changed['z_target'][:]=1e9;changed['z_current'][:]=-1e9;changed['action'][:]=1e10
    repeated,_=study.select_anchors(changed,stats,'test')
    np.testing.assert_array_equal(selected,repeated)
    changed['u_current'][700]=3
    altered,meta=study.select_anchors(changed,stats,'test')
    assert meta['outside_initial_mv_envelope']==1 and altered[0,0]==701


def test_support_is_training_only_and_excludes_overlapping_donors():
    data,_=data_fixture();a=study.fit_support(data,bank_size=80,calibration_size=65)
    changed=deepcopy(data)
    for name in ('u_current','z_current','action'):changed[name][500:]+=1e7
    b=study.fit_support(changed,bank_size=80,calibration_size=65)
    for k in a:np.testing.assert_array_equal(a[k],b[k])
    donor=a['bank_time_ns'][a['calibration_nearest_bank_position']]
    assert np.all(np.abs(donor-a['calibration_time_ns'])>11*MINUTE_NS)
    rows=a['training_indices']
    x=study.joint_features(data['u_current'][rows],data['z_current'][rows],data['action'][rows])
    np.testing.assert_allclose(a['x_mean'],x.mean(axis=0),rtol=0,atol=1e-14)
    assert float(a['threshold'])==np.quantile(a['calibration_distance'],.95)


def test_distance_time_exclusion_is_not_self_neighbor_only():
    times=np.array([0,5,20])*MINUTE_NS
    d,j=study.nearest_distance(np.zeros((1,1)),np.array([[0.],[1.],[5.]]),query_time=np.array([0]),bank_time=times)
    assert d[0]==5 and j[0]==2
    with pytest.raises(ValueError,match='no time-disjoint'):
        study.nearest_distance(np.zeros((1,1)),np.zeros((1,1)),query_time=np.array([0]),bank_time=np.array([0]))


def test_prepare_freezes_data_and_does_not_fit(tmp_path):
    cfg,data,_=study_fixture(tmp_path);out=study.prepare(cfg)
    assert not (out/'models').exists()
    values=study.archive(out/'inputs/test.npz');indices=values['indices']
    np.testing.assert_array_equal(values['z_current'],data['z_current'][indices])
    np.testing.assert_array_equal(values['truth_cv'],data['z_target'][values['chains'][:,1:]])
    np.testing.assert_array_equal(values['logged_mv'],data['u_current'][values['chains'][:,1:]])
    assert values['trialfuture_mv'].shape==(13,2,16,10,8)
    assert values['supported'].shape==values['full_request_executed'].shape==(13,16)
    assert values['logged_supported'].shape==(13,)
    with pytest.raises(FileExistsError):study.prepare(cfg)
    (out/'stats.json').write_text('{}')
    with pytest.raises(ValueError,match='frozen input changed'):study.load_prepared(cfg)


def test_fixed_alpha_fit_keeps_all_models_and_heldout_values_do_not_influence_weights(tmp_path):
    first=tmp_path/'first';first.mkdir();cfg,data,_=study_fixture(first);out=study.prepare(cfg);study.fit(cfg)
    second=tmp_path/'second';second.mkdir();cfg2,data2,stats=study_fixture(second)
    # Rebuild source provenance before preparation, preserving full model identity.
    data2['z_target'][500:]+=1e5;data2['z_current'][500:]+=1e5
    data2['z_hist'][500:]+=1e4;data2['u_hist'][500:]+=.1;data2['u_current'][500:]+=.1
    source=second/'source/data';np.savez_compressed(source/'dataset.npz',**data2)
    (second/'prior/input_hashes.json').write_text(json.dumps({str(q.resolve()):study.sha256(q) for q in source.iterdir()}))
    out2=study.prepare(cfg2);study.fit(cfg2)
    selection=json.loads((out/'selection.json').read_text())
    assert [r['model_id'] for r in selection['models']]==list(study.MODEL_IDS)
    assert all(r['alpha']==100. for r in selection['models'])
    assert len({r['training_samples'] for r in selection['models'][1:]})==1
    for model in study.MODEL_IDS:
        a,b=[study.archive(p/'models'/f'{model}.npz') for p in (out,out2)]
        for name in a:np.testing.assert_array_equal(a[name],b[name])
    with pytest.raises(FileExistsError):study.fit(cfg)


def test_full_synthetic_run_saves_all_trials_and_preserves_response_identity(tmp_path):
    cfg,_,_=study_fixture(tmp_path);out=study.prepare(cfg);study.fit(cfg);study.run(cfg)
    manifest=json.loads((out/'run_manifest.json').read_text())
    assert len(manifest['files'])==11 and manifest['trajectories_dropped']==0
    assert manifest['predictions_clipped'] is False and manifest['policy_optimized'] is False
    response=study.archive(out/'responses.npz')
    assert response['step'].shape==(5,10,9,8) and response['companion'].shape==(5,90,90)
    checks=json.loads((out/'response_checks.json').read_text())['checks'];assert len(checks)==20
    assert max(c['max_abs_error'] for c in checks)<1e-8
    for split in ('val','test'):
        for model in study.MODEL_IDS:
            a=study.archive(out/f'rollouts/{split}/{model}.npz')
            assert a['trial_pred'].shape==(13,2,16,10,9)
            assert a['trial_reward'].shape==(13,2,16,10)
            assert a['trial_return'].shape==(13,2,16)
            assert (a['trial_reward']<=0).all()
    with pytest.raises(FileExistsError):study.run(cfg)


def test_run_rejects_model_and_source_tampering(tmp_path):
    cfg,_,_=study_fixture(tmp_path);out=study.prepare(cfg);study.fit(cfg)
    source=tmp_path/'mswi_experiments/ridge_response.py';source.write_text('# changed\n')
    with pytest.raises(ValueError,match='frozen input changed'):study.run(cfg)


def test_config_rejects_posthoc_gate_change(tmp_path):
    cfg,_,_=study_fixture(tmp_path);value=json.loads(cfg.read_text());value['minimum_supported_executable_fraction']=.5
    cfg.write_text(json.dumps(value))
    with pytest.raises(ValueError,match='fixed response protocol'):study.paths(cfg)
