import hashlib,json
import numpy as np
import pytest
from mswi_experiments.operating_metrics import operating_endpoints
from mswi_experiments.frozen_mpc import load_frozen_mpc,file_sha256


def fixture():
    hist=np.zeros((1,10,9));hist[0,:,:6]=np.arange(740,840,10)[:,None]
    current=np.array([[840]*6+[-50,30,3.4]],dtype=float)
    pred=np.zeros((1,6,9));pred[0,:,:6]=np.arange(850,910,10)[:,None]
    pred[0,:,6]=-50;pred[0,:,7]=[31,29,32,32,31,30];pred[0,:,8]=[3.5,4,4.1,3.4,3.5,4]
    return pred,hist,current


def test_complete_trailing_windows_and_inclusive_oxygen_boundaries():
    p,h,c=fixture();value,r,cv=operating_endpoints(p,h,c,6)
    np.testing.assert_allclose(r,[[830,840,850,860,870,880]])
    np.testing.assert_allclose(value,[[830,2/6,4/6,10,8/6,2/6]])
    assert value[0,1]==2/6  # exactly850 is not below


def test_first_step_uses_observed_initial_not_zero_or_next_step():
    p,h,c=fixture();v,r,cv=operating_endpoints(p,h,c,1)
    np.testing.assert_allclose(v,[[830,1,1,10,1,.1]])


def test_six_sensor_average_before_rolling_not_worst_sensor():
    p,h,c=fixture();offset=np.array([-50,-30,-10,10,30,50])
    p[:,:,:6]+=offset;h[:,:,:6]+=offset;c[:,:6]+=offset
    v,r,cv=operating_endpoints(p,h,c,6)
    np.testing.assert_allclose(r,[[830,840,850,860,870,880]])
    assert cv[0,0,0]==850


def test_no_future_or_long_history_enters_early_window():
    p,h,c=fixture();a=operating_endpoints(p,h,c,6)[1]
    p[:,-1,:6]+=1000;h[:,:-3,:6]-=500
    b=operating_endpoints(p,h,c,6)[1]
    np.testing.assert_array_equal(a[:,:-1],b[:,:-1]);assert b[0,-1]==a[0,-1]+200


def test_minimum_is_per_episode_before_mean():
    p,h,c=fixture();pp=np.concatenate((p,p+100));hh=np.concatenate((h,h+100));cc=np.concatenate((c,c+100))
    v,_,_=operating_endpoints(pp,hh,cc,6)
    assert v[:,0].mean()==880 and v[:,0].min()==830


@pytest.mark.parametrize('bad',['nan','short_history','horizon'])
def test_invalid_inputs_fail(bad):
    p,h,c=fixture()
    if bad=='nan':p[0,0,0]=np.nan
    if bad=='short_history':h=h[:,:9]
    with pytest.raises(ValueError):operating_endpoints(p,h,c,7 if bad=='horizon' else 6)


def test_frozen_loader_rejects_configuration_and_dependency_edits(tmp_path):
    dependency=tmp_path/'source';dependency.write_text('fixed')
    cfg={'schema_version':1,'status':'main_configuration_frozen','dependencies':{'source':file_sha256(dependency)}}
    path=tmp_path/'config.json';path.write_text(json.dumps(cfg));digest=file_sha256(path)
    assert load_frozen_mpc(path,digest,root=tmp_path)==cfg
    path.write_text(path.read_text()+' ')
    with pytest.raises(ValueError,match='configuration hash'):load_frozen_mpc(path,digest,root=tmp_path)
    path.write_text(json.dumps(cfg));dependency.write_text('changed')
    with pytest.raises(ValueError,match='dependency changed'):load_frozen_mpc(path,digest,root=tmp_path)
