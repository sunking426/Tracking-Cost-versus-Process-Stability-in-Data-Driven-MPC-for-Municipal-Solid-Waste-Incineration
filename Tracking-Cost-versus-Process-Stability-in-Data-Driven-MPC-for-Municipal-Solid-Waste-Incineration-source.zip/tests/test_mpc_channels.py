import numpy as np
import pytest
from mswi_experiments.mpc_channels import ChannelCEM,recommend
from mswi_experiments.mpc_temperature import TemperatureCEM
from mswi_experiments.ridge_policy import Execution,RidgePolicyEnv
from mswi_experiments.secondary_air_study import REF,shared,SAMPLE_KEYS
from mswi_experiments.ridge_policy_study import read_npz

@pytest.fixture
def small():
    if not (REF/'inputs/val.npz').exists():pytest.skip('local scientific fixture missing')
    full=read_npz(REF/'inputs/val.npz')
    return {k:full[k][[0,127]] for k in SAMPLE_KEYS}

def test_channel_direction_and_budgets(small):
    stats,e,model=shared();a=e.request(np.array([[2,-2,-2],[1,1,2]]))
    np.testing.assert_array_equal(a[:,[1,4,5,6,7]],0)
    np.testing.assert_allclose(a[:,2]*e.scale[2],[0,1.5])
    a[0,2]=-.01
    with pytest.raises(ValueError):e.screen(a,small['u_hist'][:,-1],small['z_current'],small['time_ns'])

@pytest.mark.parametrize('weight',[1,2,4,8])
def test_two_channel_regression_and_shared_noise(small,weight):
    stats,e,model=shared(False);old=Execution(stats,read_npz(REF/'support.npz'))
    args=(small['u_hist'],small['z_hist'],small['z_current'],small['time_ns'],small['indices'],3)
    a,d=ChannelCEM(model,e,weight).plan(*args);oa,od=TemperatureCEM(model,old,weight).plan(*args)
    np.testing.assert_array_equal(a,oa)
    for k in ('best_requested_plan_b','selected_planning_score','selected_temperature_cost','noise_sha256'):
        np.testing.assert_array_equal(d[k],od[k])
    _,e3,_=shared();_,d3=ChannelCEM(model,e3,weight).plan(*args)
    np.testing.assert_array_equal(d3['noise_sha256'],d['noise_sha256'])
    _,base=ChannelCEM(model,e3,1).plan(*args)
    np.testing.assert_array_equal(d3['secondary_noise_sha256'],base['secondary_noise_sha256'])
    assert (d3['best_requested_plan_b'][...,2]>=0).all()

def test_affine_score_matches_full_feedback(small):
    stats,e,model=shared();planner=ChannelCEM(model,e,4)
    plans=np.random.default_rng(99).uniform(-1,1,(2,3,10,3));plans[...,2]=np.abs(plans[...,2]);plans[:,0]=0
    score,original,jt=planner.candidate_metrics(plans,small['u_hist'],small['z_hist'],small['z_current'],small['time_ns'])
    for j in range(3):
        env=RidgePolicyEnv(model,e,horizon=10);env.reset(options={'inputs':small});r=np.zeros(2);t=np.zeros(2)
        for k in range(10):
            _,rr,_,_,info=env.step(plans[:,j,k]);r+=rr.astype(float);t+=info['tracking_cost'][:,0].astype(float)
        np.testing.assert_allclose(original[:,j],r,rtol=0,atol=1e-5)
        np.testing.assert_allclose(score[:,j],r-3*t,rtol=0,atol=1e-5)

def test_strict_priority_90pct_and_relative100pct():
    ref=np.tile([-30.,50.,30.,1.,.3,.1],(4,1));cs={v:ref.copy() for v in 'ABCD'}
    cs['A'][:,0]+=4.51;cs['A'][:,1:]*=.999
    cs['B'][:,0]+=6;cs['B'][:,1:]*=1.005
    assert recommend(ref,cs,5.01)['recommended']=='3A'
    cs['A'][:,0]=ref[:,0]+4.5
    assert recommend(ref,cs,5.01)['recommended']=='3B'
    cs['B'][0,5]=1.011*ref[0,5]
    assert recommend(ref,cs,5.01)['recommended']=='2C'

def test_ties_zero_baseline_and_every_model_guard():
    ref=np.tile([-30.,50.,30.,1.,.3,0.],(4,1));cs={v:ref.copy() for v in 'ABCD'}
    cs['A'][:,0]+=5;cs['A'][:,1]*=1.005
    assert recommend(ref,cs,5)['recommended']=='2C'
    cs['A'][:,1]=ref[:,1];cs['B']=cs['A'].copy()
    assert recommend(ref,cs,5)['recommended']=='3A'
    cs['A'][2,5]=1e-12;cs['B'][3,0]=ref[3,0]
    assert recommend(ref,cs,5)['recommended']=='2C'
