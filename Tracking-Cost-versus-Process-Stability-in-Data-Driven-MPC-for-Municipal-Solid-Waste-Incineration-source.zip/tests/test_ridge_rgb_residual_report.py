"""Protect selected-versus-diagnostic separation and the predeclared RGB gate."""
import csv
import hashlib
import json
from pathlib import Path

import numpy as np
import pytest

from mswi_experiments.ridge_rgb_residual_report import (
    CORRECTORS, DAY_NS, GATE_CONTROLS, METHODS,
    load_completed_study, recursive_gate, summarize_study,
)


def _json(path,value):Path(path).write_text(json.dumps(value))
def _sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def synthetic_study(root):
    root=Path(root);seeds=[11,23,37];scale=np.arange(1.,10.)
    config={"seeds":seeds,"statistics":{"bootstrap_draws":100,"bootstrap_seed":20261105,
        "confidence_level":.95,"primary_comparisons":["rgb_vs_quality","rgb_vs_null_rgb"],
        "recursive_gate":"four strictly positive lower bounds and sixteen no-worse MAEs"}}
    _json(root/"config.json",config);(root/"PROTOCOL.txt").write_text("Synthetic fixture protocol\n")
    prepared={"delta_scale":scale};rng=np.random.default_rng(301)
    for i,split in enumerate(("train","val","test")):
        n=8;truth=rng.normal(size=(n,9));base=truth+np.ones((n,9))
        values={"indices":i*100+np.arange(n),"time_ns":(20000+i*4+np.arange(n)//4)*DAY_NS+np.arange(n)%4*60_000_000_000,
                "capture_index":i*10+np.arange(n)//2,"truth":truth,"base":base}
        prepared.update({split+"_"+k:v for k,v in values.items()})
    np.savez_compressed(root/"prepared.npz",**prepared);prepared_sha=_sha(root/"prepared.npz")
    preparation={"status":"complete","prepared_sha256":prepared_sha,
        "partition_counts":{"train":8,"val":8,"test":8},"original_partition_counts":{"train":20,"val":8,"test":8},
        "visual":{"unique_capture_counts":{"train":999,"val":4,"test":4}}}
    _json(root/"preparation.json",preparation)
    models=[];files=[]
    norm=lambda truth,pred:float(np.square((pred-truth)/scale).mean())
    for split in ("train","val","test"):
        p={k:prepared[split+"_"+k] for k in ("indices","time_ns","capture_index","truth","base")}
        raw={k:v for k,v in p.items() if k!="base"}
        path=root/f"predictions/ridge/{split}.npz";path.parent.mkdir(parents=True,exist_ok=True)
        np.savez_compressed(path,**raw,prediction=p["base"],base_prediction=p["base"],correction=np.zeros_like(p["base"]),
            trained_prediction=p["base"],delta_scale=scale)
        files.append({"method":"ridge","seed":None,"split":split,"path":str(path.relative_to(root)),
            "sha256":_sha(path),"samples":8,"normalized_mse":norm(p["truth"],p["base"])})
    for mi,method in enumerate(CORRECTORS):
        for si,seed in enumerate(seeds):
            scores={}
            for split in ("train","val","test"):
                p={k:prepared[split+"_"+k] for k in ("indices","time_ns","capture_index","truth","base")}
                # Every head is rejected on validation, despite a much better
                # diagnostic test prediction: the report must keep zero selected.
                correction=np.zeros_like(p["base"])
                trained_delta=(.2+mi*.03+si*.01) if split=="val" else -.8
                trained=p["base"]+trained_delta
                path=root/f"predictions/{method}/seed_{seed}/{split}.npz";path.parent.mkdir(parents=True,exist_ok=True)
                np.savez_compressed(path,**{k:v for k,v in p.items() if k!="base"},prediction=p["base"],base_prediction=p["base"],
                    correction=correction,trained_prediction=trained,trained_correction=np.ones_like(trained)*trained_delta,delta_scale=scale)
                score=norm(p["truth"],p["base"]);trained_score=norm(p["truth"],trained)
                files.append({"method":method,"seed":seed,"split":split,"path":str(path.relative_to(root)),
                    "sha256":_sha(path),"samples":8,"selected_epoch":0,"normalized_mse":score,"trained_normalized_mse":trained_score})
                if split=="val":scores={"val_normalized_mse":score,"zero_val_normalized_mse":score,
                                         "trained_val_normalized_mse":trained_score}
            models.append({"method":method,"seed":seed,"selected_epoch":0,"selected_kind":"zero",**scores,
                           "trained_epoch":1,"epochs_run":2,"optimizer_steps":2})
    selection={"status":"complete","prepared_sha256":prepared_sha,"methods":list(CORRECTORS),"seeds":seeds,
               "models":models,"test_evaluated":False}
    _json(root/"model_selection.json",selection)
    _json(root/"model_selection_frozen.json",{"prepared_sha256":prepared_sha,
        "artifacts":{"model_selection.json":_sha(root/"model_selection.json")}})
    _json(root/"predictions_manifest.json",{"status":"complete","files":files,
        "model_selection_frozen_sha256":_sha(root/"model_selection_frozen.json"),"prepared_sha256":prepared_sha,"test_evaluated":True})
    return root


def passing_gate_inputs():
    metrics={m:{"physical_mae":[1.,1.,1.,1.]} for m in METHODS}
    metrics["rgb"]["physical_mae"]=[.9,1.,.8,.7]
    comparisons={"rgb_vs_"+m:{"candidate":"rgb","reference":m,"difference":[.2]*5,
                              "ci_lower":[.1]*5,"ci_upper":[.3]*5} for m in GATE_CONTROLS}
    return metrics,comparisons


def test_gate_requires_every_guard_and_strictly_positive_nmse_lower_bound():
    metrics,contrasts=passing_gate_inputs();gate=recursive_gate(metrics,contrasts,"frozen rule")
    assert gate["passed"] and gate["nmse_constraints_passed"]==4 and gate["physical_constraints_passed"]==16
    contrasts["rgb_vs_ridge"]["ci_lower"][0]=0.
    gate=recursive_gate(metrics,contrasts,"frozen rule")
    assert not gate["passed"] and gate["decision"]=="stop_after_one_step"
    assert gate["nmse_constraints_passed"]==3


def test_gate_accepts_exact_mae_ties_but_rejects_any_physical_tradeoff():
    metrics,contrasts=passing_gate_inputs()
    assert recursive_gate(metrics,contrasts,"frozen rule")["passed"]
    metrics["rgb"]["physical_mae"][1]=1.0000001
    gate=recursive_gate(metrics,contrasts,"frozen rule")
    assert not gate["passed"] and gate["physical_constraints_passed"]==12
    assert not gate["test_based_model_reselection"]


def test_selected_zero_is_not_replaced_by_better_unselected_test_head(tmp_path):
    root=synthetic_study(tmp_path);result=summarize_study(root)
    assert result["selected_zero_counts"]=={m:3 for m in CORRECTORS}
    ridge=result["metrics"]["test"]["ridge"]["normalized_mse"]
    for method in CORRECTORS:
        assert result["metrics"]["test"][method]["normalized_mse"]==pytest.approx(ridge)
        assert result["trained_diagnostic_metrics"]["test"][method]["normalized_mse"]<ridge
    assert not result["recursive_gate"]["passed"]
    for interval in result["comparisons"].values():
        assert interval["difference"]==[0.]*5 and interval["ci_lower"]==[0.]*5 and interval["ci_upper"]==[0.]*5
    assert result["test_period"]["unique_captures"]==4
    assert len(result["prediction_checks"])==39 and len(result["comparisons"])==6
    for check in result["prediction_checks"]:assert check["unique_captures"]==4


def test_all_partitions_seeds_channels_and_diagnostics_export_separately(tmp_path):
    root=synthetic_study(tmp_path);summarize_study(root)
    counts={name:len(list(csv.DictReader((root/"statistics"/name).open()))) for name in
        ("overall.csv","by_seed.csv","by_day.csv","channels.csv","trained_diagnostic_overall.csv",
         "trained_diagnostic_by_seed.csv","trained_diagnostic_by_day.csv","trained_diagnostic_channels.csv",
         "comparisons.csv","selections.csv")}
    assert counts=={"overall.csv":15,"by_seed.csv":39,"by_day.csv":108,"channels.csv":486,
        "trained_diagnostic_overall.csv":15,"trained_diagnostic_by_seed.csv":39,"trained_diagnostic_by_day.csv":108,
        "trained_diagnostic_channels.csv":486,"comparisons.csv":30,"selections.csv":12}
    assert {r["metric_version"] for r in csv.DictReader((root/"statistics/overall.csv").open())}=={"selected"}
    assert {r["metric_version"] for r in csv.DictReader((root/"statistics/trained_diagnostic_overall.csv").open())}=={"trained_diagnostic"}


def test_prediction_capture_misalignment_is_rejected_even_if_manifest_rehashed(tmp_path):
    root=synthetic_study(tmp_path);path=root/"predictions/rgb/seed_11/test.npz"
    with np.load(path) as z:row={k:z[k].copy() for k in z.files}
    row["capture_index"][0]+=100;np.savez_compressed(path,**row)
    manifest=json.loads((root/"predictions_manifest.json").read_text())
    next(r for r in manifest["files"] if r["path"]==str(path.relative_to(root)))["sha256"]=_sha(path)
    _json(root/"predictions_manifest.json",manifest)
    with pytest.raises(ValueError,match="fixed identities"):load_completed_study(root)


def test_missing_seed_predictions_are_not_silently_ignored(tmp_path):
    root=synthetic_study(tmp_path);manifest=json.loads((root/"predictions_manifest.json").read_text())
    manifest["files"].pop();_json(root/"predictions_manifest.json",manifest)
    with pytest.raises(ValueError,match="incomplete unique"):load_completed_study(root)


def test_replaced_zero_correction_is_rejected(tmp_path):
    root=synthetic_study(tmp_path);path=root/"predictions/rgb/seed_11/test.npz"
    with np.load(path) as z:row={k:z[k].copy() for k in z.files}
    row["prediction"]=row["trained_prediction"].copy();row["correction"]=row["trained_correction"].copy()
    np.savez_compressed(path,**row);manifest=json.loads((root/"predictions_manifest.json").read_text())
    rec=next(r for r in manifest["files"] if r["path"]==str(path.relative_to(root)))
    rec["sha256"]=_sha(path);rec["normalized_mse"]=float(np.square((row["prediction"]-row["truth"])/row["delta_scale"]).mean())
    _json(root/"predictions_manifest.json",manifest)
    with pytest.raises(ValueError,match="selected zero was replaced"):load_completed_study(root)
