import numpy as np
from PIL import Image
import pytest
import torch

from mswi_experiments.rgb_geometry_embeddings import (geometry_tensors, letterbox_geometry,
                                                       pool_feature_map, _prepare)
from mswi_experiments.visual_image_embeddings import image_tensors


def test_squash_exactly_matches_original_rgb_pipeline():
    rng=np.random.default_rng(7)
    image=Image.fromarray(rng.integers(0,256,(1088,1920,3),dtype=np.uint8))
    squash,_,geometry=geometry_tensors(image)
    assert torch.equal(squash,image_tensors(image)[0])
    assert geometry['roi_width']==1113 and geometry['roi_height']==685


def test_letterbox_keeps_rectangle_and_exact_mean_padding():
    image=Image.new('RGB',(1920,1088),(255,0,0))
    _,letterbox,g=geometry_tensors(image)
    assert (g['resized_width'],g['resized_height'])==(224,138)
    assert (g['top'],g['bottom'],g['left'],g['right'])==(43,43,0,0)
    assert torch.count_nonzero(letterbox[:,:43])==0
    assert torch.count_nonzero(letterbox[:,181:])==0
    assert torch.count_nonzero(letterbox[:,43:181])>0


def test_portrait_and_odd_padding():
    g=letterbox_geometry(2,3)
    assert g['resized_width']==149 and g['resized_height']==224
    assert g['left']==37 and g['right']==38
    assert g['top']==g['bottom']==0


def test_square_geometry_has_no_padding_and_equal_inputs():
    # Validate square cropped ROI directly with synthetic geometry dimensions.
    assert letterbox_geometry(100,100)['left']==0
    assert letterbox_geometry(100,100)['resized_height']==224


@pytest.mark.parametrize('size',[(0,7),(7,-1),(1.5,7)])
def test_invalid_geometry_rejected(size):
    with pytest.raises(ValueError):letterbox_geometry(*size)


def test_pooling_retains_channel_major_spatial_regions():
    base=torch.arange(49,dtype=torch.float32).reshape(1,1,7,7)
    features=base.expand(2,512,7,7).clone()
    features[:,1]+=100
    global_feature,spatial=pool_feature_map(features)
    expected=torch.tensor([base[0,0,:4,:4].mean(),base[0,0,:4,3:].mean(),
                           base[0,0,3:,:4].mean(),base[0,0,3:,3:].mean()])
    assert global_feature.shape==(2,512) and spatial.shape==(2,2048)
    assert torch.equal(global_feature[:,0],torch.full((2,),24.))
    assert torch.equal(spatial[0,:4],expected)
    assert torch.equal(spatial[0,4:8],expected+100)


def test_pooling_rejects_wrong_map_or_nonfinite_values():
    with pytest.raises(ValueError):pool_feature_map(torch.zeros(1,512,8,8))
    bad=torch.zeros(1,512,7,7);bad[0,0,0,0]=float('nan')
    with pytest.raises(ValueError):pool_feature_map(bad)


def test_source_hash_validation_happens_before_decode(tmp_path):
    path=tmp_path/'image.jpg';path.write_bytes(b'not an image')
    with pytest.raises(ValueError,match='source image changed'):
        _prepare({'path':str(path),'source_sha256':'0'*64})
