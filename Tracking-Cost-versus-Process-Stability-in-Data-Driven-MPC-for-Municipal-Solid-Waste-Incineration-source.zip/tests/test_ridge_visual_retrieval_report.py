"""Semantic and provenance checks for visual-retrieval Ridge reporting."""
import json
from pathlib import Path

import numpy as np
import pytest

from mswi_experiments.numeric_baselines import sha256, write_json
from mswi_experiments.ridge_visual_retrieval_report import (
    DAY_NS, MINUTE_NS, MV_MODES, ONE_STEP_METHODS, ROLLOUT_METHODS, SPLITS,
    endpoint_differences, load_completed_study, retrieval_diagnostics, summarize,
    validate_prediction_arrays,
)


def fixture_study(root):
    root = Path(root)
    cfg = {"horizon": 10, "endpoints": [1, 5, 10], "bootstrap_draws": 100,
           "bootstrap_seed": 20261105, "confidence_level": .95}
    write_json(root / "config.json", cfg)
    write_json(root / "stats.json", {"delta_scale": list(range(1, 10))})
    write_json(root / "protocol.json", {"scope": "synthetic fixture"})
    write_json(root / "selection.json", {"status": "complete", "models": []})
    names = ("config.json", "stats.json", "protocol.json", "selection.json")
    write_json(root / "selection_frozen.json", {"status": "complete", "files": {n: sha256(root / n) for n in names}})
    records = []
    errors = dict(zip(ONE_STEP_METHODS, (2., 1., .5, 1.5, 1.2, 1.8, 1.6, .8, .6)))
    for si, split in enumerate(SPLITS):
        idx = (si + 1) * 1000 + np.arange(40)
        times = (20000 + si * 5 + np.arange(40) // 20) * DAY_NS + np.arange(40) % 20 * MINUTE_NS
        truth = np.arange(40)[:, None] * .1 + np.arange(9)[None]
        key = np.arange(40) % 5 + 100
        for method in ONE_STEP_METHODS:
            absent = method == "ridge" or method.endswith("_observed")
            row = {"indices": idx, "time_ns": times, "truth_cv": truth, "pred_cv": truth + errors[method],
                   "key_indices": np.full(40, -1) if absent else key,
                   "donor_indices": idx if method.endswith("_observed") else np.full(40, -1) if absent else key + 10,
                   "scores": np.zeros(40) if absent else np.full(40, .8)}
            rel = f"one_step/{split}/{method}.npz"; path = root / rel; path.parent.mkdir(parents=True, exist_ok=True)
            np.savez_compressed(path, **row)
            records.append({"kind": "one_step", "split": split, "method": method, "path": rel, "sha256": sha256(path)})
        positions = np.r_[np.arange(6), np.arange(20, 26)][:, None] + np.arange(10)
        for mode in MV_MODES:
            for method in ROLLOUT_METHODS:
                origin = method.removesuffix("_hold_visual")
                trace = key[positions]
                score = np.full((12, 10), .8)
                pred = truth[positions] + errors[origin]
                if method.endswith("_hold_visual"):
                    trace = np.repeat(trace[:, :1], 10, axis=1)
                    pred = pred + np.arange(10)[None, :, None] * .02
                absent = method == "ridge"
                mv = np.broadcast_to(np.arange(10)[None, :, None], (12, 10, 8)).copy()
                if mode == "hold_mv": mv = np.repeat(mv[:, :1], 10, axis=1)
                row = {"indices": idx[positions], "time_ns": times[positions], "start_time_ns": times[positions[:, 0]],
                       "truth_cv": truth[positions], "pred_cv": pred, "initial_zprev": truth[positions[:, 0]] - .1,
                       "mv_path": mv, "key_indices": np.full((12, 10), -1) if absent else trace,
                       "donor_indices": np.full((12, 10), -1) if absent else trace + 10,
                       "scores": np.zeros((12, 10)) if absent else score}
                rel = f"rollouts/{split}/{mode}/{method}.npz"; path = root / rel; path.parent.mkdir(parents=True, exist_ok=True)
                np.savez_compressed(path, **row)
                records.append({"kind": "rollout", "split": split, "method": method, "mv_mode": mode,
                                "path": rel, "sha256": sha256(path)})
    write_json(root / "predictions_manifest.json", {"status": "complete", "selection_sha256": sha256(root / "selection.json"), "files": records})
    return root


def mutate_archive(root, relative, mutate):
    path = root / relative
    with np.load(path) as archive: row = {k: archive[k].copy() for k in archive.files}
    mutate(row)
    np.savez_compressed(path, **row)
    manifest = json.loads((root / "predictions_manifest.json").read_text())
    next(r for r in manifest["files"] if r["path"] == relative)["sha256"] = sha256(path)
    write_json(root / "predictions_manifest.json", manifest)


def test_positive_difference_means_candidate_better_and_temperature_is_aggregated_first():
    truth = np.zeros((3, 9)); ref = np.ones((3, 9)) * 2; cand = np.ones((3, 9))
    result = endpoint_differences(ref, cand, truth, np.ones(9))
    np.testing.assert_array_equal(result[0], np.tile([3., 1., 1., 1., 1.], (3, 1)))
    cand[:, :6] = [1, -1, 1, -1, 1, -1]
    result = endpoint_differences(ref, cand, truth, np.ones(9))
    assert np.all(result[..., 1] == 2)


def test_complete_summary_retains_all_scenarios_and_diagnostic_denominators(tmp_path):
    root = fixture_study(tmp_path)
    result = summarize(root)
    assert len(result["prediction_checks"]) == 54
    assert len(result["retrieval_diagnostics"]) == 54
    assert result["one_step"]["test"]["ridge"]["samples"] == 40
    assert result["rollouts"]["test"]["logged"]["ridge"]["10"]["samples"] == 12
    interval = result["comparisons"]["logged"]["retrieved_rgb32_vs_ridge"]["10"]
    assert interval["training_seeds"] == 1 and interval["time_blocks"] == 2
    assert interval["ci_lower"][0] > 0
    assert len(result["comparisons"]["logged"]) == 7
    assert len(result["rollouts"]["test"]["hold_mv"]) == 9
    assert result["rollouts"]["test"]["logged"]["retrieved52"]["10"]["physical_mae"] == [1.] * 4


@pytest.mark.parametrize("fault,expected", [
    ("time", "minute alignment"), ("truth", "paired methods"),
    ("nan", "nonfinite"), ("start_prediction", "first prediction"),
])
def test_semantic_corruption_rejected_even_when_manifest_hash_is_updated(tmp_path, fault, expected):
    root = fixture_study(tmp_path)
    def change(row):
        if fault == "time": row["time_ns"][0, 1] += MINUTE_NS
        elif fault == "truth": row["truth_cv"][0, 0, 0] += 1
        elif fault == "nan": row["pred_cv"][0, 3, 0] = np.nan
        else: row["pred_cv"][0, 0, 0] += 1
    mutate_archive(root, "rollouts/test/logged/retrieved52.npz", change)
    with pytest.raises(ValueError, match=expected): load_completed_study(root)


def test_held_visual_trace_must_remain_the_initial_trace(tmp_path):
    root = fixture_study(tmp_path)
    def change(row): row["donor_indices"][0, 4] += 1
    mutate_archive(root, "rollouts/test/logged/retrieved52_hold_visual.npz", change)
    with pytest.raises(ValueError, match="held visual trace"): load_completed_study(root)


def test_held_mv_cannot_silently_use_future_operations(tmp_path):
    root = fixture_study(tmp_path)
    # Change every paired method so pairwise consistency alone cannot detect it.
    for method in ROLLOUT_METHODS:
        def change(row): row["mv_path"][0, 2, 0] += 1
        mutate_archive(root, f"rollouts/test/hold_mv/{method}.npz", change)
    with pytest.raises(ValueError, match="held MV path"): load_completed_study(root)


def test_missing_model_or_changed_frozen_selection_is_rejected(tmp_path):
    root = fixture_study(tmp_path)
    selection = json.loads((root / "selection.json").read_text()); selection["models"].append("changed")
    write_json(root / "selection.json", selection)
    with pytest.raises(ValueError, match="not complete and frozen"): load_completed_study(root)


def test_retrieval_diagnostics_count_actual_donor_switches_and_absent_context():
    row = {"key_indices": np.array([[1, 1, 2], [1, 2, 3]]),
           "donor_indices": np.array([[10, 10, 20], [10, 20, 30]]), "scores": np.full((2, 3), .75)}
    result = retrieval_diagnostics(row)
    assert result["unique_donors"] == 3 and result["donor_switch_fraction"] == .75
    assert result["mean_cosine"] == .75
    absent = {"key_indices": np.full((2, 3), -1), "donor_indices": np.full((2, 3), -1), "scores": np.zeros((2, 3))}
    assert retrieval_diagnostics(absent)["mean_cosine"] is None


def test_cosine_is_not_allowed_to_exceed_its_domain():
    row = {"indices": np.arange(3), "time_ns": np.arange(3) * MINUTE_NS,
           "truth_cv": np.zeros((3, 9)), "pred_cv": np.zeros((3, 9)),
           "key_indices": np.arange(3), "donor_indices": np.arange(3), "scores": np.full(3, 1.1)}
    with pytest.raises(ValueError, match="cosine scores"):
        validate_prediction_arrays(row, kind="one_step", method="retrieved52")
