"""Meaningful checks for admitted fixed policies and full-model MPC planning."""
from copy import deepcopy
import json
from pathlib import Path

import numpy as np
import pytest

from mswi_experiments import ridge_control_probe as probe
from mswi_experiments.control import reward_and_violation
from mswi_experiments.data import MINUTE_NS
from mswi_experiments.ridge_dynamics import RidgeDynamics
from mswi_experiments.ridge_response import analytic_responses, decision_rollout, project_trial_paths
from mswi_experiments.ridge_response_study import fit_support, MODEL_IDS


def configuration():
    return {**deepcopy(probe.FIXED),'threads':1,'source_run':'source','diagnostic_study':'diagnostic','output_dir':'output'}


def model_fixture(direction=1.):
    coefficient=np.zeros((9,178));coefficient[:6,80]=direction*.2;coefficient[6,83]=direction*.2
    return RidgeDynamics({'x_mean':np.zeros(178),'x_scale':np.ones(178),'coef':coefficient,
        'intercept':np.zeros(9),'delta_scale':np.ones(9),'kind':np.asarray('ridge'),'alpha':np.asarray(100.)})


def values_fixture(n=5):
    rng=np.random.default_rng(58);u=rng.normal(0,.15,(n,11,8));z=rng.normal(0,.5,(n,10,9));current=rng.normal(0,.5,(n,9))
    stats={'action_bound':[.5]*8,'action_scale':[.5]*8,'u_low':[-2.]*8,'u_high':[2.]*8,
        'control_low':[-5.]*4,'control_high':[5.]*4,'delta_scale':[1.]*9,
        'mv_names':[f'mv{i}' for i in range(8)],'cv_names':[f'cv{i}' for i in range(9)]}
    inputs={'u_hist':u,'z_hist':z,'z_current':current,'indices':np.arange(n),
        'time_ns':np.arange(n,dtype=np.int64)*30*MINUTE_NS,
        'future_time_ns':(np.arange(n)[:,None]*30+np.arange(1,11)[None])*MINUTE_NS,
        'truth_cv':np.zeros((n,10,9))}
    bc={'x_mean':np.zeros(187),'x_scale':np.ones(187),'coef':np.zeros((2,187)),
        'intercept':np.array([.03,-.03]),'alpha':np.asarray(100.)}
    return inputs,stats,bc


def admit_all(monkeypatch):
    monkeypatch.setattr(probe,'support_query',lambda support,u,z,delta,t:(np.zeros(len(u)),np.ones(len(u),dtype=bool),np.zeros(len(u),dtype=np.int64)))


def test_grid_candidates_fixed_order_and_units():
    _,stats,_=values_fixture();cfg=configuration();stats['action_scale'][0]=1.
    grid=probe.fixed_candidates(stats,cfg)
    assert grid.shape==(9,8) and np.array_equal(grid[0],np.zeros(8))
    assert np.array_equal(grid[:,[1,2,4,5,6,7]],np.zeros((9,6)))
    np.testing.assert_array_equal(grid[1,[0,3]],[-.05,-.1])
    assert len(np.unique(grid,axis=0))==9


def test_bc_observation_includes_current_cv_and_request_is_limited():
    inputs,stats,bc=values_fixture();cfg=configuration()
    x=probe.bc_features(inputs['u_hist'],inputs['z_hist'],inputs['z_current'])
    assert x.shape==(5,187);np.testing.assert_array_equal(x[:,178:],inputs['z_current'])
    bc['intercept']=np.array([100.,-100.])
    request=probe.bc_request(bc,inputs['u_hist'],inputs['z_hist'],inputs['z_current'],stats,cfg)
    np.testing.assert_array_equal(request[:,0],.1);np.testing.assert_array_equal(request[:,3],-.1)
    assert not request[:,[1,2,4,5,6,7]].any()


def test_unsupported_nonzero_is_rejected_and_zero_remains_explicit(monkeypatch):
    inputs,stats,bc=values_fixture();cfg=configuration()
    monkeypatch.setattr(probe,'support_query',lambda support,u,z,delta,t:(np.full(len(u),99.),np.zeros(len(u),dtype=bool),np.zeros(len(u),dtype=np.int64)))
    run=probe.rollout_policy(model_fixture(),model_fixture(),'linear_bc',inputs,bc,{},stats,cfg)
    assert run['blocked_nonzero'].all() and run['zero_action_unsupported'].all()
    assert not run['executed_action'].any() and run['requested_action'].any()
    assert not run['action_supported'].any() and (run['proposal_support_distance']==99).all()
    np.testing.assert_array_equal(run['u_path'],np.repeat(inputs['u_hist'][:,-1,None],10,axis=1))


def test_truncated_nonzero_is_not_silently_applied(monkeypatch):
    admit_all(monkeypatch);inputs,stats,bc=values_fixture();cfg=configuration()
    inputs['u_hist'][:,-1,0]=2.;bc['intercept']=np.array([.1,0.])
    run=probe.rollout_policy(model_fixture(),model_fixture(),'linear_bc',inputs,bc,{},stats,cfg)
    assert run['blocked_nonzero'].all() and not run['proposal_full_execution'].any()
    assert not run['executed_action'].any()


def test_analytic_grid_scores_match_full_canonical_rollouts(monkeypatch):
    admit_all(monkeypatch);inputs,stats,_=values_fixture();cfg=configuration();model=model_fixture();n=len(inputs['indices'])
    requests,diagnostic=probe.grid_plan(model,analytic_responses(model)['step'],inputs['u_hist'],inputs['z_hist'],inputs['z_current'],inputs['time_ns'],{},stats,cfg)
    expected=[];candidates=probe.fixed_candidates(stats,cfg)
    for request in candidates:
        executed,delta,next_u=probe._project(np.repeat(request[None],n,axis=0),inputs['u_hist'][:,-1],stats)
        path=np.repeat(next_u[:,None],10,axis=1)
        pred=decision_rollout(model,inputs['u_hist'],inputs['z_hist'],inputs['z_current'],path)
        actions=np.zeros((n,10,8));actions[:,0]=executed
        reward,_,_=reward_and_violation(pred,actions,stats);expected.append(reward.sum(1))
    np.testing.assert_allclose(diagnostic['candidate_scores'],np.stack(expected,axis=1),rtol=0,atol=3e-5)
    np.testing.assert_array_equal(requests,candidates[diagnostic['chosen_candidate']])


def test_mpc_uses_full_planner_when_evaluator_changes(monkeypatch):
    admit_all(monkeypatch);inputs,stats,bc=values_fixture();cfg=configuration();planner=model_fixture()
    same=probe.rollout_policy(planner,planner,'grid_mpc',inputs,bc,{},stats,cfg)
    other=probe.rollout_policy(model_fixture(-1.),planner,'grid_mpc',inputs,bc,{},stats,cfg)
    np.testing.assert_array_equal(same['candidate_scores'][:,0],other['candidate_scores'][:,0])
    np.testing.assert_array_equal(same['requested_action'][:,0],other['requested_action'][:,0])
    assert not np.array_equal(same['pred_cv'],other['pred_cv'])
    assert (other['reward']<=0).all() and not other['blocked_nonzero'].any()


def test_zero_wins_exact_ties_and_rejected_best_is_not_selected(monkeypatch):
    admit_all(monkeypatch);inputs,stats,_=values_fixture();cfg=configuration();model=model_fixture()
    monkeypatch.setattr(probe,'reward_and_violation',lambda pred,act,stats:(np.zeros(pred.shape[:-1]),np.zeros(pred.shape[:-1],dtype=bool),{}))
    requests,diag=probe.grid_plan(model,analytic_responses(model)['step'],inputs['u_hist'],inputs['z_hist'],inputs['z_current'],inputs['time_ns'],{},stats,cfg)
    assert not diag['chosen_candidate'].any() and not requests.any()


def test_unsupported_better_grid_candidate_is_rejected(monkeypatch):
    inputs,stats,_=values_fixture();cfg=configuration();model=model_fixture()
    monkeypatch.setattr(probe,'support_query',lambda support,u,z,delta,t:(np.full(len(u),99.),np.zeros(len(u),dtype=bool),np.zeros(len(u),dtype=np.int64)))
    request,diag=probe.grid_plan(model,analytic_responses(model)['step'],inputs['u_hist'],inputs['z_hist'],inputs['z_current'],inputs['time_ns'],{},stats,cfg)
    assert (diag['candidate_scores'].max(1)>diag['candidate_scores'][:,0]).all()
    assert not request.any() and not diag['chosen_candidate'].any()
    assert diag['candidate_admissible'][:,0].all() and not diag['candidate_admissible'][:,1:].any()


def test_truth_outcomes_never_enter_policy_or_dynamics(monkeypatch):
    admit_all(monkeypatch);inputs,stats,bc=values_fixture();cfg=configuration();model=model_fixture()
    changed=deepcopy(inputs);changed['truth_cv'][:]=1e20
    for policy in probe.POLICIES:
        a=probe.rollout_policy(model,model,policy,inputs,bc,{},stats,cfg)
        b=probe.rollout_policy(model,model,policy,changed,bc,{},stats,cfg)
        for key in ('pred_cv','u_path','requested_action','reward'):np.testing.assert_array_equal(a[key],b[key])


def archive_fixture(tmp_path):
    rng=np.random.default_rng(92);n=600;u=rng.normal(0,.2,(n+10,8));z=rng.normal(0,.5,(n+10,9))
    data={'u_hist':np.stack([u[i:i+11] for i in range(n)]),'z_hist':np.stack([z[i:i+10] for i in range(n)]),
        'u_current':u[10:].copy(),'z_current':z[10:].copy(),'z_target':z[10:].copy(),'z_prev':z[9:-1].copy(),
        'time_ns':np.arange(n,dtype=np.int64)*MINUTE_NS,'train_idx':np.arange(300),
        'val_idx':np.arange(350,450),'test_idx':np.arange(500,590),'next_idx':np.full(n,-1,dtype=np.int64),'action':np.zeros((n,8))}
    for split in ('train','val','test'):
        idx=data[split+'_idx'];data['next_idx'][idx[:-1]]=idx[1:];data['action'][idx[:-1]]=data['u_current'][idx[1:]]-data['u_current'][idx[:-1]]
    _,stats,_=values_fixture();cfg=configuration();source=tmp_path/'source/data';source.mkdir(parents=True)
    np.savez_compressed(source/'dataset.npz',**data);(source/'stats.json').write_text(json.dumps(stats));(source/'manifest.json').write_text('{}')
    diag=tmp_path/'diagnostic';(diag/'inputs').mkdir(parents=True);(diag/'models').mkdir();(diag/'statistics').mkdir()
    inputs=[]
    for split,indices in [('val',np.array([350,365])),('test',np.array([500,515]))]:
        chain=indices[:,None]+np.arange(11)[None]
        trial=project_trial_paths(data['u_current'][indices],stats)
        values={'indices':indices,'chains':chain,'time_ns':data['time_ns'][indices],
            'future_time_ns':data['time_ns'][chain[:,1:]],'u_hist':data['u_hist'][indices],
            'z_hist':data['z_hist'][indices],'z_current':data['z_current'][indices],
            'truth_cv':data['z_target'][chain[:,1:]],**trial,'supported':np.ones((2,16),dtype=bool),
            'baseline_supported':np.ones(2,dtype=bool),'logged_supported':np.ones(2,dtype=bool)}
        np.savez_compressed(diag/f'inputs/{split}.npz',**values)
    model=model_fixture();models=[]
    for name in MODEL_IDS:
        np.savez_compressed(diag/f'models/{name}.npz',**dict(model.weights))
        models.append({'model_id':name,'model_path':f'models/{name}.npz'})
    responses={'step':np.repeat(analytic_responses(model)['step'][None],5,axis=0),'amp':np.full(8,.05),'phys_scale':np.ones(4)}
    np.savez_compressed(diag/'responses.npz',**responses);np.savez_compressed(diag/'support.npz',**fit_support(data,bank_size=50,calibration_size=40))
    diag_cfg={'response_deadband_sigma':.05,'gate_endpoints':[1,5,10],'max_response_amplitude_ratio':3.,'minimum_supported_executable_fraction':.8}
    (diag/'config.json').write_text(json.dumps(diag_cfg));(diag/'stats.json').write_text(json.dumps(stats))
    (diag/'selection.json').write_text(json.dumps({'status':'complete','models':models}))
    (diag/'statistics/summary.json').write_text('{}')
    original={str(q.resolve()):probe.sha256(q) for q in source.iterdir()}
    (diag/'input_hashes.json').write_text(json.dumps(original))
    frozen_files={str(q.relative_to(diag)):probe.sha256(q) for q in diag.rglob('*') if q.is_file()}
    (diag/'selection_frozen.json').write_text(json.dumps({'status':'complete','files':frozen_files,'source_code_hashes':{}}))
    (diag/'response_checks.json').write_text(json.dumps({'status':'passed'}))
    prior_run={'status':'complete','source_selection_sha256':probe.sha256(diag/'selection.json'),
        'source_selection_frozen_sha256':probe.sha256(diag/'selection_frozen.json'),
        'response_checks_sha256':probe.sha256(diag/'response_checks.json'),
        'files':[{'path':'responses.npz','sha256':probe.sha256(diag/'responses.npz')}]}
    (diag/'run_manifest.json').write_text(json.dumps(prior_run))
    (diag/'report_manifest.json').write_text(json.dumps({'status':'complete',
        'source_run_manifest_sha256':probe.sha256(diag/'run_manifest.json'),
        'files':{'statistics/summary.json':probe.sha256(diag/'statistics/summary.json')}}))
    codes=tmp_path/'mswi_experiments';codes.mkdir()
    for name in probe.SNAPSHOT_NAMES:(codes/name).write_text('# synthetic source\n')
    path=tmp_path/'config.json';path.write_text(json.dumps(cfg))
    return path,data,stats


def test_bc_training_rows_targets_and_scaler_are_train_only():
    # Reuse the complete source fixture without preparing the control experiment.
    import tempfile
    with tempfile.TemporaryDirectory() as directory:
        cfg,data,stats=archive_fixture(Path(directory));config=configuration()
        a=probe.bc_training_inputs(data,stats,config)
        changed=deepcopy(data)
        for k in ('u_hist','z_hist','u_current','z_current','action'):changed[k][350:]+=1000
        b=probe.bc_training_inputs(changed,stats,config)
        for k in a:np.testing.assert_array_equal(a[k],b[k])
        assert a['features'].shape[1]==187 and a['normalized_target'].shape[1]==2
        assert np.max(np.abs(a['normalized_target']))<=.1+1e-12
        weights=probe.fit_bc(a['features'],a['normalized_target'])
        np.testing.assert_allclose(weights['x_mean'],a['features'].mean(0),atol=1e-14)


def test_end_to_end_fixed_inventory_and_frozen_sources(tmp_path):
    cfg,_,_=archive_fixture(tmp_path);out=probe.prepare(cfg);probe.train(cfg);probe.run(cfg)
    manifest=json.loads((out/'run_manifest.json').read_text());assert len(manifest['files'])==30
    assert manifest['planner_model']=='full' and manifest['rl_trained'] is False
    for row in manifest['files']:
        values=probe.archive(out/row['path']);assert values['pred_cv'].shape==(2,10,9)
        assert not values['executed_action'][:,:,[1,2,4,5,6,7]].any()
        assert (values['reward']<=0).all()
        if row['policy']=='grid_mpc':assert values['candidate_scores'].shape==(2,10,9)
    with pytest.raises(FileExistsError):probe.run(cfg)
    with pytest.raises(FileExistsError):probe.train(cfg)
    with pytest.raises(FileExistsError):probe.prepare(cfg)


def test_training_rejects_changed_frozen_inputs(tmp_path):
    cfg,_,_=archive_fixture(tmp_path);out=probe.prepare(cfg)
    (out/'gate.json').write_text('{}')
    with pytest.raises(ValueError,match='frozen input changed'):probe.train(cfg)


def test_fixed_protocol_rejects_posthoc_action_expansion(tmp_path):
    cfg=configuration();cfg['eligible_channels']=[0,2,3];path=tmp_path/'config.json';path.write_text(json.dumps(cfg))
    with pytest.raises(ValueError,match='fixed limited-control'):probe.paths(path)
