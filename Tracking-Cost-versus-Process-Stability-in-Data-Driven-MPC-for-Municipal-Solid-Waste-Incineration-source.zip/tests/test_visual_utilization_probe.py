import json

import numpy as np
import pytest
from sklearn.linear_model import Ridge
from threadpoolctl import threadpool_limits

from mswi_experiments.data import MINUTE_NS, control_values
from mswi_experiments.visual_diagnostics_horizons import fit_direct_ridge, apply_direct_ridge
from mswi_experiments.visual_utilization_probe import (
    prepare_group_ridge, fit_group_ridge, select_adaptive, origin_design,
    visual_contribution, _endpoint_priority,
)


def regression_data():
    rng = np.random.default_rng(48)
    x = rng.normal(size=(100, 9))*np.arange(1, 10)+np.arange(9)*2
    x[:, 3] = 7.
    x[:, 8] = x[:, 6]  # dependent visual columns remain solvable with penalties
    y = x@rng.normal(size=(9, 4))+rng.normal(size=(100, 4))*.2
    return x[:75], y[:75], x[75:], y[75:]


def test_group_rho1_matches_canonical_ridge_with_intercept():
    x, y, vx, vy = regression_data()
    with threadpool_limits(limits=1):
        expected = fit_direct_ridge(x, y, vx, vy)
        actual = fit_group_ridge(prepare_group_ridge(x, y, vx, vy, 5), 1.)
    assert float(actual['alpha']) == float(expected['alpha'])
    for key in ['x_mean', 'x_scale', 'y_mean', 'y_scale']:
        np.testing.assert_array_equal(actual[key], expected[key])
    np.testing.assert_allclose(actual['val_normalized_mse'], expected['val_normalized_mse'], rtol=0, atol=1e-12)
    np.testing.assert_allclose(actual['coef'], expected['coef'], rtol=0, atol=1e-10)
    np.testing.assert_allclose(apply_direct_ridge(actual, vx, np.zeros((25, 4))),
                               apply_direct_ridge(expected, vx, np.zeros((25, 4))), rtol=0, atol=1e-10)


def test_group_penalty_matches_post_scaling_transform_and_changes_coefficients():
    x, y, vx, vy = regression_data()
    prepared = prepare_group_ridge(x, y, vx, vy, 5)
    sx = (x-prepared['x_mean'])/prepared['x_scale']
    sy = (y-prepared['y_mean'])/prepared['y_scale']
    for rho in [.1, 10.]:
        scale = np.ones(x.shape[1]); scale[5:] = 1/np.sqrt(rho)
        with threadpool_limits(limits=1):
            direct = Ridge(alpha=1., solver='cholesky').fit(sx*scale, sy)
            fitted = fit_group_ridge(prepared, rho, [1.])
        np.testing.assert_allclose(fitted['coef'], direct.coef_*scale, rtol=0, atol=1e-10)
        np.testing.assert_allclose(fitted['intercept'], direct.intercept_, rtol=0, atol=1e-12)
    weak = fit_group_ridge(prepared, .1, [10.])
    strong = fit_group_ridge(prepared, 10., [10.])
    assert not np.allclose(weak['coef'][:, 5:], strong['coef'][:, 5:])
    assert np.linalg.norm(weak['coef'][:, 5:]) > np.linalg.norm(strong['coef'][:, 5:])


def test_scalers_train_only_and_invalid_group_penalty_rejected():
    x, y, vx, vy = regression_data()
    first = prepare_group_ridge(x, y, vx, vy, 5)
    later = prepare_group_ridge(x, y, vx+1e6, vy-1e5, 5)
    for key in ['x_mean', 'x_scale', 'y_mean', 'y_scale', 'gram', 'cross']:
        np.testing.assert_array_equal(first[key], later[key])
    for rho in [0, -1, np.inf, np.nan]:
        with pytest.raises(ValueError, match='positive'):
            fit_group_ridge(first, rho)
    with pytest.raises(ValueError, match='matrices'):
        prepare_group_ridge(x, y, vx, vy, 0)


def test_adaptive_ties_use_dimensions_then_rho_then_alpha_and_no_test_scores():
    candidates = {
        'd512': {'selected_val_score': 1., 'visual_dimension': 512, 'rho': 1., 'alpha': .1, 'test_mae': 0.},
        'd32weak': {'selected_val_score': 1., 'visual_dimension': 32, 'rho': .1, 'alpha': .1, 'test_mae': 0.},
        'd32unit': {'selected_val_score': 1., 'visual_dimension': 32, 'rho': 1., 'alpha': 100., 'test_mae': 100.},
    }
    assert select_adaptive(candidates) == 'd32unit'
    candidates['d512']['selected_val_score'] = .999
    assert select_adaptive(candidates) == 'd512'
    assert _endpoint_priority(5, 'adaptive_rgb', 'quality')['oxygen'].endswith('primary')
    assert _endpoint_priority(5, 'adaptive_rgb', 'matched_null')['steam'].endswith('primary')
    assert _endpoint_priority(5, 'adaptive_rgb', 'old52_reference')['oxygen'] == 'exploratory_secondary'


def test_null_changes_only_encoding_and_visual_term_zero_for_quality():
    n = 6; mapping = np.repeat(np.arange(3), 2)
    data = {'u_hist': np.zeros((n, 11, 8)), 'z_hist': np.zeros((n, 10, 9))}
    variants = {'timing4': np.ones((n, 4))}
    features = {'quality': np.arange(36).reshape(3, 12), 'rgb_pca128': np.arange(384).reshape(3, 128),
                'rgb_raw': np.arange(1536).reshape(3, 512), 'sample_capture_index': mapping,
                'null_donor_sample_index': np.array([4, 4, 0, 0, 2, 2])}
    rows = np.arange(n)
    real = origin_design(data, variants, features, 32, rows)
    null = origin_design(data, variants, features, 32, rows, True)
    baseline = origin_design(data, variants, features, 0, rows)
    np.testing.assert_array_equal(real[:, :194], baseline)
    np.testing.assert_array_equal(null[:, :194], baseline)
    np.testing.assert_array_equal(null[:, 194:], features['rgb_pca128'][mapping[features['null_donor_sample_index']], :32])
    fitted = {'base_dimension': np.array(194), 'x_mean': np.zeros(194), 'x_scale': np.ones(194),
              'coef': np.ones((4, 194)), 'y_scale': np.ones(4)}
    assert visual_contribution(fitted, baseline)['rms'] == [0.]*4


def test_complete_synthetic_study_freezes_selects_then_scores_and_replays(tmp_path, monkeypatch):
    import mswi_experiments.visual_utilization_probe as probe
    from mswi_experiments.visual_representation_probe import fit_capture_pca

    rng = np.random.default_rng(21)
    n = 480
    mapping = np.repeat(np.arange(n//2), 2)
    times = (2*np.arange(n//2)-1)*MINUTE_NS
    data = {'time_ns': np.arange(n)*MINUTE_NS, 'visual_time_ns': times[mapping],
            'train_idx': np.arange(300), 'val_idx': np.arange(300, 390), 'test_idx': np.arange(390, n),
            'u_hist': rng.normal(size=(n, 11, 8)), 'z_hist': rng.normal(size=(n, 10, 9)),
            'z_prev': rng.normal(size=(n, 9)), 'next_idx': np.r_[np.arange(1, n), -1]}
    data['z_target'] = data['z_prev']+rng.normal(size=(n, 9))*.1
    variants = {'timing4': rng.normal(size=(n, 4)), 'original52': rng.normal(size=(n, 52))}
    donors = np.empty(n, dtype=np.int64)
    for part in probe.PARTITIONS:
        rows = data[part+'_idx']; donors[rows] = np.repeat(rows[::2][::-1], 2)
    descriptor = tmp_path/'descriptor'; descriptor.mkdir()
    np.savez_compressed(descriptor/'feature_variants.npz', **variants)
    np.savez_compressed(descriptor/'feature_metadata.npz', null_donor_sample_index=donors)
    base_path = tmp_path/'base.json'; base_path.write_text('{}')
    (descriptor/'protocol.json').write_text(json.dumps({'input_hashes': {str(base_path): probe._sha(base_path)},
        'feature_archive_sha256': probe._sha(descriptor/'feature_variants.npz')}))
    rgb = rng.normal(size=(n//2, 512))
    np.savez_compressed(tmp_path/'embeddings.npz', capture_time_ns=times, sample_capture_index=mapping, rgb=rgb, gray=rgb.copy())
    np.savez_compressed(tmp_path/'quality.npz', capture_time_ns=times, sample_capture_index=mapping,
                        quality=rng.normal(size=(n//2, 12)), columns=np.array([f'q{i}' for i in range(12)]))
    (tmp_path/'encoder.json').write_text(json.dumps({'status': 'completed', 'embeddings_sha256': probe._sha(tmp_path/'embeddings.npz')}))
    previous = tmp_path/'previous/probe'; previous.mkdir(parents=True)
    with threadpool_limits(limits=1):
        pca, _ = fit_capture_pca(rgb, mapping, data['train_idx'], 32)
    np.savez_compressed(previous/'pca_rgb.npz', **pca)
    prior = {'status': 'completed', 'horizons': {}}
    for horizon in probe.HORIZONS:
        split_metrics = {}
        folder = previous/f'horizon_{horizon:02d}/old52'; folder.mkdir(parents=True)
        for part in probe.PARTITIONS:
            origins, destinations = probe.eligible_pairs(data, part, horizon)
            truth = control_values(data['z_target'][destinations]).astype(np.float64)
            prev = control_values(data['z_prev'][origins]).astype(np.float64)
            pred = prev.copy(); error = pred-truth
            path = folder/f'{part}_predictions.npz'
            np.savez_compressed(path, indices=origins, destination_indices=destinations,
                time_ns=data['time_ns'][origins], destination_time_ns=data['time_ns'][destinations],
                truth=truth, origin_previous=prev, pred=pred, error=error)
            split_metrics[part] = {'predictions_sha256': probe._sha(path)}
        prior['horizons'][str(horizon)] = {'methods': {'old52': {'split_metrics': split_metrics}}}
    (previous/'results.json').write_text(json.dumps(prior))
    rep = {'base_config': 'base.json', 'embeddings_file': 'embeddings.npz', 'quality_file': 'quality.npz',
           'encoder_manifest': 'encoder.json', 'output_dir': 'previous'}
    (tmp_path/'representation.json').write_text(json.dumps(rep))
    cfg = {'representation_config': 'representation.json', 'output_dir': 'new', 'bootstrap_draws': 16}
    cfg_path = tmp_path/'new.json'; cfg_path.write_text(json.dumps(cfg))
    base = {'diagnostics': {'bootstrap_draws': 16, 'bootstrap_seed': 9, 'confidence_level': .95}}
    monkeypatch.setattr(probe, 'load_study', lambda _: (base, data, {}, variants, {'null_donor_sample_index': donors}, descriptor))
    original_pca = probe.fit_capture_pca
    def checked_pca(*args, **kwargs):
        assert (tmp_path/'new/probe/protocol.json').exists()
        return original_pca(*args, **kwargs)
    monkeypatch.setattr(probe, 'fit_capture_pca', checked_pca)
    result = probe.run_utilization_probe(cfg_path)
    assert result['status'] == 'completed'
    output = tmp_path/'new/probe'
    done = json.loads((output/'fitting_completed.json').read_text())
    assert done['selected_fits'] == 33 and done['candidate_alpha_solves'] == 165
    features = probe._archive(output/'prepared_capture_features.npz')
    with threadpool_limits(limits=1):
        for horizon in probe.HORIZONS:
            hr = result['horizons'][str(horizon)]
            assert len(hr['methods']) == 13
            assert hr['methods']['matched_null']['visual_dimension'] == hr['methods']['adaptive_rgb']['visual_dimension']
            assert hr['methods']['matched_null']['rho'] == hr['methods']['adaptive_rgb']['rho']
            for method, row in hr['methods'].items():
                if method == 'old52_reference':
                    continue
                folder = output/f'horizon_{horizon:02d}'
                fitted = probe._archive(folder/row.get('selected_candidate', method)/'ridge_weights.npz')
                for part in probe.PARTITIONS:
                    path = folder/method/f'{part}_predictions.npz'
                    saved = probe._archive(path)
                    design = probe.origin_design(data, variants, features, row['visual_dimension'], saved['indices'], row['null'])
                    replay = apply_direct_ridge(fitted, design, saved['origin_previous'])
                    np.testing.assert_array_equal(replay, saved['pred'])
                    assert path.stat().st_mtime >= done['completed_unix']
            assert 'adaptive_rgb_vs_old52_reference' in hr['comparisons']
            assert 'adaptive_rgb_vs_matched_null' in hr['comparisons']
    with pytest.raises(FileExistsError, match='immutable'):
        probe.run_utilization_probe(cfg_path)
