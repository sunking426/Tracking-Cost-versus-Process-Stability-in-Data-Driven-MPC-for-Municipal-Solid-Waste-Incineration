import numpy as np
import pytest
from threadpoolctl import threadpool_limits

from mswi_experiments.data import MINUTE_NS
from mswi_experiments.numeric_baselines import linear_increment, numeric_features
from mswi_experiments.ridge_rgb_residual_data import (
    assemble_design, fit_oof_predictions, forward_folds, prepare_data,
)


def sample_data(n=420):
    rng = np.random.default_rng(82)
    time = (np.arange(n, dtype=np.int64) + 50) * MINUTE_NS
    u = rng.normal(size=(n, 11, 8))
    z = rng.normal(size=(n, 10, 9))
    delta = .2 * u[:, -1, :1] + .15 * z[:, -1] + rng.normal(scale=.05, size=(n, 9))
    return {'time_ns': time, 'source_start_ns': time - 10 * MINUTE_NS,
            'source_end_ns': time + MINUTE_NS, 'train_idx': np.arange(300, dtype=np.int64),
            'val_idx': np.arange(300, 360, dtype=np.int64),
            'test_idx': np.arange(360, n, dtype=np.int64),
            'u_hist': u, 'z_hist': z, 'z_prev': z[:, -1].copy(),
            'z_target': z[:, -1] + delta}


def test_forward_folds_use_full_source_ranges_not_only_target_time():
    data = sample_data()
    # An old image makes this one row's source earlier than a fixed ten-minute purge.
    data['source_start_ns'][139] = data['time_ns'][119]
    folds = forward_folds(data)
    assert len(folds) == 3
    assert [f['cut_time_ns'] for f in folds] == [int(data['time_ns'][i]) for i in (120, 180, 240)]
    assert 139 not in folds[0]['prediction_indices']
    seen = []
    for fold in folds:
        fit, pred = fold['fit_indices'], fold['prediction_indices']
        assert np.max(data['source_end_ns'][fit]) < np.min(data['source_start_ns'][pred])
        assert set(fit).isdisjoint(pred)
        assert set(fit).issubset(data['train_idx'])
        assert set(pred).issubset(data['train_idx'])
        assert fold['fit_rows_removed_by_source_purge'] == 1
        assert fold['prediction_rows_removed_by_source_purge'] >= 11
        seen.extend(pred.tolist())
    assert len(seen) == len(set(seen))
    assert seen[-1] == 299


@pytest.mark.parametrize('fault', ['fraction', 'bad_time', 'bad_range', 'empty_pred', 'duplicate_train'])
def test_forward_fold_invalid_inputs_fail(fault):
    data = sample_data()
    kwargs = {}
    if fault == 'fraction':
        kwargs['fractions'] = [.5, .7, .9, 1]
    elif fault == 'bad_time':
        data['time_ns'][10] = data['time_ns'][9]
    elif fault == 'bad_range':
        data['source_start_ns'][10] = data['time_ns'][10] + 1
    elif fault == 'empty_pred':
        data['source_start_ns'][:] = 0
    else:
        data['train_idx'][2] = 1
    with pytest.raises(ValueError):
        forward_folds(data, **kwargs)


def test_oof_labels_cannot_change_their_generating_ridge(tmp_path):
    data = sample_data()
    altered = {key: value.copy() for key, value in data.items()}
    # All later outcomes may be changed, but the first fitted model must be identical.
    altered['z_target'][120:] += 5000
    with threadpool_limits(limits=1):
        idx, pred, ids, records = fit_oof_predictions(data, tmp_path / 'a')
        idx2, pred2, _, _ = fit_oof_predictions(altered, tmp_path / 'b')
    np.testing.assert_array_equal(idx, idx2)
    np.testing.assert_array_equal(pred[ids == 1], pred2[ids == 1])
    with np.load(tmp_path / 'a/fold_01/model.npz') as a, np.load(tmp_path / 'b/fold_01/model.npz') as b:
        for key in a.files:
            np.testing.assert_array_equal(a[key], b[key])
    assert records[0]['parameter_selection'].startswith('none')


def test_oof_saved_weights_replay_and_scale_only_fit_rows(tmp_path):
    data = sample_data()
    with threadpool_limits(limits=1):
        rows, preds, fold_ids, records = fit_oof_predictions(data, tmp_path)
    x = numeric_features(data)
    for fold, record in zip(forward_folds(data), records):
        number = fold['fold']
        with np.load(tmp_path / f'fold_{number:02d}/model.npz') as archive:
            weights = {key: archive[key] for key in archive.files}
        fit, rows_f = fold['fit_indices'], fold['prediction_indices']
        np.testing.assert_allclose(weights['x_mean'], x[fit].mean(axis=0), rtol=0, atol=1e-14)
        delta = data['z_target'][fit] - data['z_prev'][fit]
        np.testing.assert_allclose(weights['delta_scale'], delta.std(axis=0), rtol=0, atol=1e-14)
        replay = data['z_prev'][rows_f] + linear_increment(weights, x[rows_f])
        np.testing.assert_array_equal(rows[fold_ids == number], rows_f)
        np.testing.assert_array_equal(preds[fold_ids == number], replay)
        assert record['alpha'] == 100


def test_oof_does_not_refit_existing_outputs(tmp_path):
    data = sample_data()
    with threadpool_limits(limits=1):
        fit_oof_predictions(data, tmp_path)
        with pytest.raises(FileExistsError):
            fit_oof_predictions(data, tmp_path)


def test_preparation_existing_archive_fails_before_input_load(tmp_path):
    (tmp_path / 'prepared.npz').write_bytes(b'unchanged')
    with pytest.raises(FileExistsError):
        prepare_data({'project_root': '/no/such/project'}, tmp_path)
    assert (tmp_path / 'prepared.npz').read_bytes() == b'unchanged'


def test_null_design_changes_rgb_only_and_preserves_order():
    data = sample_data()
    n = len(data['time_ns'])
    rng = np.random.default_rng(54)
    timing, quality, rgb = [rng.normal(size=(n, width)) for width in (4, 12, 32)]
    donors = np.arange(n - 1, -1, -1)
    aligned, null = assemble_design(data, timing, quality, rgb, donors)
    assert aligned.shape == null.shape == (n, 226)
    np.testing.assert_array_equal(aligned[:, :178], numeric_features(data))
    np.testing.assert_array_equal(aligned[:, 178:182], timing)
    np.testing.assert_array_equal(aligned[:, 182:194], quality)
    np.testing.assert_array_equal(aligned[:, :194], null[:, :194])
    np.testing.assert_array_equal(null[:, 194:], rgb[donors])
    np.testing.assert_array_equal(aligned[:, 194:], rgb)


def test_design_rejects_wrong_feature_contract():
    data = sample_data()
    n = len(data['time_ns'])
    with pytest.raises(ValueError, match='shape'):
        assemble_design(data, np.zeros((n, 4)), np.zeros((n, 12)), np.zeros((n, 31)), np.arange(n))
    with pytest.raises(ValueError, match='donor'):
        assemble_design(data, np.zeros((n, 4)), np.zeros((n, 12)), np.zeros((n, 32)), np.full(n, n))


def test_fixed_ridge_alpha_cannot_be_tuned_in_preparation(tmp_path):
    with pytest.raises(ValueError, match='fixed'):
        fit_oof_predictions(sample_data(), tmp_path, alpha=10)
