"""Geometry ablation contracts: training scope, fair reuse and frozen evaluation."""
import csv
import json
from types import SimpleNamespace

import numpy as np
import pytest
from threadpoolctl import threadpool_limits

from mswi_experiments import rgb_geometry_study as study
from mswi_experiments.numeric_baselines import sha256, write_json


def old_features(seed=32):
    rng=np.random.default_rng(seed)
    previous={}; scores={g:rng.normal(size=(40,32)) for g in study.GEOMETRIES}
    for split,n,offset in [('train',30,0),('val',12,30),('test',12,42)]:
        quality=rng.normal(size=(n,235)); fresh=np.arange(n)%40; stale=(fresh+9)%40
        previous.update({split+'_indices':np.arange(offset,offset+n),
            split+'_time_ns':(1000+np.arange(offset,offset+n))*60_000_000_000,
            split+'_numeric':quality[:,:219],split+'_quality':quality,
            split+'_rgb':np.column_stack((quality,scores['A'][fresh])),
            split+'_stale':np.column_stack((quality,scores['A'][stale])),
            split+'_current_capture_index':fresh,split+'_stale_capture_index':stale,
            split+'_thermal_change':(np.arange(n)%2).astype(np.int8),
            split+'_action_change':((np.arange(n)//2)%2).astype(np.int8)})
    return previous,scores


def test_pca_uses_unique_training_captures_and_no_heldout_fitting():
    rng=np.random.default_rng(8); features=rng.normal(size=(30,8))
    mapping=np.array([0,0,1,2,2,3,4,5,6,7,8,9,10,11,12,13,20,21,29])
    train=np.arange(15)
    original,score=study.fit_capture_pca(features,mapping,train,components=4)
    changed=features.copy(); changed[13:]+=10000
    updated,_=study.fit_capture_pca(changed,mapping,train,components=4)
    assert np.array_equal(original['train_capture_indices'],np.arange(13))
    for key in original:
        assert np.array_equal(original[key],updated[key]),key
    np.testing.assert_allclose(score,(features-original['mean'])@original['components'].T,rtol=0,atol=0)
    # Repeating a training capture cannot give it additional PCA weight.
    repeated,_=study.fit_capture_pca(features,np.repeat(mapping,3),np.arange(45),components=4)
    for key in original: assert np.array_equal(original[key],repeated[key])


def test_geometry_and_stale_change_only_the_rgb_tail():
    previous,scores=old_features(); current=study.assemble_classification(previous,scores)
    for split in study.SPLITS:
        for geometry in study.GEOMETRIES:
            for suffix,key in [('', 'current_capture_index'),('_stale','stale_capture_index')]:
                actual=current[split+'_'+geometry+suffix]
                assert np.array_equal(actual[:,:235],previous[split+'_quality'])
                assert np.array_equal(actual[:,235:],scores[geometry][previous[split+'_'+key]])
        for key in ('indices','time_ns',*study.TASKS):
            assert np.array_equal(current[split+'_'+key],previous[split+'_'+key])


@pytest.mark.parametrize('method,old',[('numeric','numeric'),('quality','quality'),('A','rgb'),('A_stale','stale')])
def test_reuse_requires_exact_designs_on_every_split(method,old):
    previous,scores=old_features(); current=study.assemble_classification(previous,scores)
    assert study.assert_reuse_equivalence(current,previous,method,old)['all_splits_exact']
    for split in study.SPLITS:
        key=split+'_'+method; original=current[key]
        current[key]=original.copy(); current[key][0,-1]+=1e-8
        with pytest.raises(ValueError,match='reuse design differs'):
            study.assert_reuse_equivalence(current,previous,method,old)
        current[key]=original
    current['test_thermal_change']=1-current['test_thermal_change']
    with pytest.raises(ValueError,match='reuse rows/labels differ'):
        study.assert_reuse_equivalence(current,previous,method,old)


def test_geometry_selection_fixed_ties_and_validation_only():
    rows=[{'method':g,'selected':{'val_log_loss':.4,'test_AP':float(i)}} for i,g in enumerate(study.GEOMETRIES)]
    assert study.select_geometry(rows,'val_log_loss')=='A'
    rows[3]['selected']['val_log_loss']=.4-5e-13
    assert study.select_geometry(rows,'val_log_loss')=='A'
    rows[2]['selected']['val_log_loss']=.39
    assert study.select_geometry(rows,'val_log_loss')=='C'
    for r in rows:r['selected']['test_AP']=100-r['selected']['test_AP']
    assert study.select_geometry(rows,'val_log_loss')=='C'
    with pytest.raises(ValueError,match='exactly A'):
        study.select_geometry(rows[:3],'val_log_loss')


def fixture_state(tmp_path):
    project=tmp_path/'project';out=project/'run';prior=project/'prior';ridge_study=project/'ridge'
    for folder in (out,prior,ridge_study,project/'mswi_experiments'):folder.mkdir(parents=True,exist_ok=True)
    for name in study.SNAPSHOT_NAMES:(project/'mswi_experiments'/name).write_text('# synthetic fingerprint\n')
    cfg={'source_run':'source','classification_study':'prior','current_predictor':'current_predictor.json',
         'output_dir':'run','C_grid':study.C_GRID,'alpha_grid':study.ALPHA_GRID,'alarm_quantile':.9,'threads':1}
    previous,scores=old_features();classification=study.assemble_classification(previous,scores)
    old_rows=[]
    with threadpool_limits(limits=1):
        for task in study.TASKS:
            for variant in ('numeric','quality','rgb','stale'):
                weights,candidates,chosen=study.fit_candidates(previous['train_'+variant],previous['train_'+task],
                    previous['val_'+variant],previous['val_'+task],[.001],alarm_quantile=.9)
                name=f'{task}_{variant}.npz';study.save_model(prior/name,weights)
                old_rows.append({'task':task,'variant':variant,'selected':chosen,'candidates':candidates,'model_path':name})
    rng=np.random.default_rng(19);n=54
    data={'u_hist':rng.normal(size=(n,11,8)),'z_hist':rng.normal(size=(n,10,9))}
    numeric=study.numeric_features(data);quality=np.column_stack((numeric,rng.normal(size=(n,16))))
    prev=data['z_hist'][:,-1];truth=prev+rng.normal(size=(n,9))
    reg={'numeric':numeric,'quality':quality,'z_prev':prev,'z_target':truth,'delta_scale':np.ones(9),
         'time_ns':(np.arange(n)+1000)*60_000_000_000,
         'train_indices':np.arange(30),'val_indices':np.arange(30,42),'test_indices':np.arange(42,54)}
    for g in study.GEOMETRIES:reg[g]=np.column_stack((quality,rng.normal(size=(n,32))))
    with threadpool_limits(limits=1):
        w,candidates,chosen=study.fit_linear_candidates(numeric,truth-prev,prev,truth,reg['train_indices'],reg['val_indices'],np.ones(9),[100.])
    checkpoint=ridge_study/'model.npz';np.savez_compressed(checkpoint,**w)
    write_json(ridge_study/'selection.json',{'models':[{'id':'ridge','selected_kind':'ridge','selected_alpha':100.,
                                                      'val_normalized_mse':chosen['val_normalized_mse']}]})
    with (ridge_study/'selection_candidates.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=['model_id','kind','alpha','val_normalized_mse','selected'])
        writer.writeheader();writer.writerow({'model_id':'ridge',**chosen,'selected':True})
    (out/'preparation_stub').write_bytes(b'fixed')
    write_json(out/'prepare_frozen.json',{'status':'complete','files':{'preparation_stub':sha256(out/'preparation_stub')}})
    write_json(out/'input_hashes.json',{})
    state=(cfg,project,out,data,classification,reg)
    return state,(prior,previous,{'models':old_rows},[]),({},checkpoint,ridge_study,SimpleNamespace(weights=w))


def fit_fixture(monkeypatch,fixture):
    state,prior,ridge=fixture
    monkeypatch.setattr(study,'load_prepared',lambda _:state)
    monkeypatch.setattr(study,'_load_previous',lambda *_:prior)
    monkeypatch.setattr(study,'resolve_predictor',lambda *_:ridge)
    with threadpool_limits(limits=1):study.fit('unused.json')
    return state


def test_complete_stage_freezes_twenty_models_and_predicts_forty_archives(tmp_path,monkeypatch):
    fixture=fixture_state(tmp_path);state=fit_fixture(monkeypatch,fixture)
    out,classification,reg=state[2],state[4],state[5]
    selected=json.loads((out/'selection.json').read_text())
    assert len(selected['classification'])==14 and len(selected['regression'])==6
    assert selected['selected_regression_geometry'] in study.GEOMETRIES
    for task in study.TASKS:
        rows=[r for r in selected['classification'] if r['task']==task]
        assert selected['selected_geometry'][task]==study.select_geometry(rows,'val_log_loss')
        assert next(r for r in rows if r['method']=='selected_stale')['geometry']==selected['selected_geometry'][task]
    for r in selected['classification']+selected['regression']:
        if r['reused']:assert sha256(out/r['model_path'])==sha256(r['source_model'])
    monkeypatch.setattr(study,'fit_candidates',lambda *a,**k:pytest.fail('prediction cannot fit'))
    monkeypatch.setattr(study,'fit_linear_candidates',lambda *a,**k:pytest.fail('prediction cannot fit'))
    with threadpool_limits(limits=1):study.predict('unused.json')
    manifest=json.loads((out/'predictions_manifest.json').read_text())
    assert len(manifest['files'])==40
    assert sum(r['kind']=='classification' for r in manifest['files'])==28
    for row in selected['classification']:
        model=study.load_model(out/row['model_path'])
        design=row['geometry']+'_stale' if row['method']=='selected_stale' else row['method']
        for split in ('val','test'):
            saved=study.archive(out/f"classification/{split}/{row['task']}_{row['method']}.npz")
            expected=study.predict_proba(model,classification[split+'_'+design])
            np.testing.assert_allclose(saved['probability'],expected,rtol=0,atol=1e-14)
            assert float(saved['threshold'])==float(model['threshold'])
            assert np.array_equal(saved['y'],classification[split+'_'+row['task']])
    for row in selected['regression']:
        model=study.archive(out/row['model_path'])
        for split in ('val','test'):
            indices=reg[split+'_indices'];saved=study.archive(out/f"regression/{split}/{row['method']}.npz")
            expected=reg['z_prev'][indices]+study.linear_increment(model,reg[row['method']][indices])
            np.testing.assert_allclose(saved['pred_cv'],expected,rtol=0,atol=1e-14)
            assert np.array_equal(saved['truth_cv'],reg['z_target'][indices])
    with pytest.raises(FileExistsError,match='already completed'):study.predict('unused.json')


def test_fit_does_not_use_heldout_labels_or_geometry_features(tmp_path,monkeypatch):
    first=fixture_state(tmp_path/'first');second=fixture_state(tmp_path/'second')
    for task in study.TASKS:
        second[0][4]['test_'+task]=1-second[0][4]['test_'+task]
        second[1][1]['test_'+task]=1-second[1][1]['test_'+task]
    # A/baseline designs deliberately remain fixed for exact-reuse checking.
    for g in ('B','C','D'):
        second[0][4]['test_'+g]+=10000
        second[0][4]['test_'+g+'_stale']-=10000
        second[0][5][g][second[0][5]['test_indices']]+=10000
    second[0][5]['z_target'][second[0][5]['test_indices']]+=10000
    a=fit_fixture(monkeypatch,first);b=fit_fixture(monkeypatch,second)
    sa=json.loads((a[2]/'selection.json').read_text());sb=json.loads((b[2]/'selection.json').read_text())
    assert sa['selected_geometry']==sb['selected_geometry']
    assert sa['selected_regression_geometry']==sb['selected_regression_geometry']
    for left,right in zip(sa['classification']+sa['regression'],sb['classification']+sb['regression']):
        assert left['selected']==right['selected']
        wa,wb=study.archive(a[2]/left['model_path']),study.archive(b[2]/right['model_path'])
        assert all(np.array_equal(wa[k],wb[k]) for k in wa)


@pytest.mark.parametrize('tamper',['model','source','selection'])
def test_prediction_rejects_changed_frozen_selection_or_code(tmp_path,monkeypatch,tamper):
    state=fit_fixture(monkeypatch,fixture_state(tmp_path));out=state[2]
    path={'model':out/'models/thermal_change_numeric.npz','source':state[1]/'mswi_experiments/rgb_geometry_study.py',
          'selection':out/'selection.json'}[tamper]
    with path.open('ab') as f:f.write(b'changed')
    with pytest.raises(ValueError,match='frozen input changed'):study.predict('unused.json')
    assert not (out/'classification').exists()
