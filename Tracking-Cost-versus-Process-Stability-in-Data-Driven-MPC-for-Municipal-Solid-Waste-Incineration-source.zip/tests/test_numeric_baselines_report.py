"""Checks for matched numerical forecasts, metric meaning and complete exports."""
import hashlib
import json
from pathlib import Path

import numpy as np
import pytest

from mswi_experiments.numeric_baselines_report import (
    DAY_NS, METHODS, error_components, load_completed_study, metric_summary,
    paired_endpoints, summarize_study,
)
from mswi_experiments.visual_diagnostics_statistics import paired_block_interval


def _json(path, value):
    Path(path).write_text(json.dumps(value))


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def synthetic_study(root):
    root = Path(root)
    config = {"diagnostics": {"seeds": [11, 23, 37], "bootstrap_draws": 100,
                              "bootstrap_seed": 20261104, "confidence_level": .95}}
    _json(root/"config.json", config)
    _json(root/"stats.json", {"delta_scale": list(range(1, 10)),
                             "cv_names": [f"cv{j}" for j in range(9)]})
    _json(root/"protocol.json", {"scope": "synthetic test fixture"})
    models = [{"id": m, "method": m, "seed": None} for m in METHODS[:2]]
    models += [{"id": f"{m}_seed_{s}", "method": m, "seed": s}
               for m in METHODS[2:] for s in config["diagnostics"]["seeds"]]
    _json(root/"selection.json", {"models": models})
    rng = np.random.default_rng(904)
    manifest = {"status": "complete", "selection_sha256": _sha(root/"selection.json"), "files": []}
    for split_id, split in enumerate(("train", "val", "test")):
        n = 8
        y = rng.normal(size=(n, 9))
        times = (20000+split_id*3+np.arange(n)//4)*DAY_NS + np.arange(n)*60_000_000_000
        for position, model in enumerate(models):
            pred = y + (position+1)*rng.normal(size=(n, 9))*.1
            relative = f"predictions/{model['id']}/{split}.npz"
            path = root/relative; path.parent.mkdir(parents=True, exist_ok=True)
            np.savez_compressed(path, indices=split_id*10+np.arange(n), time_ns=times,
                                y=y, pred=pred, error=pred-y)
            manifest["files"].append({"model_id": model["id"], "method": model["method"],
                "seed": model["seed"], "split": split, "path": relative, "sha256": _sha(path),
                "n": n, "shape": [n, 9]})
    _json(root/"predictions_manifest.json", manifest)
    return root


def test_temperature_aggregates_channels_before_absolute_error():
    truth = np.zeros((2, 9))
    prediction = truth.copy()
    prediction[:, :6] = [10, -10, 10, -10, 10, -10]
    metric = metric_summary(prediction[None], truth, np.ones(9))
    assert metric["physical_mae"][0] == 0.
    assert metric["channel_mae"][:6] == [10.]*6
    assert metric["normalized_mse"] == pytest.approx(600/9)


def test_primary_loss_uses_fixed_channel_scale_and_not_residual_scale():
    truth = np.zeros((2, 9)); pred = np.ones((1, 2, 9))
    scale = np.arange(1., 10.)
    squared, _, _ = error_components(pred, truth, scale)
    assert squared.mean() == pytest.approx(sum(1/j**2 for j in range(1, 10))/9)
    with pytest.raises(ValueError, match="positive"):
        error_components(pred, truth, np.zeros(9))


def test_metrics_average_fits_not_predictions():
    truth = np.zeros((2, 9))
    predictions = np.stack((np.ones((2, 9)), -np.ones((2, 9))))
    result = metric_summary(predictions, truth, np.ones(9))
    assert result["normalized_mse"] == 1.
    assert result["physical_mae"] == [1.]*4
    assert result["channel_rmse"] == [1.]*9


def test_deterministic_pairing_broadcasts_without_changing_deterministic_pair_axis():
    truth = np.zeros((4, 9)); scale = np.ones(9)
    deterministic = np.ones((1, 4, 9))*3
    stochastic = np.stack([np.ones((4, 9))*x for x in (1, 2, 4)])
    difference = paired_endpoints(deterministic, stochastic, truth, scale)
    assert difference.shape == (3, 4, 5)
    np.testing.assert_allclose(difference[:, 0, 0], [8, 5, -7])
    np.testing.assert_allclose(difference[:, 0, 1:], np.repeat([[2], [1], [-1]], 4, axis=1))
    assert paired_endpoints(deterministic, deterministic, truth, scale).shape[0] == 1
    with pytest.raises(ValueError, match="matched seed"):
        paired_endpoints(stochastic[:2], stochastic, truth, scale)


def test_unequal_calendar_blocks_keep_sample_weighted_estimand():
    values = np.array([0., 0., 0., 8.])[None, :, None]
    interval = paired_block_interval(values, np.array([1, 1, 1, 2]), draws=1000, seed=7)
    assert interval["difference"] == [2.]
    assert interval["block_sample_counts"] == [3, 1]
    assert interval["time_blocks"] == 2
    assert interval["ci_lower"][0] <= 2 <= interval["ci_upper"][0]


def test_complete_readout_reports_all_fits_splits_channels_and_six_comparisons(tmp_path):
    root = synthetic_study(tmp_path)
    result = summarize_study(root)
    assert len(result["prediction_checks"]) == 24
    assert len(result["comparisons"]) == 6
    assert result["metrics"]["test"]["persistence"]["fits"] == 1
    assert result["metrics"]["test"]["gru"]["fits"] == 3
    assert result["comparisons"]["ridge_vs_persistence"]["training_seeds"] == 1
    assert result["comparisons"]["gru_vs_persistence"]["reference_fits"] == 1
    import csv
    counts = {name: len(list(csv.DictReader((root/"statistics"/name).open())))
              for name in ("overall.csv", "individual_fits.csv", "channels.csv", "per_day.csv", "comparisons.csv")}
    assert counts == {"overall.csv": 12, "individual_fits.csv": 24, "channels.csv": 324,
                      "per_day.csv": 24, "comparisons.csv": 30}


def test_hash_change_and_target_misalignment_are_rejected(tmp_path):
    root = synthetic_study(tmp_path)
    path = root/"predictions/ridge/test.npz"
    with np.load(path) as raw: values = {k: raw[k].copy() for k in raw.files}
    values["y"][0, 0] += .1
    values["error"] = values["pred"]-values["y"]
    np.savez_compressed(path, **values)
    with pytest.raises(ValueError, match="hash"):
        load_completed_study(root)
    manifest = json.loads((root/"predictions_manifest.json").read_text())
    next(r for r in manifest["files"] if r["path"] == str(path.relative_to(root)))["sha256"] = _sha(path)
    _json(root/"predictions_manifest.json", manifest)
    with pytest.raises(ValueError, match="identical observations"):
        load_completed_study(root)


def test_missing_fit_is_not_silently_omitted(tmp_path):
    root = synthetic_study(tmp_path)
    manifest = json.loads((root/"predictions_manifest.json").read_text())
    manifest["files"].pop()
    _json(root/"predictions_manifest.json", manifest)
    with pytest.raises(ValueError, match="complete unique"):
        load_completed_study(root)
