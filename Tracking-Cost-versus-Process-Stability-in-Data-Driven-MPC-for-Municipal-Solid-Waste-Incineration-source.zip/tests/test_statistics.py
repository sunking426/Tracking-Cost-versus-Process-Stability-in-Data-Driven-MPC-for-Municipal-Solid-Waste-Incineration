"""Analytical pairing, prefix and cluster-uncertainty contracts."""
import json

import numpy as np
import pytest

from mswi_experiments.statistics import (
    METRICS, episode_metrics, paired_bootstrap, run_paired_statistics,
)


def test_episode_outcomes_use_requested_prefix_and_real_denominators():
    rewards=-np.ones((2,50))
    cv=np.broadcast_to(np.array([1000.,-50.,32.,3.8]),(2,50,4)).copy()
    flags=np.zeros((2,50),bool)
    rewards[:,10:]=-10000
    cv[:,10:]+=10000
    flags[0,9]=True
    flags[1,10:]=True
    metrics=episode_metrics(rewards,cv,flags,10,[1000,-50,32,3.8])
    np.testing.assert_array_equal(metrics[:,0],[-10,-10])
    np.testing.assert_array_equal(metrics[:,1:5],np.zeros((2,4)))
    np.testing.assert_allclose(metrics[:,5],[.1,0])
    np.testing.assert_array_equal(metrics[:,6],[0,1])
    with pytest.raises(ValueError,match='prefix'):
        episode_metrics(rewards,cv,flags,51,[1000,-50,32,3.8])


def test_paired_bootstrap_retains_pairing_and_separates_seed_reset_factors():
    # An exact additive difference remains exact in every confidence interval.
    constant=np.broadcast_to(np.array([2.,-3.]),(5,9,2)).copy()
    fixed=paired_bootstrap(constant,draws=1000,seed=2026)
    for key in ('seed_only_ci95','reset_only_ci95','seed_reset_crossed_ci95'):
        np.testing.assert_array_equal(fixed[key],[[2,2],[-3,-3]])
    # Identical reset responses within each seed imply no reset uncertainty,
    # but policy-seed uncertainty must remain nonzero.
    data=np.broadcast_to(np.array([-6.,-2.,0.,3.,8.])[:,None,None],(5,9,1)).copy()
    result=paired_bootstrap(data,draws=1000,seed=2026)
    assert result['seed_only_ci95'][0][0]<result['seed_only_ci95'][0][1]
    np.testing.assert_allclose(result['reset_only_ci95'],[[.6,.6]])
    np.testing.assert_array_equal(result['seed_only_ci95'],result['seed_reset_crossed_ci95'])
    assert result==paired_bootstrap(data,draws=1000,seed=2026)


def saved_control(tmp_path,seeds=(11,23,37,53,71)):
    n,h=6,50
    starts=np.arange(n)+100
    times=np.arange(n,dtype=np.int64)*60_000_000_000+1_700_000_000_000_000_000
    result={'rl_seeds':list(seeds),'tracking_targets':[1000,-50,32,3.8],'results':{}}
    for method,policy_seeds in [('full_td3bc',seeds),('bc',(0,))]:
        files=[];metadata=[]
        for seed in policy_seeds:
            dest=tmp_path/method/f'seed_{seed}';dest.mkdir(parents=True)
            r=-np.ones((n,h))*(2 if method=='bc' else 1)
            c=np.broadcast_to(np.array([1000.,-50.,32.,3.8]),(n,h,4)).copy()
            v=np.zeros((n,h),bool)
            if method=='full_td3bc':c[...,0]+=seed/100
            np.savez_compressed(dest/'evaluation.npz',rewards=r,control=c,violation=v,
                                start_indices=starts,start_time_ns=times)
            files.append(str((dest/'evaluation.npz').relative_to(tmp_path)))
            metadata.append({'seed':seed})
        result['results'][method]={'label':method,'evaluation_files':files,'by_seed':metadata}
    (tmp_path/'results.json').write_text(json.dumps(result))
    return result


def test_saved_statistics_does_not_invent_static_training_runs(tmp_path):
    source=tmp_path/'control';source.mkdir()
    saved_control(source)
    out=tmp_path/'statistics'
    result=run_paired_statistics(source,out,
        {'rl':{'seeds':[11,23,37,53,71]},'statistics':{'bootstrap_draws':1000}},horizons=[10,50])
    assert result==json.loads((out/'paired_statistics.json').read_text())
    assert result['shared_reset_count']==6
    assert [b['reset_count'] for b in result['temporal_blocks']]==[2,2,2]
    assert 'previously inspected' in result['interpretation']
    for h in [10,50]:
        x=result['horizons'][str(h)]
        assert x['methods']['full_td3bc']['training_seed_count']==5
        assert x['methods']['bc']['training_seed_count']==0
        assert x['methods']['bc']['evaluated_policy_count']==1
        pair=x['comparisons'][0]
        assert pair['paired_seed_ids']==[11,23,37,53,71]
        assert pair['shared_reset_count']==6
        assert pair['mean_difference'][0]==h
        np.testing.assert_allclose(pair['seed_reset_crossed_ci95'][0],[h,h])
        for block in pair['blocks']:assert block['shared_reset_count']==2
    with np.load(out/'episode_metric_matrices.npz',allow_pickle=False) as raw:
        assert raw['h10_full_td3bc'].shape==(5,6,len(METRICS))
        assert raw['h10_bc'].shape==(1,6,len(METRICS))
    assert len((out/'paired_effects.csv').read_text().splitlines())==1+2*len(METRICS)


def test_statistics_rejects_missing_seed_or_unpaired_resets(tmp_path):
    source=tmp_path/'control';source.mkdir()
    result=saved_control(source,seeds=(11,23,37))
    with pytest.raises(ValueError,match='seeds differ'):
        run_paired_statistics(source,tmp_path/'out',{'rl':{'seeds':[11,23,37,53,71]}})
    path=source/result['results']['bc']['evaluation_files'][0]
    with np.load(path,allow_pickle=False) as raw:values={k:raw[k].copy() for k in raw.files}
    values['start_indices']=values['start_indices'][::-1]
    np.savez_compressed(path,**values)
    with pytest.raises(ValueError,match='identical ordered resets'):
        run_paired_statistics(source,tmp_path/'out')
