import csv
import json

import numpy as np
import pytest

from mswi_experiments.numeric_baselines import sha256, write_json
from mswi_experiments.rgb_control_diagnostic_models import binary_metrics
from mswi_experiments.rgb_control_diagnostic_report import archive
from mswi_experiments.rgb_geometry_report import (
    CLASS_METHODS, METHODS, TASKS, build_report, declared_contrasts,
    load_study, summarize, validate_regression_archive,
)


def fixture_study(root):
    """Validation prefers B, while the best test classifier is D."""
    n = 20
    cfg = dict(alarm_quantile=.9, bootstrap_draws=30, bootstrap_seed=17,
               confidence_level=.95, primary_task='thermal_change',
               primary_metric='average_precision')
    write_json(root/'config.json',cfg)
    write_json(root/'stats.json',{'delta_scale':[1.]*9})
    write_json(root/'protocol.json',{'limits':['Previously inspected test period.']})
    write_json(root/'preparation.json',{'pca':{g:{'explained_variance_fraction':.75} for g in 'ABCD'}})
    cls = {}
    time_ns = np.arange(2*n,dtype=np.int64)*10*3600*1_000_000_000
    truth = np.zeros((2*n,9))
    reg = {'time_ns':time_ns,'z_target':truth,'delta_scale':np.ones(9)}
    labels = np.tile([0,1],n//2)
    for split,indices in [('val',np.arange(n)),('test',np.arange(n,2*n))]:
        cls[split+'_indices'] = indices
        cls[split+'_time_ns'] = time_ns[indices]
        for task in TASKS:
            cls[split+'_'+task] = labels
        reg[split+'_indices'] = indices
    np.savez_compressed(root/'classification_prepared.npz',**cls)
    np.savez_compressed(root/'regression_prepared.npz',**reg)
    (root/'models').mkdir()
    selected_class,selected_reg,predictions = [],[],[]
    for task in TASKS:
        for method in CLASS_METHODS:
            val_correct = .9 if method=='B' else .7 if method=='selected_stale' else .6
            val_probability = np.where(labels==1,val_correct,1-val_correct)
            threshold = float(np.quantile(val_probability,.9,method='linear'))
            model_path = f'models/{task}_{method}.npz'
            np.savez_compressed(root/model_path,threshold=np.asarray(threshold))
            selected_class.append({'task':task,'method':method,'model_path':model_path,
                'selected':{'val_log_loss':binary_metrics(labels,val_probability,threshold)['log_loss']},
                'geometry':'B' if method=='selected_stale' else method if method in 'ABCD' else None,
                'alarm_threshold':threshold})
            for split in ('val','test'):
                test_correct = .9 if method=='D' else .4 if method=='B' else .6
                probability = val_probability if split=='val' else np.where(labels==1,test_correct,1-test_correct)
                path = f'classification/{split}/{task}_{method}.npz'
                (root/path).parent.mkdir(parents=True,exist_ok=True)
                np.savez_compressed(root/path,indices=cls[split+'_indices'],time_ns=cls[split+'_time_ns'],
                    y=labels,probability=probability,alarm=(probability>=threshold).astype(int),
                    threshold=np.asarray(threshold))
                predictions.append({'kind':'classification','split':split,'task':task,
                                    'method':method,'path':path,'sha256':sha256(root/path)})
    for method in METHODS:
        error = {'A':.4,'B':.2,'C':.3,'D':.5}.get(method,.6)
        model_path = f'models/regression_{method}.npz'
        np.savez_compressed(root/model_path,delta_scale=np.ones(9))
        selected_reg.append({'method':method,'model_path':model_path,
                             'selected':{'val_normalized_mse':error**2}})
        for split in ('val','test'):
            path = f'regression/{split}/{method}.npz'
            (root/path).parent.mkdir(parents=True,exist_ok=True)
            indices = reg[split+'_indices']
            residual = error if split=='val' else .1 if method=='D' else .5
            np.savez_compressed(root/path,indices=indices,time_ns=time_ns[indices],
                                truth_cv=truth[indices],pred_cv=truth[indices]+residual)
            predictions.append({'kind':'regression','split':split,'method':method,
                                'path':path,'sha256':sha256(root/path)})
    write_json(root/'selection.json',{'status':'complete','classification':selected_class,
        'regression':selected_reg,'selected_geometry':{t:'B' for t in TASKS},
        'selected_regression_geometry':'B'})
    source = root/'source.py';source.write_text('# frozen fixture source\n')
    names = ['config.json','stats.json','protocol.json','preparation.json',
             'classification_prepared.npz','regression_prepared.npz','selection.json']
    names += [r['model_path'] for r in selected_class+selected_reg]
    write_json(root/'selection_frozen.json',{'status':'complete',
        'files':{p:sha256(root/p) for p in names},'source_code_hashes':{str(source):sha256(source)}})
    write_json(root/'predictions_manifest.json',{'status':'complete','files':predictions,
        'selection_sha256':sha256(root/'selection.json'),
        'selection_frozen_sha256':sha256(root/'selection_frozen.json')})
    return root


@pytest.fixture
def study(tmp_path):
    return fixture_study(tmp_path)


def alter_prediction(root,path,change):
    row = archive(root/path);change(row)
    np.savez_compressed(root/path,**row)
    manifest = json.loads((root/'predictions_manifest.json').read_text())
    for item in manifest['files']:
        if item['path']==path:
            item['sha256'] = sha256(root/path)
    write_json(root/'predictions_manifest.json',manifest)


def test_primary_geometry_is_validation_selected_despite_better_test_group(study):
    result = summarize(study)
    assert len(result['prediction_checks']) == 40
    assert result['selected_geometry']['thermal_change'] == 'B'
    assert result['selected_regression_geometry'] == 'B'
    assert result['primary_result']['candidate'] == 'B'
    test = result['classification']['test']['thermal_change']
    assert test['D']['average_precision'] > test['B']['average_precision']
    assert result['primary_result']['difference'][0] < 0
    assert result['regression']['test']['D']['normalized_mse'] < result['regression']['test']['B']['normalized_mse']
    expected_rows = {'classification_metrics':28,'classification_comparisons':54,
                     'regression_metrics':12,'regression_channels':108,'regression_comparisons':40}
    for name,count in expected_rows.items():
        with (study/'statistics'/f'{name}.csv').open() as stream:
            assert len(list(csv.DictReader(stream))) == count


def test_duplicate_declared_contrasts_are_retained():
    contrasts = declared_contrasts('D')
    assert len(contrasts) == 9
    assert [row[1:] for row in contrasts].count(('A','D')) == 2
    assert ('selected_vs_A','A','A') in declared_contrasts('A')


def test_saved_alarm_must_match_threshold(study):
    def change(row):
        row['alarm'][0] = 1-row['alarm'][0]
    alter_prediction(study,'classification/test/thermal_change_B.npz',change)
    with pytest.raises(ValueError,match='alarm differs'):
        load_study(study)


def test_changed_threshold_cannot_replace_validation_threshold(study):
    def change(row):
        row['threshold'] = np.asarray(.1)
        row['alarm'] = (row['probability']>=.1).astype(int)
    alter_prediction(study,'classification/test/thermal_change_B.npz',change)
    with pytest.raises(ValueError,match='frozen validation selection'):
        load_study(study)


@pytest.mark.parametrize('kind,path,field',[
    ('classification','classification/test/thermal_change_C.npz','y'),
    ('regression','regression/test/C.npz','truth_cv'),
])
def test_hash_consistent_targets_still_must_match_prepared_data(study,kind,path,field):
    def change(row):
        if field=='y':
            row[field][0] = 1-row[field][0]
        else:
            row[field][0,0] += 1
    alter_prediction(study,path,change)
    with pytest.raises(ValueError,match='prepared observed'):
        load_study(study)


def test_regression_alignment_is_checked_even_with_updated_hash(study):
    def change(row):
        row['time_ns'] = row['time_ns']+1
    alter_prediction(study,'regression/test/A.npz',change)
    with pytest.raises(ValueError,match='prepared identity'):
        load_study(study)


def test_duplicate_archive_does_not_hide_missing_archive(study):
    manifest = json.loads((study/'predictions_manifest.json').read_text())
    manifest['files'][-1] = manifest['files'][0]
    write_json(study/'predictions_manifest.json',manifest)
    with pytest.raises(ValueError,match='inventory/hash'):
        load_study(study)


def test_prediction_bytes_must_match_manifest(study):
    path = study/'classification/test/thermal_change_A.npz'
    path.write_bytes(path.read_bytes()+b'tamper')
    with pytest.raises(ValueError,match='inventory/hash'):
        load_study(study)


def test_frozen_model_bytes_are_verified(study):
    (study/'models/thermal_change_A.npz').write_bytes(b'changed model')
    with pytest.raises(ValueError,match='frozen artifact changed'):
        load_study(study)


def test_frozen_source_bytes_are_verified(study):
    (study/'source.py').write_text('# changed\n')
    with pytest.raises(ValueError,match='frozen source changed'):
        load_study(study)


def test_rehashed_test_based_selection_is_rejected(study):
    selection = json.loads((study/'selection.json').read_text())
    selection['selected_geometry']['thermal_change'] = 'D'
    write_json(study/'selection.json',selection)
    frozen = json.loads((study/'selection_frozen.json').read_text())
    frozen['files']['selection.json'] = sha256(study/'selection.json')
    write_json(study/'selection_frozen.json',frozen)
    manifest = json.loads((study/'predictions_manifest.json').read_text())
    manifest['selection_sha256'] = sha256(study/'selection.json')
    manifest['selection_frozen_sha256'] = sha256(study/'selection_frozen.json')
    write_json(study/'predictions_manifest.json',manifest)
    with pytest.raises(ValueError,match='differs from validation selection'):
        load_study(study)


@pytest.mark.parametrize('invalid', ['nan','shape','identity'])
def test_invalid_regression_archive_rejected(invalid):
    row = dict(indices=np.arange(3),time_ns=np.arange(3),truth_cv=np.zeros((3,9)),pred_cv=np.zeros((3,9)))
    if invalid=='nan':row['pred_cv'][1,2] = np.nan
    if invalid=='shape':row['pred_cv'] = np.zeros((3,8))
    if invalid=='identity':row['indices'][1] = 0
    with pytest.raises(ValueError):validate_regression_archive(row)


def test_complete_report_exports_three_figures_and_hashed_sources(study):
    result = build_report(study)
    assert len(list((study/'figures').glob('*.png'))) == 3
    assert len(list((study/'figures').glob('*_data.csv'))) == 3
    text = (study/'RESULTS.txt').read_text()
    assert 'validation-selected B' in text
    assert 'No factorial-interaction claim' in text
    manifest = json.loads((study/'report_manifest.json').read_text())
    for name,digest in manifest['files'].items():
        assert sha256(study/name) == digest
    assert manifest['source_selection_frozen_sha256'] == result['source_selection_frozen_sha256']
