import copy

import numpy as np

from mswi_experiments.data import MINUTE_NS
from mswi_experiments.visual_diagnostics_horizons import (
    ALPHAS, apply_direct_ridge, direct_interval, eligible_pairs, fit_direct_ridge, origin_design,
)


def fixture():
    rng = np.random.default_rng(29)
    n = 18
    time = np.arange(n, dtype=np.int64) * MINUTE_NS
    following = np.r_[np.arange(1, n), -1]
    data = {"time_ns": time, "next_idx": following,
            "train_idx": np.arange(8), "val_idx": np.arange(9, 13), "test_idx": np.arange(14, 18),
            "u_hist": rng.normal(size=(n, 11, 8)).astype(np.float32),
            "z_hist": rng.normal(size=(n, 10, 9)).astype(np.float32),
            "z_prev": rng.normal(size=(n, 9)).astype(np.float32),
            "z_target": rng.normal(size=(n, 9)).astype(np.float32)}
    variants = {name: rng.normal(size=(n, dim)).astype(np.float32) for name, dim in
                (("timing4", 4), ("original52", 52), ("static40", 40), ("fixed10", 52),
                 ("fixed60", 52), ("null_fixed10", 52))}
    return data, variants


def test_eligible_pairs_follow_exact_links_without_crossing_partitions_or_gaps():
    data, _ = fixture()
    origin, destination = eligible_pairs(data, "train", 3)
    np.testing.assert_array_equal(origin, np.arange(6))
    np.testing.assert_array_equal(destination, np.arange(2, 8))
    # Even a nonnegative next_idx pointing into the next partition is invalid.
    assert 7 not in eligible_pairs(data, "train", 2)[0]
    data["time_ns"][4:] += MINUTE_NS
    origin, destination = eligible_pairs(data, "train", 3)
    assert 2 not in origin and 3 not in origin
    assert set(origin) == {0, 1, 4, 5}
    assert (data["time_ns"][destination] - data["time_ns"][origin] == 2 * MINUTE_NS).all()


def test_origin_features_ignore_destinations_future_histories_and_all_targets():
    data, variants = fixture()
    origins = np.array([0, 1])
    before = origin_design(data, variants, "fixed10", origins)
    sensor = origin_design(data, variants, "sensor", origins)
    changed, changed_variants = copy.deepcopy(data), copy.deepcopy(variants)
    changed["u_hist"][2:] += 1e5
    changed["z_hist"][2:] -= 1e5
    changed["z_target"][:] = -1e10
    changed["z_prev"][:] = 1e10
    for value in changed_variants.values():
        value[2:] *= 1000
    np.testing.assert_array_equal(before, origin_design(changed, changed_variants, "fixed10", origins))
    np.testing.assert_array_equal(sensor, origin_design(changed, changed_variants, "sensor", origins))
    assert sensor.shape == (2, 178)
    assert before.shape == (2, 230)


def test_ridge_scalers_training_only_and_saved_fit_replays(tmp_path):
    rng = np.random.default_rng(4)
    x = rng.normal(size=(200, 9))
    change = x @ rng.normal(size=(9, 4)) + [5, -5, .1, .4]
    x[:, -1] = 2
    fitted = fit_direct_ridge(x[:120], change[:120], x[120:160], change[120:160])
    np.testing.assert_allclose(fitted["x_mean"], x[:120].mean(axis=0))
    np.testing.assert_allclose(fitted["y_mean"], change[:120].mean(axis=0))
    assert float(fitted["alpha"]) in ALPHAS
    assert fitted["x_scale"][-1] == 1
    previous = np.ones((40, 4)) * 10
    prediction = apply_direct_ridge(fitted, x[160:], previous)
    np.savez_compressed(tmp_path / "weights.npz", **fitted)
    with np.load(tmp_path / "weights.npz", allow_pickle=False) as raw:
        replay = apply_direct_ridge(dict(raw), x[160:], previous)
    np.testing.assert_array_equal(prediction, replay)
    np.testing.assert_allclose(apply_direct_ridge(fitted, x[160:], previous + 3), prediction + 3,
                               rtol=1e-14, atol=1e-14)


def test_deterministic_interval_has_only_time_block_uncertainty():
    diff = np.full((20, 4), 2.)
    interval = direct_interval(diff, np.repeat(np.arange(4), 5), {"bootstrap_draws": 40})
    assert interval["deterministic_fits"] == 1
    assert "training_seeds" not in interval
    np.testing.assert_allclose(interval["difference"], np.full(4, 2.))
    np.testing.assert_allclose(interval["ci_lower"], np.full(4, 2.))
    np.testing.assert_allclose(interval["ci_upper"], np.full(4, 2.))
    assert "no neural-training-seed axis" in interval["resampling"]
