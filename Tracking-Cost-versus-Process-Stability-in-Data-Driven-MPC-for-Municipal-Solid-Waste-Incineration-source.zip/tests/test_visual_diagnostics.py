import numpy as np
import pytest

from mswi_experiments.visual_diagnostics import capture_block_null


def test_capture_block_null_keeps_repeated_capture_content_and_timing():
    n = 72
    data = {'time_ns': np.arange(n), 'visual_time_ns': np.repeat(np.arange(n // 2), 2),
            'train_idx': np.arange(24), 'val_idx': np.arange(24, 48), 'test_idx': np.arange(48, 72)}
    content = np.repeat(np.arange(n // 2), 2)[:, None] * np.ones((1, 48))
    timing = np.arange(n)[:, None] * np.ones((1, 4))
    values = np.concatenate([content, timing], axis=1)
    before = values.copy()
    output, donors, manifest = capture_block_null(values, data, seed=12, block_captures=3)
    assert np.array_equal(values, before)
    assert np.array_equal(output[:, 48:], timing)
    assert np.array_equal(output[::2, :48], output[1::2, :48])
    for label in ['train', 'val', 'test']:
        idx = data[label + '_idx']
        assert np.isin(donors[idx], idx).all()
        assert manifest['partitions'][label]['donors_within_partition']
    same = capture_block_null(values, data, seed=12, block_captures=3)
    assert np.array_equal(same[0], output)
    assert np.array_equal(same[1], donors)


def test_capture_block_null_rejects_wrong_dimensions():
    with pytest.raises(ValueError):
        capture_block_null(np.zeros((3, 50)), {'time_ns': np.arange(3)})
