"""Boundary tests for release import and result preservation."""
import io,tarfile
from pathlib import Path
import pytest
from reproduction.files import safe_members,import_assets,write,sha
from reproduction.worker import output_dir

def make_tar(path,name):
    with tarfile.open(path,'w:gz') as t:
        rec=tarfile.TarInfo(name);rec.size=1;t.addfile(rec,io.BytesIO(b'x'))

def test_release_rejects_path_traversal(tmp_path):
    archive=tmp_path/'bad.tar.gz';make_tar(archive,'../outside')
    with tarfile.open(archive) as t:
        with pytest.raises(ValueError):list(safe_members(t,tmp_path/'destination'))

def test_release_checks_archive_hash_before_extracting(tmp_path):
    root=tmp_path/'repo';assets=tmp_path/'assets';assets.mkdir();root.mkdir()
    p=assets/'a.tar.gz';make_tar(p,'data/raw/a')
    write(root/'data/assets.json',{'assets':[{'name':'a.tar.gz','sha256':'0'*64}],'files':{}})
    with pytest.raises(ValueError,match='checksum'):import_assets(root,assets)
    assert not (root/'data/raw/a').exists()

def test_release_never_replaces_different_existing_data(tmp_path):
    root=tmp_path/'repo';assets=tmp_path/'assets';assets.mkdir();root.mkdir()
    p=assets/'a.tar.gz';make_tar(p,'data/raw/a')
    write(root/'data/assets.json',{'assets':[{'name':'a.tar.gz','sha256':sha(p)}],
        'files':{'data/raw/a':{'sha256':'0'*64,'bytes':1}}})
    f=root/'data/raw/a';f.parent.mkdir(parents=True);f.write_bytes(b'z')
    with pytest.raises(FileExistsError):import_assets(root,assets)
    assert f.read_bytes()==b'z'

def test_existing_output_is_preserved(tmp_path):
    target=tmp_path/'results';target.mkdir();(target/'keep').write_text('original')
    with pytest.raises(FileExistsError):output_dir(target)
    assert (target/'keep').read_text()=='original'

def test_resume_rejects_changed_model_inputs(tmp_path):
    from reproduction.files import validate_resume
    (tmp_path/'mswi_experiments').mkdir();(tmp_path/'reproduction').mkdir()
    f=tmp_path/'model.npz';f.write_bytes(b'original model')
    record={'scientific_code':{},'portable_code':{},'input_hashes':{'model.npz':sha(f)}}
    validate_resume(record,tmp_path,tmp_path)
    f.write_bytes(b'changed model')
    with pytest.raises(ValueError,match='input changed'):validate_resume(record,tmp_path,tmp_path)
