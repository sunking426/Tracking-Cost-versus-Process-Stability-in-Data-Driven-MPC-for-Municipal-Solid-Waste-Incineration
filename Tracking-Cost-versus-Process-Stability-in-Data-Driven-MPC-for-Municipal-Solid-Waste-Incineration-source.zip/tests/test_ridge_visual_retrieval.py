"""Training-source exclusion and recursive visual substitution contracts."""
import numpy as np
import pytest
from sklearn.preprocessing import StandardScaler

from mswi_experiments.numeric_baselines import linear_increment, numeric_features
from mswi_experiments.ridge_visual_retrieval import (
    NumericalVisualMemory, RidgeWithVisual, retrieved_rollout,
)


def dataset(n=20):
    rng = np.random.default_rng(140)
    starts = np.arange(n, dtype=np.int64) * 1000
    return {'u_hist': rng.normal(size=(n, 11, 8)), 'z_hist': rng.normal(size=(n, 10, 9)),
            'source_start_ns': starts, 'source_end_ns': starts+100,
            'visual_time_ns': starts+50, 'train_idx': np.arange(n-4),
            'z_target': rng.normal(size=(n, 9))}


def features(n=20, width=3):
    return np.arange(n*width, dtype=np.float64).reshape(n, width)


def weights(width=3):
    return {'x_mean': np.zeros(178+width), 'x_scale': np.ones(178+width),
            'coef': np.zeros((9, 178+width)), 'intercept': np.zeros(9),
            'delta_scale': np.ones(9), 'kind': np.asarray('ridge'), 'alpha': np.asarray(100.)}


def test_memory_uses_train_only_scaling_cosine_and_uniform_anchors():
    data = dataset()
    memory = NumericalVisualMemory(data, data['train_idx'], features(), max_items=5)
    anchors = data['train_idx'][np.linspace(0, 15, 5).round().astype(int)]
    np.testing.assert_array_equal(memory.indices, anchors)
    x = numeric_features(data)
    scaler = StandardScaler().fit(x[data['train_idx']])
    keys = scaler.transform(x[anchors]); keys /= np.linalg.norm(keys, axis=1, keepdims=True)
    np.testing.assert_array_equal(memory.x_mean, scaler.mean_)
    np.testing.assert_array_equal(memory.x_scale, scaler.scale_)
    np.testing.assert_allclose(memory.keys, keys, atol=1e-15)
    query = scaler.transform(x[-4:]); query /= np.linalg.norm(query, axis=1, keepdims=True)
    expected = np.argmax(query @ keys.T, axis=1)
    actual = memory.query(data['u_hist'][-4:], data['z_hist'][-4:], batch_size=1)
    np.testing.assert_array_equal(actual['key_indices'], anchors[expected])
    np.testing.assert_array_equal(actual['visual'], features()[anchors[expected]])
    np.testing.assert_allclose(actual['scores'], (query @ keys.T)[np.arange(4), expected], atol=1e-15)


def test_memory_never_uses_cv_targets_or_heldout_fit_values():
    data = dataset()
    first = NumericalVisualMemory(data, data['train_idx'], features(), max_items=8)
    data['z_target'][:] = 1e30
    data['u_hist'][-4:] = -1e20
    data['z_hist'][-4:] = 1e30
    second = NumericalVisualMemory(data, data['train_idx'], features(), max_items=8)
    for name in ('keys', 'x_mean', 'x_scale', 'visual', 'indices'):
        np.testing.assert_array_equal(getattr(first, name), getattr(second, name))


def test_real_and_shuffled_training_use_identical_union_exclusions():
    data = dataset()
    # Capture identity can match even when numeric source intervals do not.
    data['visual_time_ns'][6] = data['visual_time_ns'][2]
    # Source overlap is an independent reason for rejecting a candidate.
    data['source_start_ns'][3] = data['source_start_ns'][2]
    kwargs = dict(max_items=16, exclusion_permutation_seed=92)
    real = NumericalVisualMemory(data, data['train_idx'], features(), **kwargs)
    null = NumericalVisualMemory(data, data['train_idx'], features(), permutation_seed=92, **kwargs)
    rows = data['train_idx']
    a = real.query(data['u_hist'][rows], data['z_hist'][rows], rows)
    b = null.query(data['u_hist'][rows], data['z_hist'][rows], rows)
    np.testing.assert_array_equal(a['key_indices'], b['key_indices'])
    np.testing.assert_array_equal(a['scores'], b['scores'])
    assert np.all(null.donor_indices != null.indices)
    np.testing.assert_array_equal(a['visual'], features()[a['donor_indices']])
    np.testing.assert_array_equal(b['visual'], features()[b['donor_indices']])
    for retrieved in (a, b):
        donors = retrieved['donor_indices']
        assert np.all((data['source_start_ns'][donors] > data['source_end_ns'][rows])
                      | (data['source_end_ns'][donors] < data['source_start_ns'][rows]))
        assert np.all(data['visual_time_ns'][donors] != data['visual_time_ns'][rows])
        assert np.all(donors != rows)


def test_equal_cosines_choose_earliest_anchor_and_empty_eligibility_raises():
    data = dataset()
    data['u_hist'][:] = 0; data['z_hist'][:] = 0
    memory = NumericalVisualMemory(data, data['train_idx'], features(), max_items=3)
    result = memory.query(data['u_hist'][-1:], data['z_hist'][-1:])
    assert result['key_indices'].item() == memory.indices[0]
    assert result['scores'].item() == 0
    data['visual_time_ns'][:] = 0
    memory = NumericalVisualMemory(data, data['train_idx'], features(), max_items=3)
    with pytest.raises(ValueError, match='no eligible'):
        memory.query(data['u_hist'][:1], data['z_hist'][:1], np.array([0]))


def test_saved_memory_replays_donors_and_exclusions_without_source_data(tmp_path):
    data = dataset()
    memory = NumericalVisualMemory(data, data['train_idx'], features(), max_items=8,
                                   permutation_seed=12, exclusion_permutation_seed=12)
    path = tmp_path/'memory.npz'; memory.save(path)
    loaded = NumericalVisualMemory.load(path)
    assert loaded.source_path == path.resolve()
    rows = data['train_idx']
    for query_indices in (None, rows):
        a = memory.query(data['u_hist'][rows], data['z_hist'][rows], query_indices)
        b = loaded.query(data['u_hist'][rows], data['z_hist'][rows], query_indices)
        for name in a:
            np.testing.assert_array_equal(a[name], b[name])
    with np.load(path, allow_pickle=False) as archive:
        damaged = {key: archive[key] for key in archive.files}
    damaged['donor_indices'] = damaged['indices'].copy()
    np.savez_compressed(path, **damaged)
    with pytest.raises(ValueError, match='permutation seed'):
        NumericalVisualMemory.load(path)


def test_visual_ridge_uses_canonical_scaling_and_reloads_exactly(tmp_path):
    rng = np.random.default_rng(81)
    w = weights()
    w.update(x_mean=rng.normal(size=181), x_scale=rng.uniform(.2, 2, 181),
             coef=rng.normal(size=(9, 181)), intercept=rng.normal(size=9),
             delta_scale=rng.uniform(.1, 2, 9))
    model = RidgeWithVisual(w)
    data = dataset(); visual = features()
    expected = linear_increment(w, np.concatenate((numeric_features(data), visual), axis=1))
    np.testing.assert_array_equal(model.predict_delta(data['u_hist'], data['z_hist'], visual), expected)
    path = tmp_path/'model.npz'; model.save(path)
    loaded = RidgeWithVisual.load(path)
    np.testing.assert_array_equal(loaded.predict_next(data['u_hist'], data['z_hist'], visual),
                                  data['z_hist'][:, -1] + expected)
    with pytest.raises(ValueError):
        loaded.weights['coef'][0, 0] = 2


def test_recursion_queries_predicted_histories_and_hold_repeats_origin_only():
    class RecordingMemory:
        visual_dim = 1
        def __init__(self): self.seen = []
        def query(self, u, z):
            self.seen.append((u.copy(), z.copy()))
            visual = z[:, -1, :1].copy()
            return {'visual': visual, 'key_indices': (visual[:, 0]*100).astype(int),
                    'donor_indices': (visual[:, 0]*100+1).astype(int),
                    'scores': np.full(len(u), .9)}
    w = weights(1); w['coef'][0, -1] = .5
    # The second channel also checks changing MV path execution.
    w['coef'][1, 10*8] = 1
    model = RidgeWithVisual(w)
    u, z = np.zeros((2, 11, 8)), np.zeros((2, 10, 9))
    z[:, -1, 0] = [2, 4]
    path = np.zeros((2, 3, 8)); path[:, 1:, 0] = [[3, 7], [4, 8]]
    snapshots = u.copy(), z.copy(), path.copy()
    memory = RecordingMemory()
    result = retrieved_rollout(model, memory, u, z, path)
    expected = np.array([[3, 4.5, 6.75], [6, 9, 13.5]])
    np.testing.assert_array_equal(result['predictions'][:, :, 0], expected)
    np.testing.assert_array_equal(result['predictions'][:, :, 1], [[0, 3, 10], [0, 4, 12]])
    assert len(memory.seen) == 3
    np.testing.assert_array_equal(memory.seen[1][1][:, -1], result['predictions'][:, 0])
    np.testing.assert_array_equal(memory.seen[2][1][:, -1], result['predictions'][:, 1])
    np.testing.assert_array_equal(memory.seen[2][0][:, -1], path[:, 2])
    assert np.all(result['key_indices'][:, 1:] != result['key_indices'][:, :-1])
    hold_memory = RecordingMemory()
    held = retrieved_rollout(model, hold_memory, u, z, path, mode='hold')
    assert len(hold_memory.seen) == 1
    np.testing.assert_array_equal(held['predictions'][:, :, 0], [[3, 4, 5], [6, 8, 10]])
    np.testing.assert_array_equal(held['donor_indices'], np.repeat(held['donor_indices'][:, :1], 3, axis=1))
    for value, old in zip((u, z, path), snapshots): np.testing.assert_array_equal(value, old)


def test_real_memory_and_model_recursive_reload_is_identical(tmp_path):
    data = dataset()
    memory = NumericalVisualMemory(data, data['train_idx'], features(), max_items=8)
    w = weights(); w['coef'][:, -3:] = .0001
    model = RidgeWithVisual(w)
    u, z = data['u_hist'][-4:], data['z_hist'][-4:]
    path = np.repeat(u[:, -1, None], 3, axis=1)
    original = retrieved_rollout(model, memory, u, z, path)
    memory.save(tmp_path/'memory.npz'); model.save(tmp_path/'model.npz')
    reloaded = retrieved_rollout(RidgeWithVisual.load(tmp_path/'model.npz'),
                                NumericalVisualMemory.load(tmp_path/'memory.npz'), u, z, path)
    for key in original: np.testing.assert_array_equal(original[key], reloaded[key])
    data['z_target'][:] = 1e30
    another = retrieved_rollout(model, memory, u, z, path)
    np.testing.assert_array_equal(another['predictions'], original['predictions'])


@pytest.mark.parametrize('kwargs', [{'max_items': 0}, {'max_items': 1.5},
                                  {'permutation_seed': 1}, {'permutation_seed': -2},
                                  {'max_items': 1, 'permutation_seed': 4, 'exclusion_permutation_seed': 4}])
def test_memory_rejects_invalid_selection_and_uncovered_donors(kwargs):
    data = dataset()
    with pytest.raises(ValueError): NumericalVisualMemory(data, data['train_idx'], features(), **kwargs)


def test_memory_query_rejects_invalid_or_heldout_training_indices():
    data = dataset(); memory = NumericalVisualMemory(data, data['train_idx'], features())
    with pytest.raises(ValueError, match='training query'):
        memory.query(data['u_hist'][-1:], data['z_hist'][-1:], np.array([19]))
    with pytest.raises(ValueError, match='training query'):
        memory.query(data['u_hist'][:1], data['z_hist'][:1], np.array([0, 1]))
    with pytest.raises(ValueError): memory.query(data['u_hist'][:1], data['z_hist'][:1], batch_size=0)
    bad = data['u_hist'][:1].copy(); bad[0, 0, 0] = np.nan
    with pytest.raises(ValueError): memory.query(bad, data['z_hist'][:1])


@pytest.mark.parametrize('key,value', [('x_scale', np.zeros(181)), ('delta_scale', np.zeros(9)),
                                     ('coef', np.zeros((8, 181))), ('kind', np.asarray('zero')),
                                     ('alpha', np.asarray(-1.))])
def test_visual_model_rejects_invalid_weights(key, value):
    w = weights(); w[key] = value
    with pytest.raises(ValueError): RidgeWithVisual(w)


def test_forecast_rejects_incompatible_visuals_modes_and_mv_path():
    data = dataset(); model = RidgeWithVisual(weights())
    memory = NumericalVisualMemory(data, data['train_idx'], features())
    u, z = data['u_hist'][-1:], data['z_hist'][-1:]
    path = u[:, -1, None].copy()
    with pytest.raises(ValueError): model.predict_next(u, z, np.zeros((1, 4)))
    with pytest.raises(ValueError): model.predict_next(u, z, np.full((1, 3), np.inf))
    with pytest.raises(ValueError): retrieved_rollout(model, memory, u, z, path, mode='observed_future')
    path[:, 0, 0] += 1
    with pytest.raises(ValueError, match='first MV'): retrieved_rollout(model, memory, u, z, path)
