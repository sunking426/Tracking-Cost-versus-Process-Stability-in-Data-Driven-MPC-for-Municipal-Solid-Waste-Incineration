"""Synthetic integrity checks for the representation-report boundary."""
import hashlib
import json
from pathlib import Path

import numpy as np
import pytest

from mswi_experiments.visual_representation_probe import METHODS, HORIZONS
from mswi_experiments.visual_representation_report import (
    CONTROL_NAMES, DAY_NS, export_tables, load_completed_probe,
)


def _write(path, value):
    Path(path).write_text(json.dumps(value, indent=2))


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _refresh_completion(folder):
    old=json.loads((folder/'completed.json').read_text())
    for name in ('results','protocol','artifact_hashes'):
        old[name+'_sha256']=_sha(folder/(name+'.json'))
    _write(folder/'completed.json',old)


def create_synthetic_study(root):
    root=Path(root);folder=root/'probe';folder.mkdir(parents=True,exist_ok=True)
    protocol={'methods':list(METHODS),'horizons_minutes':list(HORIZONS),'target_names':list(CONTROL_NAMES),
              'intervals':{'multiple_comparison_adjustment':'none'},
              'input_composition':{m:'synthetic design: '+m for m in METHODS},
              'test_scope':'synthetic fixture only; no real data or model fitting'}
    results={'status':'completed','protocol':protocol,'horizons':{}};hashes={}
    rng=np.random.default_rng(743)
    factors={'sensor':[1,1,1,1],'timing':[.99,1.01,.99,.99],'old52':[.97,1.02,.96,.97],
             'quality':[.96,1,.95,.96],'rgb32':[.94,1.04,.91,.92],
             'gray32':[.95,1.03,.92,.93],'null_rgb32':[.98,1.01,.97,.98]}
    for h in HORIZONS:
        n=80;truth=np.tile([900,-100,30,7.],(n,1));base=rng.normal(size=(n,4))*np.array([2,12,.2,.14])*h
        times=(20000+np.arange(n)//10)*DAY_NS+(np.arange(n)%10)*60_000_000_000
        cell={'eligible_counts':{'train':200,'val':80,'test':n},'methods':{},'comparisons':{}}
        errors={}
        for j,m in enumerate(METHODS):
            predicted=truth+base*np.asarray(factors[m]);error=predicted-truth;errors[m]=error
            dest=folder/f'horizon_{h:02d}'/m;dest.mkdir(parents=True,exist_ok=True)
            path=dest/'test_predictions.npz'
            np.savez_compressed(path,indices=np.arange(n),destination_indices=np.arange(n)+h-1,
                                time_ns=times,destination_time_ns=times+(h-1)*60_000_000_000,
                                truth=truth,pred=predicted,error=error)
            digest=_sha(path);hashes[str(path.relative_to(folder))]=digest
            cell['methods'][m]={'mae':np.abs(error).mean(axis=0).tolist(),'rmse':np.sqrt(np.square(error).mean(axis=0)).tolist(),
                                'samples':n,'alpha':100.,'input_dimension':178+j,'predictions_sha256':digest}
        pairs={(m,r) for r in ('sensor','timing','quality') for m in METHODS if m!=r}
        pairs.update({('rgb32','null_rgb32'),('rgb32','gray32'),('rgb32','old52')})
        for m,r in sorted(pairs):
            difference=(np.abs(errors[r])-np.abs(errors[m])).mean(axis=0)
            radius=np.abs(difference)*.35+np.array([.02,.06,.002,.002])
            cell['comparisons'][m+'_vs_'+r]={'candidate':m,'reference':r,'difference':difference.tolist(),
                'ci_lower':(difference-radius).tolist(),'ci_upper':(difference+radius).tolist(),
                'samples':n,'time_blocks':8,'multiple_comparison_adjustment':'none','exploratory':True,
                'deterministic_fits':1,'confidence_level':.95,'draws':10000,
                'endpoint_priorities':{q:'synthetic' for q in CONTROL_NAMES}}
        results['horizons'][str(h)]=cell
    _write(folder/'results.json',results);_write(folder/'protocol.json',protocol);_write(folder/'artifact_hashes.json',hashes)
    _write(folder/'completed.json',{'status':'completed','fits':21});_refresh_completion(folder)
    return root


def test_complete_saved_predictions_export_all_cells(tmp_path):
    root=create_synthetic_study(tmp_path)
    results,arrays,sources,checks=load_completed_probe(root)
    assert len(checks)==21 and len(sources)==25
    paths=export_tables(root,results,arrays)
    import csv
    with paths[0].open() as f: overall=list(csv.DictReader(f))
    with paths[1].open() as f: contrasts=list(csv.DictReader(f))
    with paths[2].open() as f: daily=list(csv.DictReader(f))
    assert len(overall)==3*7*4 and len(contrasts)==3*21*4 and len(daily)==3*7*8*4
    assert {r['method'] for r in overall}==set(METHODS)


def test_truth_mismatch_rejected_even_after_hashes_updated(tmp_path):
    root=create_synthetic_study(tmp_path);folder=root/'probe'
    path=folder/'horizon_05'/'old52'/'test_predictions.npz'
    with np.load(path) as a: changed={k:a[k].copy() for k in a.files}
    changed['truth'][0,0]+=.1;changed['error']=changed['pred']-changed['truth'];np.savez_compressed(path,**changed)
    digest=_sha(path);h=json.loads((folder/'artifact_hashes.json').read_text());h[str(path.relative_to(folder))]=digest;_write(folder/'artifact_hashes.json',h)
    r=json.loads((folder/'results.json').read_text());r['horizons']['5']['methods']['old52']['predictions_sha256']=digest;_write(folder/'results.json',r)
    _refresh_completion(folder)
    with pytest.raises(ValueError,match='share test indices, times and targets'):load_completed_probe(root)


def test_inverted_contrast_direction_rejected(tmp_path):
    root=create_synthetic_study(tmp_path);folder=root/'probe'
    r=json.loads((folder/'results.json').read_text());row=r['horizons']['5']['comparisons']['rgb32_vs_quality']
    row['difference']=[-d for d in row['difference']];_write(folder/'results.json',r);_refresh_completion(folder)
    with pytest.raises(ValueError,match='paired comparison'):load_completed_probe(root)
