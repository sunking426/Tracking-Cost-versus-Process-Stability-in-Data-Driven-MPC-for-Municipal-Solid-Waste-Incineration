import numpy as np
import pytest
from scipy.special import expit
from sklearn.metrics import average_precision_score,log_loss

from mswi_experiments import rgb_control_diagnostic_models as m


def example():
    rng = np.random.default_rng(19)
    x = rng.normal(size=(100,4)); x[:,3] = 7
    y = (x[:,0]+.4*x[:,1]+rng.normal(size=100)*.8 > 0).astype(int)
    return x[:70],y[:70],x[70:],y[70:]


def test_train_scaler_saved_prediction_and_alarm_threshold(tmp_path):
    xt,yt,xv,yv = example()
    weights,rows,chosen = m.fit_candidates(xt,yt,xv+3,yv,[.01,.1,1])
    np.testing.assert_array_equal(weights['x_mean'],xt.mean(0))
    assert weights['x_scale'][3] == 1
    prediction = m.predict_proba(weights,xv+3)
    assert chosen['threshold'] == np.quantile(prediction,.9,method='linear')
    assert chosen['C'] == min(rows,key=lambda r:(r['val_log_loss'],r['C']))['C']
    for row in rows: assert row['converged'] and row['n_iter'] > 0
    path = tmp_path/'weights.npz'; m.save_model(path,weights)
    loaded = m.load_model(path)
    np.testing.assert_array_equal(prediction,m.predict_proba(loaded,xv+3))
    assert not loaded['coef'].flags.writeable
    before = float(loaded['threshold'])
    m.predict_proba(loaded,xv*100)
    assert float(loaded['threshold']) == before
    with pytest.raises(ValueError):m.predict_proba(loaded,np.ones((3,5)))


def test_fitting_has_no_test_argument_and_is_reproducible():
    args = example()
    first = m.fit_candidates(*args,[.01,.1])[0]
    second = m.fit_candidates(*args,[.01,.1])[0]
    for key in first:np.testing.assert_array_equal(first[key],second[key])


def test_nonconvergence_is_not_silently_excluded(monkeypatch):
    original = m.LogisticRegression.fit
    def fail(self,*args,**kwargs):
        import warnings
        result = original(self,*args,**kwargs)
        warnings.warn('synthetic nonconvergence',m.ConvergenceWarning)
        return result
    monkeypatch.setattr(m.LogisticRegression,'fit',fail)
    with pytest.raises(RuntimeError,match='did not converge'):
        m.fit_candidates(*example(),[1])


@pytest.mark.parametrize('grid', [[],[0],[1,1],[float('inf')]])
def test_invalid_grid(grid):
    with pytest.raises(ValueError):m.fit_candidates(*example(),grid)


def test_single_training_class_rejected():
    xt,yt,xv,yv = example()
    with pytest.raises(ValueError,match='both training classes'):
        m.fit_candidates(xt,np.zeros(len(yt)),xv,yv,[1])


def test_binary_metrics_counts_and_scoring_rules():
    y = np.array([0,0,1,1]); p = np.array([.1,.5,.5,.9])
    result = m.binary_metrics(y,p,.5)
    assert result['true_positive']==2 and result['false_positive']==1
    assert result['alarm_count']==3 and result['precision']==2/3
    assert result['recall']==1 and result['false_positive_rate']==.5
    assert result['average_precision']==average_precision_score(y,p)
    assert result['brier']==np.mean((p-y)**2)
    assert result['log_loss']==pytest.approx(log_loss(y,p),abs=1e-15)
    no_alarm = m.binary_metrics(y,p,1)
    assert no_alarm['precision'] is None and no_alarm['recall']==0


def test_missing_class_explicitly_undefined_not_fabricated():
    result = m.binary_metrics(np.zeros(4),np.arange(4)/4,.5)
    assert result['average_precision'] is None and result['roc_auc'] is None
    assert result['recall'] is None and result['brier'] is not None
    assert not result['discrimination_defined']


def test_extreme_probabilities_have_finite_logloss():
    result = m.binary_metrics([0,1],[1.,0.],.5)
    assert np.isfinite(result['log_loss'])
    assert result['brier']==1


@pytest.mark.parametrize('seed',range(5))
def test_weighted_ap_ties_matches_sklearn(seed):
    rng = np.random.default_rng(seed)
    y = rng.integers(0,2,80)
    p = rng.integers(0,7,80)/6
    w = rng.integers(0,5,80)
    actual = m.weighted_average_precision(y,p,w)
    assert actual==pytest.approx(average_precision_score(y,p,sample_weight=w),abs=2e-15)


def test_block_ap_matches_individual_weighted_ranking():
    y = np.array([0,1,1,0,0,1]); p = np.array([.3,.3,.8,.9,.2,.8])
    inverse = np.array([0,0,1,1,2,2]); weights=np.array([[2,0,1],[0,1,2],[1,1,1]])
    ranks=m._ranking_blocks(y,p,inverse,3)
    actual=m._ranked_block_ap(ranks,weights)
    expected=[m.weighted_average_precision(y,p,w[inverse]) for w in weights]
    np.testing.assert_allclose(actual,expected,rtol=0,atol=1e-15)


def test_paired_bootstrap_sign_identity_and_batch_invariance():
    y=np.array([0,1]*12); ref=np.full(24,.5); cand=.1+.8*y
    times=np.repeat(np.arange(4,dtype=np.int64)*m.DAY_NS,6)
    result=m.paired_day_bootstrap(y,ref,cand,times,draws=111,seed=12,batch_size=7)
    assert result['difference'][0] > 0 and min(result['ci_lower']) > 0
    other=m.paired_day_bootstrap(y,ref,cand,times,draws=111,seed=12,batch_size=32)
    for key in ('difference','ci_lower','ci_upper','valid_draws'):
        np.testing.assert_allclose(result[key],other[key],rtol=0,atol=1e-15)
    same=m.paired_day_bootstrap(y,ref,ref,times,draws=111,seed=12)
    assert same['difference']==[0.,0.,0.] and same['ci_lower']==[0.,0.,0.]
    inverse=m.paired_day_bootstrap(y,cand,ref,times,draws=111,seed=12)
    np.testing.assert_allclose(inverse['difference'],-np.asarray(result['difference']))
    np.testing.assert_allclose(inverse['ci_lower'],-np.asarray(result['ci_upper']))


def test_bootstrap_exact_independent_sklearn_resampling():
    y=np.array([0,1,0,0,1,1,0,1,1]); ref=np.array([.1,.2,.6,.4,.3,.9,.7,.8,.8])
    cand=np.array([.1,.5,.4,.2,.3,.9,.4,.8,.8]); inverse=np.repeat(np.arange(3),3)
    times=inverse.astype(np.int64)*m.DAY_NS
    actual=m.paired_day_bootstrap(y,ref,cand,times,draws=100,seed=71)
    rng=np.random.default_rng(71); weights=rng.multinomial(3,[1/3]*3,100)
    expected=[]
    for weight in weights:
        w=weight[inverse]
        expected.append(average_precision_score(y,cand,sample_weight=w)-average_precision_score(y,ref,sample_weight=w))
    np.testing.assert_allclose([actual['ci_lower'][0],actual['ci_upper'][0]],np.quantile(expected,[.025,.975]),atol=1e-15)


def test_degenerate_bootstrap_draws_counted():
    y=np.array([0,0,1,1]); p=np.array([.1,.3,.6,.8]); times=np.array([0,0,m.DAY_NS,m.DAY_NS])
    result=m.paired_day_bootstrap(y,np.full(4,.5),p,times,draws=100,seed=5)
    assert 0 < result['undefined_draws'][0] < 100
    assert result['valid_draws'][0]+result['undefined_draws'][0]==100
    assert result['undefined_draws'][1:]==[0,0]
    missing=m.paired_day_bootstrap(np.zeros(4),p,p,times,draws=10)
    assert missing['difference'][0] is None and missing['ci_lower'][0] is None
    assert missing['undefined_draws']==[10,0,0]


def test_invalid_probability_and_timestamps_rejected():
    with pytest.raises(ValueError):m.binary_metrics([0,1],[.1,1.1],.5)
    with pytest.raises(ValueError):m.paired_day_bootstrap([0,1],[.1,.9],[.1,.9],[0.,1.])


def test_saved_contract_tamper_rejected(tmp_path):
    weights=m.fit_candidates(*example(),[.1])[0]
    bad=dict(weights);bad['converged']=np.asarray(False)
    with pytest.raises(ValueError):m.save_model(tmp_path/'bad.npz',bad)
    bad=dict(weights);bad['x_scale']=np.zeros_like(weights['x_scale'])
    with pytest.raises(ValueError):m.predict_proba(bad,example()[0])
