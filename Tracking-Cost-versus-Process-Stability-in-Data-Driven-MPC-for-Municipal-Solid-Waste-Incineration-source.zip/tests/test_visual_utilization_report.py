"""Synthetic checks for result integrity and complete utilization readouts."""
from pathlib import Path
import json
import hashlib
import csv

import numpy as np
import pytest

from mswi_experiments.visual_utilization_report import (
    CANDIDATES, METHODS, CONTROL_NAMES, DAY_NS, HORIZONS, DIMENSIONS, RHOS,
    export_utilization_tables, load_completed_utilization,
)


def _write(path, value):
    Path(path).write_text(json.dumps(value, indent=2))


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _finish(root, result, protocol, hashes):
    folder=Path(root)/'probe'
    for name, value in [('results',result),('protocol',protocol),('artifact_hashes',hashes)]:
        _write(folder/(name+'.json'),value)
    complete={'status':'completed','selected_fits':33,'adaptive_aliases':3,'external_old52_references':3}
    for name in ['results','protocol','artifact_hashes']:complete[name+'_sha256']=_sha(folder/(name+'.json'))
    _write(folder/'completed.json',complete)


def make_synthetic_study(root):
    root=Path(root);folder=root/'probe';folder.mkdir(parents=True,exist_ok=True)
    protocol={'horizons_minutes':list(HORIZONS),'visual_dimensions':list(DIMENSIONS),'rhos':list(RHOS),
              'targets':list(CONTROL_NAMES),'intervals':{'multiple_comparison_adjustment':'none'},
              'test_scope':'synthetic fixture; no real targets or model fitting'}
    results={'status':'completed','protocol':protocol,'horizons':{}};hashes={}
    rng=np.random.default_rng(784);selected='rgb128_rho0p1'
    for h in HORIZONS:
        n=80;truth=np.tile([900.,-100.,30.,7.],(n,1))
        base=rng.normal(size=(n,4))*[2*h,12,.2*h,.14*h]
        times=(20000+np.arange(n)//10)*DAY_NS+(np.arange(n)%10)*60_000_000_000
        cell={'eligible_counts':{'train':200,'val':80,'test':n},'adaptive_selected':selected,'methods':{},'comparisons':{}}
        predictions={};errors={}
        for i,m in enumerate(METHODS):
            if m in CANDIDATES:
                d=int(m.split('_')[0][3:])
                rho={'0p1':.1,'1':1.,'10':10.}[m.split('_rho')[1]]
                score=.1 if m==selected else .4+i*.01
            elif m in ('matched_null','adaptive_rgb'):
                d,rho,score=128,.1,.1 if m=='adaptive_rgb' else .55
            else:d,rho,score=0,1.,.8
            factor=np.array([1+i*.001,1-i*.002,1-i*.003,1-i*.002])
            pred=truth+base*factor
            if m=='adaptive_rgb':pred=predictions[selected].copy()
            predictions[m]=pred;error=pred-truth;errors[m]=error
            path=folder/f'horizon_{h:02d}'/m/'test_predictions.npz'
            if m=='old52_reference':path=root/'external_reference'/f'horizon_{h:02d}'/'test_predictions.npz'
            path.parent.mkdir(parents=True,exist_ok=True)
            np.savez_compressed(path,indices=np.arange(n),destination_indices=np.arange(n)+h-1,
                                time_ns=times,destination_time_ns=times+(h-1)*60_000_000_000,
                                truth=truth,pred=pred,error=error)
            digest=_sha(path)
            if m!='old52_reference':hashes[str(path.relative_to(folder))]=digest
            metrics={'mae':np.abs(error).mean(axis=0).tolist(),'rmse':np.sqrt(np.square(error).mean(axis=0)).tolist(),
                     'samples':n,'predictions_sha256':digest}
            if m=='old52_reference':
                metrics['predictions_file']=str(path.resolve())
                row={'role':'unchanged external reference; not refitted'}
            else:
                row={'role':'selected fit','visual_dimension':d,'rho':rho,'alpha':10.,'null':m=='matched_null',
                     'input_dimension':194+d,'selected_val_score':score,'alphas':[.1,1.,10.,100.,1000.],
                     'val_normalized_mse':[score+.3,score+.1,score,score+.2,score+.4]}
                metrics['visual_contribution']={'rms':[.1,.2,.03,.04],'sd':[.09,.18,.02,.03],
                                                'mean':[0.,0.,0.,0.],'scope':'synthetic amplitude, not information gain'}
                if m=='adaptive_rgb':
                    row.update(role='alias of validation-selected existing fit',selected_candidate=selected)
            row.update(metrics);row['split_metrics']={split:dict(metrics) for split in ['train','val','test']}
            cell['methods'][m]=row
        contrasts={(a,b) for a in (*CANDIDATES,'adaptive_rgb') for b in ('quality','rgb32_rho1') if a!=b}
        contrasts.update({('adaptive_rgb','matched_null'),('adaptive_rgb','old52_reference')})
        for a,b in sorted(contrasts):
            mean=(np.abs(errors[b])-np.abs(errors[a])).mean(axis=0)
            radius=np.abs(mean)*.3+np.array([.02,.05,.002,.002])
            cell['comparisons'][a+'_vs_'+b]={'candidate':a,'reference':b,'difference':mean.tolist(),
                'ci_lower':(mean-radius).tolist(),'ci_upper':(mean+radius).tolist(),'samples':n,'time_blocks':8,
                'multiple_comparison_adjustment':'none','exploratory':True,'deterministic_fits':1,
                'confidence_level':.95,'draws':10000,'endpoint_priorities':{q:'synthetic' for q in CONTROL_NAMES}}
        results['horizons'][str(h)]=cell
    _finish(root,results,protocol,hashes)
    return root


def test_complete_readout_keeps_candidates_scores_and_alias_roles(tmp_path):
    root=make_synthetic_study(tmp_path)
    result,arrays,sources,checks=load_completed_utilization(root)
    assert len(checks)==39 and len(sources)==43
    files=export_utilization_tables(root,result,arrays)
    tables={p.name:list(csv.DictReader(p.open())) for p in files}
    assert len(tables['overall.csv'])==3*13*4
    assert len(tables['comparisons.csv'])==3*21*4
    assert len(tables['per_day.csv'])==3*13*8*4
    assert len(tables['validation_candidates.csv'])==33*5
    assert len(tables['adaptive_choices.csv'])==3
    assert len(tables['visual_contribution.csv'])==3*12*3*4
    assert {r['method'] for r in tables['overall.csv']}==set(METHODS)
    assert not any(r['method']=='adaptive_rgb' for r in tables['validation_candidates.csv'])


def test_incorrect_validation_selected_alias_rejected(tmp_path):
    root=make_synthetic_study(tmp_path);folder=root/'probe'
    result=json.loads((folder/'results.json').read_text());protocol=result['protocol']
    hashes=json.loads((folder/'artifact_hashes.json').read_text())
    result['horizons']['5']['adaptive_selected']='rgb512_rho10'
    _finish(root,result,protocol,hashes)
    with pytest.raises(ValueError,match='validation selection'):load_completed_utilization(root)


def test_external_reference_truth_mismatch_is_rejected(tmp_path):
    root=make_synthetic_study(tmp_path);folder=root/'probe'
    result=json.loads((folder/'results.json').read_text());protocol=result['protocol']
    hashes=json.loads((folder/'artifact_hashes.json').read_text())
    ref=result['horizons']['5']['methods']['old52_reference'];path=Path(ref['predictions_file'])
    with np.load(path) as source:values={k:source[k].copy() for k in source.files}
    values['truth'][0,0]+=.1;values['error']=values['pred']-values['truth'];np.savez_compressed(path,**values)
    ref['predictions_sha256']=_sha(path)
    _finish(root,result,protocol,hashes)
    with pytest.raises(ValueError,match='identical samples, times and truth'):load_completed_utilization(root)


def test_effect_direction_corruption_is_rejected(tmp_path):
    root=make_synthetic_study(tmp_path);folder=root/'probe'
    result=json.loads((folder/'results.json').read_text());protocol=result['protocol']
    hashes=json.loads((folder/'artifact_hashes.json').read_text())
    row=result['horizons']['5']['comparisons']['adaptive_rgb_vs_quality']
    row['difference']=[-v for v in row['difference']]
    _finish(root,result,protocol,hashes)
    with pytest.raises(ValueError,match='paired contrast'):load_completed_utilization(root)
