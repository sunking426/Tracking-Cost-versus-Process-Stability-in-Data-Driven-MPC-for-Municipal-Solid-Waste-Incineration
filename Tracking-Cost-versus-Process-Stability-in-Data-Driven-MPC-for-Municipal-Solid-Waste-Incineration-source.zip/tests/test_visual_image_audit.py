import hashlib
import json

import numpy as np
import pytest
from PIL import Image

from mswi_experiments.visual_image_audit import (
    QUALITY_COLUMNS, audit_capture, crop_bounds, duplicate_groups,
    load_capture_index, measure_rgb,
)


def test_pixel_quality_uses_crop_and_exact_rgb_hash():
    black=np.zeros((20,20,3),dtype=np.uint8)
    a=measure_rgb(black)
    assert a['black_fraction']==1 and a['gray_mean']==0 and a['hsv_saturation_mean']==0
    assert a['white_clipped_fraction']==a['any_channel_clipped_fraction']==0
    white=np.full((20,20,3),255,dtype=np.uint8)
    b=measure_rgb(white)
    assert b['white_clipped_fraction']==b['any_channel_clipped_fraction']==1
    assert b['gray_mean']==255 and b['black_fraction']==0
    overlay=black.copy();overlay[0,:,:]=255
    c=measure_rgb(overlay)
    assert a['crop_pixel_sha256']==c['crop_pixel_sha256']
    assert a['rgb_pixel_sha256']!=c['rgb_pixel_sha256']
    assert len(QUALITY_COLUMNS)==12


def test_rgb_saturation_and_crop_bounds():
    red=np.zeros((20,20,3),dtype=np.uint8);red[:,:,0]=255
    a=measure_rgb(red)
    assert a['hsv_saturation_mean']==1 and a['any_channel_clipped_fraction']==1
    assert a['white_clipped_fraction']==0
    assert a['red_mean']==255 and a['green_mean']==a['blue_mean']==0
    assert a['red_sd']==a['green_sd']==a['blue_sd']==0
    assert crop_bounds(1920,1088)==(403,272,1516,957)
    with pytest.raises(ValueError):crop_bounds(1,1)


def _fixture(tmp_path):
    sources=[]
    times=np.asarray(['2025-01-01T00:00:00','2025-01-01T00:10:00'],dtype='datetime64[ns]').astype(np.int64)
    for i,stamp in enumerate(times):
        name=str(np.datetime64(int(stamp),'ns').astype('datetime64[s]')).replace('T',' ')+'.jpg'
        path=tmp_path/name;Image.fromarray(np.full((20,20,3),i*255,dtype=np.uint8)).save(path)
        sources.append({'time':name[:-4],'img_name':name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'width':20,'height':20})
    manifest=tmp_path/'manifest.json';manifest.write_text(json.dumps({'image_dir':str(tmp_path),'sources':sources}))
    dataset=tmp_path/'dataset.npz'
    np.savez(dataset,time_ns=times[[0,0,1]]+60_000_000_000,visual_time_ns=times[[0,0,1]],
             train_idx=np.array([0]),val_idx=np.array([2]),test_idx=np.array([],dtype=int))
    return dataset,manifest


def test_exact_mapping_includes_unassigned_and_validates_source(tmp_path):
    dataset,manifest=_fixture(tmp_path)
    records,mapping=load_capture_index(dataset,manifest)
    np.testing.assert_array_equal(mapping,[0,0,1])
    assert records[0]['split_counts']=={'train':1,'val':0,'test':0,'unassigned':1}
    assert records[1]['split']=='val'
    assert audit_capture(records[0])['source_hash_matches']
    tampered=dict(records[0]);tampered['source_sha256']='0'*64
    with pytest.raises(ValueError,match='bytes disagree'):audit_capture(tampered)


def test_missing_or_future_source_fails(tmp_path):
    dataset,manifest=_fixture(tmp_path)
    with np.load(dataset) as saved: arrays={k:saved[k].copy() for k in saved.files}
    arrays['visual_time_ns'][0]=arrays['time_ns'][0]
    np.savez(dataset,**arrays)
    with pytest.raises(ValueError,match='causal input cutoff'):load_capture_index(dataset,manifest)


def test_duplicate_groups_explicitly_report_cross_partition():
    records=[{'capture_index':0,'img_name':'a.jpg','h':'same','split_counts':{'train':2}},
             {'capture_index':1,'img_name':'b.jpg','h':'same','split_counts':{'test':1}},
             {'capture_index':2,'img_name':'c.jpg','h':'different','split_counts':{'val':1}}]
    groups=duplicate_groups(records,'h')
    assert len(groups)==1 and groups[0]['cross_partition']
    assert groups[0]['splits']==['test','train']
