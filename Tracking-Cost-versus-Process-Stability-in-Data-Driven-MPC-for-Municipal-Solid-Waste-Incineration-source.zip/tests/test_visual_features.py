import csv
from pathlib import Path

import numpy as np
from PIL import Image
import pytest

from mswi_experiments.visual_features import (
    FEATURE_COLUMNS, add_causal_temporal_features, extract_corrected_features,
    gray_from_rgb, region_descriptors, region_pixels, spatial_descriptors,
)


def test_regions_scale_with_actual_source_dimensions():
    assert region_pixels(1920,1088)['area1']==(960,272,1516,598)
    assert region_pixels(704,576)['area3']==(147,316,352,506)
    with pytest.raises(ValueError):region_pixels(2,2)


def test_grayscale_rgb_order_and_no_uint8_overflow():
    image=np.asarray([[[255,0,0],[0,255,0],[0,0,255],[255,255,255]]],dtype=np.uint8)
    np.testing.assert_array_equal(gray_from_rgb(image),[[76,150,29,255]])


def test_known_pixel_statistics_and_threshold_means():
    gray=np.asarray([[0,110],[190,255]],dtype=np.uint8)
    out=region_descriptors(np.repeat(gray[...,None],3,axis=-1))
    assert out['ft_1']==.75
    assert out['ft_3']==.5
    assert out['ft_2']==185
    assert out['ft_4']==222.5
    assert out['ft_5']==2/3
    assert out['ft_11']==.5
    assert out['ft_10']==1
    assert out['ft_9']==out['ft_12']==pytest.approx(gray.std())


def test_uniform_regions_have_resolution_invariant_area_fractions():
    small=np.full((40,50,3),200,dtype=np.uint8)
    large=np.full((80,100,3),200,dtype=np.uint8)
    assert region_descriptors(small)==region_descriptors(large)
    out=region_descriptors(small)
    assert out['ft_1']==out['ft_3']==out['ft_11']==1
    assert out['ft_6']==pytest.approx(0)
    assert out['fire_line']==0


def test_hot_horizontal_centroid_is_not_vertical_coordinate():
    first=np.zeros((5,7,3),dtype=np.uint8);second=first.copy()
    first[0,0]=255;second[4,0]=255
    assert region_descriptors(first)['ft_6']==region_descriptors(second)['ft_6']==.5


def test_absence_and_threshold_front_are_explicit():
    black=np.zeros((5,7,3),dtype=np.uint8)
    assert all(value==0 for name,value in region_descriptors(black).items() if name!='fire_line')
    assert region_descriptors(black)['fire_line']==1
    black[3:]=255
    assert region_descriptors(black)['fire_line']==.75


def test_overlay_bands_cannot_change_measured_features_and_input_is_immutable():
    image=np.full((200,300,3),150,dtype=np.uint8);reference=image.copy()
    baseline=spatial_descriptors(image)
    np.testing.assert_array_equal(image,reference)
    image[:40]=255;image[180:]=0
    assert spatial_descriptors(image)==baseline


def _temporal_row(i):
    row={'img_name':f'2025-04-01 00:{i:02}:00.jpg','time':f'2025-04-01 00:{i:02}:00'}
    for a in range(1,5):row.update({f'ft_1_area{a}':float(i),f'ft_2_area{a}':float(i*10)})
    return row


def test_temporal_features_use_only_latest_six_past_or_current_sources():
    prefix=list(add_causal_temporal_features([_temporal_row(i) for i in range(3)]))
    whole=list(add_causal_temporal_features([_temporal_row(i) for i in range(8)]))
    assert whole[:3]==prefix
    assert whole[0]['ft_7_area1']==0
    assert whole[-1]['ft_7_area1']==pytest.approx(np.arange(2,8).std())
    assert whole[-1]['ft_8_area1']==pytest.approx((np.arange(2,8)*10).std())
    assert whole[-1]['feature_source_start_time']=='2025-04-01 00:02:00'
    with pytest.raises(ValueError):list(add_causal_temporal_features([_temporal_row(2),_temporal_row(1)]))


def test_export_keeps_fixed_selection_and_tracks_earliest_source(tmp_path):
    images=tmp_path/'images';images.mkdir()
    selection=tmp_path/'selected.csv'
    with selection.open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=['img_name','time']);writer.writeheader()
        for i,level in enumerate([30,130,230]):
            row=_temporal_row(i);writer.writerow({k:row[k] for k in ['img_name','time']})
            Image.fromarray(np.full((80,100,3),level,dtype=np.uint8)).save(images/row['img_name'])
    first=tmp_path/'features.csv';other=tmp_path/'features-threaded.csv'
    one=extract_corrected_features(selection,images,first,workers=1,examples=False)
    two=extract_corrected_features(selection,images,other,workers=2,examples=False)
    assert first.read_bytes()==other.read_bytes()
    assert one['rows']==two['rows']==3 and one['features']==52
    assert len(one['sources'])==3
    with first.open() as f:rows=list(csv.DictReader(f))
    assert set(rows[0])==set(FEATURE_COLUMNS)|{'img_name','time','feature_source_start_time'}
    assert rows[-1]['feature_source_start_time']=='2025-04-01 00:00:00'
    assert float(rows[-1]['ft_7_area1'])>0
    with pytest.raises(ValueError):extract_corrected_features(selection,images,selection,examples=False)
