"""Response diagnostics against known systems and canonical execution paths."""
import numpy as np
import pytest

from mswi_experiments.ridge_dynamics import RidgeDynamics, recursive_rollout
from mswi_experiments.ridge_response import (
    analytic_responses, autoregressive_stability, decision_rollout,
    physical_coefficients, project_trial_paths,
)


def weights():
    return {'x_mean': np.zeros(178), 'x_scale': np.ones(178),
            'coef': np.zeros((9, 178)), 'intercept': np.zeros(9),
            'delta_scale': np.ones(9), 'kind': np.asarray('ridge'),
            'alpha': np.asarray(100.)}


def histories(n=3):
    rng = np.random.default_rng(20261106)
    return (rng.normal(size=(n, 11, 8)), rng.normal(size=(n, 10, 9)),
            rng.normal(size=(n, 9)))


def varied_model():
    rng = np.random.default_rng(71)
    w = weights()
    w.update(x_mean=rng.normal(size=178), x_scale=rng.uniform(.2, 3, 178),
             coef=rng.normal(scale=.003, size=(9, 178)),
             intercept=rng.normal(scale=.2, size=9),
             delta_scale=rng.uniform(.1, 4, 9))
    return RidgeDynamics(w)


def projection_stats():
    return {'u_low': [0.]*8, 'u_high': [10.]*8,
            'action_bound': [2.]*8, 'action_scale': [2.]*8}


def test_physical_coefficients_remove_scaling_and_include_level_identity():
    model = varied_model()
    u, z = physical_coefficients(model)
    assert u.shape == (9, 11, 8) and z.shape == (9, 10, 9)
    matrix = model.weights['coef'] * model.weights['delta_scale'][:, None] / model.weights['x_scale']
    np.testing.assert_array_equal(u.reshape(9, 88), matrix[:, :88])
    expected = matrix[:, 88:].reshape(9, 10, 9).copy()
    expected[:, -1] += np.eye(9)
    np.testing.assert_array_equal(z, expected)
    u[:] = 0; z[:] = 0
    fresh_u, fresh_z = physical_coefficients(model)
    assert np.any(fresh_u != 0) and np.any(fresh_z != 0)


def test_next_decision_uses_current_observation_and_next_mv_once():
    w = weights()
    w['coef'][0, 88+9*9] = .5
    w['coef'][0, 10*8] = 1.
    w['coef'][0, 9*8] = .1
    w['intercept'][1:] = np.arange(1, 9)
    model = RidgeDynamics(w)
    u, z, current = histories(2)
    path = np.repeat(u[:, -1, None], 4, axis=1)
    path[:, :, 0] = [[7, -1, 6, 2], [1, 8, -2, 4]]
    before = [x.copy() for x in (u, z, current, path)]
    actual = decision_rollout(model, u, z, current, path)
    old_u, old_z = u[:, -1, 0].copy(), current[:, 0].copy()
    expected = np.zeros_like(actual)
    for step in range(4):
        old_z = 1.5*old_z + path[:, step, 0] + .1*old_u
        expected[:, step, 0] = old_z
        expected[:, step, 1:] = current[:, 1:] + (step+1)*np.arange(1, 9)
        old_u = path[:, step, 0]
    np.testing.assert_allclose(actual, expected, rtol=1e-12, atol=1e-12)
    expected_canonical = recursive_rollout(model,
        np.concatenate((u[:, 1:], path[:, 0, None]), axis=1),
        np.concatenate((z[:, 1:], current[:, None]), axis=1), path)
    np.testing.assert_array_equal(actual, expected_canonical)
    for value, copy in zip((u, z, current, path), before):
        np.testing.assert_array_equal(value, copy)


def test_known_pulse_step_and_delayed_response():
    w = weights()
    # First CV: z_k = .5*z_(k-1) + 2*u_k + 3*u_(k-2).
    w['coef'][0, 88+9*9] = -.5
    w['coef'][0, 10*8] = 2.
    w['coef'][0, 8*8] = 3.
    response = analytic_responses(RidgeDynamics(w), 4)
    np.testing.assert_allclose(response['pulse'][:, 0, 0], [2., 1., 3.5, 1.75])
    np.testing.assert_allclose(response['step'][:, 0, 0], [2., 3., 6.5, 8.25])
    np.testing.assert_array_equal(response['pulse'][:, 1:], 0.)
    # A pure one-minute MV delay has exactly zero first response.
    w = weights(); w['coef'][:, 88+9*9:88+10*9] = -np.eye(9)
    w['coef'][0, 9*8] = 1.
    response = analytic_responses(RidgeDynamics(w), 4)
    np.testing.assert_array_equal(response['pulse'][:, 0, 0], [0., 1., 0., 0.])
    np.testing.assert_array_equal(response['step'][:, 0, 0], [0., 1., 1., 1.])


@pytest.mark.parametrize('pattern', ['pulse', 'step'])
def test_all_unit_responses_match_scaled_canonical_forecasts(pattern):
    model = varied_model(); u, z, current = histories(3)
    response = analytic_responses(model, 10)[pattern]
    path = np.repeat(u[:, -1, None], 10, axis=1)
    baseline = decision_rollout(model, u, z, current, path)
    for channel in range(8):
        for amplitude in (-.4, .7):
            trial = path.copy()
            if pattern == 'pulse': trial[:, 0, channel] += amplitude
            else: trial[:, :, channel] += amplitude
            actual = decision_rollout(model, u, z, current, trial) - baseline
            expected = np.broadcast_to(response[:, :, channel]*amplitude, actual.shape)
            np.testing.assert_allclose(actual, expected, atol=2e-12, rtol=2e-12)


def test_superposition_and_operating_state_independence():
    model = varied_model(); u, z, current = histories(3)
    path = np.repeat(u[:, -1, None], 8, axis=1)
    delta = np.asarray([.2, -.1, .5, 0., 0., -.8, .3, -.2])
    expected = np.einsum('hcu,u->hc', analytic_responses(model, 8)['step'], delta)
    actual = decision_rollout(model, u, z, current, path+delta) - decision_rollout(model, u, z, current, path)
    for i in range(len(u)):
        np.testing.assert_allclose(actual[i], expected, rtol=2e-12, atol=2e-12)


def test_current_cv_is_initial_state_and_no_future_cv_argument_exists():
    model = RidgeDynamics(weights()); u, z, current = histories(2)
    z[:, -1] = 999.
    path = np.repeat(u[:, -1, None], 3, axis=1)
    actual = decision_rollout(model, u, z, current, path)
    np.testing.assert_array_equal(actual, np.repeat(current[:, None], 3, axis=1))
    with pytest.raises(TypeError):
        decision_rollout(model, u, z, current, path, future_cv=np.zeros((2, 3, 9)))


def test_companion_spectrum_matches_known_stable_and_unstable_recursions():
    w = weights(); w['coef'][:, 88+9*9:88+10*9] = -np.eye(9)
    w['coef'][0, 88+9*9] = -.5
    model = RidgeDynamics(w); result = autoregressive_stability(model)
    assert result['companion'].shape == (90, 90)
    assert result['spectral_radius'] == pytest.approx(.5)
    state = np.arange(90, dtype=float).reshape(10, 9)
    transformed = (result['companion'] @ state.reshape(-1)).reshape(10, 9)
    np.testing.assert_array_equal(transformed[:-1], state[1:])
    expected = np.zeros(9); expected[0] = .5*state[-1, 0]
    np.testing.assert_array_equal(transformed[-1], expected)
    w['coef'][0, 88+9*9] = .2
    assert autoregressive_stability(RidgeDynamics(w))['spectral_radius'] == pytest.approx(1.2)


def test_trial_paths_execute_initial_change_and_project_pulse_reversal():
    stats = projection_stats()
    current = np.full((3, 8), 5.); current[0, 0] = 0.; current[1, 0] = 10.
    original = current.copy()
    trials = project_trial_paths(current, stats, fraction=.1, horizon=4)
    assert trials['trialfuture_mv'].shape == (3, 2, 16, 4, 8)
    assert trials['normalized_actions'].shape == trials['trialfuture_mv'].shape
    np.testing.assert_array_equal(trials['cases_mv'], np.repeat(np.arange(8), 2))
    np.testing.assert_array_equal(trials['cases_sign'], np.tile([-1., 1.], 8))
    assert list(trials['pattern_names']) == ['pulse', 'step']
    assert not trials['nonzero_executed'][0, 0]
    assert not trials['nonzero_executed'][1, 1]
    assert not trials['full_request_executed'][0, 0]
    assert trials['full_request_executed'][2].all()
    for i in range(3):
        for case in range(16):
            initial = current[i] + trials['executed_delta'][i, case]
            np.testing.assert_array_equal(trials['trialfuture_mv'][i, 0, case, 0], initial)
            np.testing.assert_array_equal(trials['trialfuture_mv'][i, 1, case], np.repeat(initial[None], 4, axis=0))
            np.testing.assert_allclose(trials['trialfuture_mv'][i, 0, case, 1:],
                                       np.repeat(current[i, None], 3, axis=0), atol=1e-14)
            for pattern in range(2):
                path = trials['trialfuture_mv'][i, pattern, case]
                moves = np.diff(np.concatenate((current[i, None], path), axis=0), axis=0)
                np.testing.assert_allclose(moves/np.asarray(stats['action_scale']),
                                           trials['normalized_actions'][i, pattern, case], atol=1e-14)
    np.testing.assert_array_equal(current, original)
    assert (trials['trialfuture_mv'] >= 0).all() and (trials['trialfuture_mv'] <= 10).all()


def test_projection_limits_requested_displacement_when_action_scale_is_smaller():
    stats = projection_stats(); stats['action_scale'] = [.1]*8
    trials = project_trial_paths(np.full((1, 8), 5.), stats, fraction=.5, horizon=2)
    assert not trials['full_request_executed'].any()
    for case, channel in enumerate(trials['cases_mv']):
        assert abs(trials['executed_delta'][0, case, channel]) == pytest.approx(.1)
    np.testing.assert_allclose(trials['trialfuture_mv'][0, 0, :, 1], 5.)


def test_single_step_pulse_has_no_unobserved_reversal():
    trials = project_trial_paths(np.full((2, 8), 5.), projection_stats(), horizon=1)
    np.testing.assert_array_equal(trials['trialfuture_mv'][:, 0], trials['trialfuture_mv'][:, 1])
    np.testing.assert_array_equal(trials['normalized_actions'][:, 0], trials['normalized_actions'][:, 1])


@pytest.mark.parametrize('horizon', [0, -1, 1.5, True])
def test_invalid_horizon_rejected(horizon):
    model = RidgeDynamics(weights())
    with pytest.raises(ValueError): analytic_responses(model, horizon)
    with pytest.raises(ValueError): project_trial_paths(np.full((1, 8), 5.), projection_stats(), horizon=horizon)


@pytest.mark.parametrize('fraction', [0., -.1, 1.1, np.nan, np.inf, True])
def test_invalid_displacement_fraction_rejected(fraction):
    with pytest.raises(ValueError):
        project_trial_paths(np.full((1, 8), 5.), projection_stats(), fraction=fraction)


def test_invalid_histories_observations_paths_and_outside_envelope_rejected():
    model = RidgeDynamics(weights()); u, z, current = histories(2)
    path = np.repeat(u[:, -1, None], 3, axis=1)
    with pytest.raises(ValueError): decision_rollout(model, u[:, :-1], z, current, path)
    with pytest.raises(ValueError): decision_rollout(model, u, z, current[:, :-1], path)
    with pytest.raises(ValueError): decision_rollout(model, u, z, current, path[:, :0])
    bad = path.copy(); bad[0, 0, 0] = np.nan
    with pytest.raises(ValueError): decision_rollout(model, u, z, current, bad)
    bad = np.full((1, 8), 5.); bad[0, 0] = -.001
    with pytest.raises(ValueError, match='outside'): project_trial_paths(bad, projection_stats())
    bad[0, 0] = np.nan
    with pytest.raises(ValueError, match='finite'): project_trial_paths(bad, projection_stats())
    stats = projection_stats(); stats['action_scale'][0] = 0.
    with pytest.raises(ValueError): project_trial_paths(np.full((1, 8), 5.), stats)
    with pytest.raises(TypeError): physical_coefficients(object())


def test_nonfinite_forecasts_raise_without_fallback():
    class Broken:
        def predict_next(self, u, z):
            return np.full((len(u), 9), np.inf)
    u, z, current = histories(1)
    with pytest.raises(FloatingPointError):
        decision_rollout(Broken(), u, z, current, u[:, -1, None])
