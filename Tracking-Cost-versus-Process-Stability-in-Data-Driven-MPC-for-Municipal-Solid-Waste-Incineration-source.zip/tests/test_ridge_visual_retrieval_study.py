"""Stage-level safeguards for the historical-visual Ridge study."""
from pathlib import Path
import json

import numpy as np
import pytest
from threadpoolctl import threadpool_limits

from mswi_experiments import ridge_visual_retrieval_study as study
from mswi_experiments.numeric_baselines import sha256, write_json
from mswi_experiments.ridge_visual_retrieval import NumericalVisualMemory


SNAPSHOT_NAMES = (
    'ridge_visual_retrieval.py', 'ridge_visual_retrieval_study.py',
    'ridge_visual_retrieval_report.py', 'numeric_baselines.py',
    'numeric_baselines_report.py', 'ridge_dynamics.py', 'ridge_validation.py',
    'ridge_validation_report.py', 'visual_diagnostics_statistics.py', 'data.py',
)


def fixture_study(root):
    """Small real models/memories, with only the source-loading boundary stubbed."""
    project = root / 'project'; out = project / 'run'
    for sub in ('models', 'memories'):
        (out / sub).mkdir(parents=True)
    code = project / 'mswi_experiments'; code.mkdir()
    for name in SNAPSHOT_NAMES:
        (code / name).write_text('# frozen synthetic source\n')
    rng = np.random.default_rng(918)
    n = 100
    u = rng.normal(size=(n, 11, 8)); z = rng.normal(size=(n, 10, 9))
    delta = .15 * z[:, -1] + .1 * u[:, -1, :1] + rng.normal(0, .01, (n, 9))
    times = np.arange(n, dtype=np.int64) * 60_000_000_000
    data = {'u_hist': u, 'z_hist': z, 'z_prev': z[:, -1].copy(),
            'z_target': z[:, -1] + delta, 'time_ns': times,
            'source_start_ns': times, 'source_end_ns': times,
            'visual_time_ns': times - 60_000_000_000,
            'train_idx': np.arange(60), 'val_idx': np.arange(60, 80),
            'test_idx': np.arange(80, 100)}
    cfg = {'horizon': 10, 'endpoints': [1, 5, 10], 'memory_items': 512,
           'ridge_alphas': [1, 10], 'threads': 1, 'output_dir': 'run'}
    stats = {'delta_scale': np.ones(9).tolist()}
    prepared = {}
    for width, d in (('52', 52), ('rgb32', 32)):
        visual = rng.normal(size=(n, d))
        prepared['observed52' if width == '52' else 'observed_rgb32'] = visual
        for mode in ('real', 'shuffled'):
            mem = NumericalVisualMemory(data, data['train_idx'], visual,
                max_items=24, permutation_seed=64 if mode == 'shuffled' else None,
                exclusion_permutation_seed=64)
            mem.save(out / f'memories/{width}_{mode}.npz')
            retrieved = np.empty_like(visual)
            for split in ('train', 'val', 'test'):
                rows = data[split + '_idx']
                result = mem.query(u[rows], z[rows],
                    query_indices=rows if split == 'train' else None)
                retrieved[rows] = result['visual']
            prepared[f'{width}_{mode}_visual'] = retrieved
    weights = dict(x_mean=np.zeros(178), x_scale=np.ones(178),
        coef=np.zeros((9, 178)), intercept=np.zeros(9), delta_scale=np.ones(9),
        kind=np.asarray('ridge'), alpha=np.asarray(100.))
    np.savez_compressed(out / 'models/ridge.npz', **weights)
    np.savez_compressed(out / 'chains.npz',
        val=np.stack([np.arange(60, 70), np.arange(61, 71)]),
        test=np.stack([np.arange(80, 90), np.arange(81, 91)]))
    frozen = {str(p.relative_to(out)): sha256(p) for p in out.rglob('*.npz')}
    write_json(out / 'prepare_frozen.json', {'status': 'complete', 'files': frozen})
    return cfg, project, out, data, stats, prepared


def fit_fixture(monkeypatch, state):
    monkeypatch.setattr(study, 'load_prepared', lambda _: state)
    with threadpool_limits(limits=1):
        study.fit('synthetic.json')


def test_fitting_and_selection_are_invariant_to_test_targets(tmp_path, monkeypatch):
    first = fixture_study(tmp_path / 'first')
    second = fixture_study(tmp_path / 'second')
    second[3]['z_target'][second[3]['test_idx']] += 1e9
    fit_fixture(monkeypatch, first)
    fit_fixture(monkeypatch, second)
    a = json.loads((first[2] / 'selection.json').read_text())['models']
    b = json.loads((second[2] / 'selection.json').read_text())['models']
    assert a == b
    for row in a:
        left = study.archive(first[2] / row['model_path'])
        right = study.archive(second[2] / row['model_path'])
        assert left.keys() == right.keys()
        assert all(np.array_equal(left[k], right[k]) for k in left)


def test_observed_diagnostics_use_retrieved_validation_inputs(tmp_path, monkeypatch):
    state = fixture_study(tmp_path)
    cfg, project, out, data, stats, prepared = state
    calls = []
    canonical = study.fit_linear_candidates

    def recording_fit(x, *args, **kwargs):
        calls.append(x.copy())
        return canonical(x, *args, **kwargs)

    monkeypatch.setattr(study, 'fit_linear_candidates', recording_fit)
    fit_fixture(monkeypatch, state)
    for method, design in zip(study.FIT_METHODS, calls):
        width, mode, training = study.FIT_METHODS[method]
        expected = prepared[f'{width}_{mode}_visual']
        for split in ('val', 'test'):
            idx = data[split + '_idx']
            assert np.array_equal(design[idx, 178:], expected[idx])
        idx = data['train_idx']
        if training == 'observed':
            key = 'observed52' if width == '52' else 'observed_rgb32'
            expected = prepared[key]
        assert np.array_equal(design[idx, 178:], expected[idx])


def test_prediction_reloads_frozen_models_without_fitting(tmp_path, monkeypatch):
    state = fixture_study(tmp_path)
    fit_fixture(monkeypatch, state)
    monkeypatch.setattr(study, 'fit_linear_candidates',
        lambda *a, **k: pytest.fail('prediction must never fit or select a model'))
    with threadpool_limits(limits=1):
        study.predict('synthetic.json')
    out = state[2]
    manifest = json.loads((out / 'predictions_manifest.json').read_text())
    assert manifest['status'] == 'complete'
    assert len(manifest['files']) == 54
    for split in ('val', 'test'):
        for method in ('ridge', *study.FIT_METHODS):
            single = study.archive(out / f'one_step/{split}/{method}.npz')
            logged = study.archive(out / f'rollouts/{split}/logged/{method}.npz')
            hold_mv = study.archive(out / f'rollouts/{split}/hold_mv/{method}.npz')
            np.testing.assert_allclose(logged['pred_cv'][:, 0], single['pred_cv'][:2], rtol=0, atol=1e-12)
            np.testing.assert_allclose(logged['pred_cv'][:, 0], hold_mv['pred_cv'][:, 0], rtol=0, atol=1e-12)
            assert logged['pred_cv'].shape == (2, 10, 9)
            assert np.isfinite(logged['pred_cv']).all()
        for method in ('retrieved52', 'retrieved_rgb32'):
            held = study.archive(out / f'rollouts/{split}/logged/{method}_hold_visual.npz')
            assert np.array_equal(held['key_indices'], np.repeat(held['key_indices'][:, :1], 10, axis=1))
            assert np.array_equal(held['donor_indices'], np.repeat(held['donor_indices'][:, :1], 10, axis=1))
    with pytest.raises(FileExistsError, match='already completed'):
        study.predict('synthetic.json')


def test_prediction_rejects_changed_frozen_source(tmp_path, monkeypatch):
    state = fixture_study(tmp_path)
    fit_fixture(monkeypatch, state)
    source = state[1] / 'mswi_experiments/ridge_visual_retrieval.py'
    source.write_text('# changed implementation\n')
    with pytest.raises(ValueError, match='frozen source changed'):
        study.predict('synthetic.json')
    assert not (state[2] / 'one_step').exists()


def test_load_prepared_rejects_changed_configuration_before_loading(tmp_path):
    cfg = {'horizon': 10, 'endpoints': [1, 5, 10], 'memory_items': 512,
           'output_dir': 'run', 'threads': 1}
    write_json(tmp_path / 'config.json', cfg)
    (tmp_path / 'run').mkdir()
    write_json(tmp_path / 'run/config.json', dict(cfg, threads=2))
    with pytest.raises(ValueError, match='configuration changed'):
        study.load_prepared(tmp_path / 'config.json')


def test_verify_rejects_altered_prepared_artifact(tmp_path):
    path = tmp_path / 'prepared.bin'; path.write_bytes(b'original')
    frozen = {path.name: sha256(path)}
    path.write_bytes(b'changed')
    with pytest.raises(ValueError, match='frozen source changed'):
        study.verify(frozen, tmp_path)
