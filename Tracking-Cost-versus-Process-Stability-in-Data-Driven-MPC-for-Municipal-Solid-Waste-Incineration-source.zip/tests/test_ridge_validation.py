"""Synthetic checks for fixed-model recursive and event-study orchestration."""
from copy import deepcopy
import json

import numpy as np
import pytest

from mswi_experiments import ridge_validation as rv
from mswi_experiments.data import MINUTE_NS
from mswi_experiments.ridge_dynamics import RidgeDynamics


def event_fixture():
    n = 40
    u = np.zeros((n, 11, 8), dtype=np.float64)
    # Channel 0 has repeated nonzero changes; ties must remain eligible.
    u[:, -1, 0] = 2.
    u[:, -1, 1] = np.arange(n) / 10
    zprev = np.zeros((n, 9)); target = np.zeros((n, 9))
    target[:20, :6] = np.arange(20)[:, None]
    target[:20, 6:] = np.arange(20)[:, None] / 10
    return {'u_hist': u, 'z_prev': zprev, 'z_target': target,
            'train_idx': np.arange(20), 'time_ns': np.arange(n)*MINUTE_NS,
            'action': np.full((n, 8), 999.)}, {'mv_names': [f'mv_{j}' for j in range(8)]}


def test_thresholds_only_training_data_and_inactive_channels():
    data, stats = event_fixture()
    original = rv.training_event_thresholds(data, stats)
    assert original['mv_thresholds'][0] == 2.
    assert original['mv_thresholds'][2:] == [None]*6
    assert original['mv_nonzero_training_counts'][0] == 20
    changed = deepcopy(data)
    changed['u_hist'][20:] = 1e9
    changed['z_target'][20:] = 1e8
    changed['action'][:] = -1e12
    assert rv.training_event_thresholds(changed, stats) == original
    assert original['direction_deadbands'][0] == 9.5


def test_event_ties_current_operation_and_nonoverlapping_first_selection():
    data, stats = event_fixture()
    thresholds = rv.training_event_thresholds(data, stats)
    chains = np.arange(25)[:, None] + np.arange(10)[None]
    events = rv.select_operation_events(data, chains, thresholds, example_count=2)
    np.testing.assert_array_equal(events['candidate_positions'], np.arange(25))
    np.testing.assert_array_equal(events['selected_positions'], [0, 10, 20])
    np.testing.assert_array_equal(events['example_positions'], [0, 20])
    assert events['trigger_mask'][:, 0].all()
    assert not events['trigger_mask'][:, 2:].any()
    np.testing.assert_array_equal(events['current_delta'][:, 0], 2.)
    assert events['future_change_steps'].shape == (25,)
    with pytest.raises(ValueError, match='must not overlap'):
        rv.select_operation_events(data, chains, thresholds, minimum_separation=9)


def test_time_separation_is_elapsed_time_not_number_of_candidates():
    data, stats = event_fixture()
    data['time_ns'][15:] += 100*MINUTE_NS
    chains = np.array([np.arange(10), np.arange(2, 12), np.arange(15, 25), np.arange(18, 28)])
    events = rv.select_operation_events(data, chains, rv.training_event_thresholds(data, stats))
    np.testing.assert_array_equal(events['selected_positions'], [0, 2])


def test_zero_changes_are_not_events_even_if_threshold_zero():
    data, stats = event_fixture()
    data['u_hist'][:] = 0
    threshold = rv.training_event_thresholds(data, stats)
    threshold['mv_thresholds'] = [0.]*8
    chains = np.arange(20)[:, None]+np.arange(10)[None]
    events = rv.select_operation_events(data, chains, threshold)
    assert len(events['candidate_positions']) == len(events['selected_positions']) == 0
    assert events['example_positions'].dtype == np.int64


def study_fixture(tmp_path):
    rng = np.random.default_rng(39)
    n = 120
    u_raw, z_raw = rng.normal(size=(n+10, 8)), rng.normal(size=(n+10, 9))
    data = {'u_hist': np.stack([u_raw[i:i+11] for i in range(n)]),
            'z_hist': np.stack([z_raw[i:i+10] for i in range(n)]),
            'z_target': z_raw[10:].copy(), 'z_prev': z_raw[9:-1].copy(),
            'time_ns': np.arange(n, dtype=np.int64)*MINUTE_NS,
            'source_start_ns': (np.arange(n, dtype=np.int64)-10)*MINUTE_NS,
            'source_end_ns': (np.arange(n, dtype=np.int64)+1)*MINUTE_NS,
            'train_idx': np.arange(10,35), 'val_idx': np.arange(50,75), 'test_idx': np.arange(90,115),
            'next_idx': np.full(n, -1, dtype=np.int64)}
    for split in ('train', 'val', 'test'):
        idx = data[split+'_idx']; data['next_idx'][idx[:-1]] = idx[1:]
    stats = {'delta_scale': np.arange(1., 10.).tolist(),
             'mv_names': [f'mv_{j}' for j in range(8)], 'cv_names': [f'cv_{j}' for j in range(9)]}
    source = tmp_path/'source/data'; source.mkdir(parents=True)
    np.savez_compressed(source/'dataset.npz', **data)
    (source/'stats.json').write_text(json.dumps(stats))
    (source/'manifest.json').write_text(json.dumps({'synthetic': True}))
    prior = tmp_path/'prior'; checkpoint = prior/'models/ridge/model.npz'; checkpoint.parent.mkdir(parents=True)
    np.savez_compressed(checkpoint, x_mean=np.zeros(178), x_scale=np.ones(178),
        coef=rng.normal(scale=.001, size=(9,178)), intercept=np.zeros(9),
        delta_scale=np.arange(1.,10.), kind=np.asarray('ridge'), alpha=np.asarray(100.))
    model = RidgeDynamics.load(checkpoint)
    selection = {'status': 'complete', 'models': [{'id':'ridge', 'method':'ridge', 'base_model_path':None,
        'model_path':'models/ridge/model.npz', 'selected_alpha':100.}]}
    (prior/'selection.json').write_text(json.dumps(selection))
    (prior/'selection_frozen.json').write_text(json.dumps({'status':'complete', 'files':{
        'selection.json':rv.sha256(prior/'selection.json'), 'models/ridge/model.npz':rv.sha256(checkpoint)}}))
    (prior/'stats.json').write_text(json.dumps(stats))
    records=[]
    for split in ('train','val','test'):
        idx=data[split+'_idx']; path=prior/f'predictions/ridge/{split}.npz';path.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(path,indices=idx,y=data['z_target'][idx],pred=model.predict_next(data['u_hist'][idx],data['z_hist'][idx]))
        records.append({'model_id':'ridge','split':split,'sha256':rv.sha256(path)})
    (prior/'predictions_manifest.json').write_text(json.dumps({'status':'complete','selection_sha256':rv.sha256(prior/'selection.json'),'files':records}))
    predictor={'kind':'ridge','model_id':'ridge','selected_study':'prior','checkpoint':'prior/models/ridge/model.npz',
        'checkpoint_sha256':rv.sha256(checkpoint),'selection_sha256':rv.sha256(prior/'selection.json')}
    (tmp_path/'current_predictor.json').write_text(json.dumps(predictor))
    cfg={'source_run':'source','current_predictor':'current_predictor.json','output_dir':'output','horizon':10,
        'endpoints':[1,5,10],'threads':1,'event_quantile':.9,'event_nonzero_tolerance':1e-6,
        'event_minimum_separation_minutes':10,'direction_deadband_floor':1e-6,'example_count':4}
    config=tmp_path/'config.json';config.write_text(json.dumps(cfg))
    return config,data,stats


def test_predictor_identity_rejects_residual_path_even_with_same_shapes(tmp_path):
    config,_,_=study_fixture(tmp_path)
    rv.resolve_predictor(tmp_path,'current_predictor.json')
    p=tmp_path/'current_predictor.json';value=json.loads(p.read_text());value['checkpoint']='prior/residual.npz';p.write_text(json.dumps(value))
    with pytest.raises(ValueError,match='not the selected direct Ridge path'):
        rv.resolve_predictor(tmp_path,'current_predictor.json')


def test_prepare_freezes_and_run_saves_all_four_branches(tmp_path):
    config,data,_=study_fixture(tmp_path)
    out=rv.prepare(config)
    assert not (out/'rollouts').exists()
    assert rv.prepare(config)==out
    with np.load(out/'chains.npz') as raw:
        assert raw['test_chains'].shape==(16,10)
    manifest=rv.run(config)
    assert len(manifest['files'])==12
    assert manifest['model_retrained'] is False and manifest['trajectories_dropped']==0
    with np.load(out/'rollouts/test/ridge_logged.npz') as logged, np.load(out/'rollouts/test/ridge_hold_mv.npz') as held, np.load(out/'rollouts/test/ridge_teacher_forced.npz') as teacher, np.load(out/'rollouts/test/persistence.npz') as persistence:
        np.testing.assert_allclose(logged['pred_cv'][:,0],teacher['pred_cv'][:,0],rtol=0,atol=1e-10)
        np.testing.assert_array_equal(logged['pred_cv'][:,0],held['pred_cv'][:,0])
        np.testing.assert_array_equal(held['mv_path'],np.repeat(held['mv_path'][:,:1],10,axis=1))
        np.testing.assert_array_equal(persistence['pred_cv'],np.repeat(persistence['initial_zprev'][:,None],10,axis=1))
        assert not np.array_equal(logged['pred_cv'][:,1:],teacher['pred_cv'][:,1:])
    with pytest.raises(ValueError,match='already exist'):
        rv.run(config)


def test_prepared_thresholds_and_current_model_are_immutable(tmp_path):
    config,_,_=study_fixture(tmp_path);out=rv.prepare(config)
    p=out/'event_thresholds.json';value=json.loads(p.read_text());value['mv_thresholds'][0]=1e9;p.write_text(json.dumps(value))
    with pytest.raises(ValueError,match='frozen prepared artifact changed'):
        rv.run(config)


def test_prepared_config_cannot_silently_change(tmp_path):
    config,_,_=study_fixture(tmp_path);rv.prepare(config)
    cfg=json.loads(config.read_text());cfg['event_quantile']=.8;config.write_text(json.dumps(cfg))
    with pytest.raises(ValueError,match='exact configuration'):
        rv.prepare(config)


def test_comparison_reports_roundoff_and_rejects_material_difference():
    expected=np.zeros((2,9));actual=expected+1e-12
    row=rv._prediction_comparison(actual,expected,'fixture')
    assert row['exact_equal'] is False and row['max_absolute_difference']==1e-12
    with pytest.raises(AssertionError,match='differs'):
        rv._prediction_comparison(actual+1e-3,expected,'fixture')
