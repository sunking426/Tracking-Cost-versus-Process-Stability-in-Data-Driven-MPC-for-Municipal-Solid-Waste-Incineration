"""Stage contracts for observed-outcome RGB control-use diagnostics."""
import json

import numpy as np
import pytest
from threadpoolctl import threadpool_limits

from mswi_experiments import rgb_control_diagnostic_study as study
from mswi_experiments.numeric_baselines import sha256, write_json


SNAPSHOT_NAMES = (
    'rgb_control_diagnostic_data.py', 'rgb_control_diagnostic_models.py',
    'rgb_control_diagnostic_study.py', 'rgb_control_diagnostic_report.py',
    'ridge_rgb_residual_data.py', 'ridge_dynamics.py', 'numeric_baselines.py',
    'visual_representation_probe.py', 'data.py',
)


def fixture_study(root):
    project = root / 'project'; out = project / 'run'
    out.mkdir(parents=True)
    code = project / 'mswi_experiments'; code.mkdir()
    for name in SNAPSHOT_NAMES:
        (code / name).write_text('# synthetic source fingerprint\n')
    cfg = {'horizon': 5, 'thermal_quantile': .8, 'action_quantile': .9,
           'stale_min_minutes': 60, 'stale_max_minutes': 70,
           'primary_task': 'thermal_change', 'primary_contrast': 'rgb_vs_quality',
           'output_dir': 'run', 'C_grid': [.01, .1], 'alarm_quantile': .9, 'threads': 1}
    rng = np.random.default_rng(2301)
    data = {}
    for split, n, offset in [('train', 70, 0), ('val', 30, 100), ('test', 30, 200)]:
        full = rng.normal(size=(n, 267))
        data[split+'_numeric'] = full[:, :219].copy()
        data[split+'_quality'] = full[:, :235].copy()
        data[split+'_rgb'] = full.copy()
        stale = full.copy(); stale[:, 235:] = rng.normal(size=(n, 32))
        data[split+'_stale'] = stale
        # Independent labels for the two tasks, each with both classes.
        data[split+'_thermal_change'] = (full[:, 0] > 0).astype(np.int8)
        data[split+'_action_change'] = (full[:, 1] > 0).astype(np.int8)
        data[split+'_indices'] = np.arange(offset, offset+n, dtype=np.int64)
        data[split+'_time_ns'] = (data[split+'_indices']+1000)*60_000_000_000
    np.savez_compressed(out/'prepared.npz', **data)
    write_json(out/'prepare_frozen.json', {'status':'complete',
        'files':{'prepared.npz':sha256(out/'prepared.npz')}})
    return cfg, project, out, data


def fit_fixture(monkeypatch, state):
    monkeypatch.setattr(study, 'load_prepared', lambda _: state)
    with threadpool_limits(limits=1):
        study.fit('synthetic.json')


def test_fit_and_selection_ignore_test_labels_and_features(tmp_path, monkeypatch):
    first = fixture_study(tmp_path/'first')
    second = fixture_study(tmp_path/'second')
    for task in study.TASKS:
        second[3]['test_'+task] = 1-second[3]['test_'+task]
    for variant in study.VARIANTS:
        second[3]['test_'+variant] += 1e6
    fit_fixture(monkeypatch, first)
    fit_fixture(monkeypatch, second)
    left = json.loads((first[2]/'selection.json').read_text())['models']
    right = json.loads((second[2]/'selection.json').read_text())['models']
    assert left == right
    assert len(left) == 8
    for row in left:
        a = study.archive(first[2]/row['model_path'])
        b = study.archive(second[2]/row['model_path'])
        assert a.keys() == b.keys()
        assert all(np.array_equal(a[k], b[k]) for k in a)


def test_each_fit_receives_only_its_train_validation_features_and_labels(tmp_path, monkeypatch):
    state = fixture_study(tmp_path)
    canonical = study.fit_candidates
    calls = []

    def record(x_train, y_train, x_val, y_val, *args, **kwargs):
        calls.append((x_train.copy(), y_train.copy(), x_val.copy(), y_val.copy()))
        return canonical(x_train, y_train, x_val, y_val, *args, **kwargs)

    monkeypatch.setattr(study, 'fit_candidates', record)
    fit_fixture(monkeypatch, state)
    expected = [(t,v) for t in study.TASKS for v in study.VARIANTS]
    assert len(calls) == len(expected)
    for (task, variant), actual in zip(expected, calls):
        keys = ('train_'+variant, 'train_'+task, 'val_'+variant, 'val_'+task)
        assert all(np.array_equal(a, state[3][k]) for a,k in zip(actual, keys))


def test_prediction_freshloads_models_without_fit_and_preserves_threshold(tmp_path, monkeypatch):
    state = fixture_study(tmp_path)
    fit_fixture(monkeypatch, state)
    monkeypatch.setattr(study, 'fit_candidates',
        lambda *a, **k: pytest.fail('prediction must never fit or select'))
    with threadpool_limits(limits=1):
        study.predict('synthetic.json')
    out, data = state[2:]
    selection = json.loads((out/'selection.json').read_text())['models']
    manifest = json.loads((out/'predictions_manifest.json').read_text())
    assert manifest['status'] == 'complete'
    assert len(manifest['files']) == 16
    for row in selection:
        task, variant = row['task'], row['variant']
        weights = study.load_model(out/row['model_path'])
        val_p = study.predict_proba(weights, data['val_'+variant])
        # The threshold is chosen from validation, then transferred unchanged.
        expected_threshold = np.quantile(val_p, .9)
        assert float(weights['threshold']) == pytest.approx(expected_threshold, abs=1e-14)
        for split in ('val','test'):
            saved = study.archive(out/f'predictions/{split}/{task}_{variant}.npz')
            expected = study.predict_proba(weights, data[split+'_'+variant])
            np.testing.assert_allclose(saved['probability'], expected, rtol=0, atol=1e-14)
            assert np.array_equal(saved['indices'], data[split+'_indices'])
            assert np.array_equal(saved['y'], data[split+'_'+task])
            assert float(saved['threshold']) == float(weights['threshold'])
            assert np.array_equal(saved['alarm'], (expected>=float(weights['threshold'])).astype(np.int8))
    with pytest.raises(FileExistsError, match='already completed'):
        study.predict('synthetic.json')


@pytest.mark.parametrize('tamper', ['source', 'model'])
def test_prediction_rejects_changed_frozen_inputs(tmp_path, monkeypatch, tamper):
    state = fixture_study(tmp_path)
    fit_fixture(monkeypatch, state)
    if tamper == 'source':
        path = state[1]/'mswi_experiments/rgb_control_diagnostic_models.py'
    else:
        path = state[2]/'models/thermal_change_numeric.npz'
    with path.open('ab') as stream:
        stream.write(b'changed')
    with pytest.raises(ValueError, match='frozen input changed'):
        study.predict('synthetic.json')
    assert not (state[2]/'predictions').exists()


def test_load_prepared_rejects_changed_configuration(tmp_path):
    state = fixture_study(tmp_path)
    cfg, project, out, _ = state
    write_json(project/'config.json', cfg)
    write_json(out/'config.json', dict(cfg, alarm_quantile=.8))
    with pytest.raises(ValueError, match='configuration changed'):
        study.load_prepared(project/'config.json')


def test_verify_rejects_tampered_prepared_artifact(tmp_path):
    path = tmp_path/'prepared.bin'; path.write_bytes(b'original')
    hashes = {path.name:sha256(path)}
    path.write_bytes(b'altered')
    with pytest.raises(ValueError, match='frozen input changed'):
        study.verify(hashes,tmp_path)
