"""Pure acceptance rules for the frozen two-input control comparison.

The caller owns trajectory provenance, paired starts, canonical metric
calculation, action budgets and completeness checks. This module only judges
already validated paired summaries; it neither loads nor runs an experiment.
Every difference uses the existing report convention: positive means better.
The return difference therefore equals the reduction in cumulative cost.

Interval support is exploratory and conditional on the fitted models. The
individual intervals are not a simultaneous 95% guarantee or a plant-safety
certificate. Action magnitude is constrained upstream, not compared with the
zero-action reference under the zero-degradation rule.
"""
from __future__ import annotations

from collections.abc import Mapping

import numpy as np

from .ridge_control_probe_report import METRICS


REQUIRED_MODELS = ("early", "middle", "late", "pooled_matched")
_UNCERTAINTY = {
    "confidence_level": 0.95,
    "bootstrap_draws": 10000,
    "bootstrap_seed": 20261106,
    "minimum_time_blocks_for_interval_support": 10,
    "exploratory": True,
    "multiple_comparison_adjustment": "none",
}
_INTERVAL_FIELDS = (
    "ci_lower", "ci_upper", "confidence_level", "draws", "seed", "time_blocks"
)


def _positive_integer(value, label):
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, np.integer)) or value <= 0:
        raise ValueError(f"{label} must be a positive integer")
    return int(value)


def _vector(value, label):
    result = np.asarray(value)
    if result.shape != (len(METRICS),) or result.dtype.kind not in "ifu":
        raise ValueError(f"{label} must contain six numeric endpoint values")
    result = result.astype(np.float64)
    if not np.isfinite(result).all():
        raise ValueError(f"{label} must be finite")
    return result


def _validate_protocol(protocol):
    if not isinstance(protocol, Mapping):
        raise ValueError("protocol must be a mapping")
    if (type(protocol.get("schema_version")) is not int or protocol["schema_version"] != 1
            or type(protocol.get("primary_horizon_steps")) is not int
            or protocol["primary_horizon_steps"] != 10
            or protocol.get("reference_policy") != "hold"
            or protocol.get("required_evaluation_models") != list(REQUIRED_MODELS)
            or protocol.get("metric_order") != list(METRICS)
            or protocol.get("cost_improvement_strict") is not True):
        raise ValueError("protocol differs from the fixed ten-step, hold-reference comparison")
    margins = protocol.get("allowed_degradation")
    if not isinstance(margins, Mapping) or set(margins) != set(METRICS[1:]):
        raise ValueError("five explicit zero-degradation margins are required")
    for name, value in margins.items():
        if (isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, float, np.number))
                or not np.isfinite(value) or value != 0):
            raise ValueError(f"{name} allowed degradation must be exactly zero")
    uncertainty = protocol.get("uncertainty")
    if not isinstance(uncertainty, Mapping):
        raise ValueError("fixed uncertainty settings are required")
    for key, expected in _UNCERTAINTY.items():
        value = uncertainty.get(key)
        if isinstance(expected, bool):
            valid = value is expected
        elif isinstance(expected, int):
            valid = type(value) is int and value == expected
        else:
            valid = not isinstance(value, (bool, np.bool_)) and value == expected
        if not valid:
            raise ValueError(f"uncertainty setting {key} differs from the frozen rule")


def _read_interval(summary, model):
    present = [key in summary for key in _INTERVAL_FIELDS]
    if not any(present):
        return None
    if not all(present):
        raise ValueError(f"{model}: interval values and metadata must be supplied together")
    if (isinstance(summary["confidence_level"], (bool, np.bool_))
            or summary["confidence_level"] != _UNCERTAINTY["confidence_level"]
            or _positive_integer(summary["draws"], f"{model}.draws") != _UNCERTAINTY["bootstrap_draws"]
            or _positive_integer(summary["seed"], f"{model}.seed") != _UNCERTAINTY["bootstrap_seed"]):
        raise ValueError(f"{model}: interval settings differ from the frozen protocol")
    blocks = _positive_integer(summary["time_blocks"], f"{model}.time_blocks")
    samples = _positive_integer(summary.get("samples"), f"{model}.samples")
    if blocks > samples:
        raise ValueError(f"{model}: time blocks cannot exceed paired samples")
    if "exploratory" in summary and summary["exploratory"] is not True:
        raise ValueError(f"{model}: incompatible interval metadata exploratory")
    if ("multiple_comparison_adjustment" in summary
            and summary["multiple_comparison_adjustment"] != "none"):
        raise ValueError(f"{model}: incompatible interval metadata multiple_comparison_adjustment")
    lower = _vector(summary["ci_lower"], f"{model}.ci_lower")
    upper = _vector(summary["ci_upper"], f"{model}.ci_upper")
    if np.any(lower > upper):
        raise ValueError(f"{model}: interval lower bound exceeds upper bound")
    return lower, upper, blocks, samples


def assess_contrasts(contrasts, protocol):
    """Assess one candidate versus hold in each of the four required models.

    ``contrasts[model]`` follows ``paired_block_interval`` output, with its six
    values ordered as ``ridge_control_probe_report.METRICS``. A mean-only
    summary may omit all interval fields. Missing/invalid data raise
    ``ValueError`` rather than producing a passing or partially filled result.

    Zero degradation is evaluated on unrounded per-model mean differences,
    not on every step or individual trajectory. No floating-point allowance
    converts a negative guard difference into a pass. Interval labels are
    separate from the point decision; an interval crossing zero is not
    evidence of non-degradation.
    """
    _validate_protocol(protocol)
    if not isinstance(contrasts, Mapping) or set(contrasts) != set(REQUIRED_MODELS):
        raise ValueError("exactly the four required non-planner evaluation models are required")
    models = {}
    for model in REQUIRED_MODELS:
        summary = contrasts[model]
        if not isinstance(summary, Mapping) or "difference" not in summary:
            raise ValueError(f"{model}: a paired difference summary is required")
        means = _vector(summary["difference"], f"{model}.difference")
        interval = _read_interval(summary, model)
        point_passes = means >= 0
        point_passes[0] = means[0] > 0
        failures = []
        endpoints = {}
        for j, name in enumerate(METRICS):
            reason = None if point_passes[j] else (
                "cumulative_cost_did_not_strictly_decrease" if j == 0 else "key_metric_degraded"
            )
            if reason:
                failures.append({"endpoint": name, "reason": reason,
                                 "mean_improvement": float(means[j])})
            endpoints[name] = {
                "mean_improvement": float(means[j]),
                "required_improvement": ">0" if j == 0 else ">=0",
                "point_pass": bool(point_passes[j]),
                "failure_reason": reason,
            }
        interval_reasons = []
        interval_support = False
        if interval is None:
            interval_reasons.append("intervals_not_provided")
            blocks = samples = None
        else:
            lower, upper, blocks, samples = interval
            lower_passes = lower >= 0
            lower_passes[0] = lower[0] > 0
            for j, name in enumerate(METRICS):
                endpoints[name].update({"ci_lower": float(lower[j]), "ci_upper": float(upper[j]),
                                       "interval_lower_pass": bool(lower_passes[j])})
                if not lower_passes[j]:
                    interval_reasons.append(f"{name}:lower_bound_does_not_support_required_improvement")
            if blocks < _UNCERTAINTY["minimum_time_blocks_for_interval_support"]:
                interval_reasons.append("fewer_than_ten_time_blocks")
            interval_support = bool(point_passes.all() and not interval_reasons)
        point_pass = bool(point_passes.all())
        label = ("interval_support_exploratory" if interval_support else
                 "point_pass_uncertain" if point_pass else "point_rejected")
        models[model] = {
            "point_pass": point_pass, "interval_support": interval_support,
            "evidence_label": label, "endpoints": endpoints, "failures": failures,
            "interval_assessed": interval is not None, "interval_reasons": interval_reasons,
            "time_blocks": blocks, "samples": samples,
        }
    point_pass = all(value["point_pass"] for value in models.values())
    interval_support = all(value["interval_support"] for value in models.values())
    return {
        "schema_version": 1,
        "point_pass": point_pass,
        "interval_support": interval_support,
        "evidence_label": ("interval_support_exploratory" if interval_support else
                           "point_pass_uncertain" if point_pass else "point_rejected"),
        "failed_models": [name for name, value in models.items() if not value["point_pass"]],
        "models": models,
        "claim_scope": "Per-model mean comparison; exploratory, conditional on fixed fitted dynamics.",
        "simultaneous_95_percent_guarantee": False,
        "upstream_checks_required": ["trajectory_provenance", "paired_starts", "canonical_metrics",
                                     "complete_trajectories", "action_and_support_constraints"],
    }
