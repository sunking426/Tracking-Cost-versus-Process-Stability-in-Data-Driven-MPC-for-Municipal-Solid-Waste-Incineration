import copy
import json

import numpy as np
import pytest

from mswi_experiments.control_acceptance import REQUIRED_MODELS, assess_contrasts
from mswi_experiments.ridge_control_probe_report import METRICS


@pytest.fixture
def protocol():
    return {
        "schema_version": 1, "primary_horizon_steps": 10, "reference_policy": "hold",
        "required_evaluation_models": list(REQUIRED_MODELS), "metric_order": list(METRICS),
        "allowed_degradation": {name: 0.0 for name in METRICS[1:]},
        "cost_improvement_strict": True,
        "uncertainty": {"confidence_level": 0.95, "bootstrap_draws": 10000,
                        "bootstrap_seed": 20261106, "minimum_time_blocks_for_interval_support": 10,
                        "exploratory": True, "multiple_comparison_adjustment": "none"},
    }


@pytest.fixture
def contrasts():
    return {name: {"difference": [2.0, 0.4, 1.0, 0.1, 0.02, 0.01],
                   "ci_lower": [1.0, 0.1, 0.5, 0.01, 0.0, 0.0],
                   "ci_upper": [3.0, 0.7, 1.5, 0.2, 0.04, 0.02],
                   "confidence_level": 0.95, "draws": 10000, "seed": 20261106,
                   "time_blocks": 12, "samples": 256, "exploratory": True,
                   "multiple_comparison_adjustment": "none"} for name in REQUIRED_MODELS}


def test_all_models_can_support_exploratory_improvement(protocol, contrasts):
    before = copy.deepcopy(contrasts)
    result = assess_contrasts(contrasts, protocol)
    assert result["point_pass"] and result["interval_support"]
    assert result["evidence_label"] == "interval_support_exploratory"
    assert result["simultaneous_95_percent_guarantee"] is False
    assert not result["failed_models"]
    assert contrasts == before
    json.dumps(result, allow_nan=False)


def test_return_gain_cannot_pay_for_temperature_degradation(protocol, contrasts):
    contrasts["early"]["difference"][0] = 100.0
    contrasts["early"]["difference"][1] = -0.01
    result = assess_contrasts(contrasts, protocol)
    assert not result["point_pass"]
    assert result["failed_models"] == ["early"]
    assert result["models"]["early"]["failures"][0]["endpoint"] == "temperature_tracking_mae"


def test_other_models_cannot_hide_one_model_degradation(protocol, contrasts):
    for name in REQUIRED_MODELS:
        contrasts[name]["difference"][3] = 100.0
    contrasts["middle"]["difference"][3] = -0.001
    assert not assess_contrasts(contrasts, protocol)["point_pass"]


@pytest.mark.parametrize("gain", [0.0, -0.1])
def test_cost_reduction_must_be_strict(protocol, contrasts, gain):
    contrasts["late"]["difference"][0] = gain
    result = assess_contrasts(contrasts, protocol)
    assert not result["point_pass"]
    assert result["models"]["late"]["failures"][0]["reason"] == "cumulative_cost_did_not_strictly_decrease"


def test_exactly_unchanged_guards_pass(protocol, contrasts):
    for name in REQUIRED_MODELS:
        contrasts[name]["difference"][1:] = [0.0] * 5
        contrasts[name]["ci_lower"][1:] = [0.0] * 5
        contrasts[name]["ci_upper"][1:] = [0.0] * 5
    assert assess_contrasts(contrasts, protocol)["interval_support"]


def test_even_tiny_negative_guard_is_not_numerical_tolerance(protocol, contrasts):
    contrasts["early"]["difference"][4] = -1e-15
    assert not assess_contrasts(contrasts, protocol)["point_pass"]


@pytest.mark.parametrize("endpoint", range(6))
def test_interval_crossing_zero_does_not_support_improvement(protocol, contrasts, endpoint):
    contrasts["pooled_matched"]["ci_lower"][endpoint] = -0.001
    result = assess_contrasts(contrasts, protocol)
    assert result["point_pass"]
    assert not result["interval_support"]
    assert result["evidence_label"] == "point_pass_uncertain"


def test_cost_interval_touching_zero_is_not_strict_improvement(protocol, contrasts):
    contrasts["early"]["ci_lower"][0] = 0.0
    assert not assess_contrasts(contrasts, protocol)["interval_support"]


def test_few_time_blocks_prevent_interval_support(protocol, contrasts):
    contrasts["late"]["time_blocks"] = 9
    result = assess_contrasts(contrasts, protocol)
    assert result["point_pass"] and not result["interval_support"]
    assert "fewer_than_ten_time_blocks" in result["models"]["late"]["interval_reasons"]


def test_mean_only_input_is_explicitly_uncertain(protocol, contrasts):
    means = {name: {"difference": value["difference"]} for name, value in contrasts.items()}
    result = assess_contrasts(means, protocol)
    assert result["point_pass"] and not result["interval_support"]
    assert result["models"]["early"]["interval_assessed"] is False


@pytest.mark.parametrize("field", ["ci_lower", "ci_upper", "confidence_level", "draws", "seed", "time_blocks", "samples"])
def test_partial_interval_is_rejected(protocol, contrasts, field):
    del contrasts["early"][field]
    with pytest.raises(ValueError):
        assess_contrasts(contrasts, protocol)


@pytest.mark.parametrize("bad", [[1.0] * 5, [1.0] * 7, [[1.0] * 6], [True] * 6,
                                ["1"] * 6, [np.nan] * 6, [np.inf] * 6])
def test_bad_mean_vector_is_rejected(protocol, contrasts, bad):
    contrasts["early"]["difference"] = bad
    with pytest.raises(ValueError):
        assess_contrasts(contrasts, protocol)


@pytest.mark.parametrize("field,value", [("confidence_level", 0.9), ("draws", 1000),
                                        ("seed", 42), ("time_blocks", 0),
                                        ("time_blocks", 1.5), ("samples", 5),
                                        ("exploratory", False), ("exploratory", 1),
                                        ("multiple_comparison_adjustment", "bonferroni")])
def test_wrong_interval_metadata_rejected(protocol, contrasts, field, value):
    contrasts["early"][field] = value
    with pytest.raises(ValueError):
        assess_contrasts(contrasts, protocol)


def test_inverted_interval_rejected(protocol, contrasts):
    contrasts["middle"]["ci_lower"][0] = 4.0
    with pytest.raises(ValueError):
        assess_contrasts(contrasts, protocol)


@pytest.mark.parametrize("mutation", ["missing", "extra", "planner_instead"])
def test_wrong_model_set_rejected(protocol, contrasts, mutation):
    if mutation == "missing":
        del contrasts["late"]
    elif mutation == "extra":
        contrasts["full"] = contrasts["late"]
    else:
        contrasts["full"] = contrasts.pop("late")
    with pytest.raises(ValueError):
        assess_contrasts(contrasts, protocol)


@pytest.mark.parametrize("field,value", [("schema_version", 2), ("schema_version", True),
                                        ("primary_horizon_steps", 50),
                                        ("reference_policy", "linear_bc"),
                                        ("cost_improvement_strict", False),
                                        ("metric_order", list(reversed(METRICS)))])
def test_changed_protocol_is_rejected(protocol, contrasts, field, value):
    protocol[field] = value
    with pytest.raises(ValueError):
        assess_contrasts(contrasts, protocol)


@pytest.mark.parametrize("margin", [0.01, -0.01, np.nan, False, "0"])
def test_nonzero_or_invalid_degradation_margin_rejected(protocol, contrasts, margin):
    protocol["allowed_degradation"][METRICS[1]] = margin
    with pytest.raises(ValueError):
        assess_contrasts(contrasts, protocol)


def test_action_magnitude_cannot_be_added_to_zero_degradation_guards(protocol, contrasts):
    protocol["allowed_degradation"]["action_magnitude"] = 0.0
    with pytest.raises(ValueError):
        assess_contrasts(contrasts, protocol)


def test_uncertainty_protocol_cannot_be_relaxed(protocol, contrasts):
    protocol["uncertainty"]["minimum_time_blocks_for_interval_support"] = 1
    with pytest.raises(ValueError):
        assess_contrasts(contrasts, protocol)
