"""Inventory factory definitions, CSV schema and saved-array shapes; no outcomes."""
from pathlib import Path
import ast,csv,hashlib,json,sys
from openpyxl import load_workbook
import numpy as np

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
DATA=ROOT.parent/'datav2'

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def save(name,x):
    (OUT/name).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

def main():
    bindings={}
    def bind(p):
        p=Path(p);bindings[str(p.relative_to(ROOT)) if p.is_relative_to(ROOT) else '../'+str(p.relative_to(ROOT.parent))]=sha(p)
    book=DATA/'MV和CV.xlsx';bind(book)
    wb=load_workbook(book,read_only=False,data_only=False)
    extracts={s.title:{'cells':{c.coordinate:c.value for row in s for c in row if c.value is not None},
        'merged_ranges':[str(x) for x in s.merged_cells.ranges]} for s in wb}
    save('workbook_evidence.json',extracts)
    code=ROOT/'mswi_experiments/data.py';bind(code)
    constants={}
    for node in ast.parse(code.read_text()).body:
        if isinstance(node,ast.Assign):
            for target in node.targets:
                if isinstance(target,ast.Name) and target.id in ('MV_COLUMNS','MV_NAMES','CV_COLUMNS'):
                    constants[target.id]=ast.literal_eval(node.value)
    modeled=set(constants['MV_COLUMNS']+constants['CV_COLUMNS'])
    inventory=[]
    for sheet,namecol,tagcol,start in [('MV',3,5,3),('CV',2,4,3)]:
        s=wb[sheet]
        for r in range(start,s.max_row+1):
            tag=s.cell(r,tagcol).value
            if not isinstance(tag,str) or not tag.startswith('V4::'):continue
            name=s.cell(r,namecol).value
            inventory.append(dict(sheet=sheet,name=name,tag_cell=s.cell(r,tagcol).coordinate,tag=tag,
                in_current_model=tag in modeled,category=('damper_opening' if sheet=='MV' and '挡板-开度' in name else
                    'switch' if sheet=='MV' and '投切' in name else 'waste_mass_counter' if '累积' in name else 'other')))
    headers={};summary=[]
    raw=sorted((DATA/'ts').glob('DataFile(20*.csv'))
    for path in raw+[DATA/'ts/DataFile_all.csv']:
        bind(path)
        enc='utf-8-sig' if path.name=='DataFile_all.csv' else 'gb18030'
        with path.open(encoding=enc,newline='') as f:
            rd=csv.reader(f)
            if path.name=='DataFile_all.csv':header=next(rd);desc=['']*len(header);unit=['']*len(header);sample=next(rd)
            else:next(rd);header=next(rd);desc=next(rd);unit=next(rd);sample=next(rd)
        headers[path.name]={'header':header,'description':desc,'unit_row':unit,'encoding':enc}
        summary.append(dict(file=str(path),tag_columns=len(header)-1,unique_tags=len(set(header[1:])),
            missing_factory_tags=[r['tag'] for r in inventory if r['tag'] not in header],
            checked_scope='schema only; one first record inspected for field population; no coverage statistics'))
        for row in inventory:
            row[path.name+'_present']=row['tag'] in header
        if '202504' in path.name:
            for row in inventory:
                i=header.index(row['tag']);row['raw_description']=desc[i]
                row['april_first_record_example']=sample[i]
    with (OUT/'field_inventory.csv').open('w',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=list(inventory[0]));wr.writeheader();wr.writerows(inventory)
    save('csv_schema_evidence.json',headers)
    save('source_inventory_summary.json',dict(files=summary,current_model_mv=list(constants['MV_COLUMNS']),
        current_model_cv=list(constants['CV_COLUMNS']),factory_tag_rows=len(inventory),
        damper_openings=sum(r['category']=='damper_opening' for r in inventory),
        switch_tags=sum(r['category']=='switch' for r in inventory),
        mass_counter_tags=sum(r['category']=='waste_mass_counter' for r in inventory),
        no_time_series_metric_computed=True))
    refs={'C0':'mpc_temperature_20261107/trajectories/C/{model}.npz',
        **{f'S{w}':f'mpc_stability_v2_20261108/trajectories/S{w}/{{model}}.npz' for w in (1,2,4,8)},
        'C3':'secondary_air_control_20261107/trajectories/C/{model}.npz',
        'hold':'ridge_policy_pipeline_20261107/trajectories/val/{model}/hold/seed0.npz'}
    shapes=[]
    for model in ('early','middle','late','pooled_matched'):
        entries=[(method,0,rel.format(model=model)) for method,rel in refs.items()]
        entries += [('BC',seed,f'ridge_policy_pipeline_20261107/trajectories/val/{model}/bc/seed{seed}.npz') for seed in (11,23,37,53,71)]
        for method,seed,rel in entries:
            path=ROOT/'experiment_runs'/rel;bind(path);bind(path.with_suffix('.json'))
            meta=json.loads(path.with_suffix('.json').read_text());assert sha(path)==meta['sha256']
            with np.load(path,allow_pickle=False) as a:
                shape=list(a['pred_cv'].shape)
                shapes.append(dict(method=method,model=model,seed=seed,path=str(path.relative_to(ROOT)),
                    sha256=sha(path),pred_cv_shape=shape,available_horizons=[h for h in (10,50) if shape[1]>=h]))
    save('trajectory_inventory.json',shapes)
    for rel in ['experiment_protocols/mpc_C_frozen_20261107/config.json',
        'experiment_runs/secondary_air_control_20261107/protocol.json',
        'experiment_runs/ridge_policy_pipeline_20261107/protocol.json',
        'experiment_runs/mpc_stability_v2_20261108/protocol.json',
        'experiment_runs/ridge_control_probe_20261106/inputs/val.npz']:
        bind(ROOT/rel)
    save('source_bindings.json',bindings)
    print(json.dumps(dict(workbook_sheets=wb.sheetnames,field_rows=len(inventory),
        damper_columns=sum(r['category']=='damper_opening' for r in inventory),
        switch_columns=sum(r['category']=='switch' for r in inventory),
        all_raw_schemas_have_factory_tags=all(not r['missing_factory_tags'] for r in summary),
        trajectories=len(shapes),three_channel_available_horizons=[10],new_outcome_statistics_computed=False),ensure_ascii=False))

if __name__=='__main__':main()
