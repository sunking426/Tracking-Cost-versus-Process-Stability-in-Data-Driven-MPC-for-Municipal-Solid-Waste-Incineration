# Package validation

Validation used the recorded Python dependency environment on macOS ARM64.

- All 8,070 source images were reprocessed. Descriptors and all prepared arrays matched.
- Five Ridge models, the support bank, reset histories and residual draws were rebuilt.
- Three GRU fits and their correction models reproduced all 24 prediction archives exactly.
- Five BC and five TD3+BC fits reproduced the archived network parameters exactly.
- Nine representative control conditions were executed twice; all output arrays matched.
- Four cases using the newly fitted models matched the archived control arrays.
- All final statistics and paired intervals were recalculated; seven CSVs matched exactly.
- Earlier forecasting, validation and visual endpoints passed 44 arithmetic checks.
- All 16 figure PNGs matched the manuscript.
- A clean checkout imported all ten assets, checked all hashes and repeated pooled MPC twice.
- Resume, source/data Git separation and 25 selected tests passed.

The complete 273-job evaluation was not rerun during packaging. Its original
546 executions and full 9,935-file manifest are included. The README provides
the full rerun command. Auxiliary visual variants retain their original code
and assets; their full fresh refits are not part of the unified numerical runner.
A fresh pip installation and hosted CI run were not performed. See
`PACKAGE_CHECKS.json` for individual checks and the recorded environment.
