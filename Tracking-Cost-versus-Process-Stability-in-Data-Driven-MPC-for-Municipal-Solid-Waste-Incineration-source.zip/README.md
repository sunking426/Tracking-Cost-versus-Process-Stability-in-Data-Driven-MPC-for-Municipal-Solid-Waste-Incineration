# Tracking Cost versus Process Stability in Data-Driven MPC for Municipal Solid Waste Incineration

Code and data for **Tracking Cost versus Process Stability in Data-Driven MPC
for Municipal Solid Waste Incineration**, Yang Wang and Enhong Chen.

The controller uses a Ridge increment model, cross-entropy planning and a
historical state–action support filter. The experiments compare tracking and
stability objectives on common initial conditions. 

## Requirements

The recorded environment is Python 3.10.8 on macOS ARM64, using CPU computation.
Use Linux or macOS; Windows users should use WSL because source image names
contain colons. Package versions are given in `requirements.txt` and the recorded
dependency closure is in `requirements-lock.txt`. Optional RGB experiments also
require `requirements-visual-representation.txt`.

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

## Availability

This repository currently provides source code, configuration files and documentation.
Raw data, image files, model checkpoints, archived trajectories, the manuscript and
supplementary paper files have not been uploaded. The reproduction commands require
the corresponding local data assets. No data release is currently available here.

## Data

If you already have the matching `mswi-data-*.tar.gz` archives, keep them in one
directory and import them from the repository root:

```bash
python reproduce.py import-data --assets ../release-assets
python reproduce.py verify --full
```

`data/assets.json` lists every data file and its SHA256 checksum. The assets
contain:

- Three DCS exports: 93,600 one-minute records from April–June 2025.
- The 8,070 source flame images used by the experiments, visual descriptors and
  the plant variable table.
- Causal data windows, training statistics, model checkpoints and support banks.
- Validation studies and the final 273 evaluation batches, including both
  archived executions of each batch.

Historical provenance files retain their original paths. The commands below use
repository-relative inputs and write new results under `outputs/`. They do not
write into the archived studies.

## Reproduction

### Data and Ridge models

```bash
python reproduce.py prepare --extract-images
python reproduce.py fit-ridge
```

The first command re-extracts the 52 image descriptors, rebuilds the causal data
windows and compares all arrays with the archived dataset. The resulting split
contains 43,406 training, 9,228 validation and 9,226 test windows. The second
command refits the full, early, middle, late and pooled Ridge models, rebuilds
the support bank, selects the reset histories and generates the training-residual
disturbances. Comparisons with the archived numerical assets are recorded in
`outputs/retrained/`.

### Control evaluation

```bash
python reproduce.py evaluate --jobs smoke --steps 10 --compare
```

The smoke suite covers Hold, BC, TD3+BC, both MPC objectives, both ablations,
residual feedback and GRU feedback. Every job retains the original batch of
256 starts and the original ten-step planning horizon. It compares the generated
arrays with the corresponding saved trajectory prefixes.

To rerun all 273 batches at their recorded horizons, with two fresh executions
per batch:

```bash
python reproduce.py evaluate --jobs all --repeats 2 --compare --output outputs/full_evaluation
```

This is a long CPU run. The original single-thread pooled MPC batch required
about 138 seconds for 256 starts over 50 minutes; total time depends on the
machine. To continue a completed part of the run, repeat the command with
`--resume`. A changed or incomplete result is rejected.

A particular batch can be selected by its original job ID:

```bash
python reproduce.py evaluate --jobs 52 --steps 10 --compare --output outputs/job52
```

Job definitions are in
`experiment_runs/heldout_final_20261109/protocol.json`. `--steps 10` truncates the
feedback experiment, not the MPC planning horizon.

### Statistics and figures

```bash
python reproduce.py statistics
python reproduce.py audit-earlier
python reproduce.py figures --statistics outputs/statistics
```

`statistics` recomputes the final means, paired differences, SD ratios,
ablations and fan curves from all 273 accepted trajectories. The bootstrap uses
10,000 resamples of the 256 original starts. Each regenerated CSV is compared
with the archived result. `audit-earlier` recalculates the forecasting,
validation-scan and visual-comparison endpoints. The `figures` command additionally
requires the paper figure inputs, which are not included in this source-only upload.

Statistics can also be calculated from a complete new control run:

```bash
python reproduce.py statistics --evaluation outputs/full_evaluation --output outputs/new_statistics
python reproduce.py figures --statistics outputs/new_statistics --output outputs/new_figures
```

The output directories must be new. Existing results are not overwritten.

### Refitting GRU and policy models

After `prepare` and `fit-ridge`, run:

```bash
python reproduce.py train-forecasts
python reproduce.py train-policies
python reproduce.py evaluate --workspace outputs/retrained --jobs all --repeats 2 --output outputs/refitted_evaluation
python reproduce.py statistics --evaluation outputs/refitted_evaluation --output outputs/refitted_statistics
```

`train-forecasts` runs the original three-seed GRU, Ridge and residual-correction
training procedure. `train-policies` rebuilds the policy training samples and
fits BC and model-assisted TD3+BC for seeds 11, 23, 37, 53 and 71. The controller
settings remain fixed. Refitted models are stored in a separate workspace;
archive comparisons use the original frozen models. Different numerical
libraries can affect refitted weights and closed-loop results.

The auxiliary visual studies retain their configurations, extraction/training
code, pretrained image weights, saved predictions and reports. Their relation
to the manuscript is listed in `docs/EXPERIMENTS.md`.

## Reference results

Residual-disturbed ten-minute feedback, averaged equally over four Ridge models:

| Quantity | BC | MPC0 | MPC8 |
|---|---:|---:|---:|
| Original return | -39.8206 | -34.8954 | -34.9545 |
| Temperature detrended SD (°C) | 2.4177 | 2.4880 | 2.3928 |
| Steam detrended SD (t/h) | 0.2456 | 0.2499 | 0.2405 |
| Oxygen detrended SD (percentage points) | 0.1966 | 0.1988 | 0.1953 |

The additional variation penalty is used in planning; reported original returns
use the unchanged evaluation reward. Fan settings retain the DCS scale.
The feedback experiments are simulations in fitted models. Repeated executions,
policy seeds and disturbance draws do not increase the number of independent
starting conditions.

## Repository structure

```text
mswi_experiments/          Original numerical and learning implementations
reproduction/             Portable data, training, evaluation and analysis entry points
experiment_protocols/     Frozen controller and experiment settings
experiment_runs/          Archived inputs, checkpoints, predictions and trajectories
artifacts/                Corrected visual descriptors and provenance
data/raw/                Source DCS records and flame images
data/assets.json         Release-asset manifest
tests/                    Numerical and package tests
outputs/                  New reproduction results
```

See `docs/EXPERIMENTS.md` for the figure/table mapping,
`docs/DATA.md` for variable definitions and `docs/REPRODUCTION.md` for numerical
comparison rules. The package verification record is in `verification/`.

## Citation and license

Citation metadata are provided in `CITATION.cff`. No public distribution license
has been selected for the research code or industrial data. Third-party notices
are listed in `THIRD_PARTY_NOTICES.md`.
