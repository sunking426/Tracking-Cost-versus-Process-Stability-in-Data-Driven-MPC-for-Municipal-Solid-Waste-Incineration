# Third-party material

- `paper/sn-jnl.cls` and `paper/sn-basic.bst` are Springer/LaTeX template files.
  Their original license notices are retained in the files.
- The optional visual diagnostics use the torchvision ResNet18 ImageNet1K V1
  checkpoint (`resnet18-f37072fd.pth`). Its source is
  <https://download.pytorch.org/models/resnet18-f37072fd.pth>.
  The archive records the exact checksum. Consult the torchvision distribution
  and the checkpoint provider for their applicable terms.
- Python dependencies are installed separately and retain their own licenses.
