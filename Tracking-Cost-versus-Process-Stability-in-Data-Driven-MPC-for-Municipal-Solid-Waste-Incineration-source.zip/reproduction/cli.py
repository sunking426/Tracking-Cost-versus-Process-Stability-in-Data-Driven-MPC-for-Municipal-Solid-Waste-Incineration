"""Process orchestration; scientific definitions remain in mswi_experiments."""
from pathlib import Path
import argparse,json,os,subprocess,sys
from .files import import_assets,read,sha,verify,write,validate_resume
ROOT=Path(__file__).resolve().parents[1]

def launch(task,**options):
    command=[sys.executable,'-m','reproduction.worker',task]
    for key,value in options.items():
        if value is None:continue
        if isinstance(value,bool):
            if value:command.append('--'+key.replace('_','-'))
        else:command+=['--'+key.replace('_','-'),str(value)]
    env=os.environ.copy()
    for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','BLIS_NUM_THREADS','NUMEXPR_NUM_THREADS'):env[k]='1'
    env['PYTHONHASHSEED']='0';env['PYTHONPATH']=str(ROOT)
    env.setdefault('MPLCONFIGDIR',str(ROOT/'outputs/matplotlib_cache'))
    subprocess.run(command,cwd=ROOT,env=env,check=True)

def parser():
    p=argparse.ArgumentParser(description=__doc__);s=p.add_subparsers(dest='command',required=True)
    a=s.add_parser('import-data',help='Import the release assets after checking their hashes');a.add_argument('--assets',type=Path,required=True)
    a=s.add_parser('verify',help='Verify included data and original frozen source bindings');a.add_argument('--full',action='store_true')
    a=s.add_parser('prepare',help='Rebuild all causal data windows from the raw records');a.add_argument('--extract-images',action='store_true');a.add_argument('--output',type=Path,default=ROOT/'outputs/prepared')
    a=s.add_parser('fit-ridge',help='Fit Ridge predictors, support reference, starts and residuals');a.add_argument('--data',type=Path,default=ROOT/'outputs/prepared');a.add_argument('--workspace',type=Path,default=ROOT/'outputs/retrained')
    a=s.add_parser('train-forecasts',help='Refit all three GRUs, Ridge and corrected-GRU forecasters');a.add_argument('--data',type=Path,default=ROOT/'outputs/prepared');a.add_argument('--workspace',type=Path,default=ROOT/'outputs/retrained');a.add_argument('--seeds',default='11,23,37')
    a=s.add_parser('train-policies',help='Rebuild policy training data and fit BC/TD3+BC');a.add_argument('--workspace',type=Path,default=ROOT/'outputs/retrained');a.add_argument('--seeds',default='11,23,37,53,71')
    a=s.add_parser('evaluate',help='Run frozen or newly fitted controllers in fresh processes')
    a.add_argument('--jobs',default='smoke',help='smoke, all, or comma-separated original job IDs');a.add_argument('--steps',type=int,choices=(10,50));a.add_argument('--repeats',type=int,default=1,choices=(1,2))
    a.add_argument('--output',type=Path,default=ROOT/'outputs/evaluation');a.add_argument('--workspace',type=Path);a.add_argument('--compare',action='store_true');a.add_argument('--resume',action='store_true')
    a=s.add_parser('statistics',help='Recompute tables and intervals from all 273 accepted trajectories');a.add_argument('--output',type=Path,default=ROOT/'outputs/statistics');a.add_argument('--evaluation',type=Path)
    a=s.add_parser('audit-earlier',help='Recompute forecasting, validation-scan and visual endpoints');a.add_argument('--output',type=Path,default=ROOT/'outputs/earlier_statistics')
    a=s.add_parser('figures',help='Redraw every main/supplementary figure');a.add_argument('--output',type=Path,default=ROOT/'outputs/figures');a.add_argument('--statistics',type=Path)
    a=s.add_parser('all',help='Rebuild data/Ridge, rerun all frozen control jobs twice, reconstruct statistics and figures');a.add_argument('--output',type=Path,default=ROOT/'outputs')
    return p

def selected_jobs(spec):
    jobs=read(ROOT/'experiment_runs/heldout_final_20261109/protocol.json')['jobs']
    if spec=='all':return jobs
    if spec=='smoke':
        chosen=[]
        rules=[('D','pooled_matched',m,11 if m in ('bc','ridge_td3bc') else 0,0) for m in ('hold','bc','ridge_td3bc','C0','S8','D1','D2')]
        rules += [('C','pooled_matched','S8',0,0),('B','gru23','S8',0,0)]
        for rule in rules:
            chosen.append(next(j for j in jobs if tuple(j[k] for k in ('layer','model','method','seed','replicate'))==rule))
        return chosen
    ids=[int(x) for x in spec.split(',')]
    if len(set(ids))!=len(ids) or any(i<0 or i>=len(jobs) for i in ids):raise ValueError('Invalid original job ID list')
    return [jobs[i] for i in ids]

def main(argv=None):
    a=parser().parse_args(argv);c=a.command
    if c=='import-data':print(json.dumps(import_assets(ROOT,a.assets),indent=2));return
    if c=='verify':
        r=verify(ROOT,a.full);write(ROOT/'outputs/verification.json',r);print(json.dumps(r,indent=2));return
    if c in ('prepare','fit-ridge','train-forecasts','train-policies','statistics','audit-earlier','figures'):
        options=vars(a).copy();options.pop('command');launch(c,**options);return
    if c=='evaluate':
        if a.compare and a.workspace:raise ValueError('Archive comparison is for frozen models; omit --workspace')
        verify(ROOT,False);a.output=a.output.resolve();results=[]
        for job in selected_jobs(a.jobs):
            steps=min(a.steps or job['horizon'],job['horizon'])
            for repeat in range(a.repeats):
                dest=a.output/f"job{job['id']:03d}"/f'repeat{repeat}'
                if dest.exists():
                    if not a.resume:raise FileExistsError(str(dest)+' exists; choose a new output or --resume')
                    done=read(dest/'result.json')
                    validate_resume(done,a.workspace.resolve() if a.workspace else ROOT,ROOT)
                    if done['status']!='passed' or done['job']!=job or done['steps']!=steps or done['trajectory_sha256']!=sha(dest/'trajectory.npz'):raise ValueError('Invalid resume result: '+str(dest))
                else:launch('case',job=job['id'],steps=steps,output=dest,workspace=a.workspace,compare=a.compare)
                results.append(read(dest/'result.json'))
            if a.repeats==2:
                left,right=[read(a.output/f"job{job['id']:03d}"/f'repeat{r}'/'result.json')['array_hashes'] for r in range(2)]
                if left!=right:raise AssertionError('Computational repeats differ: '+str(job['id']))
            write(a.output/'evaluation.json',{'status':'running','cases_completed':len(results),'requested_jobs':a.jobs,'repeats':a.repeats,'results':results})
        write(a.output/'evaluation.json',{'status':'passed','cases_completed':len(results),'requested_jobs':a.jobs,'repeats':a.repeats,'results':results});return
    if c=='all':
        verify(ROOT,True)
        launch('prepare',output=a.output/'prepared',extract_images=True)
        launch('fit-ridge',data=a.output/'prepared',workspace=a.output/'retrained')
        main(['evaluate','--jobs','all','--repeats','2','--compare','--output',str(a.output/'evaluation')])
        launch('statistics',output=a.output/'statistics',evaluation=a.output/'evaluation')
        launch('audit-earlier',output=a.output/'earlier_statistics')
        launch('figures',output=a.output/'figures',statistics=a.output/'statistics')
