"""Fresh-process worker for data, models, control and result reconstruction."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,sys,time
from .files import read,sha,write
ROOT=Path(__file__).resolve().parents[1]
MODELS=('early','middle','late','pooled_matched')

def output_dir(path):
    p=Path(path).resolve()
    if p==ROOT or ROOT/'experiment_runs'==p or ROOT/'experiment_runs' in p.parents:
        raise ValueError('Reproduction outputs must not overwrite the archived experiment_runs')
    p.mkdir(parents=True,exist_ok=False);return p

def load_npz(path):
    import numpy as np
    with np.load(path,allow_pickle=False) as a:return {k:a[k] for k in a.files}

def compare_arrays(actual,expected,prefix=False):
    import numpy as np
    errors={}
    for k,a in actual.items():
        if k not in expected:raise AssertionError('Reference field absent: '+k)
        b=expected[k]
        if prefix and a.ndim>=2 and b.ndim>=2 and a.shape[0]==b.shape[0] and a.shape[1]<=b.shape[1]:b=b[:,:a.shape[1]]
        if a.shape!=b.shape:raise AssertionError('Shape mismatch: '+k)
        if np.issubdtype(a.dtype,np.floating):
            tol=1e-5 if k in ('reward','tracking','oxygen','movement','violation_cost') else 1e-8
            if 'action' in k or k=='u_path':tol=1e-10
            np.testing.assert_allclose(a,b,rtol=0,atol=tol,err_msg=k)
            errors[k]=float(np.max(np.abs(a-b))) if a.size else 0.
        else:np.testing.assert_array_equal(a,b,err_msg=k)
    return errors

def prepare(a):
    from mswi_experiments.data import prepare_data,load_data
    from mswi_experiments.run import read_config
    out=output_dir(a.output)
    cfg=read(ROOT/'experiment_strengthening.json')
    cfg['data']['process_files']=[str(p) for p in sorted((ROOT/'data/raw/process').glob('*.csv'))]
    cfg['data']['feature_file']=str(ROOT/'artifacts/visual_features_corrected.csv')
    if a.extract_images:
        # Use the public extraction entry point, preserving its measured pixel definitions.
        import subprocess
        subprocess.run([sys.executable,'-m','mswi_experiments.visual_features',
            '--selection-csv',str(ROOT/'image_features_all.csv'),'--image-dir',str(ROOT/'data/raw/images'),
            '--output',str(out/'visual_features_corrected.csv'),'--workers','2'],cwd=ROOT,check=True)
        if sha(out/'visual_features_corrected.csv')!=sha(ROOT/'artifacts/visual_features_corrected.csv'):
            raise AssertionError('Re-extracted image descriptors differ')
        cfg['data']['feature_file']=str(out/'visual_features_corrected.csv')
    data,stats,manifest=prepare_data(cfg,out/'data')
    reference,rstats,_=load_data(ROOT/'experiment_runs/corrected_vision/data')
    import numpy as np
    for k,v in data.items():np.testing.assert_array_equal(v,reference[k],err_msg=k)
    if stats!=rstats:raise AssertionError('Training statistics differ')
    write(out/'checks.json',{'status':'passed','samples':len(data['time_ns']),
        'split':{s:len(data[s+'_idx']) for s in ('train','val','test')},
        'all_arrays_equal_reference':True,'images_reextracted':a.extract_images})
    print('Causal data reconstruction passed.',flush=True)

def workspace(path,data_folder=None):
    p=Path(path).resolve()
    if p==ROOT or ROOT in p.parents and ROOT/'outputs' not in p.parents:
        raise ValueError('Use an independent workspace under outputs/ or outside the repository')
    if not p.exists():
        p.mkdir(parents=True)
        shutil.copytree(ROOT/'mswi_experiments',p/'mswi_experiments',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
        shutil.copytree(ROOT/'experiment_protocols',p/'experiment_protocols')
        write(p/'DERIVED_WORKSPACE.json',{'kind':'refit','created_from':sha(ROOT/'paper/main.pdf'),
            'scientific_code':{f.name:sha(f) for f in (ROOT/'mswi_experiments').glob('*.py')},
            'frozen_hyperparameters_unchanged':True,'reference_results_overwritten':False})
    if not (p/'DERIVED_WORKSPACE.json').exists():raise ValueError('Not a generated training workspace')
    if data_folder is not None:
        source=Path(data_folder).resolve()/'data';destination=p/'experiment_runs/corrected_vision/data'
        if not destination.exists():shutil.copytree(source,destination)
        else:
            if sha(source/'dataset.npz')!=sha(destination/'dataset.npz'):raise ValueError('Workspace data changed')
    return p

def fit_ridge(a):
    import numpy as np
    from mswi_experiments.data import load_data
    from mswi_experiments.numeric_baselines import numeric_features,fit_linear_candidates
    from mswi_experiments.ridge_response_study import training_blocks,fit_support,select_anchors
    from mswi_experiments.ridge_dynamics import RidgeDynamics
    w=workspace(a.workspace,a.data);ref=w/'experiment_runs/ridge_control_probe_20261106'
    if ref.exists():raise FileExistsError('Ridge workspace already fitted')
    (ref/'evaluation_models').mkdir(parents=True);(ref/'inputs').mkdir()
    data,stats,_=load_data(w/'experiment_runs/corrected_vision/data');write(ref/'stats.json',stats)
    x=numeric_features(data);y=np.asarray(data['z_target'],float);prev=np.asarray(data['z_prev'],float)
    groups,details=training_blocks(data);parameters=read(ROOT/'numeric_baselines_20261104.json')
    results=[]
    for mid in ('full',)+MODELS:
        alphas=parameters['diagnostics']['ridge_alphas'] if mid=='full' else [100.]
        m,candidates,chosen=fit_linear_candidates(x,y-prev,prev,y,groups[mid],data['val_idx'],stats['delta_scale'],alphas)
        if float(m['alpha'])!=100.:raise AssertionError('Recorded Ridge selection was not reproduced')
        np.savez_compressed(ref/f'evaluation_models/{mid}.npz',**m)
        expected=load_npz(ROOT/f'experiment_runs/ridge_control_probe_20261106/evaluation_models/{mid}.npz')
        errors=compare_arrays(m,expected)
        results.append({'model':mid,'rows':len(groups[mid]),'alpha':float(m['alpha']),'maximum_errors':errors})
    support=fit_support(data,bank_size=2048,calibration_size=1024,quantile=.95,exclusion_minutes=11)
    np.savez_compressed(ref/'support.npz',**support)
    support_errors=compare_arrays(support,load_npz(ROOT/'experiment_runs/ridge_control_probe_20261106/support.npz'))
    for split in ('val','test'):
        chain,meta=select_anchors(data,stats,split,10,11,256);idx=chain[:,0]
        vals={k:np.asarray(data[k],float)[idx] for k in ('u_hist','z_hist','z_current')}
        vals.update(indices=idx,time_ns=data['time_ns'][idx])
        compare_arrays(vals,load_npz(ROOT/f'experiment_runs/ridge_control_probe_20261106/inputs/{split}.npz'))
        np.savez_compressed(ref/f'inputs/{split}.npz',**vals)
    make_residuals(w,data,groups)
    write(w/'ridge_checks.json',{'status':'passed','models':results,'support_errors':support_errors,'blocks':details})
    print('All five Ridge predictors, support and reset histories reconstructed.',flush=True)

def make_residuals(w,data,groups):
    import numpy as np
    from mswi_experiments.ridge_dynamics import RidgeDynamics
    ref=w/'experiment_runs/ridge_control_probe_20261106';out=w/'experiment_runs/heldout_final_20261109/residuals';out.mkdir(parents=True)
    starts=load_npz(ref/'inputs/test.npz')['indices'];reports=[]
    for mid in MODELS:
        rows=data['train_idx'] if mid=='pooled_matched' else groups[mid]
        u,z,truth,times=[data[k][rows] for k in ('u_hist','z_hist','z_target','time_ns')]
        model=RidgeDynamics.load(ref/f'evaluation_models/{mid}.npz')
        pred=np.concatenate([model.predict_next(u[i:i+512],z[i:i+512]) for i in range(0,len(rows),512)])
        residual=truth.astype(float)-pred
        positions=np.lib.stride_tricks.sliding_window_view(np.arange(len(rows)),10)
        bt=times[positions];positions=positions[(np.diff(bt,axis=1)==60_000_000_000).all(1)&(bt[:,0]//86_400_000_000_000==bt[:,-1]//86_400_000_000_000)]
        if not len(positions):raise ValueError('No consecutive training residual blocks')
        chosen=np.empty((256,5,5),np.int64)
        for i,idx in enumerate(starts):
            for rep in range(5):
                rng=np.random.default_rng(np.random.SeedSequence([20261109,MODELS.index(mid),int(idx),rep]));chosen[i,rep]=rng.integers(0,len(positions),5)
        values={'residual':residual[positions[chosen]].reshape(256,5,50,9),'start_indices':starts,'chosen_block_positions':chosen,
            'residual_source_indices':rows[positions[chosen]].reshape(256,5,50),'residual_source_time_ns':times[positions[chosen]].reshape(256,5,50)}
        errors=compare_arrays(values,load_npz(ROOT/f'experiment_runs/heldout_final_20261109/residuals/{mid}.npz'))
        np.savez_compressed(out/f'{mid}.npz',**values);reports.append({'model':mid,'maximum_errors':errors})
    write(w/'residual_checks.json',{'status':'passed','models':reports,'pooled_scope':'all original training rows; retained protocol exception'})

def forecasts(a):
    from mswi_experiments import numeric_baselines as n
    w=workspace(a.workspace,a.data);cfg=read(ROOT/'numeric_baselines_20261104.json')
    cfg.update(source_run=str(w/'experiment_runs/corrected_vision'),output_dir=str(w/'experiment_runs/numeric_baselines_20261104'))
    seeds=list(map(int,a.seeds.split(',')))
    if any(s not in (11,23,37) for s in seeds) or not seeds:raise ValueError('Use the recorded forecast seeds')
    cfg['diagnostics']['seeds']=seeds
    path=w/'numeric_training.json';write(path,cfg)
    n.prepare(path);n.train(path);n.predict(path)
    print('Forecast training and prediction completed.',flush=True)

def policies(a):
    # Imported only after the new workspace was inserted into sys.path in main().
    import numpy as np
    from mswi_experiments.ridge_policy_study import OUT,ROOT as WROOT,prepare,read_npz
    from mswi_experiments.ridge_policy_training import bc_fit,train_one
    from mswi_experiments.data import load_data
    if not (OUT/'logged_train.npz').exists():prepare()
    train,val=read_npz(OUT/'logged_train.npz'),read_npz(OUT/'logged_val.npz')
    data,_,_=load_data(WROOT/'experiment_runs/corrected_vision/data');resets=np.load(OUT/'training_reset_indices.npy')
    for seed in map(int,a.seeds.split(',')):
        if seed not in (11,23,37,53,71):raise ValueError('Use the recorded policy seeds')
        bc_fit(seed,'full',train,val);train_one('ridge_td3bc',seed,train,data,resets)


def case(a):
    import numpy as np
    from mswi_experiments.ridge_policy_study import shared,read_npz
    from mswi_experiments.ridge_policy import RidgePolicyEnv
    from mswi_experiments.ridge_policy_evaluation import DecisionPolicy
    from mswi_experiments.ridge_dynamics import RidgeDynamics
    from mswi_experiments.mpc_stability import StabilityCEM
    from mswi_experiments.mpc_ablation import AblationExecution,AblationCEM
    from mswi_experiments.s8_cross_evaluation import GRUFeedback,ResidualFeedback
    from mswi_experiments.frozen_mpc import load_frozen_mpc
    root=Path(a.workspace).resolve() if a.workspace else ROOT
    job=read(ROOT/'experiment_runs/heldout_final_20261109/protocol.json')['jobs'][a.job]
    out=output_dir(a.output);begin=time.monotonic();ref=root/'experiment_runs/ridge_control_probe_20261106'
    if a.workspace:
        if not (root/'DERIVED_WORKSPACE.json').exists():raise ValueError('Not a derived model workspace')
        parent=read(root/'experiment_protocols/mpc_C_frozen_20261107/config.json')
    else:parent=load_frozen_mpc()
    stats,ex,context,full=shared();inputs=read_npz(ref/'inputs/test.npz');method=job['method']
    if method in ('D1','D2'):
        ex=AblationExecution(stats,read_npz(ref/'support.npz'),8 if method=='D1' else 2,'complete' if method=='D2' else 'supported')
        planner=AblationCEM(full,ex,128)
    elif method in ('C0','S8'):planner=StabilityCEM(full,ex,8 if method=='S8' else 0,parent)
    else:planner=None
    policy=DecisionPolicy(method,job['seed'],full,ex,context) if planner is None else None
    model=GRUFeedback() if job['layer']=='B' else RidgeDynamics.load(ref/f"evaluation_models/{job['model']}.npz")
    noise=None
    if job['layer']=='C':
        saved=read_npz(root/f"experiment_runs/heldout_final_20261109/residuals/{job['model']}.npz")
        np.testing.assert_array_equal(saved['start_indices'],inputs['indices']);noise=saved['residual'][:,job['replicate'],:a.steps];model=ResidualFeedback(model,noise)
    learned=method in ('bc','ridge_td3bc');env=RidgePolicyEnv(model,ex,context if learned else None,horizon=a.steps)
    state,_=env.reset(options={'inputs':inputs});buf={}
    source_paths=[ref/'stats.json',ref/'support.npz',ref/'inputs/test.npz',ref/'evaluation_models/full.npz']
    source_paths.append(root/'experiment_runs/numeric_baselines_20261104/models/gru/seed_23/twin.pt' if job['layer']=='B' else ref/f"evaluation_models/{job['model']}.npz")
    if learned:
        from mswi_experiments.ridge_policy_evaluation import actor_path
        source_paths += [root/'experiment_runs/ridge_policy_pipeline_20261107/policy_context.npz',actor_path(method,job['seed'])]
    if noise is not None:source_paths.append(root/f"experiment_runs/heldout_final_20261109/residuals/{job['model']}.npz")
    if method in ('C0','S8'):source_paths.append(root/'experiment_protocols/mpc_C_frozen_20261107/config.json')
    source_hashes={str(p.relative_to(root)):sha(p) for p in source_paths}
    portable_code={p.name:sha(p) for p in (ROOT/'reproduction').glob('*.py')}
    for step in range(a.steps):
        donors=env.last_donors.copy() if learned else None
        request,diag=policy.decide(env,state,step) if planner is None else planner.plan(env.u,env.z,env.current,env.times,env.indices,step)
        state,_,done,cut,info=env.step_request(request)
        if done.any() or cut.all()!=(step==a.steps-1):raise AssertionError('Termination contract')
        if donors is not None:info['visual_donor']=donors
        info.update(diag)
        if noise is not None:info['injected_residual']=noise[:,step]
        for k,v in info.items():buf.setdefault(k,[]).append(v)
    arrays={k:np.stack(v,axis=1) for k,v in buf.items()}
    arrays.update(indices=inputs['indices'],time_ns=inputs['time_ns'],initial_u=inputs['u_hist'][:,-1],initial_z_current=inputs['z_current'])
    for k,v in arrays.items():
        if np.issubdtype(v.dtype,np.number) and not np.isfinite(v).all():raise FloatingPointError(k)
    errors=None
    if a.compare:
        rec=read(ROOT/'experiment_runs/heldout_final_20261109/ACCEPTED.json')[str(a.job)]
        original=load_npz(ROOT/'experiment_runs/heldout_final_20261109'/rec['selected_path'])
        # Only step-indexed fields are truncated; initial_u and current observations are unchanged.
        reference={k:(v[:,:a.steps] if k not in ('indices','time_ns','initial_u','initial_z_current') and v.ndim>=2 else v) for k,v in original.items()}
        errors=compare_arrays(arrays,reference)
    np.savez_compressed(out/'trajectory.npz',**arrays)
    hashes={k:hashlib.sha256(np.ascontiguousarray(v).tobytes()).hexdigest() for k,v in arrays.items()}
    write(out/'result.json',{'status':'passed','job':job,'steps':a.steps,'starts':256,'seconds':time.monotonic()-begin,
        'archive_comparison':a.compare,'maximum_absolute_errors':errors,'array_hashes':hashes,
        'trajectory_sha256':sha(out/'trajectory.npz'),'input_hashes':source_hashes,'portable_code':portable_code,'model_source':'refitted' if a.workspace else 'frozen',
        'scientific_code':{f.name:sha(f) for f in (root/'mswi_experiments').glob('*.py')}})
    print('Completed job',a.job,job['layer'],job['model'],method,round(time.monotonic()-begin,2),'s',flush=True)


def main():
    p=argparse.ArgumentParser();p.add_argument('task');p.add_argument('--output',type=Path);p.add_argument('--data',type=Path)
    p.add_argument('--workspace',type=Path);p.add_argument('--seeds',default='11,23,37,53,71');p.add_argument('--job',type=int)
    p.add_argument('--steps',type=int);p.add_argument('--extract-images',action='store_true');p.add_argument('--compare',action='store_true')
    p.add_argument('--evaluation',type=Path);p.add_argument('--statistics',type=Path);a=p.parse_args()
    if a.workspace and a.task in ('case','train-policies'):
        if not (a.workspace/'DERIVED_WORKSPACE.json').exists():raise ValueError('Run fit-ridge first')
        sys.path.insert(0,str(a.workspace.resolve()))
    import torch
    from threadpoolctl import threadpool_limits
    threads=4 if a.task=='train-policies' else 2 if a.task=='train-forecasts' else 1
    torch.set_num_threads(threads);torch.set_num_interop_threads(1)
    actions={'prepare':prepare,'fit-ridge':fit_ridge,'train-forecasts':forecasts,'train-policies':policies,'case':case}
    if a.task not in actions:
        from .results import statistics,earlier,figures
        actions.update(statistics=statistics,**{'audit-earlier':earlier,'figures':figures})
    with threadpool_limits(threads):actions[a.task](a)
if __name__=='__main__':main()
