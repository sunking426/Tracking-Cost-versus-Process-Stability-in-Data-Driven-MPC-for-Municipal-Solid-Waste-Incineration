"""Reconstruct published metrics and figures from saved experiment outputs."""
from pathlib import Path
import csv,importlib,json,os,shutil,subprocess,sys
from .files import read,sha,write
ROOT=Path(__file__).resolve().parents[1]

def compare_csv(actual,expected):
    import numpy as np
    def rows(p):
        with p.open(newline='') as f:return list(csv.DictReader(f))
    left,right=rows(actual),rows(expected)
    if len(left)!=len(right):raise AssertionError('CSV row count changed: '+actual.name)
    maximum=0.
    for a,b in zip(left,right):
        if a.keys()!=b.keys():raise AssertionError('CSV schema changed: '+actual.name)
        for k,v in a.items():
            try:x,y=float(v),float(b[k])
            except (ValueError,TypeError):
                if v!=b[k]:raise AssertionError('CSV identity differs: '+actual.name+'/'+k)
            else:
                np.testing.assert_allclose(x,y,atol=1e-10,rtol=0,err_msg=actual.name+'/'+k);maximum=max(maximum,abs(x-y))
    return {'file':actual.name,'rows':len(left),'maximum_absolute_error':maximum}

def collect_new(report,protocol,path):
    import numpy as np
    from .worker import load_npz
    inputs=load_npz(ROOT/'experiment_runs/ridge_control_probe_20261106/inputs/test.npz')
    samples={};curves={};audits=[];bindings={}
    for job in protocol['jobs']:
        d=path/f"job{job['id']:03d}/repeat0";status=read(d/'result.json')
        if status['status']!='passed' or status['steps']!=job['horizon']:raise ValueError('All native-horizon jobs are required for statistics')
        if status['trajectory_sha256']!=sha(d/'trajectory.npz'):raise ValueError('Changed evaluation trajectory')
        a=load_npz(d/'trajectory.npz');bindings[str(d/'trajectory.npz')]=sha(d/'trajectory.npz')
        for h in ((10,50) if job['horizon']==50 else (10,)):
            v,detail=report.metric_values(a,inputs,h);b=report.behavior(a,h)
            request=np.any(a['requested_action'][:,:h]!=0,axis=2)
            incomplete=request&~a['proposal_full_execution'][:,:h]
            unsupported=request&~a['proposal_supported'][:,:h]
            rejected=unsupported&a['proposal_full_execution'][:,:h]
            if job['method']=='D2':rejected=np.zeros_like(request)
            key=(job['layer'],job['model'],job['method'],h)
            samples.setdefault(key,[]).append(np.column_stack((v,b,incomplete.sum(1),rejected.sum(1),unsupported.sum(1))))
            curves.setdefault(key,[]).append(a['u_path'][:,:h,[0,3]]-a['initial_u'][:,None,[0,3]])
            audits.append(dict(job=job['id'],layer=job['layer'],model=job['model'],method=job['method'],seed=job['seed'],replicate=job['replicate'],horizon=h,**detail))
    data={k:np.mean(v,axis=0) for k,v in samples.items()};curves={k:np.mean(v,axis=0) for k,v in curves.items()}
    for layer,mid,method,h in list(data):
        if mid==report.MODELS[0]:
            keys=[(layer,m,method,h) for m in report.MODELS]
            data[layer,'four_model_mean',method,h]=np.mean([data[k] for k in keys],axis=0)
            curves[layer,'four_model_mean',method,h]=np.mean([curves[k] for k in keys],axis=0)
    return data,curves,audits,bindings

def statistics(a):
    from .worker import output_dir
    archived=ROOT/'experiment_runs/heldout_final_20261109';sys.path.insert(0,str(archived));report=importlib.import_module('report')
    protocol=report.verify_seal();out=output_dir(a.output)
    if a.evaluation:data,curves,audits,bindings=collect_new(report,protocol,a.evaluation.resolve())
    else:data,curves,audits,bindings=report.collect(protocol,read(archived/'ACCEPTED.json'))
    weights=report.bootstrap(protocol['bootstrap']['seed'])
    summary,differences,ratios=report.tables(data,weights);rules,ablation,gaps=report.decisions(data,weights)
    checks=[]
    for name,rows in [('metrics',summary),('paired_differences',differences),('stability_ratios',ratios),('primary_ablation',ablation),('planning_evaluation_gap',gaps),('trajectory_metric_audit',audits)]:
        report.csv_write(out/(name+'.csv'),rows)
        if a.evaluation is None:checks.append(compare_csv(out/(name+'.csv'),archived/'report'/(name+'.csv')))
    lines=[]
    for (layer,model,method,h),v in curves.items():
        for ch,name in enumerate(('primary_air','induced_draft')):
            mean,lo,hi=report.interval(v[:,:,ch],weights)
            for step in range(h):lines.append(dict(layer=layer,model=model,method=method,horizon=h,channel=name,step=step+1,mean=float(mean[step]),ci_low=float(lo[step]),ci_high=float(hi[step])))
    report.csv_write(out/'fan_change_curves.csv',lines)
    if a.evaluation is None:checks.append(compare_csv(out/'fan_change_curves.csv',archived/'report/fan_change_curves.csv'))
    write(out/'R1_R4.json',rules);write(out/'source_bindings.json',bindings)
    write(out/'checks.json',{'status':'passed','batches':273,'bootstrap_draws':10000,'original_starts':256,
        'reference_comparison':a.evaluation is None,'CSV_checks':checks,
        'data_source':str(a.evaluation.resolve()) if a.evaluation else 'archived accepted trajectories'})
    print('Reconstructed metrics, paired intervals, ablations and action curves.',flush=True)

def earlier(a):
    from .worker import output_dir
    out=output_dir(a.output);env=os.environ.copy();env['MSWI_REPRO_OUTPUT']=str(out)
    subprocess.run([sys.executable,'-m','reproduction.earlier_arithmetic'],cwd=ROOT,env=env,check=True)

def figures(a):
    from .worker import output_dir
    out=output_dir(a.output);source=ROOT/'paper/figure_reconstruction'
    for f in source.iterdir():
        if f.is_file():shutil.copy2(f,out/f.name)
    shutil.copytree(source/'evidence',out/'evidence')
    if a.statistics:
        checks=read(a.statistics/'checks.json')
        if checks['status']!='passed':raise ValueError('Statistics must complete before plotting')
        mapping={'metrics.csv':'final_metrics.csv','paired_differences.csv':'final_contrasts.csv','stability_ratios.csv':'final_ratios.csv','primary_ablation.csv':'final_ablation.csv','fan_change_curves.csv':'final_fan_curves.csv'}
        for src,dst in mapping.items():shutil.copy2(a.statistics/src,out/'evidence'/dst)
    env=os.environ.copy();env['MPLCONFIGDIR']=str(out/'matplotlib_cache')
    subprocess.run([sys.executable,str(out/'build_extended_figures.py')],cwd=out,env=env,check=True)
    import re
    paths={p for n in ('main','supplementary') for p in re.findall(r'\\includegraphics(?:\[[^]]*\])?\{([^}]+)\}',(ROOT/'paper'/(n+'.tex')).read_text())}
    checks=[]
    for rel in sorted(paths):
        p=Path(rel).with_suffix('.png');same=sha(out/p)==sha(ROOT/'paper'/p)
        checks.append({'figure':p.stem,'PNG_equal_reference':same})
    if a.statistics is None or read(a.statistics/'checks.json')['reference_comparison']:
        if not all(c['PNG_equal_reference'] for c in checks):raise AssertionError('A reconstructed figure differs')
    write(out/'checks.json',{'status':'passed','figures':len(checks),'checks':checks})
