"""Portable arithmetic reconstruction from archived predictions; no model fitting."""
from pathlib import Path
import json,hashlib,csv
import numpy as np
from sklearn.metrics import average_precision_score
import os
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'experiment_runs'
OUT=Path(os.environ['MSWI_REPRO_OUTPUT']);OUT.mkdir(parents=True,exist_ok=True)
report={'scope':'Independent read-only arithmetic and asset audit; no fitting or new control search','checks':[],'findings':[]}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def data(p):
 with np.load(p,allow_pickle=False) as a:return {k:a[k].copy() for k in a.files}
def rows(p):return list(csv.DictReader(p.open()))
def one(rs,**kw):
 a=[r for r in rs if all(r[k]==str(v) for k,v in kw.items())];assert len(a)==1,(kw,len(a));return a[0]
def check(label,source,**details):report['checks'].append({'label':label,'source':str(source.relative_to(ROOT)),'details':details})
base=RUN/'numeric_baselines_20261104';stats=json.loads((base/'stats.json').read_text());scale=np.array(stats['delta_scale'])
with np.load(RUN/'corrected_vision/data/dataset.npz') as a:
 truth=a['z_current'];zh=a['z_hist'];uh=a['u_hist'];prev=a['z_prev'];times=a['time_ns'];test=a['test_idx']
summary=rows(base/'statistics/overall.csv');cache={}
for method,instances in [('persistence',['persistence']),('ridge',['ridge']),('gru',['gru_seed_'+str(s) for s in (11,23,37)]),('gru_residual',['gru_residual_seed_'+str(s) for s in (11,23,37)])]:
 values=[]
 for name in instances:
  p=base/'predictions'/name/'test.npz';a=data(p);np.testing.assert_array_equal(a['indices'],test);np.testing.assert_array_equal(a['y'],truth[test]);np.testing.assert_array_equal(a['time_ns'],times[test]);assert np.isfinite(a['pred']).all()
  e=a['pred']-a['y'];values.append([np.mean((e/scale)**2),np.abs(e[:,:6].mean(1)).mean(),np.abs(e[:,6]).mean(),np.abs(e[:,7]).mean(),np.abs(e[:,8]).mean()]);cache[name]=a
  check('single_step_saved_prediction',p,samples=len(test),truth_equal_prepared_dataset=True,sha256=sha(p))
 actual=np.mean(values,axis=0);row=one(summary,split='test',method=method);expected=np.array([float(row[k]) for k in ('normalized_mse','temperature_mae','pressure_mae','steam_mae','oxygen_mae')]);np.testing.assert_allclose(actual,expected,atol=1e-12,rtol=0)
 check('single_step_metrics_recomputed',base/'statistics/overall.csv',method=method,values=actual.tolist(),max_error=float(abs(actual-expected).max()))
m=data(base/'models/ridge/model.npz');x=np.concatenate([uh[test].reshape(len(test),-1),zh[test].reshape(len(test),-1)],1);pred=prev[test]+(((x-m['x_mean'])/m['x_scale'])@m['coef'].T+m['intercept'])*m['delta_scale'];error=float(abs(pred-cache['ridge']['pred']).max());assert error<1e-8
check('ridge_coefficient_reconstruction',base/'models/ridge/model.npz',max_prediction_error=error,alpha=float(m['alpha']))
for seed in (11,23,37):
 d=base/f'models/gru/seed_{seed}';hist=json.loads((d/'history.json').read_text());meta=json.loads((d/'metrics.json').read_text());assert len(hist)==meta['epochs_completed'];assert (d/'twin.pt').stat().st_size>100000
 check('gru_checkpoint_and_training_history',d/'twin.pt',seed=seed,epochs=len(hist),bytes=(d/'twin.pt').stat().st_size,sha256=sha(d/'twin.pt'))
# Saved recursive prediction endpoints, including factual truth alignment.
for name in ('ridge_logged','ridge_hold_mv','persistence'):
 p=RUN/'ridge_validation_20261104/rollouts/test'/f'{name}.npz';a=data(p);assert a['pred_cv'].shape==(9172,10,9);np.testing.assert_array_equal(a['truth_cv'],truth[a['indices']]);nmse=float(np.mean(((a['pred_cv'][:,-1]-a['truth_cv'][:,-1])/scale)**2));check('recursive_prediction_raw_endpoint',p,ten_step_nmse=nmse,truth_equal_prepared_dataset=True)
# All plotted scan trajectories, independently recompute the displayed endpoints.
models=('early','middle','late','pooled_matched');ts=RUN/'mpc_temperature_20261107';ss=RUN/'mpc_stability_v2_20261108';tr=rows(ts/'report/endpoint_means.csv');sr=rows(ss/'report/endpoint_means.csv');low=rows(RUN/'factory_feedback_reassessment_v2_20261108/report/metric_means.csv')
scan_errors=[]
for variant in ('A','B','C','D'):
 for model in models:
  p=ts/f'trajectories/{variant}/{model}.npz';a=data(p);meta=json.loads(p.with_suffix('.json').read_text());assert sha(p)==meta['sha256'];assert a['pred_cv'].shape==(256,50,9);assert meta['split']=='val';assert np.isfinite(a['pred_cv']).all()
  ret=a['reward'][:,:10].astype(float).sum(1).mean();temp=np.abs(a['pred_cv'][:,:10,:6].mean(2)-1000).mean();o=a['pred_cv'][:,:,8];dist=(np.maximum(3.5-o,0)+np.maximum(o-4,0)).mean()
  vals=[ret,temp,dist];exp=[float(one(tr,model=model,variant=variant,horizon=h)[k]) for h,k in [(10,'return'),(10,'temperature_tracking_mae'),(50,'oxygen_band_distance')]];err=float(np.max(np.abs(np.array(vals)-exp)));assert err<1e-5;scan_errors.append(err)
check('temperature_scan_all_16_plotted_runs',ts/'trajectories',count=16,max_display_endpoint_error=max(scan_errors),weights=[1,2,4,8],validation_only=True)
se=[]
for method in ('C0','S1','S2','S4','S8'):
 for model in models:
  p=ts/f'trajectories/C/{model}.npz' if method=='C0' else ss/f'trajectories/{method}/{model}.npz';a=data(p);meta=json.loads(p.with_suffix('.json').read_text());assert sha(p)==meta['sha256'];assert meta['split']=='val';ret=a['reward'][:,:10].astype(float).sum(1).mean();expected=float(one(sr,model=model,method=method,horizon=10)['return']);err=abs(ret-expected);assert err<1e-10
  fraction=(a['pred_cv'][:,:,8]<3.5).mean();ex=float(one(low,model=model,method=method,horizon=50)['oxygen_low3p5_fraction']);assert abs(fraction-ex)<1e-12;se.append(err)
check('lambda_scan_all_20_plotted_runs',ss/'trajectories',count=20,max_return_error=max(se),low_oxygen_fraction_recomputed=True,validation_only=True)
# Response arrays -> physical normalized table -> all 32 gate cells, without helper imports.
r=RUN/'ridge_response_20261106';a=data(r/'responses.npz');cfg=json.loads((r/'config.json').read_text());stats2=json.loads((r/'stats.json').read_text());raw=a['step'];physical=np.concatenate([raw[:,:,:6,:].mean(2,keepdims=True),raw[:,:,6:,:]],2)*a['amp'][None,None,None,:];norm=physical/a['phys_scale'][None,None,:,None];block=norm[1:];dead=cfg['response_deadband_sigma'];last=block[:,9];sign=(last>dead).all(0)|(last < -dead).all(0);ratio=np.max(abs(last),0)/np.min(abs(last),0);ref=norm[0,9];opp=((last>dead).all(0)&(ref < -dead))|((last < -dead).all(0)&(ref>dead));stable=sign&(ratio<=cfg['max_response_amplitude_ratio'])&~opp
pairs=rows(r/'statistics/stability_pairs.csv');response=rows(r/'statistics/responses.csv');maxe=0
for q,quantity in enumerate(('temperature','pressure','steam','oxygen')):
 for j,mv in enumerate(stats2['mv_names']):
  assert bool(stable[q,j])==(one(pairs,quantity=quantity,mv=mv)['stable_h10_pair']=='True')
  for mi,model in enumerate(a['model_ids']):maxe=max(maxe,abs(norm[mi,9,q,j]-float(one(response,pattern='step',model=model,horizon=10,quantity=quantity,mv=mv)['response_sigma'])))
assert maxe<1e-12
v=data(r/'inputs/val.npz');cov=(v['full_request_executed']&v['supported']).mean(0).reshape(8,2);summary2=json.loads((r/'statistics/summary.json').read_text());np.testing.assert_array_equal(cov,np.array(summary2['coverage']['val']['joint_fraction']));check('response_gate_all_32_cells',r/'responses.npz',stable_pairs=int(stable.sum()),max_normalized_response_error=maxe,secondary_direction_coverage=cov[2].tolist(),validation_masks_recomputed=True)
# Five seeds of each learned policy: actual checkpoint hashes, training curves and generated data.
for group in ('bc_full','ridge_td3bc'):
 for seed in (11,23,37,53,71):
  d=RUN/f'ridge_policy_pipeline_20261107/models/{group}/seed{seed}';meta=json.loads((d/'complete.json').read_text());history=json.loads((d/'history.json').read_text());assert sha(d/'actor.pt')==meta['checkpoint_sha256'];assert history
  detail=dict(group=group,seed=seed,history_entries=len(history),sha256=sha(d/'actor.pt'))
  if group=='ridge_td3bc':
   a=data(d/'generated_replay.npz');detail['generated_fields']={k:list(v.shape) for k,v in a.items()};assert meta['critic_updates']==1500 and meta['actor_updates']==750
  check('policy_fitted_checkpoint_and_training_evidence',d/'actor.pt',**detail)
# Representative raw predictions for visual comparisons (all three seeds where means are quoted).
for variant in ('sensor','original52'):
 vals=[]
 for seed in (11,23,37):
  p=RUN/f'visual_information_20261104/models/{variant}/seed_{seed}/test_predictions.npz';a=data(p);vals.append(float(np.abs(a['pred'][:,:6].mean(1)-a['y'][:,:6].mean(1)).mean()));assert (p.parent/'twin.pt').exists()
 check('causal52_temperature_mae_recomputed',RUN/f'visual_information_20261104/models/{variant}',three_seed_mean=float(np.mean(vals)))
for variant in ('numeric','rgb'):
 vals=[]
 for seed in (11,23,37):
  p=RUN/f'ridge_rgb_residual_20261105/predictions/{variant}/seed_{seed}/test.npz';a=data(p);vals.append(float(np.mean(((a['prediction']-a['truth'])/a['delta_scale'])**2)))
 check('rgb_residual_nmse_recomputed',p.parent.parent,three_seed_mean=float(np.mean(vals)))
for variant in ('ridge','retrieved52','retrieved_rgb32'):
 p=RUN/f'ridge_visual_retrieval_20261105/rollouts/test/logged/{variant}.npz';a=data(p);val=float(np.mean(((a['pred_cv'][:,-1]-a['truth_cv'][:,-1])/scale)**2));check('visual_retrieval_nmse_recomputed',p,ten_step_nmse=val)
for variant in ('quality','rgb'):
 p=RUN/f'rgb_control_diagnostic_20261106/predictions/test/thermal_change_{variant}.npz';a=data(p);ap=float(average_precision_score(a['y'],a['probability']));check('visual_event_ap_recomputed',p,average_precision=ap,samples=len(a['y']))
for variant in ('quality','A'):
 p=RUN/f'rgb_geometry_20261106/regression/test/{variant}.npz';a=data(p);nmse=float(np.mean(((a['pred_cv']-a['truth_cv'])/scale)**2));check('visual_geometry_nmse_recomputed',p,nmse=nmse,samples=len(a['pred_cv']))
rep=RUN/'visual_representation_20261104';emb=data(rep/'embeddings.npz');check('rgb_encoder_asset',rep/'embeddings.npz',fields={k:list(v.shape) for k,v in emb.items()},encoder_log_exists=(rep/'encoder.log').exists(),checkpoint_count=len(list((rep/'pretrained').glob('*'))),note='Asset and protocol inspection only; full encoding and all PCA/regularization fits not rerun.')
report['limitations']=['Local numerical outputs and source alignment establish archived computational evidence, not third-party certification of plant sensor authenticity.','No models were retrained and no new CEM control runs were started.','The complete upstream raw DCS-to-window ETL was not reconstructed in this bounded subreview.','Full RGB image encoding, all PCA/regularization candidates and every visual confidence interval were not rerun.']
(OUT/'earlier_evidence_checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('PASS',len(report['checks']),'evidence checks')
