"""Checksummed release-asset import and read-only archive verification."""
from pathlib import Path
import hashlib,json,tarfile

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(2**20),b''):h.update(b)
    return h.hexdigest()

def read(path):return json.loads(Path(path).read_text())
def write(path,obj):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

def safe_members(archive,root):
    root=Path(root).resolve()
    for member in archive.getmembers():
        destination=(root/member.name).resolve()
        if destination==root or root not in destination.parents or not member.isfile():
            raise ValueError('Invalid release member: '+member.name)
        yield member

def import_assets(root,source):
    root=Path(root).resolve();manifest=read(root/'data/assets.json');source=Path(source)
    for asset in manifest['assets']:
        p=source/asset['name']
        if sha(p)!=asset['sha256']:raise ValueError('Asset checksum mismatch: '+p.name)
        print('Importing',p.name,flush=True)
        with tarfile.open(p,'r:gz') as t:
            for member in safe_members(t,root):
                target=root/member.name;expected=manifest['files'][member.name]
                if target.exists():
                    if sha(target)!=expected['sha256']:raise FileExistsError('Existing file differs: '+member.name)
                    continue
                target.parent.mkdir(parents=True,exist_ok=True)
                with t.extractfile(member) as src,target.open('xb') as dst:
                    import shutil
                    shutil.copyfileobj(src,dst)
                if sha(target)!=expected['sha256']:
                    target.unlink();raise ValueError('Extracted checksum mismatch: '+member.name)
    return {'status':'passed','assets':len(manifest['assets']),'files':len(manifest['files'])}

def verify(root,full=False):
    root=Path(root);manifest=read(root/'data/assets.json');bad=[]
    for name,row in manifest['files'].items():
        p=root/name
        if not p.is_file() or p.stat().st_size!=row['bytes'] or (full and sha(p)!=row['sha256']):bad.append(name)
    if bad:raise ValueError('Missing or changed data files: '+', '.join(bad[:12]))
    # These hashes include both the original numerical implementation and frozen assets.
    seal=read(root/'experiment_runs/heldout_final_20261109/seal.json')
    for name,h in seal['hashes'].items():
        if sha(root/name)!=h:raise ValueError('Frozen evaluation source changed: '+name)
    parent=read(root/'experiment_protocols/mpc_C_frozen_20261107/config.json')
    for name,h in parent['dependencies'].items():
        if sha(root/name)!=h:raise ValueError('Frozen controller source changed: '+name)
    return {'status':'passed','files':len(manifest['files']),'full_hash_check':full,
            'frozen_evaluation_dependencies':len(seal['hashes'])}

def validate_resume(record,root,code_root):
    """A completed trajectory may be reused only with unchanged inputs and code."""
    root=Path(root);code_root=Path(code_root)
    for key,base in (('scientific_code',root/'mswi_experiments'),('portable_code',code_root/'reproduction')):
        expected=record.get(key)
        actual={p.name:sha(p) for p in base.glob('*.py')}
        if expected!=actual:raise ValueError('Resume source changed: '+key)
    expected=record.get('input_hashes')
    if not expected:raise ValueError('Resume record has no input bindings')
    for name,digest in expected.items():
        if sha(root/name)!=digest:raise ValueError('Resume input changed: '+name)
