# Reproduction notes

## Three operations

1. **Reconstruction:** raw records/images to descriptors, data windows, Ridge
   coefficients, support bank, initial histories and residual draws.
2. **Frozen-model execution:** saved models and the original candidate streams
   to newly computed control trajectories.
3. **Result reconstruction:** accepted trajectories/predictions to the published
   means, paired intervals, tables and figures.

`train-forecasts` and `train-policies` additionally refit the GRU and policy
models. They use the original training routines in an independent workspace.
The auxiliary visual-study source and assets are included; only their saved
prediction endpoints are covered by the portable arithmetic audit.

## Original implementation and portable entry points

`mswi_experiments/` is copied without numerical changes. Frozen controller and
final-evaluation hash checks continue to use the original code and assets.
The `reproduction/` package owns path resolution, fresh subprocesses, new output
directories and comparison reports. It calls the existing predictor,
admission, CEM, policy, reward and statistical functions.

Archived research drivers retain their original output paths and provenance
checks. Use `reproduce.py` for portable runs. Do not run an archived driver in
place if its output directory already contains the saved experiment.

## Numeric comparisons

Raw data windows and split indices are checked exactly. Ridge coefficients,
support values, reset histories and residuals are compared field by field with
their archived counterparts. Control comparison uses the archived batch of
256 starts; it does not substitute a smaller batch. Fixed absolute tolerances
are `1e-10` for action fields, `1e-8` for state/planner arrays and `1e-5` for the
float32 reward/cost fields. Integer and Boolean arrays are checked exactly.
Every maximum difference is saved in the case report.

With `--repeats 2`, each case uses two fresh interpreters, and all output-array
hashes must match. A mismatch stops the command. The interface does not select a
run according to its performance. Each repetition has its own output directory.

The original experiment's full instrumented audit is retained in the data
assets. The portable runner does not claim to replace that audit merely by
passing an output comparison.

## Statistics

Trajectory metrics are computed first. Seeds and residual draws are averaged
within each original start; the four Ridge evaluators then receive equal weight.
Intervals use 10,000 paired-start bootstrap resamples, seed 20261109. Ratios are
ratios of mean SDs, recomputed inside each resample. Detrending removes a fitted
intercept and linear slope from each trajectory before calculating SD.

The original evaluation reward is unchanged. Additional temperature emphasis
and steam/oxygen variation terms are used in planning only. Reported cost gains
refer to the original reward. Ten minutes is the primary feedback endpoint;
fifty minutes is the extended feedback test.

## Validation performed during packaging

`verification/PACKAGE_CHECKS.json` records the checks actually run on this
package. It distinguishes newly executed cases from the included archival
executions. Full source/data hashes, data reconstruction, model comparisons,
representative control cases, statistical reconstruction, figure checks and
archive-import checks are recorded separately. Consult that file for the exact
coverage; the presence of an archived experiment is not a claim that it was
rerun while building this release.
