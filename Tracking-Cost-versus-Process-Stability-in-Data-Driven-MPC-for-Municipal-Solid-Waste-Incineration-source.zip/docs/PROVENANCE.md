# Archive provenance

The final evaluation is the frozen post-development test completed on
2026-11-09. Its 273 accepted batches, 546 original executions, integrity records,
source bindings and 9,935-file final manifest are included without alteration.
The controller configuration was frozen on 2026-11-07. The manuscript snapshot
is the 20-page version dated 2026-11-10, with its 13-page supplement.

Earlier studies are included where they provide inputs, comparison results,
validation scans, channel diagnostics or cited numerical evidence. For the older
validation ablation study, the released subset contains its reported trajectories,
reports and audit notes. Separate debugging/quarantine copies are not distributed.
Some historical manifests enumerate those additional copies. `data/assets.json`
is the file inventory for this release. No final-test trajectory is omitted by
this earlier-study selection.

Model/code hashes bind the original assets. The new portable entry points
resolve the package root and keep newly generated results in separate output
directories. The five refitted Ridge models, support reference and residual draws
are checked against the original assets; fresh neural-model fits are recorded
separately from control replay with frozen checkpoints.
