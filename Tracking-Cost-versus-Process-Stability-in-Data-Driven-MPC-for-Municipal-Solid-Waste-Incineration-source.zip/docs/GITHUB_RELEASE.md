# Preparing a GitHub release

The source archive contains the files intended for the Git repository. The data
archives belong in the release assets. `data/assets.json` is tracked with the
source; it records the names, sizes and checksums of every release asset.

1. Create a repository and add the contents of the source archive.
2. Set the repository's `origin` to its GitHub URL and push the source.
3. Create release `v1.0.0` and attach all `mswi-data-*.tar.gz` files and their
   `SHA256SUMS.txt` from `release-assets/`.
4. Retain the source and all data assets under the same release tag.

The package is divided so that each data asset is below 2 GiB. Generated data,
model archives and reproduction outputs are excluded by `.gitignore`.
The local combined delivery ZIP is for transfer; upload its source/data parts,
not the combined ZIP, as the GitHub release.

A public distribution license has not been assigned. The local package does not
create a GitHub repository, push files or publish a release.

GitHub documentation:
- <https://docs.github.com/en/repositories/releasing-projects-on-github/about-releases>
- <https://docs.github.com/en/repositories/working-with-files/managing-large-files/about-large-files-on-github>
