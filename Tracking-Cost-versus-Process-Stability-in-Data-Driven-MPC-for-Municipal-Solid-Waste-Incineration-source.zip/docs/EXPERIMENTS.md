# Experiment index

The main paper contains nine figures, six tables and one algorithm. The
supplement contains seven figures, ten tables and two algorithms. Figure/table
numbers below refer to the 20-page manuscript distributed with this package.

## Main paper

| Item | Content | Experiment or source |
|---|---|---|
| Figure 1 | Plant process and MV/CV locations | `paper/figure_reconstruction/draw_diagrams.py` |
| Figure 2 | Controller and evaluation workflow | `paper/figure_reconstruction/draw_diagrams.py` |
| Figure 3 | Recursive prediction | `ridge_validation_20261104/rollouts/test/` |
| Figure 4 | Channel responses and coverage | `ridge_response_20261106/statistics/` |
| Figure 5 | Validation weight scans | `mpc_temperature_20261107/`, `mpc_stability_v2_20261108/` |
| Figure 6 | Cost–fluctuation mismatch | Final evaluation report and accepted trajectories |
| Figure 7 | Per-model SD ratios | Final evaluation `report/stability_ratios.csv` |
| Figure 8 | Shared-reset ten-minute trajectories | Final jobs 046, 051 and 052; display uses BC seed 11 |
| Figure 9 | Action/support ablations | Final evaluation `report/primary_ablation.csv` |
| Table 1 | Related work | `paper/references.bib` |
| Table 2 | Operating references | `data/raw/MV_CV.xlsx` |
| Table 3 | Forecasting error | `numeric_baselines_20261104/predictions/` |
| Tables 4–6 | Return, SD and operating fractions | Final evaluation report and accepted trajectories |
| Algorithm 1 | CEM-MPC | `ridge_policy_planning.py`, `mpc_temperature.py`, `mpc_stability.py` |

Experiment paths in this document are relative to `experiment_runs/` unless
stated otherwise. Module paths are relative to `mswi_experiments/`.

## Supplementary information

| Item | Content | Experiment or source |
|---|---|---|
| Figure S1 | Fan accumulation | Final evaluation `report/fan_change_curves.csv` |
| Figure S2 | Observed temperature context | `corrected_vision/data/dataset.npz` |
| Figure S3 | One-step prediction | `numeric_baselines_20261104/predictions/` |
| Figures S4–S5 | Complete validation scans | Temperature/stability study trajectories |
| Figure S6 | Fifty-minute continuation | Same pooled reset as main Figure 8 |
| Figure S7 | Operating-level tradeoff | Final evaluation metrics |
| Table S1 | Action bounds | `ridge_control_probe_20261106/stats.json` |
| Table S2 | Recorded decision latency | `ridge_policy_pipeline_20261107/latency/` |
| Tables S3–S6 | Detailed SDs, costs and action totals | Final evaluation metrics and paired differences |
| Table S7 | Abbreviations | Manuscript definitions |
| Table S8 | Visual/policy comparisons | Auxiliary studies listed below |
| Table S9 | GRU feedback | Final layer B |
| Table S10 | Channel/support ablations | Final layers D/C/P |
| Algorithm S1 | Predictor/support preparation | `numeric_baselines.py`, `ridge_response_study.py` |
| Algorithm S2 | Paired evaluation | Final `study.py`, `report.py`; portable entry points in `reproduction/` |

The latency result is the archived same-budget CEM baseline measurement; this
package does not relabel it as a new MPC8 timing experiment.

## Auxiliary visual studies

| Study | Implementation | Stored input and result directory |
|---|---|---|
| Causal 52-feature GRU | `visual_diagnostics*.py`, `training.py` | `visual_information_20261104/` |
| Frozen RGB encoding/PCA | `visual_image_*.py`, `visual_representation_*.py` | `visual_representation_20261104/` |
| Visual utilization | `visual_utilization_*.py` | `visual_utilization_20261104/` |
| RGB residual correction | `ridge_rgb_residual*.py` | `ridge_rgb_residual_20261105/` |
| Historical visual retrieval | `ridge_visual_retrieval*.py` | `ridge_visual_retrieval_20261105/` |
| Event diagnostics | `rgb_control_diagnostic*.py` | `rgb_control_diagnostic_20261106/` |
| Geometry/spatial pooling | `rgb_geometry*.py` | `rgb_geometry_20261106/` |

Each study includes its configuration, fitted assets, saved predictions and
report. Original drivers are retained with the research implementation;
`audit-earlier` reconstructs the manuscript endpoints from these saved arrays.
The RGB encoder weights are included under the visual representation study.
A complete fresh refit of all auxiliary visual variants is not part of the
portable numerical `train-forecasts`/`train-policies` commands.

## Final evaluation layers

- D: deterministic feedback from four Ridge evaluators.
- C: the same Ridge evaluators with five shared residual sequences per start.
- B: numerical-only GRU feedback, seed 23.
- P: full-training planning-model checks.

`protocol.json` contains 273 jobs. `ACCEPTED.json` records the selected identical
execution pair for each job. Both original executions are included, with their
logs, integrity checks and source bindings. The final archive contains 546
computational executions. The bootstrap sample size remains 256 original starts.
