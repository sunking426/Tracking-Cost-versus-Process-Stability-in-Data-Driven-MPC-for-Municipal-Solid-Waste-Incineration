# Data description

## Raw files

`data/raw/process/` contains the three original DCS exports. They cover
2025-04-01 00:00 to 2025-06-04 23:59 at one-minute intervals. The files retain
the vendor tag names and quality tokens. `data/raw/images/` contains the 8,070
JPGs selected by the original feature manifest. Image bytes and filenames are
unchanged. `data/raw/MV_CV.xlsx` contains the plant variable/reference table.

## Variables

| Index | Manipulated variable |
|---|---|
| 1 | Primary-air fan setting |
| 2 | Primary-air temperature-valve opening |
| 3 | Secondary-air fan setting |
| 4 | Induced-draft fan setting |
| 5 | Feeder stopping time |
| 6 | Drying-grate stopping time |
| 7 | Combustion-grate stopping time |
| 8 | Burnout-grate stopping time |

The nine CV channels are six furnace temperatures (°C), furnace pressure (Pa),
main steam flow (t/h) and oxygen concentration (percent). Temperature tracking
uses the six-sensor mean; high-temperature time checks all sensors. Fan settings
retain the DCS scale because the source metadata do not establish Hz or percent.
The main controller changes channels 1 and 4. The eight-channel variant is a
separate ablation.

## Prepared arrays

The common source dataset is
`experiment_runs/corrected_vision/data/dataset.npz`. The portable preparation
command writes a reconstructed copy to `outputs/prepared/data/`.

| Field | Meaning |
|---|---|
| `u_hist` | Eleven consecutive MV vectors, shape `(N, 11, 8)` |
| `z_hist` | Ten past CV vectors, shape `(N, 10, 9)` |
| `z_prev`, `z_target`, `z_current` | Previous, target/current CV vectors |
| `u_current` | Current MV vector |
| `action` | Next logged MV minus current MV |
| `visual` | 52 causal flame descriptors |
| `time_ns` | Process minute in nanoseconds |
| `source_start_ns`, `source_end_ns` | Information-source interval |
| `train_idx`, `val_idx`, `test_idx` | Chronological partition indices |
| `next_idx` | Consecutive within-partition transition link |

The retained sample set has 62,011 windows before boundary exclusions. The final
partition counts are 43,406 / 9,228 / 9,226. Only past observations are used for
filling. Training samples determine normalizers, increment scales and empirical
bounds. Numerical models retain the common image-available sample mask but do
not consume image features.

The predictor has 178 numerical inputs. Learned policy comparisons use 178
numerical entries plus 52 retrieved historical descriptors. The support filter
uses the joint vector of eight MV levels, nine CV levels and eight proposed
increments. These are separate interfaces.

## Trajectories

Final trajectory files are stored below
`experiment_runs/heldout_final_20261109/runs/jobNNN/attemptN/`.
Each file contains 256 starts. Time-indexed arrays include `pred_cv`, `u_path`,
`requested_action`, `executed_action`, `reward`, admission masks and planner
diagnostics. Initial indices, timestamps and observed states are also retained.
Layer C includes the injected residuals. See the job protocol for the evaluator,
method, policy seed, residual replicate and feedback horizon.

Finite negative-oxygen predictions are retained. The archive records 132 such
values among 2,664,960 predicted steps. No clipping or outcome-based resampling
is introduced by the portable entry points.
