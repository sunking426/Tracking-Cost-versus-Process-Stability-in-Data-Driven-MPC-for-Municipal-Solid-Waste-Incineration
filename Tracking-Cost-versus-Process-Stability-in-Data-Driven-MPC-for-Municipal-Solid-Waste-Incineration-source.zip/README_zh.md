# 垃圾焚烧稳定性MPC实验

本仓库对应论文《Tracking Cost versus Process Stability in Data-Driven MPC
for Municipal Solid Waste Incineration》。作者：Yang Wang、Enhong Chen。
主方法由Ridge增量预测、CEM滚动规划和历史状态—动作支持过滤组成。

## 环境

原实验使用Python 3.10.8、macOS ARM64和CPU。依赖版本见`requirements.txt`，
完整环境记录见`requirements-lock.txt`。Linux可按相同步骤安装；Windows请使用WSL。

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

## 当前提供范围

本仓库目前只提供源码、配置和项目说明。原始数据、图像、模型权重、归档轨迹、论文及补充材料均暂未上传。下列复现命令需要配套本地数据；当前仓库没有可下载的数据Release。绘图命令还需要未上传的论文图表输入。

## 数据导入

将同一版本的全部`mswi-data-*.tar.gz`放在一个目录中。在仓库根目录运行：

```bash
python reproduce.py import-data --assets ../release-assets
python reproduce.py verify --full
```

附件包括三份完整DCS记录、8070张源图像、处理后的样本、模型、验证实验、最终评价轨迹及校验记录。
文件清单和SHA256见`data/assets.json`。历史清单中的原机器路径作为来源记录保留，
新的复现入口按仓库相对位置读取数据。

## 运行步骤

重建数据并重新拟合Ridge模型：

```bash
python reproduce.py prepare --extract-images
python reproduce.py fit-ridge
```

检查九种代表性控制条件，包括BC、TD3+BC、MPC、消融、扰动和GRU反馈：

```bash
python reproduce.py evaluate --jobs smoke --steps 10 --compare
```

重新计算完整最终统计和较早实验的图表数据，；绘图命令需另备论文图表输入：

```bash
python reproduce.py statistics
python reproduce.py audit-earlier
python reproduce.py figures --statistics outputs/statistics
```

重新执行全部273个批次，每个批次在新进程中计算两次：

```bash
python reproduce.py evaluate --jobs all --repeats 2 --compare --output outputs/full_evaluation
```

完整控制评价耗时较长。原环境中，256个起点、50分钟的一个pooled MPC批次约耗时138秒。
已完成部分可加`--resume`继续；不同或不完整的结果不会直接跳过。

如需重新训练GRU、BC和TD3+BC，在重建数据及Ridge模型后运行：

```bash
python reproduce.py train-forecasts
python reproduce.py train-policies
python reproduce.py evaluate --workspace outputs/retrained --jobs all --repeats 2 --output outputs/refitted_evaluation
python reproduce.py statistics --evaluation outputs/refitted_evaluation --output outputs/refitted_statistics
```

所有新结果写入`outputs/`，不覆盖原始归档。输出目录须为新目录。
重新训练的结果与冻结模型的轨迹重放分开记录。

## 文件说明

- `mswi_experiments/`：原实验实现。
- `reproduction/`：可迁移的复现入口。
- `experiment_protocols/`：冻结配置。
- `experiment_runs/`：归档输入、模型、轨迹和统计。
- `docs/EXPERIMENTS.md`：论文图表与实验来源的对应关系。
- `docs/DATA.md`：数据和变量定义。
- `docs/REPRODUCTION.md`：校验方法及数值口径。
- `verification/`：本次打包后的运行检查记录。

公开发行许可尚未指定，见`LICENSE`。本地实验包不代表已在GitHub公开发布。
